# LAV-T03 · Volltext · Teil 1 von 8 (PDF-Seiten 1–19 von 102)

Studie: Helsana-Report: Arzneimittel – Medikamente erstmals grösster Kostenblock der Grundversicherung · Quelldatei: arzneimittelreport-2024-31e5177c.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 8 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T03, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 1/102 · Umschlag]]

## Helsana-Report: Arzneimittel

Medikamente erstmals grösster Kostenblock der Grundversicherung

helsana.ch/arzneimittelreport2024

[Bild: Logo Helsana. Text: «Helsana»; «Engagiert für das Leben.»]

[[Seite 2/102]]

## Helsana-Arzneimittelreport 2024

Auswertungsergebnisse der Helsana Arzneimitteldaten aus den Jahren 2020 bis 2023 für die Schweiz

- Schur, Nadine[1, 2]
- Lupatsch, Judith[1, 2]
- Twerenbold, Sibylle[3]
- El Saadany, Tämer[4]
- Daikeler, Thomas[5]
- Schwenkglenks, Matthias[1, 2]

[Fussnote 1] Institut für Pharmazeutische Medizin (ECPM), Universität Basel, Basel, Schweiz

[Fussnote 2] Health Economics Facility, Department of Public Health, Universität Basel, Basel, Schweiz

[Fussnote 3] Agaplesion, Diakonieklinikum Hamburg, Hamburg, Deutschland

[Fussnote 4] Tumor- und Forschungszentrum, Kantonsspital Graubünden, Chur, Schweiz

[Fussnote 5] Rheumatologie, Universitäres Zentrum für Immunologie, Universitätsspital Basel, Basel, Schweiz

Unter Mitarbeit von Helsana Versicherungen AG:

Manuel Elmiger, Carola Huber, Andri Signorell, Sabrina Stollberg

November 2024 (aktualisierte Version September 2026)

[[Seite 3/102]]

## Inhaltsverzeichnis

| Abschnitt | Titel | Seite |
|---|---|---|
| 1 | Einleitung | 10 |
| 2 | Methoden | 11 |
| 2.1 | Datenquelle: Die Helsana-Gruppe | 11 |
| 2.2 | Population und Studiensetting | 13 |
| 2.3 | Hochrechnung | 13 |
| 2.4 | Analysen | 13 |
| 2.5 | Anatomisch-therapeutisch-chemische Klassifikation (ATC) | 15 |
| 3 | Ergebnisse allgemeiner Teil | 17 |
| 3.1 | Gesamtmarkt der Medikamente in der Schweiz | 17 |
| 3.2 | Entwicklung der Kosten und Bezüge ausgewählter Therapiegebiete | 20 |
| 3.2.1 | Krebs- und Immunsystemmittel (L) | 27 |
| 3.2.2 | Nervensystemmittel (N) | 29 |
| 3.2.3 | Stoffwechselmittel (A) | 31 |
| 3.2.4 | Herz-Kreislaufmittel (C) | 32 |
| 3.2.5 | Antiinfektiva (J) | 33 |
| 3.2.6 | Blutsystemmittel (B) | 34 |
| 3.2.7 | Sinnesorgane (S) | 35 |
| 3.2.8 | Fazit | 36 |
| 3.3 | Neuheiten und potenzielle Innovationen | 37 |
| 3.3.1 | Neuheiten und potenzielle Innovationen 2023 | 37 |
| 3.3.2 | Marktentwicklung der Neuheiten aus 2022 | 42 |
| 3.4 | Patente, Generika und Biosimilars | 45 |
| 3.4.1 | Preisentwicklung patentabgelaufener Medikamente | 45 |
| 3.4.2 | Nutzung und Einsparpotenzial von Generika | 48 |
| 3.4.3 | Nutzung und Einsparpotenzial von Biosimilars | 50 |
| 4 | Ergebnisse spezifischer Teil | 56 |
| 4.1 | Sicherheitswarnungen zu Januskinase -Inhibitoren (JAKi): Einfluss auf die Verwendung und wirtschaftliche Implikationen | 56 |
| 4.1.1 | Einleitung | 56 |
| 4.1.2 | Methoden | 58 |
| 4.1.3 | Resultate und Diskussion | 61 |
| 4.1.4 | Fazit | 71 |
| 4.2 | Zielgerichtete Therapien und Immuntherapien beim Lungenkrebs | 73 |
| 4.2.1 | Einleitung | 73 |
| 4.2.2 | Methoden | 75 |
| 4.2.3 | Resultate und Diskussion | 78 |
| 4.2.4 | Fazit | 86 |
| 5 | Anhang | 89 |

[[Seite 4/102]]

## Zusammenfassung

Die Kosten im Medikamentenbereich sind im Jahr 2023 erneut deutlich gestiegen und der Markteintritt hochpreisiger Medikamente beförderte das allgemeine Preisniveau im patentgeschützten Bereich. Mitverantwortlich ist der Mechanismus des Preisvergleichs im In- und Ausland (therapeutischer Quervergleich respektive Auslandspreisvergleich) sowie allfällige Innovationszuschläge. Zusätzlich tragen Mengenausweitungen erheblich zu den Kostensteigerungen bei, vor allem aufgrund von Indikationserweiterungen oder geänderten Therapieempfehlungen. Die im internationalen Vergleich noch immer seltene Nutzung von Nachahmerpräparaten (Generika und Biosimilars) verursacht ebenfalls unnötige Mehrkosten.

Der elfte Arzneimittelreport basiert wie die Berichte der Vorjahre auf Abrechnungsdaten von Helsana und liefert verlässliche Daten zum Schweizer Arzneimittelmarkt. Die Analysen basieren auf den Leistungsabrechnungsdaten aus der Grundversicherung der Helsana-Gruppe, die in diesem Bereich rund ein Siebtel der Schweizer Bevölkerung zu ihren Kundinnen und Kunden zählt. Sämtliche Leistungen sind auf die Gesamtbevölkerung hochgerechnet und repräsentativ für die Schweiz. Der Report fördert die Transparenz über die Mengen- und Kostenentwicklung im Gesundheitswesen und bietet einen detaillierten Einblick in den Medikamenteneinsatz. Die gewonnenen Erkenntnisse können dazu beitragen, Therapieentscheide effizienter und rationaler zu gestalten und schaffen eine fundierte Grundlage für gesundheitspolitische Diskussionen.

Im Jahr 2023 betrugen die ambulanten Medikamentenkosten zu Lasten der Grundversicherung insgesamt CHF 9 Milliarden bei 137 Millionen Medikamentenbezügen. Sie stellen damit den grössten Kostenblock der Grundversicherung dar. Sowohl die Kosten (+5.9%) als auch die Anzahl der Personen mit Bezügen (+1.5%) und die Anzahl der Medikamentenbezüge (+2.1%) stiegen gegenüber dem Vorjahr. Drei Medikamente – das Krebsmittel Keytruda® (Pembrolizumab), das Augenmedikament Eylea® (Aflibercept) und der Gerinnungshemmer Xarelto® (Rivaroxaban) – führten die Liste der umsatzstärksten Präparate an und verursachten gemeinsam Kosten von CHF 478 Millionen (5.3% der Gesamtkosten). Eylea® verlor seinen ersten Platz, weil sich ein Teil der Bezüge auf das neue Augenmedikament Vabysmo® verlagerte.

Krebs- und Immunsystemmittel verursachten Kosten von CHF 2.8 Milliarden, was fast einem Drittel der gesamten Medikamentenkosten entspricht, obwohl der Anteil an den Bezügen nur 1.9% beträgt. Neuere hochpreisige Medikamente wie das bei Prostatakrebs eingesetzte Erleada® und das unter anderem bei Brustkrebs eingesetzte Enhertu® sowie weniger einschränkende Limitationen oder Indikationserweiterungen bei bekannten Präparaten wie dem Prostatakrebsmittel Xtandi®, dem Lungenkrebsmittel Imfinzi® und dem Krebsmittel Keytruda® trugen zu den gestiegenen Kosten bei.

Bei den Stoffwechselmitteln waren die Diabetesmedikamente die Hauptursache für den Kostenanstieg. Von besonderer Bedeutung war der Wirkstoff Semaglutid (Ozempic®, Rybelsus® und Wegovy®), ein GLP-1-Rezeptoragonist, der auch zur Gewichtsreduktion eingesetzt wird. Semaglutid verursachte mit

[[Seite 5/102]]

CHF 113 Millionen die höchsten Kosten aller Diabetesmedikamente. Das Stoffwechselmittel Pantoprazol (ein Magensäureblocker) überschritt erneut die CHF 100 Millionen-Marke.

Die Kosten für Antiinfektiva erreichten fast CHF 732 Millionen. Den grössten Kostenzuwachs von über CHF 26 Millionen generierten die Impfstoffe. Der Herpes-Zoster-Impfstoff Shingrix® war mit einem Umsatzplus von CHF 17.1 Millionen in den Top-Fünf der Wirkstoffe mit dem grössten Kostenzuwachs.

Im Jahr 2023 wurden 28 neue Wirkstoffe in die Spezialitätenliste aufgenommen, darunter hauptsächlich Krebsmedikamente und Immunsuppressiva. Es resultierten bereits im Einführungsjahr Kosten von CHF 87 Millionen. Nur zwei dieser neuen Wirkstoffe, das Enzymtherapeutikum Nexviadyme® (Avalglucosidase alfa) und das Herzmittel Camzyos® (Mavacamten), basierten auf neuartigen Wirkmechanismen. Gesamthaft entfielen 53% des gesamten Marktvolumens auf patentgeschützte Präparate, wo aufgrund der Preisbildungskriterien kein echter Preiswettbewerb herrscht und Neuzulassungen immer teurer werden. Es kamen drei neue Biosimilars auf den Markt: Yuflyma® (Adalimumab; Original: Humira®), Vegzelma® (Bevacizumab; Original: Avastin®), Byooviz® (Ranibizumab; Original: Lucentis®). Der Umsatz aller Biologika mit verfügbaren Biosimilars betrug CHF 481.5 Millionen, davon entfielen 37.8% (CHF 182.2 Millionen) auf Biosimilars, was eine deutliche Zunahme gegenüber dem Vorjahr darstellt. Der Umsatz von Wirkstoffen mit verfügbaren Generika erreichte CHF 2.2 Milliarden, mit einem Anteil der Generika von knapp CHF 1.4 Milliarden.

Der spezifische Teil des diesjährigen Arzneimittelreports konzentrierte sich auf zwei Spezialthemen. Erstens wurde der Einsatz von Januskinase-Inhibitoren (JAKi) und der Einfluss von Sicherheitswarnungen auf deren Abgabepraxis analysiert. Zweitens beleuchtet der Report die neuen Entwicklungen bei zielgerichteten Therapien und Immuntherapien im Bereich der Onkologie, mit besonderem Fokus auf Lungenkrebs.

Das erste Spezialkapitel konzentriert sich auf die Verwendung von JAKi im Zusammenhang mit Sicherheitsbedenken für Risikogruppen aufgrund schwerwiegender Nebenwirkungen. JAKi sind eine relativ neue Medikamentenklasse, die zur Behandlung chronisch-entzündlicher und autoimmuner Erkrankungen (z.B. rheumatoider Arthritis) eingesetzt wird. Die Gesamtkosten für JAKi stiegen zwischen 2013 und 2023 kontinuierlich auf jährlich etwa CHF 122 Millionen an. Aufgrund von Sicherheitsbedenken, insbesondere bei älteren Personen mit kardialen Risikofaktoren, wurden weltweit Warnungen von Zulassungsbehörden ausgesprochen. Die erste Schweizer Warnung im Jahr 2019 betraf Tofacitinib (Xeljanz®), woraufhin ein Rückgang der Bezüge zu beobachten war, allerdings nicht spezifisch bei Risikopersonen. Anfang 2023 wurden die beobachteten Probleme dann als Klasseneffekt eingestuft und die Warnungen auf drei weitere JAKi ausgeweitet. Der darin eingeschlossene Wirkstoff Upadacitinib (Rinvoq®) wurde trotzdem weiterhin häufig eingesetzt. Die zusätzlichen Kosten für die Überwachung der Patientinnen und Patienten sowie die Behandlung von Nebenwirkungen beeinträchtigen die Kosteneffektivität der JAKi-Therapien, mit Implikationen für deren Wirtschaftlichkeit.

[[Seite 6/102]]

Preisanpassungen könnten die finanziellen Auswirkungen der Behandlungen bei Patientinnen und Patienten ohne alternative Therapieoptionen mildern.

Das zweite Spezialkapitel fokussiert sich auf die Auswirkungen von zielgerichteten Therapien und Immuntherapien auf dem Onkologikamarkt, am Beispiel von Lungenkrebs. Seit der Einführung dieser Therapien hat sich die Behandlung von Lungenkrebs grundlegend verändert. Allerdings gehen mit diesen neuen Therapien auch deutlich höhere Preise einher, die sich in den Gesamtkosten für Onkologika bei Lungenkrebs niederschlagen. Die Kosten stiegen von CHF 63 Millionen im Jahr 2013 auf CHF 146 Millionen im Jahr 2023, was einem Anstieg von 169% entspricht. Dieser Kostenzuwachs ist zu einem grossen Teil auf die Einführung von Immuntherapien zurückzuführen. Im Jahr 2016 erhielten 81% der Personen mit Lungenkrebs eine Chemotherapie als erste Behandlung, während 13% mit zielgerichteten Therapien behandelt wurden. Zu diesem Zeitpunkt waren Immuntherapien in der ersten Linie praktisch nicht vertreten und kamen erst in der zweiten Therapielinie nach einer Chemotherapie bei etwa 50% der Betroffenen zum Einsatz. Im Jahr 2021 erhielt noch etwa die Hälfte der Lungenkrebspatientinnen und -patienten eine Chemotherapie als erste medikamentöse Therapie (einschliesslich adjuvanter und neoadjuvanter Chemotherapie). Der Einsatz zielgerichteter Therapien blieb mit 13% in der ersten Therapielinie konstant. Immuntherapien wurden hingegen bei 12% der Patientinnen und Patienten als Monotherapie eingesetzt und bei 23% in Kombination mit Chemotherapie. Diese Entwicklungen verdeutlichen den schrittweisen Wandel in der Behandlung von Lungenkrebs und die zunehmende Rolle der modernen Therapien.

[[Seite 7/102]]

## Summary

Drug costs rose significantly in 2023, and the market entry of high-priced drugs is driving up the general price level in patent-protected areas. Price comparisons in Switzerland and abroad (therapeutic cross-comparisons and international price comparisons) and innovation surcharges are partly responsible for this. In addition, volume expansions contribute significantly to cost increases, especially because of extensions of indications or changes in clinical recommendations. The use of generics and biosimilars, which remains low in international comparison, also implies unnecessary additional costs.

As in previous years, the eleventh drug utilization report is based on billing data from Helsana and provides reliable data on the Swiss pharmaceutical market. The analyses are based on claims to the Helsana Group’s basic health insurance, which covers approximately one-seventh of the Swiss population. All data were extrapolated to the total population level and are representative for Switzerland. The report promotes transparency regarding the development of utilization and costs in the healthcare sector and provides detailed insights into the use of medicines. Findings may support more efficient and rational treatment decisions, and provide a sound basis for health policy discussions.

In 2023, outpatient medication costs covered by basic insurance totalled CHF 9 billion, arising from 137 million medication purchases, making them the largest cost block for basic insurance. The costs (+5.9%) as well as the number of people with purchases (+1.5%) and the number of purchases (+2.1%) increased compared with the previous year. Three drugs – the cancer drug Keytruda® (pembrolizumab), the ophthalmic drug Eylea® (aflibercept) and the anticoagulant Xarelto® (rivaroxaban) – head the list of top-selling products. Together, they generated costs of CHF 478 million (5.3% of total costs). Eylea® lost its first place because of a shift to the new ophthalmic drug Vabysmo®.

Cancer and immune system drugs generated costs of CHF 2.8 billion, which corresponds to almost a third of total drug costs, although they only accounted for 1.9% of total purchases. Newer, high-priced drugs such as Erleada®, which is used for prostate cancer, and Enhertu®, which is used for breast cancer, as well as less restrictive limitations or indication extensions for well-known drugs such as the prostate cancer drug Xtandi®, the lung cancer drug Imfinzi® and the cancer drug Keytruda® were contributing to the rising costs.

Aming the metabolic agents, diabetes medications were the main cause of increased costs. The active substances semaglutide (Ozempic®, Rybelsus®, and Wegovy®), a GLP-1 receptor agonist that is also used for weight loss, was of particular importance. It generated the highest costs of all diabetes drugs of CHF 113 million. The metabolic agent pantoprazole (a gastric acid blocker) exceeded the CHF 100 million mark.

The costs of anti-infectives amounted to almost CHF 732 million. Vaccines generated the largest increase in costs of over CHF 26 million. The herpes zoster vaccine Shingrix® was one of the top five active substances with the highest cost growth, with an increase of CHF 17.1 million.

[[Seite 8/102]]

By 2023, 28 new active substances, mainly cancer drugs and immunosuppressants, were added to the specialty list, resuting in costs of CHF 87 million. Only two of these new active substances, the enzyme therapy Nexviadyme® (avalglucosidase alfa) and the cardiac drug Camzyos® (mavacamten), are based on novel mechanisms of action. About 53% of the total market volume is still accounted for by patent-protected products. Given the current pricing criteria, there is no real price competition for these and new approvals are becoming increasingly expensive. Three new biosimilars were also launched: Yuflyma® (adalimumab; Humira®), Vegzelma® (bevacizumab; Avastin®), and Byooviz® (ranibizumab; Lucentis®). Sales of all biologics with available biosimilars amounted to CHF 481.5 million, of which 37.8% (CHF 182.2 million) were attributable to the biosimilars, a significant increase compared to the previous year. For substances with available generics, total sales amounted to CHF 2.2 billion, with nearly CHF 1.4 billion attributed to generics.

The specific part of this year’s drug utilization report focused on two topics of special interest. First, the use of januskinase inhibitors (JAKi) and the influence of safety warnings on dispensing practices were analyzed. Second, the report highlights new developments in targeted therapies and immunotherapies in the field of oncology, with a particular focus on lung cancer.

The first special chapter focuses on the use of JAKi in the context of safety concerns for at-risk groups due to serious side effects. JAKi are a relatively new class of drugs used to treat chronic inflammatory and autoimmune diseases, such as rheumatoid arthritis. From 2013 to 2023, the total costs of JAKi increased steadily to approximately CHF 122 million per year. Owing to safety concerns, particularly in older adults with cardiac risk factors, warnings have been issued by regulatory authorities worldwide. The first warning in 2019 concerned tofacitinib (Xeljanz®), whereafter a decline in purchases was observed, although not specifically in at-risk individuals. At the beginning of 2023, the observed safety problems were classified as a class effect, and the warnings were extended to three additional JAKi. Among these, the active substance upadacitinib (Rinvoq®) was still frequently used. The additional costs of monitoring patients and treating side effects affect the cost-effectiveness of JAKi therapies and have implications for their efficiancy. Price adjustments could mitigate the financial impact of treatment in patients without alternative treatment options.

The second special chapter focuses on the impact of targeted therapies and immunotherapies on the oncology market, using lung cancer as an example. Since the introduction of these therapies, the treatment of lung cancer has fundamentally changed. These new therapies also come with significantly higher prices, which are reflected in the overall costs of oncology drugs for lung cancer. Costs increased from CHF 63 million in 2013 to CHF 146 million in 2023, representing a 169% rise. This increase is largely attributable to the introduction of immunotherapies. In 2016, 81% of individuals with lung cancer received chemotherapy as their first treatment, while 13% were treated with targeted therapies. At that time, immunotherapies were virtually absent as first-line treatment and were only used in second line after chemotherapy; about 50% of patients who received subsequent treatment after chemotherapy

[[Seite 9/102]]

were given immunotherapy. By 2021, half of the lung cancer patients still received chemotherapy as their first-line drug therapy (including adjuvant chemotherapy). The use of targeted therapies remained constant at 13% in the first treatment line. In contrast, immunotherapies were used as monotherapy in 12% of patients and in combination with chemotherapy in 23%. These developments illustrate the gradual shift in the treatment of lung cancer and the increasing role of modern therapies.

[[Seite 10/102]]

## 1 Einleitung

Die Schweiz verfügt über ein sehr gutes und sehr teures Gesundheitssystem. Die solidarisch finanzierte soziale Grundversicherung hat jedoch auch ihre Herausforderungen. Innovationen und begrüssenswerte medizinische Fortschritte haben ihren Preis. Unter anderem aufgrund des demografischen Wandels und der zunehmenden Verbreitung chronischer Krankheiten steigen die Kosten stark, was sich auf die Krankenversicherungsprämien niederschlägt. Medikamente tragen einen erheblichen Anteil daran. Neue innovative Arzneimittel sind für die Bekämpfung vieler Krankheiten essenziell, jedoch sind sie meist mit hohen Preisen verbunden.

Zum elften Mal erscheint dieser Arzneimittelreport. Er basiert auf der Abrechnungsdatenbank der Helsana-Gruppe, bei der mehr als 2 Millionen Personen in der Schweiz versichert sind. Solche Daten zu Mengen- und Kostenentwicklungen sind von zentraler Bedeutung, um die Entwicklung des Medikamentenmarkts im Schweizer Gesundheitssystem im Detail zu analysieren. Der Bericht ist in einen allgemeinen und einen spezifischen Teil gegliedert. Im allgemeinen Teil werden die Kosten und Bezüge verschiedener Medikamentengruppen und Wirkstoffe aus dem Jahr 2023 genauer betrachtet und mit den Zahlen aus früheren Jahren verglichen. Zudem liegt ein Fokus auf dem Verbrauch von Biosimilars und Generika. Die Spezialkapitel befassen sich in diesem Jahr mit dem Einfluss von Sicherheitswarnungen auf die Verwendung von Januskinase-Inhibitoren und die daraus resultierenden wirtschaftlichen Implikationen. Ausserdem werden neue Entwicklungen bei zielgerichteten Therapien und Immuntherapien im Bereich der Onkologie untersucht. Der Report zeigt anhand des Beispiels Lungenkrebs den Wandel beim Einsatz der verschiedenen Therapieformen auf und die Auswirkungen auf die Kosten und die Wirkung.

Als akademische Autoren streben wir eine neutrale Darstellung der gewonnenen Erkenntnisse an, ohne die Standpunkte von Krankenversicherern, Patientenorganisationen oder der pharmazeutischen Industrie zu vertreten. Unser Ziel ist, eine qualitativ hochwertige und kosteneffiziente Arzneimittelversorgung in der Schweiz zu fördern und eine fundierte Diskussion über die Entwicklung des Schweizer Gesundheitssystems anzuregen.

[[Seite 11/102]]

## 2 Methoden

## 2.1 Datenquelle: Die Helsana-Gruppe

Die Helsana-Gruppe (bestehend aus Helsana Versicherungen, Helsana Zusatzversicherungen, Helsana Unfall und ehemals Progrès Versicherungen) zählt mit mehr als 2 Millionen versicherten Personen zu den führenden Krankenversicherern der Schweiz. Sie beschäftigt fast 3’500 Mitarbeitende und erzielte im Jahr 2023 ein Prämienvolumen von CHF 7.8 Milliarden [1].

Der vorliegende Bericht basiert auf den Helsana-Abrechnungsdaten der Grundversicherung (Tabelle 1) und wird zu Repräsentativitätszwecken auf die Gesamtbevölkerung hochgerechnet.

|  | 2023 | 2022 | 2021 | 2020 |
|---|---|---|---|---|
| **Anzahl Grundversicherte Helsana-Gruppe** |  |  |  |  |
| Gesamt | 1’328’056 | 1’440’058 | 1’387’297 | 1’313’259 |
| davon Frauen (%) | 678’138 (51.1) | 734’819 (51.0) | 708’449 (51.1) | 672’563 (51.2) |
| davon Männer (%) | 649’918 (48.9) | 705’239 (49.0) | 678’848 (48.9) | 640’696 (48.8) |
| **Durchschnittsalter (± Standardabweichung)** |  |  |  |  |
| Gesamt | 42.6 (± 24.1) | 42.0 (± 23.8) | 42.1 (± 24.0) | 42.6 (± 24.2) |
| Frauen | 44.0 (± 24.7) | 43.3 (± 24.4) | 43.5 (± 24.5) | 44.0 (± 24.7) |
| Männer | 41.2 (± 23.5) | 40.6 (± 23.2) | 40.7 (± 23.3) | 41.0 (± 23.5) |
| **Anzahl Personen mit Medikamentenbezügen** |  |  |  |  |
| Gesamt | 1’016’858 | 1’090’585 | 1’026’660 | 968’284 |
| davon Frauen (%) | 557’430 (54.8) | 598’529 (54.9) | 567’539 (55.3) | 535’504 (55.3) |
| davon Männer (%) | 459’428 (45.2) | 492’056 (45.1) | 459’121 (44.7) | 432’780 (44.7) |
| **Durchschnittsalter der Personen mit Medikamentenbezügen (± Standardabweichung)** |  |  |  |  |
| Gesamt | 44.7 (± 25.4) | 44.0 (± 25.2) | 44.6 (± 25.3) | 45.1 (± 25.5) |
| Frauen | 45.9 (± 25.3) | 45.1 (± 25.1) | 45.7 (± 25.2) | 46.3 (± 25.4) |
| Männer | 43.3 (± 25.4) | 42.7 (± 25.3) | 43.2 (± 25.4) | 43.7 (± 25.6) |

Tabelle 1: Allgemeine Kennzahlen der durch die Helsana-Gruppe grundversicherten Personen, 2020-2023

Mit 51.1% war der Frauenanteil bei den Grundversicherten der Helsana-Gruppe leicht höher als in der Schweizerischen Gesamtbevölkerung, die laut Bundesamt für Statistik im Jahr 2023 einen Frauenanteil von 50.3% aufwies [2]. In Bezug auf die Altersverteilung zeigte sich, dass der prozentuale Anteil der grundversicherten Helsana-Kundinnen und -Kunden in den Altersgruppen 0 bis 19 Jahre sowie über 80 Jahre im Vergleich zur Gesamtbevölkerung höher war, während die Altersgruppe 20 bis 64 Jahre eher unterrepräsentiert war (Abbildung 1).

Im Jahr 2023 stagnierte erstmals seit vielen Jahren der Trend zu alternativen Versicherungsmodellen (AVM). Der Anteil der Personen mit einem AVM lag wie im Vorjahr bei etwa 78% (Abbildung 2). Bei Personen mit einem AVM war der Anteil derjenigen mit Medikamentenbezügen (75%) etwas niedriger als bei Personen im Standardmodell (82%).

[[Seite 12/102]]

**[Grafik 1] Abbildung 1: Altersverteilung des Helsana-Versichertenkollektivs im Vergleich zur Gesamtbevölkerung (Quelle: Bundesamt für Statistik [2], BFS), 2023**

Darstellung: Gruppierte Säulen. Achsen: Alter; Anteil Personen. Wertstatus: abgelesen ca.; alle Werte in %, Genauigkeit ± 1 Prozentpunkt. Die Säulen sind nicht mit Werten beschriftet. Skala: 0%, 5%, 10%, 15%, 20%, 25%, 30%, 35%.

| Alter | Helsana | BFS |
|---|---|---|
| 0-19 | ca. 21 | ca. 20 |
| 20-39 | ca. 26 | ca. 26 |
| 40-64 | ca. 33 | ca. 35 |
| 65-79 | ca. 14 | ca. 14 |
| 80 plus | ca. 7 | ca. 6 |

**[Ende Grafik 1]**

**[Grafik 2] Abbildung 2: Anteil von alternativen Versicherungsmodellen (AVM) gegenüber dem Standardmodell (ST) und Anteil an Personen mit Medikamentenbezügen nach Modelltyp im Helsana-Versichertenkollektiv, 2020-2023**

Darstellung: Liniendiagramm. Achsen: Jahr; Anteil Personen. Wertstatus: abgelesen ca.; alle Werte in %, Genauigkeit ± 1 Prozentpunkt. Die Linien sind nicht mit Werten beschriftet. AVM-Anteil: magenta; AVM-Bezüge: beige; ST-Bezüge: gelb. Skala: 0%, 10%, 20%, 30%, 40%, 50%, 60%, 70%, 80%, 90%. Die Werte für 2023 stimmen innerhalb der Ablesegenauigkeit mit den Angaben auf Seite 11 überein.

| Jahr | AVM-Anteil | AVM-Bezüge | ST-Bezüge |
|---|---|---|---|
| 2020 | ca. 75 | ca. 71 | ca. 81 |
| 2021 | ca. 77 | ca. 72 | ca. 82 |
| 2022 | ca. 78 | ca. 74 | ca. 83 |
| 2023 | ca. 78 | ca. 75 | ca. 82 |

**[Ende Grafik 2]**

**[Grafik 3] Abbildung 3: Übersicht der gewählten Franchisen im gesamten Helsana-Versichertenkollektiv und bei Personen mit Medikamentenbezügen, 2023**

Darstellung: Gruppierte Säulen. Achsen: Franchise [CHF]; Anteil Personen. Wertstatus: abgelesen ca.; alle Werte in %, Genauigkeit ± 1 Prozentpunkt. Die Säulen sind nicht mit Werten beschriftet. Skala: 0%, 5%, 10%, 15%, 20%, 25%, 30%, 35%, 40%, 45%.

| Franchise [CHF] | Alle Versicherte | Personen mit Bezügen |
|---|---|---|
| 0 | ca. 20 | ca. 20 |
| 300 | ca. 39 | ca. 45 |
| 500 | ca. 9 | ca. 10 |
| 1'000 | ca. 2 | ca. 2 |
| 1'500 | ca. 3 | ca. 3 |
| 2'000 | ca. 1 | ca. 1 |
| 2'500 | ca. 27 | ca. 19 |

Die Franchisestufe CHF 0 bezieht sich auf Kinder und Jugendliche bis einschliesslich 18 Jahre.

**[Ende Grafik 3]**

[[Seite 13/102]]

Die Franchise von CHF 300 blieb im Jahr 2023 die häufigste Wahl, sowohl bei allen Versicherten als auch bei Personen mit Medikamentenbezügen. Die Franchise von CHF 2’500 belegte den zweiten Platz in der Beliebtheit (Abbildung 3). Personen mit Medikamentenbezügen bevorzugten häufiger eine Franchise von CHF 300 im Vergleich zu allen Versicherten, während bei der höchsten Franchise der umgekehrte Trend zu beobachten war. Dies spiegelt den Bedarf an medizinischen Leistungen wider und lässt darauf schliessen, dass Personen mit einer hohen Franchise wahrscheinlich häufig gesünder sind.

## 2.2 Population und Studiensetting

Die in diesem Report zusammengefassten Analysen beruhen auf Abrechnungsdaten der Helsana-Gruppe und beziehen sich, wo nicht anders vermerkt, auf den Zeitraum zwischen 2020 und 2023. Die erhobenen Daten beschränken sich auf die obligatorische Krankenpflegeversicherung (OKP; Grundversicherung).

Um die Identifizierung individueller Personen zu verunmöglichen, wurden alle personenbezogenen Daten vor der Auswertung anonymisiert. Die Grundgesamtheit des Helsana-Kollektivs unterscheidet sich jedes Jahr leicht. Folglich wurde mit auf die Schweiz hochgerechneten Daten gearbeitet (siehe auch Kapitel 2.3).

Bei den verfügbaren Daten handelt es sich um Leistungsdaten, auf deren Basis die Leistungserbringer vergütet werden. Da die meisten Leistungen im akutstationären Bereich pauschal – also ohne Aufschlüsselung nach Einzelleistungen – abgerechnet werden, basieren die Analysen auf Angaben aus dem ambulanten Bereich, in dem standardmässig jedes Medikament individuell erfasst und abgerechnet wird.

Bezüge und Medikamente, die direkt von Patientinnen und Patienten im Over-The-Counter-Bereich selbst bezahlt oder von einer anderen Versicherung vergütet wurden, werden nicht berücksichtigt. Ebenso fehlen Leistungsabrechnungen, die von den Versicherten oder den Leistungserbringern nicht eingesandt wurden.

## 2.3 Hochrechnung

Die Helsana-Daten wurden mit jahresspezifischen Hochrechnungsfaktoren kombiniert, um kleinere demografische Unterschiede zwischen der Schweizer Bevölkerung und dem Helsana-Kollektiv auszugleichen. Dadurch sind Schätzungen für die Gesamtbevölkerung möglich. Die Hochrechnungsfaktoren wurden anhand der Risikoausgleichsstatistik berechnet, basierend auf Wohnkanton, Geschlecht und Altersstruktur (Alterskategorien: 0-18 Jahre, 19-25 Jahre, danach in 5-Jahresschritten bis 90 Jahre, und über 90 Jahre). Da es sich bei den hochgerechneten Resultaten um Schätzungen handelt, können diese insbesondere bei selten in Anspruch genommenen Leistungen von den realen Werten für die Schweiz abweichen.

## 2.4 Analysen

Die Datenbank beinhaltet sämtliche Medikamentenbezüge von bei Helsana grundversicherten Personen. Neben dem eigentlichen Bezug werden weitere Details erfasst, darunter Informationen zum

[[Seite 14/102]]

Medikament wie dessen anatomisch-therapeutisch-chemische Klassifikation (ATC-Code), Pharmacode, Swissmedic-Kategorie (Liste A bis E), Packungsgrösse, Galenik und Preis, sowie patientenspezifische Angaben wie Alter, Geschlecht, Wohnkanton, Franchise, Versicherungsmodell und allfällige Unfallversicherungsdeckung. Ebenso sind Details zum verordnenden Leistungserbringer (in der Regel Arzt oder Spital) und zum Abgabekanal der Medikamente (hauptsächlich Apotheke, Arztpraxis oder Spital) enthalten.

Anhand der Leistungsabrechnungen wird die Bezugshäufigkeit verschiedener Wirkstoffgruppen, Wirkstoffe und Produkte (Markennamen) erfasst. In diesem Jahr werden erstmals gleichzeitige Bezüge mehrerer identischer Packungen als separate Bezüge behandelt, während Bezüge kleinerer Mengen einzelner Packungen als Teilbezüge erfasst sind. Dabei wird nicht zwischen Packungsgrössen unterschieden, so dass kein direkter Rückschluss auf die Anzahl eingenommener Dosen möglich ist. Ausserdem muss berücksichtigt werden, dass ein Bezug eines Medikaments nicht zwingend mit dessen Einnahme gleichgestellt werden kann. Für die hier durchgeführten direkten Kostenanalysen ist dies jedoch nicht relevant.

Die Daten aller relevanten Jahre werden jährlich neu aus der Datenbank extrahiert. Auf dieser Basis werden auch die Berechnungen für frühere Jahre angepasst und aktualisiert. Zudem können neue Annahmen getroffen und methodische Anpassungen vorgenommen werden, wie beispielsweise die oben erwähnte Änderung in der Berechnung der Bezüge. Diese Änderungen können die Resultate beeinflussen, weshalb die Ergebnisse der Berichte verschiedener Jahre nicht direkt miteinander vergleichbar sind. Es ist daher wichtig, die Resultate im jeweiligen Kontext zu betrachten und Vergleiche mit Zahlen aus früheren Berichten nur mit Vorsicht zu ziehen.

Alle Medikamentenkosten sind Bruttokosten und beruhen auf den eingereichten Rechnungsbeträgen, d.h. unterschiedliche Franchisen sowie allfällige Selbstbehalte spielen keine Rolle. Eventuelle Rückforderungen, welche im Rahmen von Preisabsprachen zwischen dem Bundesamt für Gesundheit (BAG) und Lizenzinhaberinnen durch die Krankenversicherer bei den Herstellern für bestimmte Medikamente eingefordert werden müssen [3], sind jedoch berücksichtigt. Allerdings wird bei Präparaten mit geheimem Preismodell auf die Angabe von Bezügen und der Anzahl Personen mit Bezügen in den Tabellen auf Wirkstoff- und Präparateebene verzichtet, um Rückschlüsse auf den Preis zu vermeiden.

Die Kosten sind in der Regel auf jährlicher Basis zusammengefasst. Lediglich in Kapitel 3.3 werden monatliche Durchschnittskosten verwendet, um eine bessere Vergleichbarkeit der neuen Medikamente zu gewährleisten.

Die Einteilung der Medikamente in Originalpräparate, Generika, Referenzpräparate und Biosimilars erfolgt auf Grundlage der Spezialitätenliste. Neue Medikamente werden durch einen Abgleich mit den Spezialitätenlisten der vorhergehenden Jahre identifiziert.

Die Analysen wurden mittels der Statistiksoftware STATA/SE 15.0 sowie mit Microsoft Excel (Office Professional Plus 2020) durchgeführt. Die Karten für die Schweiz wurden mit der Software QGIS Desktop 3.38.0 erstellt.

[[Seite 15/102]]

## 2.5 Anatomisch-therapeutisch-chemische Klassifikation (ATC)

Den Analysen des vorliegenden Reports liegt das anatomisch-therapeutisch-chemische Klassifikationssystem (Anatomical Therapeutic Chemical, ATC-Klassifikation) zugrunde. Dieses international anerkannte System zur Klassifikation von Arzneimitteln teilt Wirkstoffe nach Einsatzorgan, Wirkprinzip, pharmakologischen und chemischen Eigenschaften ein, nicht jedoch nach Handelspräparaten (Markennamen) [4]. Teilweise kommt es vor, dass Medikamente im Laufe der Zeit umklassifiziert werden und einen neuen ATC-Code erhalten. Dadurch können teilweise Abweichungen im Vergleich mit älteren Berichten auftreten.

Die ATC-Klassifikation enthält fünf Ebenen (Tabelle 2). Der allgemeine Teil analysiert alle in der Helsana-Datenbank erfassten Medikamente anhand der 1., 2. und 5. Ebene der ATC-Klassifikation nach Kosten und Bezügen. Ebene 1 umfasst 15 Hauptgruppen, die das Organsystem bzw. das physiologische System beschreiben (Tabelle 3). Die Hauptgruppe Q, welche veterinärmedizinische Arzneimittel umfasst, ist nicht berücksichtigt. Während Ebene 2 die therapeutische Subgruppe beinhaltet, beschreibt Ebene 5 den Wirkstoff bzw. die chemische Substanz.

| ATC | Level | Bezeichnung |
|---|---|---|
| A | Level 1, anatomische Hauptgruppe | Alimentäres System und Stoffwechsel |
| A10 | Level 2, therapeutische Subgruppe | Antidiabetika |
| A10B | Level 3, pharmakologische Subgruppe | Antidiabetika, exklusiv Insuline (orale) |
| A10BA | Level 4, chemische Subgruppe | Biguanide |
| A10BA02 | Level 5, chemische Substanz | Metformin |

Tabelle 2: Ebenen der ATC-Klassifikation am Beispiel des Diabetes-Medikaments Metformin [4]

[[Seite 16/102]]

| ATC Ebene 1 | Anatomische Hauptgruppe | Bezeichnung | Beispiele |
|---|---|---|---|
| A | Alimentäres System und Stoffwechsel | Stoffwechsel | Mittel bei gastrointestinalen Beschwerden, Supplemente, Antidiabetika |
| B | Blut und blutbildende Organe | Blut | Mittel zur Prävention und Therapie von Thrombosen sowie Blutarmut |
| C | Kardiovaskuläres System | Herz-Kreislauf | Mittel zur Behandlung kardiovaskulärer Erkrankungen (z.B. Bluthochdruck, erhöhte Cholesterinwerte, Herzrhythmusstörungen) |
| D | Dermatika | Haut | Mittel zur Behandlung diverser Hauterkrankungen; ausschliesslich zur äusseren Anwendung |
| G | Urogenitalsystem und Sexualhormone | Geschlechtsorgane | Mittel bei durch Geschlechtsverkehr übertragenen Infekten (ausschliesslich zur äusseren Anwendung), Mittel zur Konzeptionsverhütung, Sexualhormone |
| H | Hormone, systemisch (ohne Sexualhormone) | Hormone | Mittel zur Behandlung hormoneller Störungen wie Schilddrüsenunter- und -überfunktion |
| J | Antiinfektiva für systemische Gabe | Antiinfektiva | Mittel zur Behandlung bakterieller, mykotischer und viraler Erkrankung, Impfstoffe |
| L | Antineoplastische und immunmodulierende Substanzen | Krebs/Immunsystem | Mittel zur Behandlung von Krebs, Mittel zur Aktivierung und Unterdrückung des Immunsystems |
| M | Muskel- und Skelettsystem | Bewegungsapparat | Orale und topische Mittel zur Behandlung von Schmerzen und Entzündungen rheumatischen Ursprungs, Mittel zur Behandlung von Gicht und Knochenerkrankungen |
| N | Nervensystem | Nervensystem | Mittel zur Behandlung von Schmerzen nicht-rheumatischen Ursprungs, Psychosen, Depressionen, Schlafstörungen, Epilepsie und Parkinson |
| P | Antiparasitäre Substanzen, Insektizide, Repellentien | Parasiten | Mittel zur Bekämpfung von Parasiten wie Wurmbefall aber auch Malaria |
| R | Respirationstrakt | Atmung | Mittel zur Behandlung von Erkrankungen des Respirationstraktes wie Husten, Halsschmerzen, Schnupfen aber auch Allergien |
| S | Sinnesorgane | Sinnesorgane | Mittel zur Behandlung von Erkrankungen, welche die Augen oder Ohren betreffen |
| V | Verschiedene | Verschiedene | Hauptsächlich Mittel zur Verwendung von diagnostischen Tests wie Kontrastmittel, aber auch Diäten zur Unterstützung bei Übergewicht |

Hauptgruppe Q (veterinärmedizinische Arzneimittel) wurde im vorliegenden Report nicht berücksichtigt.

Tabelle 3: ATC-Klassifikation, Ebene 1 (anatomische Hauptgruppen)

[[Seite 17/102]]

## 3 Ergebnisse allgemeiner Teil

## 3.1 Gesamtmarkt der Medikamente in der Schweiz

**[Kernaussagen]**

- Die Medikamentenkosten zu Lasten der OKP stiegen im Jahr 2023 um CHF 500 Millionen an (+5.9% gegenüber dem Jahr 2022) und beliefen sich neu auf über CHF 9 Milliarden. Sie stellen nun erstmals den grössten Kostenblock der OKP dar.

- Die Gesamtzahl der Bezüge stieg auf 137 Millionen Bezüge (+2.1%), während die Anzahl der Personen mit Medikamentenbezügen auf knapp 6.9 Millionen Bezüge (+1.5%) anstieg.

- Die Pro-Kopf-Kosten von Personen mit Bezügen sind ebenfalls gestiegen (+4.3%), was auf das hohe Preisniveau von Produkten mit Marktausdehnungen und teure Neueinführungen zurückzuführen ist.

- Aufgrund einer höheren Zahl an Bezügen und Personen mit Bezügen verursachten Frauen trotz geringerer Pro-Kopf-Kosten höhere Medikamentenkosten als Männer.

- Bereits früher beobachtete kantonale Unterschiede der Medikamentenbezüge und -kosten blieben weiterhin bestehen. Gründe dafür sind vermutlich demografische und kulturelle Unterschiede sowie die unterschiedliche Dichte an Leistungsangeboten.

**[Ende Kernaussagen]**

Trotz regelmässiger Preisüberprüfungen durch das BAG stiegen die OKP-Kosten für Medikamente auch im Jahr 2023 stark an. Sie beliefen sich auf insgesamt CHF 9’021 Millionen, was eine Zunahme von 5.9% gegenüber dem Vorjahr bedeutet (Tabelle 4). Damit sind die Medikamente gemäss der Statistik der OKP nun der grösste Kostenblock der Grundversicherung [5]. Gründe für dieses Kostenwachstum sind unter anderem Neueinführungen und Marktausdehnungen sehr teurer medikamentöser Therapien, was sich in gestiegenen Pro-Kopf-Kosten bei Personen mit Bezügen widerspiegelt (+4.3%). Dieser Trend zeigte sich in vielen verschiedenen Wirkstoffgruppen. Eine detailliertere Betrachtung der für diese Anstiege hauptverantwortlichen Wirkstoffgruppen und Arzneimittel erfolgt in Kapitel 3.2.

Die Zahl der Gesamtbezüge stieg gegenüber dem Jahr 2022 auf knapp 137 Millionen Bezüge (+2.1%) weiter an. Während die Zahl der Pro-Kopf-Bezüge (+0.6%) nur leicht anstieg, stieg die Zahl der Personen mit Medikamentenbezügen deutlicher (+1.5%). Die demografische Entwicklung stellt eine wesentliche Ursache hierfür dar: Zwischen 2022 und 2023 wuchs die ständige Wohnbevölkerung der Schweiz um 1.7%, die Zahl der Personen ab 65 Jahren um 2.3% [6].

Frauen verursachten aufgrund höherer Pro-Kopf-Bezüge und mehr Personen mit Bezügen im Jahr 2023 insgesamt höhere Medikamentenkosten als Männer (CHF 4.6 Milliarden vs. CHF 4.4 Milliarden). Die Pro-Kopf-Kosten der Frauen mit Bezügen (CHF 1’244) lagen jedoch unter denen der Männer (CHF 1’387), da sie im Durchschnitt preisgünstigere Medikamente bezogen. Die Pro-Kopf- und Gesamtbezüge der Frauen wuchsen gegenüber dem Vorjahr weniger stark (+0.4% und +1.7%) als jene der Männer (+0.9% und +2.6%).

[[Seite 18/102]]

|  | 2023 | 2022 | 2021 | 2020 | Ø Anstieg pro Jahr seit 2022 [%] | Ø Anstieg pro Jahr seit 2020 [%] |
|---|---|---|---|---|---|---|
| **Medikamentenkosten [Mio. CHF]** |  |  |  |  |  |  |
| Total | 9’021 | 8’518 | 8’131 | 7’783 | +5.9 | +5.0 |
| Frauen | 4’623 | 4’399 | 4’204 | 4’042 | +5.1 | +4.6 |
| Männer | 4’397 | 4’119 | 3’928 | 3’741 | +6.8 | +5.5 |
| **Bezüge [Mio.]** |  |  |  |  |  |  |
| Total | 136.6 | 133.8 | 126.9 | 124.5 | +2.1 | +3.1 |
| Frauen | 78.7 | 77.3 | 73.5 | 72.1 | +1.7 | +3.0 |
| Männer | 57.9 | 56.4 | 53.4 | 52.4 | +2.6 | +3.3 |
| **Anzahl Personen mit Medikamentenbezügen [Mio.]** |  |  |  |  |  |  |
| Total | 6.9 | 6.8 | 6.5 | 6.4 | +1.5 | +2.2 |
| Frauen | 3.7 | 3.7 | 3.6 | 3.5 | +1.3 | +1.9 |
| Männer | 3.2 | 3.1 | 3.0 | 2.9 | +1.7 | +2.6 |
| **Pro-Kopf-Kosten bei Personen mit Bezügen [CHF]** |  |  |  |  |  |  |
| Total | 1’310 | 1’255 | 1’244 | 1’207 | +4.3 | +2.8 |
| Frauen | 1’244 | 1’199 | 1’180 | 1’152 | +3.7 | +2.6 |
| Männer | 1’387 | 1’321 | 1’320 | 1’273 | +5.0 | +2.9 |
| **Pro-Kopf-Bezüge bei Personen mit Bezügen** |  |  |  |  |  |  |
| Total | 19.8 | 19.7 | 19.4 | 19.3 | +0.6 | +0.9 |
| Frauen | 21.2 | 21.1 | 20.6 | 20.5 | +0.4 | +1.0 |
| Männer | 18.3 | 18.1 | 17.9 | 17.8 | +0.9 | +0.8 |

Tabelle 4: Medikamentenkosten, Bezüge, Personen, Pro-Kopf-Kosten und Pro-Kopf-Bezüge, Hochrechnung für die gesamte Schweiz, 2020-2023

Die kantonalen Unterschiede in den Medikamentenbezügen und -kosten waren wie in den Vorjahren auch im Jahr 2023 stark ausgeprägt. Während in Genf, Neuenburg und Tessin die Bezüge pro Person deutlich über dem schweizerischen Durchschnitt von 15.1 Bezügen lagen, hatten Appenzell Innerrhoden, Obwalden, Uri und Zug die niedrigsten Werte (Abbildung 4). Mit Kosten von mehr als CHF 1’100 pro Person waren die Kantone Basel-Landschaft und Tessin die Spitzenreiter bei den Medikamentenkosten, während in Appenzell Innerrhoden Kosten von weniger als CHF 800 pro Person anfielen (Abbildung 5).

Die Medikamentenkosten waren häufig dort am höchsten, wo auch viele Medikamentenbezüge verzeichnet wurden. Für die Unterschiede dürfte die demografische Zusammensetzung der Bevölkerung und in städtischen Kantonen die deutlich höhere Dichte des medizinischen Leistungsangebots ursächlich sein. Aber auch kulturelle Unterschiede dürften eine Rolle spielen. In der Zentral- und Ostschweiz wurden Medikamente vermutlich etwas zurückhaltender eingesetzt als im nationalen Durchschnitt.

[[Seite 19/102]]

**[Grafik 4] Abbildung 4: Durchschnittliche kantonale Medikamentenbezüge pro Kopf, 2023**

Darstellung: Choroplethenkarte der Schweizer Kantone. Wertstatus: Klassen in der Legende beschriftet; Kantonszuordnung am Seitenbild abgelesen und anhand der Füllfarben im gerenderten Bild gegen die Legende geprüft. Keine kantonalen Einzelwerte beschriftet. Die Klassengrenzen werden unverändert übernommen.

Legende (hell nach dunkel): < 10; 10.1 - 12.0; 12.1 - 14.0; 14.1 - 16.0; 16.1 - 18.0; > 18.0.

| Kanton (Kartenbeschriftung) | Klasse laut Legende |
|---|---|
| AG | 12.1 - 14.0 |
| AI | < 10 |
| AR | 12.1 - 14.0 |
| BE | 14.1 - 16.0 |
| BL | 16.1 - 18.0 |
| BS | 16.1 - 18.0 |
| FR | 14.1 - 16.0 |
| GE | 16.1 - 18.0 |
| GL | 16.1 - 18.0 |
| GR | 12.1 - 14.0 |
| JU | 14.1 - 16.0 |
| LU | 14.1 - 16.0 |
| NE | 16.1 - 18.0 |
| NW | 12.1 - 14.0 |
| OW | 12.1 - 14.0 |
| SG | 14.1 - 16.0 |
| SH | 14.1 - 16.0 |
| SO | 14.1 - 16.0 |
| SZ | 14.1 - 16.0 |
| TG | 12.1 - 14.0 |
| TI | > 18.0 |
| UR | 12.1 - 14.0 |
| VD | 14.1 - 16.0 |
| VS | 14.1 - 16.0 |
| ZG | 12.1 - 14.0 |
| ZH | 12.1 - 14.0 |

Durchschnittsanzahl der Bezüge pro Person in der Schweiz: 15.1 Bezüge

**[Ende Grafik 4]**

**[Grafik 5] Abbildung 5: Durchschnittliche kantonale Medikamentenkosten pro Kopf, 2023**

Darstellung: Choroplethenkarte der Schweizer Kantone. Wertstatus: Klassen in der Legende beschriftet; Kantonszuordnung am Seitenbild abgelesen und anhand der Füllfarben im gerenderten Bild gegen die Legende geprüft. Keine kantonalen Einzelwerte beschriftet. Die Klassengrenzen werden unverändert übernommen.

Legende (hell nach dunkel): < 800 CHF; 801 - 850 CHF; 851 - 900 CHF; 901 - 950 CHF; 951 - 1000 CHF; > 1000 CHF.

| Kanton (Kartenbeschriftung) | Klasse laut Legende |
|---|---|
| AG | 901 - 950 CHF |
| AI | < 800 CHF |
| AR | 951 - 1000 CHF |
| BE | > 1000 CHF |
| BL | > 1000 CHF |
| BS | > 1000 CHF |
| FR | 951 - 1000 CHF |
| GE | > 1000 CHF |
| GL | > 1000 CHF |
| GR | > 1000 CHF |
| JU | 951 - 1000 CHF |
| LU | 951 - 1000 CHF |
| NE | > 1000 CHF |
| NW | > 1000 CHF |
| OW | 851 - 900 CHF |
| SG | 951 - 1000 CHF |
| SH | 951 - 1000 CHF |
| SO | > 1000 CHF |
| SZ | 901 - 950 CHF |
| TG | 901 - 950 CHF |
| TI | > 1000 CHF |
| UR | 801 - 850 CHF |
| VD | 951 - 1000 CHF |
| VS | 951 - 1000 CHF |
| ZG | 901 - 950 CHF |
| ZH | 901 - 950 CHF |

Durchschnittskosten pro Person in der Schweiz: CHF 996

**[Ende Grafik 5]**

---

— Ende Teil 1 von 8 · Kontrollwort Teil 1: SUSTEN-23 · weiter mit teil-02.md —
