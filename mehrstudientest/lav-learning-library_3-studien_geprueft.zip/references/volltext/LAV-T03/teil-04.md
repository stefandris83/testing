# LAV-T03 · Volltext · Teil 4 von 8 (PDF-Seiten 45–56 von 102)

Studie: Helsana-Report: Arzneimittel – Medikamente erstmals grösster Kostenblock der Grundversicherung · Quelldatei: arzneimittelreport-2024-31e5177c.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 8 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T03, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 45/102]]

## 3.4 Patente, Generika und Biosimilars

**[Kernaussagen]**

- Die Zeitspanne zwischen der Aufnahme eines Originalpräparats in die SL und dem ersten Nachahmerpräparat (Generikum bzw. Biosimilar) beträgt typischerweise zwischen 9 und 15 Jahren. Die Überprüfung der Preise im Rahmen der Dreijahresüberprüfung des BAG und der durch die Nachahmerpräparate entstehende Wettbewerbsdruck führen in der Folge zu einer Senkung der Preise der Originalpräparate. Die Originalpräparate bleiben in der Regel jedoch teurer als ihre Nachahmerprodukte. Bei Bevorzugung der Originalpräparate entsteht dadurch ein ungenutztes Einsparpotenzial.

- Im Jahr 2023 entfielen etwa 66% der ambulanten Medikamentenkosten in der OKP auf Produkte, die keine Nachahmerpräparate auf der SL haben, ein im internationalen Vergleich tiefer Wert. Das Preisniveau der Originalpräparate bei Aufnahme auf die SL hat sich in den vergangenen Jahren mit CHF 860 auf CHF 1’500 fast verdoppelt. Zeitgleich erhöhten sich auch die Einstiegspreise für Nachahmerpräparate. Dies trägt zu den steigenden Medikamentenkosten bei und schwächt den kostendämpfenden Effekt der im Lebenszyklus einzelner Präparate sinkenden Preise erheblich ab.

- Der Umsatz von Wirkstoffen mit verfügbaren Generika erreichte CHF 2.2 Milliarden, mit einem Anteil der Generika von knapp CHF 1.4 Milliarden. Der Gesamtumsatz aller Biologika mit verfügbaren Biosimilars belief sich auf CHF 482 Millionen, wovon CHF 182 Millionen auf die Biosimilars entfielen.

- Das potenziell ungenutzte Einsparpotenzial durch den Einsatz von Generika und Biosimilars ging leicht zurück, blieb jedoch weiterhin beträchtlich. Es lag im Jahr 2023 bei CHF 263 Millionen respektive CHF 39.4 Millionen. Über den gesamten Zeitraum zwischen 2020 und 2023 summierte sich das Einsparpotenzial auf insgesamt über CHF 1.2 Milliarden.

**[Ende Kernaussagen]**

## 3.4.1 Preisentwicklung patentabgelaufener Medikamente

Der Patentschutz spielt eine zentrale Rolle in der Arzneimittelindustrie. Ein Patent verleiht der Patentinhaberin das Recht, ein neues Medikament für eine befristete Zeit exklusiv zu vermarkten. Während dieser Zeit darf kein anderes Unternehmen das geschützte Medikament ohne die Erlaubnis der Patentinhaberin verkaufen oder importieren. Dieser Schutz ist gerechtfertigt, um die hohen Kosten der klinischen Forschung und der Zulassungsverfahren zu amortisieren. Ohne den Patentschutz wäre es für viele Unternehmen wirtschaftlich unattraktiv, neue Medikamente zu entwickeln, weil die Gewinnspanne durch frühzeitige Konkurrenz erheblich geschmälert würde. Da patentierte Medikamente jedoch häufig sehr teuer sind, kann dies den Zugang von Patientinnen und Patienten zu lebenswichtigen Arzneimitteln einschränken.

Nach Ablauf des Patentschutzes können andere Hersteller Nachahmerpräparate, sogenannte Generika respektive Biosimilars, auf den Markt bringen. Generika und Biosimilars sind gemäss Swissmedic mit ihren Originalen respektive Referenzpräparaten austauschbar, ohne dass Unterschiede in ihrer therapeutischen Wirksamkeit, Verträglichkeit oder Sicherheit bestehen [28].

Im Arzneimittelbereich beträgt der Patentschutz eigentlich maximal 20 Jahre. Unterschiedliche Strategien mit Sekundärpatenten und juristischen Streitigkeiten können diese Zeitdauern jedoch

[[Seite 46/102]]

verlängern. In der Praxis liegt die Zeitspanne zwischen der Aufnahme eines Originalpräparats in die SL und der Aufnahme des ersten Nachahmerpräparats typischerweise zwischen 9 und 15 Jahren (Abbildung 6). Es gab jedoch auch Fälle, in denen Nachahmerpräparate bereits im ersten Jahr nach der Aufnahme des Originals auf die SL kamen. Dies betraf Medikamente, deren Marktzulassung durch Swissmedic oder eine andere ausländische Zulassungsbehörde bereits Jahre zuvor erfolgte, die aber erst kurz vor Ablauf des Patentschutzes in die SL aufgenommen wurden.

Die verbliebene Dauer respektive der Ablauf des Patentschutzes der verschiedenen Präparate wird nicht systematisch in einer Datenbank erfasst. Als Annäherung ist daher in diesem Report nicht der Patentschutz an sich massgebend, sondern die Angaben der SL über die Verfügbarkeit von Nachahmerprodukten. Berücksichtigt wurden als Originale gekennzeichnete Präparate der SL mit neu aufgenommenen Nachahmerpräparaten ab 01. Januar 2010. Alle Medikamente ohne Nachahmerprodukte wurden der Einfachheit halber als patentgeschützt angesehen. Nachahmerpräparate und Originale mit fehlender Kennzeichnung auf der SL wurden als Wirkstoffe ohne Nachahmerpräparate eingestuft. Inzwischen entfallen 66% des Marktumsatzes respektive 52% der Bezüge auf patentgeschützte Präparate, wo aufgrund der Preisbildungskriterien kein echter Preiswettbewerb herrscht und Neuzulassungen immer teurer werden. Im internationalen Vergleich sind das tiefe Zahlen [29], was bedeutet, dass relativ wenige Nachahmerpräparate im Schweizer Markt erhältlich sind.

**[Grafik 6] Abbildung 6: Durchschnittliche Dauer zwischen der Aufnahme der Originalpräparate auf die Spezialitätenliste (SL) und der Aufnahme der jeweils ersten Nachahmerpräparate (Generika oder Biosimilars)**

Darstellung: Säulendiagramm. X-Achse: Jahre zwischen Erstaufnahme Original- und Nachahmerpräparat. Y-Achse: Häufigkeit, 0%, 2%, 4%, 6%, 8%, 10%, 12%, 14%. Wertstatus: abgelesen ca.; Genauigkeit ±0.5 Prozentpunkte. Bei 2 und 3 Jahren ist keine Säule oberhalb der Nulllinie sichtbar.

| Jahre zwischen Erstaufnahme Original- und Nachahmerpräparat | Häufigkeit |
|---|---|
| ≤1 | ca. 1.5% |
| 2 | ca. 0% |
| 3 | ca. 0% |
| 4 | ca. 2% |
| 5 | ca. 1.5% |
| 6 | ca. 2% |
| 7 | ca. 3% |
| 8 | ca. 3.5% |
| 9 | ca. 8% |
| 10 | ca. 13.5% |
| 11 | ca. 7.5% |
| 12 | ca. 11.5% |
| 13 | ca. 9% |
| 14 | ca. 13.5% |
| 15 | ca. 8.5% |
| 16 | ca. 1.5% |
| 17 | ca. 0.5% |
| 18 | ca. 2% |
| 19 | ca. 0.5% |
| 20 | ca. 2% |
| >20 | ca. 10.5% |

**[Ende Grafik 6]**

Aufgrund der geringeren Entwicklungskosten sind Nachahmerpräparate preiswerter als Originalpräparate. Wenn sie in die SL aufgenommen werden, müssen diese Präparate im Vergleich zum Originalpräparat um mindestens 20% billiger sein. Der dadurch entstehende Wettbewerbsdruck führt in der Folge auch zu Preissenkungen der Originalpräparate (Abbildung 7). Bei Originalpräparaten bei denen die Nachahmerpräparate bei Einführung um mehr als 50% billiger sind, ist der Wettbewerbsdruck entsprechend grösser und die Preissenkungen fallen im Schnitt etwas höher aus. Durch diese Dynamik tragen Generika und Biosimilars zur Kosteneffizienz im Gesundheitssystem bei und bremsen das Kostenwachstum. In der Vergangenheit erreichte die Preissenkung der Originalpräparate jedoch meist nicht den Preis der Nachahmerpräparate.

[[Seite 47/102]]

**[Grafik 7] Abbildung 7: Durchschnittliche Preisentwicklung der Original- und Nachahmerpräparate auf der Spezialitätenliste (SL) vor und nach Patentablauf**

Darstellung: Liniendiagramm mit sechs Legendeneinträgen. X-Achse: Jahre seit Einführung des Nachahmerpräparats; senkrechte schwarze Trennlinie bei 0. Y-Achse: Preisänderung, 0%, 10%, 20%, 30%, 40%, 50%, 60%, 70%, 80%, 90%, 100%. Wertstatus: abgelesen ca.; Genauigkeit ±2 Prozentpunkte. Die bordeauxrote Linie bezeichnet Originale vor Patentablauf, die beige Linie Originale nach Patentablauf, die gelbe Linie Nachahmer und die grüne Linie Originale mit Generikum-Einführungspreis unter 50%. Die gepunkteten Linien sind die entsprechenden linearen Trends. Überlagerte Linienabschnitte sind nicht eindeutig ablesbar; – bedeutet ausserhalb des dargestellten Verlaufs der betreffenden Serie.

| Jahre seit Einführung des Nachahmerpräparats | Originale vor Patentablauf | Originale nach Patentablauf | Nachahmer | Originale mit Generikum-Einführungspreis unter 50% | Linear (Originale vor Patentablauf) | Linear (Originale nach Patentablauf) |
|---|---|---|---|---|---|---|
| -5 | ca. 100% | – | – | – | nicht eindeutig ablesbar | ca. 93% |
| -4 | ca. 96% | – | – | – | nicht eindeutig ablesbar | ca. 90% |
| -3 | ca. 94% | – | – | – | nicht eindeutig ablesbar | ca. 88% |
| -2 | ca. 92% | – | – | – | nicht eindeutig ablesbar | ca. 86% |
| -1 | ca. 90% | – | – | – | nicht eindeutig ablesbar | ca. 83% |
| 0 | ca. 86% | ca. 86% | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 80% |
| +1 | – | ca. 77% | ca. 62% | ca. 76% | ca. 84% | nicht eindeutig ablesbar |
| +2 | – | ca. 74% | ca. 62% | ca. 71% | ca. 81% | nicht eindeutig ablesbar |
| +3 | – | ca. 71% | ca. 62% | ca. 70% | ca. 79% | nicht eindeutig ablesbar |
| +4 | – | ca. 69% | ca. 60% | ca. 66% | ca. 77% | nicht eindeutig ablesbar |
| +5 | – | ca. 66% | ca. 58% | ca. 63% | ca. 74% | nicht eindeutig ablesbar |

**[Ende Grafik 7]**

Das Preisniveau der neu auf die SL aufgenommenen Präparate stieg in den letzten Jahren merklich (Abbildung 8). Insbesondere der Markteintritt hochpreisiger Medikamente förderte das allgemeine Preisniveau im patentgeschützten Bereich. Betrug der durchschnittliche Preis der neuen Originalpräparate im Zeitraum 2010 bis 2014 noch etwa CHF 860, waren es zwischen 2019 und 2023 knapp CHF 1’500 (+74%). Auch die durchschnittlichen Einstiegspreise der Nachahmerpräparate stiegen stark. Dies führte zu einem erheblichen Anstieg der Gesamtausgaben im Arzneimittelbereich.

Obwohl die Preise vieler Präparate im Laufe ihres Lebenszyklus sinken, wird dieser kostensenkende Effekt durch die ansteigenden Einstiegspreise stark relativiert. Somit kann der gewünschte dämpfende Einfluss auf die Gesamtmedikamentenkosten nicht in dem erwarteten Mass erzielt werden, da die Preissenkungen im späteren Verlauf nicht mehr ausreichen, um den initialen Anstieg der Kosten zu kompensieren.

**[Grafik 8] Abbildung 8: Durchschnittliches Preisniveau der neuen Präparate auf der Spezialitätenliste (SL)**

Darstellung: Liniendiagramm. X-Achse: Jahr, 2010 bis 2023. Y-Achse: Preisniveau (in CHF), – (Nulllinie), 250, 500, 750, 1’000, 1’250, 1’500, 1’750, 2’000. Gesamt ist bordeauxrot, Nachahmer beige und Originale gelb. Wertstatus: abgelesen ca.; Genauigkeit ±50 CHF. Die im Fliesstext genannten CHF 860 und knapp CHF 1’500 beziehen sich auf mehrjährige Zeiträume, nicht auf einzelne Jahreswerte.

| Jahr | Gesamt | Nachahmer | Originale |
|---|---|---|---|
| 2010 | ca. 400 | ca. 75 | ca. 750 |
| 2011 | ca. 200 | ca. 100 | ca. 275 |
| 2012 | ca. 525 | ca. 100 | ca. 1000 |
| 2013 | ca. 675 | ca. 100 | ca. 1175 |
| 2014 | ca. 650 | ca. 100 | ca. 1125 |
| 2015 | ca. 925 | ca. 175 | ca. 1550 |
| 2016 | ca. 450 | ca. 175 | ca. 675 |
| 2017 | ca. 925 | ca. 150 | ca. 1500 |
| 2018 | ca. 500 | ca. 125 | ca. 850 |
| 2019 | ca. 800 | ca. 200 | ca. 1275 |
| 2020 | ca. 750 | ca. 350 | ca. 1000 |
| 2021 | ca. 1100 | ca. 400 | ca. 2000 |
| 2022 | ca. 1150 | ca. 450 | ca. 1725 |
| 2023 | ca. 1000 | ca. 500 | ca. 1475 |

**[Ende Grafik 8]**

[[Seite 48/102]]

Bisher sind und waren unzureichende finanzielle Anreizmechanismen ein Problem bei der Abgabe von Nachahmerpräparaten. Patientinnen und Patienten mit hohen Medikamentenkosten hatten kaum finanzielle Nachteile, wenn sie sich gegen eine Therapie mit Nachahmerpräparaten entschieden. Gleichzeitig erhielten die abgebenden Leistungserbringer höhere Vergütungen, wenn sie teurere Originalpräparate abgaben, da die Margen preisabhängig waren.

Seit Januar 2024 sind jedoch Änderungen in Kraft, die sowohl die Generika als auch die Biosimilars betreffen. Diese adressieren den erhöhten Selbstbehalt und einen einheitlichen Vertriebsanteil. Ihre Auswirkungen sind im vorliegenden Report noch nicht sichtbar. Es gilt abzuwarten, ob und in welchem Ausmass sich die neuen Regelungen auf die Nutzung von Nachahmerpräparaten auswirken werden.

## 3.4.2 Nutzung und Einsparpotenzial von Generika

Generika sind wirkstoffgleiche Nachahmerprodukte eines Originalmedikaments, die von anderen Herstellern auf den Markt gebracht werden. Sie haben sich als wichtiger Bestandteil der Arzneimittelversorgung etabliert und bieten Patientinnen und Patienten eine qualitativ gleichwertige, aber kostengünstigere Alternative zu Originalmedikamenten. Durch die breite Verfügbarkeit von Generika wird auch die Preisbildung auf dem Markt positiv beeinflusst, was zur Entlastung des Gesundheitssystems beiträgt.

Ende 2023 waren auf der SL etwa 290 Wirkstoffe und Wirkstoffkombinationen mit vorhandenen Generika gekennzeichnet. Der Gesamtumsatz dieser Wirkstoffe betrug über CHF 2.2 Milliarden, wovon knapp CHF 1.4 Milliarden (61.8%) auf Generika entfielen, anteilig etwas mehr als die Substitutionsrate im Vorjahr (60.1%). Der höchste Umsatz unter den Wirkstoffen mit verfügbaren Generika wurde im Jahr 2023 mit dem Magensäurehemmer Pantoprazol erzielt, der CHF 104 Millionen generierte. Der Anteil des Originals am Umsatz lag dabei nur bei 3.1%, was einen leichten Rückgang gegenüber dem Jahr 2022 (3.6%) entsprach.

Die Generikaquote, gemessen an den Bezügen ab der SL-Aufnahme des jeweils ersten Generikums, stieg über alle gekennzeichneten Wirkstoffe mit Nachahmern auf 68.9%, verglichen mit 64.5% im Jahr 2020 (Tabelle 14). Im Jahr 2023 wiesen Orginalpräparate bei etwa 120 von 290 Wirkstoffen einen Anteil von unter 20% im Vergleich zu den Generika auf. Gleichzeitig gab es jedoch etwa 50 Originalpräparate, bei denen die Generikaquote unter 20% lag. Im Vergleich zum Ausland war die Substitutionsrate respektive Generikadurchdringung relativ klein [29], weil es beispielsweise finanzielle Fehlanreize die Abgabe der teureren Originalpräparate begünstigten, es keine verpflichtende Abgabe von Generika gab, Patientinnen und Patienten nicht hinreichend sensitiviert werden, die Preisunterschiede zum Original oftmals vergleichsweise gering waren, Behörden und Versicherer wenig zur Generikaförderung unternehmen und (fast) die ganze Generikapromotion von den Generikanabietern geschultert werden muss. Das umsatzstärkste dieser Präparate war das Kontrastmittel Dotarem® (Gadotersäure) mit einem Umsatz von CHF 31.0 Millionen und einer Generikaquote von lediglich 5.8%, obwohl die ersten Generika bereits im Jahr 2017 in die SL aufgenommen wurden.

[[Seite 49/102]]

| Jahr | Generikaquote | Ungenutztes Einsparpotenzial [CHF] |
|---|---|---|
| 2020 | 64.5% | 206’436’510 |
| 2021 | 65.9% | 203’929’072 |
| 2022 | 68.2% | 264’105’028 |
| 2023 | 68.9% | 263’206’290 |
| Total |  | 937’676’900 |

Tabelle 14: Anteil der Generika-Bezüge und ungenutztes Einsparpotenzial durch Generika, 2020-2023, Hochrechnung für die gesamte Schweiz

Um das theoretische Einsparpotenzial für Generika zu ermitteln, wurde eine ähnliche Methodik wie bei den Biosimilars angewendet (siehe Kapitel 3.4.3). Zwei hypothetische Datensätze wurden erstellt, wobei die abgerechneten Präparatekosten durch den offiziellen Publikumspreis ersetzt wurden respektive durch den günstigsten verfügbaren Generikapreis entsprechender Dosierung und Packungsgrösse. Für Wirkstoffe, bei denen kein Generikum entsprechender Dosierung und Packungsgrösse verfügbar war, wurde die durchschnittliche Preisersparnis angesetzt. Das theoretische Einsparpotenzial ergibt sich aus der Differenz zwischen diesen beiden Datensätzen.

Das ungenutzte Einsparpotenzial durch die vollständige Umstellung auf die jeweils günstigsten Generika betrug zwischen 2020 und 2023 etwa CHF 938 Millionen (Tabelle 14). Während das jährliche Einsparpotenzial im Jahr 2020 noch bei CHF 206 Millionen lag (entsprechend 2.7% der gesamten Medikamentenkosten), stieg es bis zum Jahr 2023 auf über CHF 260 Millionen (2.9% der gesamten Medikamentenkosten). Obwohl die Generikaquote auf der Ebene der Bezüge von 64.5% auf 68.9% zunahm, wuchs das Einsparpotenzial aufgrund des Bevölkerungswachstums und der steigenden Medikamentenverordnungen weiter. Trotz eines Plateaus im Vergleich zum Vorjahr blieb das Potenzial für Kosteneinsparungen durch den Einsatz von Generika somit erheblich.

| Wirkstoff | Original | SL Aufnahme erstes Generikum | Umsatz 2023 [CHF] | Einsparpotenzial [CHF] | Generikaquote |
|---|---|---|---|---|---|
| Fingolimod | Gilenya® | 01.05.2022 | 35’110’732 | 20’498’732 | 36.1% |
| Atorvastatin | Sortis® | 01.03.2012 | 75’414’834 | 19’193’567 | 97.6% |
| Rosuvastatin | Crestor® | 01.04.2017 | 51’860’620 | 17’504’970 | 91.7% |
| Pantoprazol | Pantozol® | 01.01.2010 | 104’349’084 | 12’518’957 | 97.0% |
| Metformin/Sitagliptin | Janumet® | 01.02.2023 | 25’236’079 | 8’310’637 | 8.4% |
| Escitalopram | Cipralex® | 01.06.2014 | 36’031’804 | 7’952’051 | 81.9% |
| Ciclosporin | Lacrycon® | 01.01.2019 | 37’133’920 | 7’193’475 | 33.8% |
| Gadotersäure | Dotarem® | 01.10.2017 | 31’024’003 | 7’092’675 | 5.8% |
| Pregabalin | Lyrica® | 01.11.2015 | 33’535’927 | 6’881’351 | 85.6% |
| Atorvastatin/Ezetimib | Atozet® | 01.05.2021 | 28’542’239 | 6’880’852 | 55.2% |

Tabelle 15: Top 10 der Generika mit dem höchsten ungenutztens Einsparpotenzial und Anteil der Generikabezüge, 2023, Hochrechnung für die gesamte Schweiz

Das grösste Einsparpotenzial durch Generika gab es bei den Präparaten Gilenya® (Fingolimod; zur Behandlung von Multipler Sklerose), Sortis® (Atorvastatin; ein Cholesterinsenker), Crestor®

[[Seite 50/102]]

(Rosuvastatin; ebenfalls ein Cholesterinsenker) und Pantozol® (Pantoprazol; ein Magensäurehemmer), wobei bei jedem dieser Wirkstoffe mehr als CHF 10 Millionen eingespart werden könnten (Tabelle 15). Spitzenreiter war Fingolimod mit einem theoretischen Einsparpotenzial von CHF 20.5 Millionen, was auf die moderate Generikaquote von 36% und den hohen Publikumspreis des Präparats zurückzuführen ist. Bei den anderen drei Präparaten lag die Generikaquote zwar jeweils über 90%, doch die hohen Bezüge und die Preisunterschiede auch zwischen den Generika untereinander führten dennoch zu einer beträchtlichen theoretischen Ersparnis.

Die niedrige Generikaquote bei Fingolimod lässt sich vermutlich darauf zurückführen, dass Generika erst seit Mai 2022 auf der SL geführt werden. Da Multiple Sklerose eine chronische Erkrankung ist, bleiben betroffene Patientinnen und Patienten zumeist bei ihrem ursprünglichen Medikament, sofern keine anderen Gründe für einen Wechsel vorliegen. Es wird sich im nächsten Jahr zeigen, ob die neuen Verordnungsänderungen hier einen Paradigmenwechsel auslösen können. Auch für Metformin/Sitagliptin sind Generika erst seit Februar 2023 verfügbar, und viele Patientinnen und Patienten bevorzugen es, bei ihrem bewährten Medikament zu bleiben. Im Gegensatz dazu handelt es sich bei Gadotersäure um ein Spitalprodukt, bei dem Spitalapothekerinnen und -apotheker direkt mit dem Anbieter über den Einkaufspreis verhandeln. Häufig kann das Originalprodukt zu einem günstigeren Preis angeboten werden und wird dann an die Patientinnen und Patienten abgegeben, die auf diese Entscheidung keinen Einfluss haben.

Es bleibt abzuwarten, ob und in welchem Ausmass sich das ungenutzte Einsparpotenzial ab 2024 verändern wird, wenn die neuen Regelungen zum höheren Selbstbehalt bei Wahl des Originals und der einheitliche Vertriebsanteil für wirkstoffgleiche Medikamente in Kraft treten (siehe auch Kapitel 3.4.1).

## 3.4.3 Nutzung und Einsparpotenzial von Biosimilars

Biologika sind Medikamente, die sich durch eine hochkomplexe Struktur und ein hohes Molekulargewicht auszeichnen. Sie werden entweder aus biologischen Organismen hergestellt, oder unter Verwendung von biologischen Prozessen produziert. Aufgrund ihrer aufwändigen Entwicklung und Herstellung sind Biologika jedoch oft teurer als herkömmliche Arzneimittel.

Nach Ablauf des Patentschutzes für ein Biologikum können andere Hersteller zu den Referenzpräparaten sogenannte Biosimilars auf den Markt bringen. Die ersten Biosimilars, Tevagrastim® und Filgrastim Mepha®, wurden im Januar 2009 in die SL aufgenommen. Diese beiden Präparate enthalten den Wirkstoff Filgrastim, der zur Behandlung von Neutropenien eingesetzt wird, indem die Entstehung und Freisetzung neutrophiler Granulozyten gefördert wird.

Ende des Jahres 2023 fanden sich insgesamt 42 als Biosimilars gekennzeichnete Präparate für 15 Referenzpräparate auf der SL (Tabelle 16). Im Jahr 2023 kamen gegenüber 2022 drei neue Biosimilars hinzu. Zwei davon basierten auf Wirkstoffen, für die bereits Biosimilars verfügbar sind: Yuflyma® (Adalimumab, L04AB04), unter anderem eingesetzt zur Behandlung der rheumatoiden Arthritis, von Morbus Crohn und Psoriasis, und Vegzelma® (Bevacizumab, L01XC07) zur Behandlung verschiedener Krebsarten wie Dickdarmkrebs, Brustkrebs und Lungenkrebs. Mit dem Präparat Byooviz® (Ranibizumab, S01LA04), das unter anderem zur Behandlung der feuchten altersbezogenen Makuladegeneration und bei einem Makulaödem eingesetzt wird, bekam zusätzlich ein weiteres Referenzprodukt (Lucentis®) erstmalig Konkurrenz.

[[Seite 51/102]]

| Wirkstoff | Referenzpräparat | Biosimilar | Erstaufnahme SL | Kosten 2023 [CHF] | Anteil Bezüge [%] |
|---|---|---|---|---|---|
| Enoxaparin | Clexane® | Nein | 15.03.1990 | 10’251’002 | 98.6 |
| Enoxaparin | Hepaxane® | Ja | 01.07.2022 | 10’880 | 0.1 |
| Enoxaparin | Inhixa® | Ja | 01.08.2020 | 126’326 | 1.3 |
| Insulin glargin | Lantus® | Nein | 15.09.2003 | 13’675’786 | 98.2 |
| Insulin glargin | Abasaglar® | Ja | 01.09.2015 | 212’544 | 1.8 |
| Ranibizumab | Lucentis® | Nein | 01.04.2014 | 3’052’743 | 97.8 |
| Ranibizumab | Byooviz® | Ja | 01.05.2023 | 51’398 | 2.2 |
| Teriparatid | Forsteo® | Nein | 01.11.2005 | 5’927’281 | 78.6 |
| Teriparatid | Livogiva® | Ja | 01.11.2021 | 0 | 0.0 |
| Teriparatid | Movymia® | Ja | 01.09.2019 | 406’845 | 6.5 |
| Teriparatid | Sondelbay® | Ja | 01.11.2022 | 48’302 | 0.8 |
| Teriparatid | Terrosa® | Ja | 01.09.2019 | 873’513 | 14.0 |
| Follitropin alfa | Gonal-F® | Nein | 15.03.1998 | 3’143’821 | 77.6 |
| Follitropin alfa | Ovaleap® | Ja | 01.11.2018 | 650’833 | 22.4 |
| Adalimumab | Humira® | Nein | 01.07.2003 | 96’864’731 | 75.7 |
| Adalimumab | Abrilada® | Ja | 01.06.2021 | 2’852’994 | 1.9 |
| Adalimumab | Amgevita® | Ja | 01.11.2019 | 11’628’398 | 6.0 |
| Adalimumab | Hukyndra® | Ja | 01.08.2022 | 1’073’605 | 0.6 |
| Adalimumab | Hulio® | Ja | 01.08.2020 | 1’783’531 | 1.0 |
| Adalimumab | Hyrimoz® | Ja | 01.11.2019 | 20’518’690 | 12.4 |
| Adalimumab | Idacio® | Ja | 01.08.2020 | 645’439 | 0.3 |
| Adalimumab | Imraldi® | Ja | 01.07.2020 | 3’572’757 | 1.8 |
| Adalimumab | Yuflyma® | Ja | 01.01.2023 | 565’605 | 0.4 |
| Somatropin | Genotropin® | Nein | 23.05.1990 | 766’604 | 60.4 |
| Somatropin | Omnitrope® | Ja | 01.05.2015 | 1’482’303 | 39.6 |
| Infliximab | Remicade® | Nein | 01.07.2000 | 79’328’160 | 59.5 |
| Infliximab | Inflectra® | Ja | 01.08.2016 | 31’215’634 | 26.3 |
| Infliximab | Remsima® | Ja | 01.01.2016 | 17’189’919 | 14.3 |
| Epoetin alfa | Eprex® | Nein | 27.07.1988 | 502’693 | 56.4 |
| Epoetin alfa | Binocrit® | Ja | 01.10.2009 | 298’745 | 43.6 |
| Trastuzumab | Herceptin® | Nein | 15.03.1999 | 16’925’581 | 55.6 |
| Trastuzumab | Herzuma® | Ja | 01.12.2021 | 2’146’954 | 8.2 |
| Trastuzumab | Kanjinti® | Ja | 01.02.2020 | 2’884’712 | 10.6 |
| Trastuzumab | Ogivri® | Ja | 01.09.2020 | 1’483’515 | 7.5 |
| Trastuzumab | Trazimera® | Ja | 01.10.2019 | 4’931’092 | 18.0 |
| Etanercept | Enbrel® | Nein | 15.04.2000 | 22’585’610 | 50.1 |
| Etanercept | Benepali® | Ja | 01.04.2019 | 5’071’063 | 9.7 |
| Etanercept | Erelzi® | Ja | 01.07.2018 | 13’783’275 | 40.2 |
| Rituximab | MabThera® | Nein | 15.03.1998 | 18’185’538 | 49.1 |

[[Seite 52/102]]

| Wirkstoff | Referenzpräparat | Biosimilar | Erstaufnahme SL | Kosten 2023 [CHF] | Anteil Bezüge [%] |
|---|---|---|---|---|---|
| Rituximab | Rixathon® | Ja | 01.09.2018 | 12’555’237 | 46.8 |
| Rituximab | Truxima® | Ja | 01.01.2019 | 980’228 | 4.2 |
| Pegfilgrastim | Neulasta® | Nein | 01.11.2003 | 9’765’781 | 37.9 |
| Pegfilgrastim | Fulphila® | Ja | 01.06.2020 | 165’238 | 0.8 |
| Pegfilgrastim | Grasustek | Ja | 01.09.2021 | 1’400’481 | 7.1 |
| Pegfilgrastim | Pelgraz® | Ja | 01.11.2019 | 3’468’957 | 18.1 |
| Pegfilgrastim | Pelmeg® | Ja | 01.01.2020 | 49’845 | 0.4 |
| Pegfilgrastim | Ziextenzo® | Ja | 01.07.2020 | 6’720’173 | 35.7 |
| Bevacizumab | Avastin® | Nein | 15.01.2005 | 16’194’700 | 34.3 |
| Bevacizumab | Bevacizumab-Teva® | Ja | 01.07.2021 | 2’883’397 | 8.5 |
| Bevacizumab | Mvasi® | Ja | 01.07.2020 | 7’894’198 | 20.0 |
| Bevacizumab | Oyavas® | Ja | 01.08.2021 | 2’069’836 | 5.6 |
| Bevacizumab | Vegzelma® | Ja | 01.08.2023 | 417’735 | 1.1 |
| Bevacizumab | Zirabev® | Ja | 01.08.2020 | 11’089’741 | 30.5 |
| Filgrastim | Neupogen Amgen® | Nein | 15.03.1994 | 2’093’957 | 17.2 |
| Filgrastim | Accofil® | Ja | 01.11.2019 | 236’177 | 2.4 |
| Filgrastim | Filgrastim-Teva® | Ja | 01.03.2010 | 2’878’664 | 44.4 |
| Filgrastim | Zarzio® | Ja | 01.05.2010 | 3’891’878 | 36.0 |

Hinweis: Auflistung ohne Kombinationspräparate

Tabelle 16: Kosten und Anteil an den Bezügen der Referenzpräparate und Biosimilars die auf der Spezialitätenliste (SL) geführt werden (Stand Dezember 2023), 2023, Hochrechnung für die gesamte Schweiz

Der Gesamtumsatz aller Biologika mit verfügbaren Biosimilars betrug im Jahr 2023 CHF 481.5 Millionen. Davon entfielen CHF 182.2 Millionen (37.8%) auf Biosimilars. Im Vergleich zum Vorjahr, in dem der Umsatz bei CHF 143.6 Millionen (30.7%) lag, zeigte sich eine deutliche Zunahme. Beispiele hierfür sind die Wirkstoffe Adalimumab (Humira® und Biosimilars) und Infliximab (Remicade® und Biosimilars), die beide zur Behandlung von rheumatoider Arthritis, Morbus Crohn und Psoriasis eingesetzt werden und die auch im Jahr 2023 die höchsten Umsätze unter den Wirkstoffen mit verfügbaren Biosimilars erzielten. Der Umsatz von Adalimumab belief sich auf CHF 139.5 Millionen, wobei der Anteil der Biosimilar-Bezüge bei lediglich 24.3% lag. Immerhin stellte dies eine Steigerung gegenüber dem Vorjahr (+20.4%) dar. Bei Infliximab betrug der Umsatz CHF 127.7 Millionen, und die Biosimilars machten 40.5% der Bezüge aus, gegenüber 34.5% im Vorjahr.

Unter allen Wirkstoffen mit verfügbaren Biosimilars gab es nur zwei Wirkstoffe (Infliximab und Bevacizumab), die ausschliesslich als intravenöse Infusion verabreicht werden und drei weitere Wirkstoffe bei denen sowohl Injektionen als auch intravenöse Infusionen möglich waren. Diese fünf Wirkstoffe unterschieden sich bezüglich Gesamtumsatz und Biosimilarquote nicht von den anderen Wirkstoffen, jedoch waren die Preisabstände zwischen Referenzprodukt und Biosimilar in der Regel geringer (Abbildung 9). Tendenziell waren die Preisabstände bei kleineren Biosimilarquoten (<40%) etwas grösser als bei höheren Biosimilarquoten, was aber grösstenteils auf die geringe Anzahl an Wirkstoffen mit intravenöser Darreichungsform zurückzuführen ist.

[[Seite 53/102]]

**[Grafik 9] Abbildung 9: Gesamtumsatz der Biosimilars im Vergleich zur Biosimilarquote (bezogen auf die Bezüge ab SL-Aufnahme) sowie nach Verabreichungsart und Preisabstand zwischen Referenzpräparat und Biosimilar, 2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Blasendiagramm. X-Achse: Gesamtumsatz [Mio CHF], – (Nulllinie), 20, 40, 60, 80, 100, 120, 140, 160. Y-Achse: Biosimilarquote, 0%, 20%, 40%, 60%, 80%, 100%. Legende: subkutane/intravitreale Injektion (rot); intravenöse Infusion (ggf. auch subkutane Injektion möglich) (beige); Preisabstand (Blasengrösse). Wertstatus: abgelesen ca.; Genauigkeit ±2 Mio CHF und ±2 Prozentpunkte. Die Blasengrösse hat keine bezifferte Skala; der Preisabstand ist daher nicht quantitativ ablesbar. Die drei roten Blasen bei ca. 3–7 Mio CHF und ca. 20–27% überlagern sich; ihre Zuordnung zu Follitropin alfa, Teriparatid und Ranibizumab ist nicht eindeutig ablesbar. Die Werte von Infliximab und Adalimumab sind mit den Fliesstextangaben auf Seite 52 innerhalb der Ablesegenauigkeit vereinbar.

| Wirkstoff | Gesamtumsatz [Mio CHF] | Biosimilarquote | Verabreichungsart | Preisabstand |
|---|---|---|---|---|
| Filgrastim | ca. 9 | ca. 83% | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |
| Pegfilgrastim | ca. 22 | ca. 62% | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |
| Rituximab | ca. 32 | ca. 51% | intravenöse Infusion (ggf. auch subkutane Injektion möglich) | nicht quantitativ ablesbar |
| Bevacizumab | ca. 41 | ca. 66% | intravenöse Infusion (ggf. auch subkutane Injektion möglich) | nicht quantitativ ablesbar |
| Etanercept | ca. 41 | ca. 50% | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |
| Epoetin alfa | ca. 1 | ca. 44% | intravenöse Infusion (ggf. auch subkutane Injektion möglich) | nicht quantitativ ablesbar |
| Somatropin | ca. 2 | ca. 40% | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |
| Trastuzumab | ca. 28 | ca. 44% | intravenöse Infusion (ggf. auch subkutane Injektion möglich) | nicht quantitativ ablesbar |
| Follitropin alfa | nicht eindeutig ablesbar | nicht eindeutig ablesbar | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |
| Teriparatid | nicht eindeutig ablesbar | nicht eindeutig ablesbar | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |
| Ranibizumab | nicht eindeutig ablesbar | nicht eindeutig ablesbar | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |
| Enoxaparin | ca. 10 | ca. 3% | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |
| Insulin glargin | ca. 14 | ca. 1% | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |
| Infliximab | ca. 128 | ca. 40% | intravenöse Infusion (ggf. auch subkutane Injektion möglich) | nicht quantitativ ablesbar |
| Adalimumab | ca. 139 | ca. 24% | subkutane/intravitreale Injektion | nicht quantitativ ablesbar |

[Hinweis Transkription: Tabelle 16 auf Seite 51 nennt für Byooviz® (Ranibizumab) 2.2% Anteil Bezüge. Im überlagerten Diagrammbereich lässt sich der mit Ranibizumab beschriftete Punkt nicht zuverlässig diesem Wert zuordnen; keine Korrektur oder eindeutige Zuordnung vorgenommen.]

**[Ende Grafik 9]**

Trotz Verbesserungen verläuft die Marktentwicklung bei den meisten Biosimilars respektive die Substitution von Referenzpräparaten eher schleppend (Abbildung 10). Die Biosimilarquote in der Schweiz, gemessen an den Bezügen, lag über alle biosimilarfähigen Wirkstoffe hinweg bei im internationalen Vergleich tiefen 26.7%. Die regionalen Unterschiede waren beträchtlich, mit Quoten zwischen 17.2% in Nidwalden und 43.2% in Appenzell Innerrhoden. Im Jahr 2023 hatten bei vier Referenzpräparaten die jeweiligen Biosimilars zusammen einen Marktanteil von über 50%. Allerdings gab es nur zwei Biosimilars, die sich gegen das Referenzpräparat durchsetzen konnten und dieses anteilmässig überholten. Dazu zählten Filgrastim-Teva® und Zarzio®, beides Filgrastim-Biosimilars zum Referenzpräparat Neupogen Amgen®. Das Potenzial von Biosimilars wird also trotz positiver Entwicklungen bei weitem noch nicht ausgeschöpft, was auf verschiedene Gründe zurückzuführen ist.

**[Grafik 10] Abbildung 10: Biosimilarquote (bezogen auf die Bezüge ab SL-Aufnahme) in 2022 (beige) und 2023 (rot), total und nach Referenzpräparaten, sortiert nach Ersteinführung eines Biosimilars**

Darstellung: Horizontale Balkenpaare. X-Achse: Biosimilarquote, 0%, 20%, 40%, 60%, 80%, 100%. Wertstatus: abgelesen ca.; Genauigkeit ±1 Prozentpunkt. Der Gesamtwert 2023 von 26.7% steht im Fliesstext derselben Seite und stimmt mit dem Balken überein. 2022 beige, 2023 rot; die beiden Total-Balken sind hellblau bzw. dunkelblau. Für Lucentis® ist kein 2022-Balken dargestellt (–). Die Jahreszahl beim Referenzpräparat bezeichnet die Ersteinführung eines Biosimilars.

| Referenzpräparat, Ersteinführung eines Biosimilars | 2022 (beige) | 2023 (rot) |
|---|---|---|
| Total | ca. 22.5% | 26.7% (Fliesstext derselben Seite) |
| Lucentis®, 2023 | – | ca. 3.5% |
| Clexane®, 2020 | ca. 1% | ca. 1.5% |
| Avastin®, 2020 | ca. 51.5% | ca. 65.5% |
| Neulasta®, 2019 | ca. 53.5% | ca. 62% |
| Humira®, 2019 | ca. 20.5% | ca. 24.5% |
| Herceptin®, 2019 | ca. 28% | ca. 44.5% |
| Forsteo®, 2019 | ca. 16.5% | ca. 21.5% |
| Gonal-F®, 2018 | ca. 23% | ca. 22.5% |
| MabThera®, 2018 | ca. 46.5% | ca. 51% |
| Enbrel®, 2018 | ca. 46.5% | ca. 50% |
| Remicade®, 2016 | ca. 34.5% | ca. 40.5% |
| Lantus®, 2015 | ca. 2% | ca. 1.5% |
| Genotropin®, 2015 | ca. 24% | ca. 39.5% |
| Eprex®, 2009 | ca. 32% | ca. 43.5% |
| Neupogen®, 2009 | ca. 84.5% | ca. 83% |

**[Ende Grafik 10]**

[[Seite 54/102]]

Trotz der nachgewiesenen Wirksamkeit und Sicherheit von Biosimilars bestehen seitens Leistungserbringern und Patientinnen und Patienten nach wie vor Bedenken, die in aller Regel unbegründet sind. Biosimilars sind ihren Referenzarzneimitteln gegenüber gleichwertig und können ebenso eingesetzt werden [30,31]. Daher sollte sowohl bei der Erstverordnung als auch bei der Fortsetzungstherapie die wirtschaftlichste Alternative gewählt werden. Bisher fehlten jedoch adäquate finanzielle Anreize. Seit 2024 sind nun neue Regelungen in Kraft, die sowohl Biosimilars als auch die Generika betreffen. Die Auswirkungen dieser Massnahmen sind im jetzigen Arzneimittelreport noch nicht sichtbar. Bei mangelndem Erfolg könnten striktere Vorgaben zur wirtschaftlichen Verordnung, wie sie in Deutschland erfolgreich eingesetzt wurden, die Biosimilarquoten erhöhen [32,33].

Wie hoch wäre das theoretische Einsparpotenzial, wenn alle verfügbaren Biosimilars ihre entsprechenden Referenzprodukte vollständig auf dem Markt ersetzen würden? Um diese Frage zu beantworten, wurden zwei hypothetische Datensätze erstellt. Im ersten Datensatz basierten die Berechnungen auf den Helsana-Daten, wobei zur Vereinheitlichung die Präparatekosten durch die Publikumspreise vom 01. Januar des Folgejahres ersetzt wurden. Im zweiten Datensatz wurden für alle Bezüge die Publikumspreise des günstigsten verfügbaren Biosimilars mit entsprechender Dosierung respektive Packungsgrösse ab dem Zeitpunkt der SL-Aufnahme verwendet (ebenfalls basierend auf den Preisen vom 01. Januar des jeweiligen Folgejahres), sofern ein solches Biosimilar bereits auf dem Markt verfügbar war. War kein entsprechendes Biosimilar-Äquivalent für die Dosierung/Packungsgrösse des Referenzprodukts vorhanden, wurde die durchschnittliche Preisersparnis herangezogen. Eventuelle Preismodelle wurden hierbei nicht berücksichtigt. Das theoretische Einsparpotenzial ergab sich dann aus der Differenz zwischen den beiden hypothetischen Datensätzen.

| Wirkstoff | Referenzprodukt | Einsparpotenzial 2020 [CHF] | Einsparpotenzial 2021 [CHF] | Einsparpotenzial 2022 [CHF] | Einsparpotenzial 2023 [CHF] | Einsparpotenzial Gesamt [CHF] |
|---|---|---|---|---|---|---|
| Infliximab | Remicade® | 24’005’401 | 8’163’384 | 8’248’965 | 9’696’249 | 50’113’999 |
| Adalimumab | Humira® | 27’517’090 | 28’017’369 | 23’217’752 | 9’674’348 | 88’426’558 |
| Etanercept | Enbrel® | 7’691’023 | 6’621’418 | 6’058’073 | 5’603’509 | 25’974’023 |
| Pegfilgrastim | Neulasta® | 8’608’338 | 6’588’379 | 4’742’239 | 4’776’331 | 24’715’287 |
| Enoxaparin | Clexane® | 1’109’815 | 2’447’747 | 1’921’115 | 1’923’502 | 7’402’179 |
| Trastuzumab | Herceptin® | 6’536’996 | 6’124’610 | 4’917’227 | 1’552’112 | 19’130’945 |
| Rituximab | MabThera® | 4’485’153 | 4’035’837 | 3’627’044 | 1’420’660 | 13’568’694 |
| Bevacizumab | Avastin® | 4’555’352 | 8’100’121 | 5’077’267 | 1’317’942 | 19’050’682 |
| Teriparatid | Forsteo® | 3’645’765 | 3’037’549 | 1’227’327 | 1’037’289 | 8’947’929 |
| Insulin glargin | Lantus® | 3’229’058 | 2’697’695 | 2’604’301 | 938’247 | 9’469’300 |
| Follitropin alfa | Gonal-F® | 634’951 | 805’327 | 745’812 | 736’998 | 2’923’088 |
| Ranibizumab | Lucentis® | - | - | - | 466’782 | 466’782 |
| Filgrastim | Neupogen® | 443’918 | 218’736 | 191’309 | 183’223 | 1’037’185 |
| Somatropin | Genotropin® | 56’601 | 66’399 | 61’785 | 66’522 | 251’308 |
| Epoetin alfa | Eprex® | 72’077 | 49’969 | 60’757 | 46’802 | 229’605 |
| Total |  | 92’591’538 | 76’974’540 | 62’700’972 | 39’440’514 | 271’707’564 |

Tabelle 17: Ungenutztes Einsparpotenzial durch Biosimilars, 2020-2023, Hochrechnung für die gesamte Schweiz

[[Seite 55/102]]

Das ungenutzte Einsparpotenzial im Vergleich zu einer vollständigen Umstellung auf Biosimilars belief sich zwischen 2020 und 2023 insgesamt auf etwa CHF 272 Millionen (Tabelle 17). Während es im Jahr 2020 noch bei über CHF 92 Millionen lag (entsprechend 1.1% der gesamten Medikamentenkosten), ist es seither kontinuierlich gesunken. Im Jahr 2023 erreichte es mit CHF 39 Millionen (0.4% der gesamten Medikamentenkosten) seinen vorläufig niedrigsten Stand. Trotz der positiven Entwicklungen blieb das ungenutzte Einsparpotenzial insgesamt weiterhin erheblich.

Das grösste Einsparpotenzial durch Biosimilars gab es bei den Präparaten Remicade® und Humira®, die jeweils CHF 9.7 Millionen ausmachten. Dieses Potenzial war grösstenteils auf die hohen Gesamtumsätze dieser Präparate zurückzuführen, aber auch auf die moderaten Biosimilarquoten von 41% respektive 24%. Trotz Preissenkungen und einer damit einhergehenden deutlichen Reduktion des Einsparpotenzials gegenüber dem Vorjahr war daher das Potenzial von Humira® noch immer beträchtlich. Bei Neulasta® war das Einsparpotenzial mit CHF 4.8 Millionen ebenfalls hoch, trotz einer Biosimilarquote von immerhin 62%. Hier spielte der hohe Publikumspreis eine wesentliche Rolle. Im Gegensatz dazu war das Einsparpotenzial bei Lantus® vergleichsweise gering, obwohl die Biosimilarquote nur 2% betrug, was auf den relativ niedrigen Publikumspreis zurückzuführen war.

Das Einsparpotenzial zwischen den Kantonen variierte stark, wie das Beispiel Adalimumab (Humira® und Biosimilars) zeigt (Tabelle 18). Im Kanton Zürich entfielen aufgrund der Bevölkerungszahl und vieler Bezüge CHF 1.9 Millionen auf das ungenutzte Potenzial, etwa ein Fünftel des Gesamtpotenzials. Die Biosimilarquote lag mit 24% im schweizerischen Durchschnitt. Das geringste Einsparpotenzial von CHF 10’000 hatte Appenzell Innerrhoden, trotz einer Biosimilarquote von 0%. Hier gab es im Jahr 2023 aber auch nur etwa 100 Adalimumab-Bezüge. Der höchste Biosimilaranteil wurde im Kanton Jura erreicht (56%), bei einem Einsparpotenzial von CHF 45’000 und ebenfalls geringer Bezüge.

| Kanton | Biosimilarquote [%] | Einsparpotenzial [CHF] |
|---|---|---|
| AG | 26.5 | 960’202 |
| AI | 0 | 10’265 |
| AR | 0 | 80’615 |
| BE | 24.6 | 1’006’537 |
| BL | 22.9 | 404’861 |
| BS | 22.2 | 237’962 |
| FR | 36.1 | 255’071 |
| GE | 24.5 | 682’334 |
| GL | 18.9 | 33’171 |
| GR | 32.6 | 129’482 |
| JU | 55.5 | 44’535 |
| LU | 26.7 | 370’196 |
| NE | 29.3 | 263’960 |
| NW | 49.1 | 35’679 |
| OW | 5.0 | 59’842 |
| SG | 16.2 | 399’701 |
| SH | 51.2 | 33’617 |
| SO | 23.9 | 342’857 |
| SZ | 26.6 | 163’588 |
| TG | 23.4 | 235’613 |
| TI | 32.7 | 233’050 |
| UR | 23.4 | 43’913 |
| VD | 19.5 | 952’348 |
| VS | 14.0 | 564’468 |
| ZG | 24.7 | 209’978 |
| ZH | 23.7 | 1’920’504 |

Tabelle 18: Anteil der Biosimilar-Bezüge und ungenutztes Einsparpotenzial nach Kanton am Beispiel von Adalimumab (Humira® und Biosimilars), 2023, Hochrechnung für die gesamte Schweiz

[[Seite 56/102]]

## 4 Ergebnisse spezifischer Teil

## 4.1 Sicherheitswarnungen zu Januskinase -Inhibitoren (JAKi): Einfluss auf die Verwendung und wirtschaftliche Implikationen

**[Kernaussagen]**

- Januskinase-Inhibitoren (JAKi) sind eine relativ neue Medikamentenklasse, die zur Behandlung verschiedener chronisch-entzündlicher und autoimmuner Erkrankungen, wie beispielsweise der rheumatoiden Arthritis, eingesetzt werden. Sie gelten als hochwirksam.

- Aufgrund von Sicherheitsbedenken, insbesondere bei älteren Personen mit kardialen Risikofaktoren, wurden weltweit Warnungen der zuständigen Zulassungsbehörden herausgegeben. Es liess sich auch auf Basis der Helsana-Abrechnungsdaten eine erhöhte Inzidenz für kritische Ereignisse zwischen rheumatisch erkrankten Personen mit und ohne JAKi-Nutzung zeigen (Gefährdungsquotient: 1.60), insbesondere für Thromboembolien (1.93), Mortalität (1.88), schwerwiegende Infektionen (1.65) und kardiovaskuläre Ereignisse (1.35). Diese Ereignisse waren also bei den Personen mit Nutzung etwa 60% häufiger als bei jenen ohne Nutzung.

- Im Jahr 2019 erfolgte die erste Warnung zu Tofacitinib (Xeljanz®), woraufhin ein Rückgang der Bezüge zu beobachten war. Anfang 2023 wurden die Warnungen auf drei weitere JAKi (Cibinqo®, Olumiant®, Rinvoq®) ausgedehnt. Der darin eingeschlossene Wirkstoff Upadacitinib (Rinvoq®) wurde trotzdem weiterhin häufig eingesetzt.

- Zwischen den Jahren 2018 und 2023 ging der Anteil an Personen mit Risikofaktoren bei Tofacitini-Nutzenden leicht zurück. Bei Personen mit einem Risiko für schwere Infektionen war der Rückgang vergleichsweise gross, jedoch blieb der Anteil der über 65-Jährigen und der Personen mit Risiko für schwerwiegende kardiovaskuläre Ereignisse stabil.

- Die jährlichen Gesamtkosten für eine medikamentöse Behandlung von Patientinnen und Patienten im Jahr 2023 betrugen CHF 16’300 für Personen mit JAKi-Bezügen. Im Vergleich dazu kostete eine Person ohne JAKi-Bezüge (aber mit JAKi-Bezügen in früheren Jahren) «nur» CHF 10’300 und verursachte somit CHF 6’000 (37%) weniger Kosten

- Die Sicherheitsrisiken verschoben nachteilig die Benefit-Harm-Balance, die zur ursprünglichen Bewertung der Wirtschaftlichkeit herangezogen wurde. Die nun höheren Kosten für die Überwachung der Patientinnen und Patienten und für die Behandlung der negativen Effekte beeinträchtigen die Kosten-Effektivität. Es liegt nahe, die Marktpreise für JAKi nach unten zu korrigieren, um die langfristigen finanziellen Auswirkungen der Therapien bei nicht anders zu behandelnden Patientinnen und Patienten auszugleichen.

**[Ende Kernaussagen]**

## 4.1.1 Einleitung

Januskinase-Inhibitoren (JAKi) stellen eine hochwirksame Klasse von Medikamenten dar, unter anderem für die Behandlung verschiedener chronisch-entzündlicher und autoimmuner Erkrankungen. Ihre Anwendungsbereiche erstrecken sich über eine breite Palette von Indikationen, darunter rheumatologische Krankheiten wie rheumatoide Arthritis, entzündliche Darmerkrankungen wie Colitis ulcerosa sowie dermatologische Erkrankungen wie Psoriasis und atopische Dermatitis. Die JAKi bilden

---

— Ende Teil 4 von 8 · Kontrollwort Teil 4: BIETSCHHORN-67 · weiter mit teil-05.md —
