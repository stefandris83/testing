# LAV-T03 · Volltext · Teil 8 von 8 (PDF-Seiten 93–102 von 102)

Studie: Helsana-Report: Arzneimittel – Medikamente erstmals grösster Kostenblock der Grundversicherung · Quelldatei: arzneimittelreport-2024-31e5177c.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 8 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T03, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 93/102]]

[Fortsetzung Tabelle 27 von Seite 92; Spaltenüberschriften übernommen.]

| Wirkstoff | Präparatname | Typ | Lungenkrebs-spezifisch | Datum Aufnahme SL |
|---|---|---|---|---|
| Everolimus | Afinitor® | zielgerichete Therapie | Nein | 01.02.2010 |
| Entrectinib | Rozlytrek® | zielgerichete Therapie | Nein | 01.05.2022 |
| Selpercatinib | Retsevmo® | zielgerichete Therapie | Nein | 01.03.2022 |
| Pralsetinib | Gavreto® | zielgerichete Therapie | Nein | N/A |
| Bevacizumab | Avastin®, Biosimilars | zielgerichete Therapie | Nein | 15.01.2005 |
| Gefitinib | Iressa® | zielgerichete Therapie | Ja | 01.03.2011 |
| Erlotinib | Tarceva® | zielgerichete Therapie | Ja | 01.06.2005 |
| Afatinib | Giotrif® | zielgerichete Therapie | Ja | 01.03.2014 |
| Osimertinib | Tagrisso® | zielgerichete Therapie | Ja | 01.08.2018 |
| Mobocertinib | Exkivity® | zielgerichete Therapie | Ja | N/A |
| Ceritinib | Zykadia® | zielgerichete Therapie | Ja | 01.08.2020 |
| Alectinib | Alecensa® | zielgerichete Therapie | Ja | 01.08.2017 |
| Brigatinib | Alunbrig® | zielgerichete Therapie | Ja | 01.12.2021 |
| Capmatinib | Tabrecta® | zielgerichete Therapie | Ja | 01.04.2022 |
| Tepotinib | Tepmetko® | zielgerichete Therapie | Ja | 01.08.2022 |
| Amivantamab | Rybrevant® | zielgerichete Therapie | Ja | 01.09.2022 |
| Nivolumab | Opdivo® | Immuntherapie | Nein | 01.04.2016 |
| Pembrolizumab | Keytruda® | Immuntherapie | Nein | 01.05.2020 |
| Durvalumab | Imfinzi® | Immuntherapie | Nein | 01.09.2018 |
| Atezolizumab | Tecentriq® | Immuntherapie | Nein | 01.07.2017 |
| Cemiplimab | Libtayo® | Immuntherapie | Nein | 01.11.2022 |
| Ipilimumab* | Yervoy® | Immuntherapie | Nein | 01.01.2012 |

Anmerkung: Stand Spezialitätenliste (SL) 31.12.2023

*nur in Kombination mit Nivolumab seit 2020

Tabelle 27: Inkludierte lungenkrebsspezifische und unspezifische Onkologika

[Hinweis Transkription: Tabelle 27 enthält auf Seiten 92–93 insgesamt 17 Zytostatika, 19 als «zielgerichete Therapie» bezeichnete Wirkstoffe und 6 Immuntherapien einschliesslich Ipilimumab*, das laut Fussnote nur in Kombination mit Nivolumab seit 2020 eingesetzt wird. 12 Zeilen sind als lungenkrebsspezifisch («Ja») gekennzeichnet. Der Fliesstext auf Seite 78 nennt dagegen 5 Immuntherapien und 14 spezifisch für Lungenkrebs zugelassene Onkologika. Alle Originalangaben unverändert übernommen.]

[[Seite 94/102]]

## Abkürzungen

|  |  |
|---|---|
| ADHS | Aufmerksamkeitsdefizit-/Hyperaktivitätsstörung |
| ALK | Anaplastic Lymphoma Kinase |
| ATC | Anatomisch-Therapeutisch-Chemisch |
| AVM | Alternative Versicherungsmodelle |
| BAG | Bundesamt für Gesundheit |
| BFS | Bundesamt für Statistik |
| BSC | bestmögliche unterstützende Therapie (best supportive care) |
| CHF | Schweizer Franken |
| CT | Computertomographie |
| DHPC | Dear Healthcare Professional |
| DMARDs | Disease-Modifying Antirheumatic Drugs |
| DOAK | Direkte orale Antikoagulantien |
| EGFR | Epidermaler Wachstumsfaktor-Rezeptors (epidermal growth factor receptor) |
| EMA | Europäische Arzneimittelagentur |
| FDA | U.S. Food and Drug Administration |
| FSME | Frühsommer-Meningo-Enzephalitis |
| HIV | Humanes Immunschwäche Virus |
| ICD | Internationale statistische Klassifikation der Krankheiten und verwandter Gesundheitsprobleme |
| JAKi | Januskinase-Inhibitoren |
| KRAS | Kirsten Rat Sarcoma Viral Oncogene |
| MACE | schwerwiegendes kardiovaskuläres Ereignis |
| MRI | Magnetresonanztomographie (magnetic resonance imaging) |
| NSAR | nichtsteroidale Antirheumatika |
| NSCLC | nicht-kleinzelliges Bronchialkarzinom (non-small cell lung cancer) |
| OKP | Obligatorische Krankenpflegeversicherung, Grundversicherung |
| SCLC | kleinzelliges Bronchialkarzinom (small cell lung cancer) |
| RAAS | Renin-Angiotensin-Aldosteron-System |
| siRNA | small interfering RNA |
| SL | Spezialitätenliste |
| TKI | Tyrosinkinase |
| TNFi | Tumor-Nekrose-Faktor-Inhibitoren |

[[Seite 95/102]]

## Abbildungsverzeichnis

|  |  |
|---|---|
| Abbildung 1: Altersverteilung des Helsana-Versichertenkollektivs im Vergleich zur Gesamtbevölkerung (Quelle: Bundesamt für Statistik [2], BFS), 2023 | 12 |
| Abbildung 2: Anteil von alternativen Versicherungsmodellen (AVM) gegenüber dem Standardmodell (ST) und Anteil an Personen mit Medikamentenbezügen nach Modelltyp im Helsana-Versichertenkollektiv, 2020-2023 | 12 |
| Abbildung 3: Übersicht der gewählten Franchisen im gesamten Helsana-Versichertenkollektiv und bei Personen mit Medikamentenbezügen, 2023 | 12 |
| Abbildung 4: Durchschnittliche kantonale Medikamentenbezüge pro Kopf, 2023 | 19 |
| Abbildung 5: Durchschnittliche kantonale Medikamentenkosten pro Kopf, 2023 | 19 |
| Abbildung 6: Durchschnittliche Dauer zwischen der Aufnahme der Originalpräparate auf die Spezialitätenliste (SL) und der Aufnahme der jeweils ersten Nachahmerpräparate (Generika oder Biosimilars) | 46 |
| Abbildung 7: Durchschnittliche Preisentwicklung der Original- und Nachahmerpräparate auf der Spezialitätenliste (SL) vor und nach Patentablauf | 47 |
| Abbildung 8: Durchschnittliches Preisniveau der neuen Präparate auf der Spezialitätenliste (SL) | 47 |
| Abbildung 9: Gesamtumsatz der Biosimilars im Vergleich zur Biosimilarquote (bezogen auf die Bezüge ab SL-Aufnahme) sowie nach Verabreichungsart und Preisabstand zwischen Referenzpräparat und Biosimilar, 2023, Hochrechnung für die gesamte Schweiz | 53 |
| Abbildung 10: Biosimilarquote (bezogen auf die Bezüge ab SL-Aufnahme) in 2022 (beige) und 2023 (rot), total und nach Referenzpräparaten, sortiert nach Ersteinführung eines Biosimilars | 53 |
| Abbildung 11: Anzahl der Personen mit Verwendung von JAKi nach Indikationsgebiet und Geschlecht, 2023, Hochrechnung für die gesamte Schweiz | 62 |
| Abbildung 12: JAKi-Bezüge pro Quartal nach Wirkstoff und Zeitpunkte der DHPCs, 2013-2023, Hochrechnung für die gesamte Schweiz | 63 |
| Abbildung 13: JAKi-Bezüge pro Quartal nach Indikationsgebiet, 2013-2023, Hochrechnung für die gesamte Schweiz | 64 |
| Abbildung 14: Verhältnis der Bezüge medikamentöser Behandlungsmöglichkeiten bei Personen mit mindestens einmaliger JAKi-Einnahme bei rheumatischer (A), gastrointestinaler (B) und dermatologischer Indikation (C), 2013-2023, Hochrechnung für die gesamte Schweiz | 66 |
| Abbildung 15: Anteil an mit Tofacitinib (Xeljanz®)-behandelten Personen mit Behandlungsabbrüchen und solchen mit Start anderer medikamentöser Behandlungsmöglichkeiten im rheumatischen Bereich, 2013-2023, Hochrechnung für die gesamte Schweiz | 67 |
| Abbildung 16: Medikamentöse Gesamtkosten der JAKi-Nutzenden über alle Indikationsgebiete, 2013-2023, Hochrechnung für die gesamte Schweiz | 68 |
| Abbildung 17: Gesamtkosten der JAKi und weiteren medikamentösen Behandlungen im rheumatologischen Bereich für Personen mindestens einem JAKi-Bezug im jeweiligen Jahr (A) und ohne jemalige JAKi-Bezüge (B), 2013-2023, Hochrechnung für die gesamte Schweiz | 69 |
| Abbildung 18: Jährliche Pro-Kopf-Kosten der JAKi und weiteren medikamentösen Behandlungen im rheumatologischen Bereich zwischen Personen mit mindestens einem JAKi-Bezug im jeweiligen Jahr (A) und ohne jemalige JAKi-Bezüge (B), 2013-2023, Hochrechnung für die gesamte Schweiz | 70 |
| Abbildung 19: Anzahl Personen mit Medikamentenbezügen nach Kategorie und Jahr, 2013-2023, Hochrechnung für die gesamte Schweiz | 79 |
| Abbildung 20: Jährliche Bezüge in den Kategorien Chemotherapie, zielgerichtete Therapie und Immuntherapie bei Personen mit Lungenkrebs, 2013-2023, Hochrechnung für die gesamte Schweiz | 79 |
| Abbildung 21: Gesamtkosten von Onkologika bei Lungenkrebs aufgeteilt nach Kategorien, 2013-2023, Hochrechnung für die gesamte Schweiz | 80 |
| Abbildung 22: Onkologikakosten pro Person mit Lungenkrebs nach Kategorien, 2013-2023, Hochrechnung für die gesamte Schweiz | 80 |

[[Seite 96/102]]

|  |  |
|---|---|
| Abbildung 23: Behandlungsmuster beim Lungenkrebs bei Personen mit Diagnose und Therapiebeginn im Jahr 2021 | 84 |
| Abbildung 24: Behandlungsmuster beim Lungenkrebs bei Personen mit Diagnose und Therapiebeginn im Jahr 2016 | 85 |

[[Seite 97/102]]

## Tabellenverzeichnis

|  |  |
|---|---|
| Tabelle 1: Allgemeine Kennzahlen der durch die Helsana-Gruppe grundversicherten Personen, 2020-2023 | 11 |
| Tabelle 2: Ebenen der ATC-Klassifikation am Beispiel des Diabetes-Medikaments Metformin [4] | 15 |
| Tabelle 3: ATC-Klassifikation, Ebene 1 (anatomische Hauptgruppen) | 16 |
| Tabelle 4: Medikamentenkosten, Bezüge, Personen, Pro-Kopf-Kosten und Pro-Kopf-Bezüge, Hochrechnung für die gesamte Schweiz, 2020-2023 | 18 |
| Tabelle 5: Anatomische Hauptgruppen (ATC 1). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz | 21 |
| Tabelle 6: Die 15 kostenintensivsten therapeutischen Medikamentengruppen (ATC 3). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz | 22 |
| Tabelle 7: Die 15 meistbezogenen therapeutischen Medikamentengruppen (ATC 3). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz | 23 |
| Tabelle 8: Die 20 kostenintensivsten Wirkstoffe (ATC 5). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz | 24 |
| Tabelle 9: Die 20 meistbezogenen Wirkstoffe (ATC 5). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz | 25 |
| Tabelle 10: Die 20 kostenintensivsten Präparate. Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz | 26 |
| Tabelle 11: Umsatzsteigerung der jeweils fünf Wirkstoffe mit dem grössten absoluten Wachstum innerhalb der wachstumsstärksten therapeutischen Medikamentengruppen, 2023, Hochrechnung für die gesamte Schweiz | 27 |
| Tabelle 12: Übersicht und monatliche Kosten der neuen Wirkstoffe im Jahr 2023, Hochrechnung | 38 |
| Tabelle 13: Entwicklung der durchschnittlichen monatlichen Kosten der neuen Wirkstoffe aus dem Jahr 2022, Hochrechnung für die gesamte Schweiz | 44 |
| Tabelle 14: Anteil der Generika-Bezüge und ungenutztes Einsparpotenzial durch Generika, 2020-2023, Hochrechnung für die gesamte Schweiz | 49 |
| Tabelle 15: Top 10 der Generika mit dem höchsten ungenutztens Einsparpotenzial und Anteil der Generikabezüge, 2023, Hochrechnung für die gesamte Schweiz | 49 |
| Tabelle 16: Kosten und Anteil an den Bezügen der Referenzpräparate und Biosimilars die auf der Spezialitätenliste (SL) geführt werden (Stand Dezember 2023), 2023, Hochrechnung für die gesamte Schweiz | 52 |
| Tabelle 17: Ungenutztes Einsparpotenzial durch Biosimilars, 2020-2023, Hochrechnung für die gesamte Schweiz | 54 |
| Tabelle 18: Anteil der Biosimilar-Bezüge und ungenutztes Einsparpotenzial nach Kanton am Beispiel von Adalimumab (Humira® und Biosimilars), 2023, Hochrechnung für die gesamte Schweiz | 55 |
| Tabelle 19: Zugelassene JAKi (Stand: Dezember 2023) | 58 |
| Tabelle 20: Einteilung der Indikationsgebiete | 59 |
| Tabelle 21: Direct-Healthcare-Professional-Communications (DHPC) zu JAKi in der Schweiz | 61 |
| Tabelle 22: Inzidenz und Prävalenz von Lungenkrebs bei Personen mit und ohne Onkologikabezug, 2012-2023, Hochrechnung für die gesamte Schweiz | 76 |
| Tabelle 23: Top 20 zielgerichtete Therapien und Immuntherapien für Lungenkrebs, 2013 und 2023, Hochrechnung für die gesamte Schweiz | 81 |
| Tabelle 24: Anteil Personen mit zielgerichteter und Immuntherapie mit Bezügen sonstiger Medikamentengruppen, 2023, Hochrechnung für die gesamte Schweiz | 83 |
| Tabelle 25: Zahlen und Kosten zu Therapielinien 2016 vs. 2021 | 86 |
| Tabelle 26: Vergleich geschätzte Fallzahlen Nationales Krebsregister Schweiz vs. Helsanadaten | 92 |
| Tabelle 27: Inkludierte lungenkrebsspezifische und unspezifische Onkologika | 93 |

[[Seite 98/102]]

## Quellenverzeichnis

[1] Helsana Versicherungen AG. Helsana Geschäftsbericht 2023.

[2] Bundesamt für Statistik. Stand und Entwicklung. https://www.bfs.admin.ch/bfs/de/home/statistiken/bevoelkerung/stand-entwicklung.html (accessed July 30, 2024).

[3] Carl DL, Vokinger KN. Patients’ access to drugs with rebates in Switzerland – Empirical analysis and policy implications for drug pricing in Europe. Lancet Reg Health – Eur 2021;3. https://doi.org/10.1016/j.lanepe.2021.100050.

[4] WHO Collaborating Centre for Drug Statistics Methodology (WHOCC). ATC/DDD Index 2023. https://www.whocc.no/atc_ddd_index/ (accessed October 16, 2023).

[5] BAG. Statistik der obligatorischen Krankenversicherung. https://www.bag.admin.ch/bag/de/home/zahlen-und-statistiken/statistiken-zur-krankenversicherung/statistik-der-obligatorischen-krankenversicherung.html (accessed October 3, 2024).

[6] BFS. Starkes Bevölkerungswachstum in der Schweiz im Jahr 2023 - Bestand und Entwicklung der Bevölkerung der Schweiz im Jahr 2023: definitive Ergebnisse | Medienmitteilung. https://www.bfs.admin.ch/asset/de/32174452 (accessed September 11, 2024).

[7] Leitlinienprogramm Onkologie. S3-Leitlinie Diagnostik, Therapie und Nachsorge für Patienten mit monoklonaler Gammopathie unklarer Signifikanz (MGUS) oder Multiplem Myelom, Langversion 1.0. AWMF-Registernummer: 018/035OL 2022.

[8] Schur N, Twerenbold S, Reinau D, Schwenkglenks M, Meier CR. Helsana Arzneimittelreport 2020.

[9] Twerenbold S, Schur N, Wittwer N, Schneider C, Marxer C, Spöndlin J, et al. Helsana Arzneimittelreport 2022.

[10] McMurray JJV, DeMets DL, Inzucchi SE, Køber L, Kosiborod MN, Langkilde AM, et al. A trial to evaluate the effect of the sodium–glucose co-transporter 2 inhibitor dapagliflozin on morbidity and mortality in patients with heart failure and reduced left ventricular ejection fraction (DAPA-HF). Eur J Heart Fail 2019;21:665–75. https://doi.org/10.1002/ejhf.1432.

[11] Packer M, Anker SD, Butler J, Filippatos G, Pocock SJ, Carson P, et al. Cardiovascular and Renal Outcomes with Empagliflozin in Heart Failure. N Engl J Med 2020;383:1413–24. https://doi.org/10.1056/NEJMoa2022190.

[12] Lehmann R. Swiss Diabetes Guide. 2021 211516 2021;21:251–6.

[13] McDonagh TA, Metra M, Adamo M, Gardner RS, Baumbach A, Böhm M, et al. Focused Update of the 2021 ESC Guidelines for the diagnosis and treatment of acute and chronic heart failure. Eur Heart J 2023;44:3627–39. https://doi.org/10.1093/eurheartj/ehad195.

[14] Dieter Kaag. Häufig gestellte Fragen zum rationalen Einsatz von Protonenpumpeninhibitoren. Krankenhauspharmazie 2018. https://www.krankenhauspharmazie.de/heftarchiv/2018/12/haufig-gestellte-fragen-zum-rationalen-einsatz-von-protonenpumpeninhibitoren.html (accessed October 12, 2023).

[15] Muheim L, Signorell A, Markun S, Chmiel C, Neuner-Jehle S, Blozik E, et al. Potentially inappropriate proton-pump inhibitor prescription in the general population: a claims-based retrospective time trend analysis. Ther Adv Gastroenterol 2021;14:1756284821998928. https://doi.org/10.1177/1756284821998928.

[16] Kahwati LC, Weber RP, Pan H, Gourlay M, LeBlanc E, Coker-Schwimmer M, et al. Vitamin D, Calcium, or Combined Supplementation for the Primary Prevention of Fractures in Community-Dwelling Adults: Evidence Report and Systematic Review for the US Preventive Services Task Force. JAMA 2018;319:1600–12. https://doi.org/10.1001/jama.2017.21640.

[17] Manson JE, Bassuk SS. Vitamin D Research and Clinical Practice: At a Crossroads. JAMA 2015;313:1311–2. https://doi.org/10.1001/jama.2015.1353.

[18] Taylor PN, Davies JS. A review of the growing risk of vitamin D toxicity from inappropriate practice. Br J Clin Pharmacol 2018;84:1121–7. https://doi.org/10.1111/bcp.13573.

[19] Cannon CP, Blazing MA, Giugliano RP, McCagg A, White JA, Theroux P, et al. Ezetimibe Added to Statin Therapy after Acute Coronary Syndromes. N Engl J Med 2015;372:2387–97. https://doi.org/10.1056/NEJMoa1410489.

[20] Schur N, Twerenbold S, Rothweiler LJ, Blankart KE, Fischer R, Stöckle M, et al. Helsana Arzneimittelreport 2023.

[[Seite 99/102]]

[21] Fralick M, Colacci M, Schneeweiss S, Huybrechts KF, Lin KJ, Gagne JJ. Effectiveness and Safety of Apixaban Compared With Rivaroxaban for Patients With Atrial Fibrillation in Routine Practice: A Cohort Study. Ann Intern Med 2020;172:463–73. https://doi.org/10.7326/M19-2522.

[22] Ray WA, Chung CP, Stein CM, Smalley W, Zimmerman E, Dupont WD, et al. Association of Rivaroxaban vs Apixaban With Major Ischemic or Hemorrhagic Events in Patients With Atrial Fibrillation. JAMA 2021;326:2395–404. https://doi.org/10.1001/jama.2021.21222.

[23] BAG. Eisentherapie bei Eisenmangel ohne Blutarmut. https://www.bag.admin.ch/bag/de/home/versicherungen/krankenversicherung/krankenversicherung-leistungen-tarife/hta/hta-projekte/eisentherapie.html (accessed October 7, 2024).

[24] SGE. Vegetarische Ernährung. https://www.sge-ssn.ch/ich-und-du/essen-und-trinken/vegetarische-ernaehrung/ (accessed September 10, 2024).

[25] Heier JS, Khanani AM, Quezada Ruiz C, Basu K, Ferrone PJ, Brittain C, et al. Efficacy, durability, and safety of intravitreal faricimab up to every 16 weeks for neovascular age-related macular degeneration (TENAYA and LUCERNE): two randomised, double-masked, phase 3, non-inferiority trials. Lancet Lond Engl 2022;399:729–40. https://doi.org/10.1016/S0140-6736(22)00010-1.

[26] Gemeinsamer Bundesausschuss. Trastuzumab-Deruxtecan (neues Anwendungsgebiet: Mammakarzinom, HER2-low). https://www.arzneimitteltherapie.de/heftarchiv/2023/09/trastuzumab-deruxtecan-neues-anwendungsgebiet-mammakarzinom-her2-low.html (accessed August 7, 2024).

[27] BAG. Schweizerischer Impfplan 2023. https://www.ksa.ch/dokumente/kantonsspital-aarau/fachbereiche/reisemedizin/schweizerischer-impfplan-de-reisemedizin-ksa.pdf (accessed October 2, 2024).

[28] Swissmedic. Anpassung der Wegleitung Zulassung Biosimilar. https://www.swissmedic.ch/swissmedic/de/home/humanarzneimittel/authorisations/informationen/anpassung-wl-zl-biosimilar.html (accessed October 31, 2023).

[29] Health at a Glance 2023. OECD 2023. https://www.oecd.org/en/publications/health-at-a-glance-2023_7a7afb35-en.html (accessed November 5, 2024).

[30] Arzneimittelkommission der deutschen Ärzteschaft (AkdÄ). Leitfaden der Arzneimittelkommission der deutschen Ärzteschaft (AkdÄ). Biosimilars 2021.

[31] European Medicines Agency (EMA), Heads of Medicines Agencies (HMA). Biosimilar medicines can be interchanged. Eur Med Agency 2022. https://www.ema.europa.eu/en/news/biosimilar-medicines-can-be-interchanged (accessed October 12, 2023).

[32] Blankart KE, Arndt F. Physician-Level Cost Control Measures and Regional Variation of Biosimilar Utilization in Germany. Int J Environ Res Public Health 2020;17:4113. https://doi.org/10.3390/ijerph17114113.

[33] Birkner B, Blankart KE. The Effect of Biosimilar Prescription Targets for Erythropoiesis-Stimulating Agents on the Prescribing Behavior of Physicians in Germany. Value Health 2022;25:1528–38. https://doi.org/10.1016/j.jval.2022.03.005.

[34] Ytterberg SR, Bhatt DL, Mikuls TR, Koch GG, Fleischmann R, Rivas JL, et al. Cardiovascular and Cancer Risk with Tofacitinib in Rheumatoid Arthritis. N Engl J Med 2022;386:316–26. https://doi.org/10.1056/NEJMoa2109927.

[35] Harigai M. Growing evidence of the safety of JAK inhibitors in patients with rheumatoid arthritis. Rheumatology 2019;58:i34–42. https://doi.org/10.1093/rheumatology/key287.

[36] Harrington R, Nokhatha SAA, Conway R. JAK Inhibitors in Rheumatoid Arthritis: An Evidence-Based Review on the Emerging Clinical Data. J Inflamm Res 2020;13:519–31. https://doi.org/10.2147/JIR.S219586.

[37] Samuel C, Cornman H, Kambala A, Kwatra SG. A Review on the Safety of Using JAK Inhibitors in Dermatology: Clinical and Laboratory Monitoring. Dermatol Ther 2023;13:729–49. https://doi.org/10.1007/s13555-023-00892-5.

[38] Olivera PA, Lasa JS, Bonovas S, Danese S, Peyrin-Biroulet L. Safety of Janus Kinase Inhibitors in Patients With Inflammatory Bowel Diseases or Other Immune-mediated Diseases: A Systematic Review and Meta-Analysis. Gastroenterology 2020;158:1554-1573.e12. https://doi.org/10.1053/j.gastro.2020.01.001.

[39] Swissmedic. https://www.swissmedic.ch/swissmedic/de/home.html (accessed July 10, 2024).

[40] HCI Solutions AG. Compendium. https://compendium.ch/ (accessed July 10, 2024).

[41] BAG. Spezialitätenliste (SL). https://www.spezialitaetenliste.ch/ (accessed September 26, 2023).

[[Seite 100/102]]

[42] Swissmedic. DHPC – Xeljanz (Tofacitinib) 26.04.2019. https://www.swissmedic.ch/swissmedic/de/home/humanarzneimittel/marktueberwachung/healthcare-professional-communications/dhpc-xeljanz_tofacitinib.html (accessed July 10, 2024).

[43] Swissmedic. DHPC – Xeljanz (Tofacitinib) 04.06.2019. https://www.swissmedic.ch/swissmedic/de/home/humanarzneimittel/marktueberwachung/healthcare-professional-communications/dhpc_xeljanz.html (accessed July 10, 2024).

[44] Swissmedic. DHPC – Xeljanz (Tofacitinib) 29.01.2021. https://www.swissmedic.ch/swissmedic/de/home/humanarzneimittel/marktueberwachung/healthcare-professional-communications/dhpc-xeljanz-tofacitinib.html (accessed July 10, 2024).

[45] Swissmedic. DHPC – Xeljanz (Tofacitinib) 25.06.2021. https://www.swissmedic.ch/swissmedic/de/home/humanarzneimittel/marktueberwachung/healthcare-professional-communications/dhcp-xeljanz-tofacitinib-2.html (accessed July 10, 2024).

[46] Swissmedic. DHPC - Xeljanz (Tofacitinib) 15.09.2021. https://www.swissmedic.ch/swissmedic/de/home/humanarzneimittel/marktueberwachung/healthcare-professional-communications/dhpc-xeljanz-tofacitinib0.html (accessed July 10, 2024).

[47] Swissmedic. DHPC – Januskinase (JAK)-Inhibitoren / Cibinqo (Abrocitinib), Olumiant (Baricitinib), Rinvoq (Upadacitinib), Xeljanz (Tofacitinib) 01.03.2023. https://www.swissmedic.ch/swissmedic/de/home/humanarzneimittel/marktueberwachung/healthcare-professional-communications/dhpc-januskinase-jak-inhibitoren.html (accessed July 10, 2024).

[48] Dragotto M, D’Onghia M, Trovato E, Tognetti L, Rubegni P, Calabrese L. Therapeutic Potential of Targeting the JAK/STAT Pathway in Psoriasis: Focus on TYK2 Inhibition. J Clin Med 2024;13:3091. https://doi.org/10.3390/jcm13113091.

[49] Landis MN, Smith SR, Berstein G, Fetterly G, Ghosh P, Feng G, et al. Efficacy and safety of topical brepocitinib cream for mild-to-moderate chronic plaque psoriasis: a phase IIb randomized double-blind vehicle-controlled parallel-group study. Br J Dermatol 2023;189:33–41. https://doi.org/10.1093/bjd/ljad098.

[50] Mease P, Helliwell P, Silwinska-Stanczyk P, Miakisz M, Ostor A, Peeva E, et al. Efficacy and Safety of the TYK2/JAK1 Inhibitor Brepocitinib for Active Psoriatic Arthritis: A Phase IIb Randomized Controlled Trial. Arthritis Rheumatol Hoboken NJ 2023;75:1370–80. https://doi.org/10.1002/art.42519.

[51] Zeiser R, Socié G, Schroeder MA, Abhyankar S, Vaz CP, Kwon M, et al. Efficacy and safety of itacitinib versus placebo in combination with corticosteroids for initial treatment of acute graft-versus-host disease (GRAVITAS-301): a randomised, multicentre, double-blind, phase 3 trial. Lancet Haematol 2022;9:e14–25. https://doi.org/10.1016/S2352-3026(21)00367-7.

[52] Lebwohl M, Warren RB, Sofen H, Imafuku S, Paul C, Szepietowski JC, et al. Deucravacitinib in plaque psoriasis: 2-year safety and efficacy results from the phase III POETYK trials. Br J Dermatol 2024;190:668–79. https://doi.org/10.1093/bjd/ljae014.

[53] BFS. Schweizerischer Krebsbericht 2021 - Stand und Entwicklungen. https://www.bfs.admin.ch/asset/de/19305696 (accessed September 10, 2024).

[54] BAG. Faktenblatt - Kostenentwicklung Medikamente. 2023. https://www.bag.admin.ch/bag/de/home/versicherungen/krankenversicherung/krankenversicherung-versicherte-mit-wohnsitz-in-der-schweiz/praemien-kostenbeteiligung/praemienvergleich.html (accessed September 11, 2024) (accessed September 11, 2024)

[55] Serra-Burriel M, Perényi G, Laube Y, Mitchell AP, Vokinger KN. The cancer premium – explaining differences in prices for cancer vs non-cancer drugs with efficacy and epidemiological endpoints in the US, Germany, and Switzerland: a cross sectional study. eClinicalMedicine 2023;61. https://doi.org/10.1016/j.eclinm.2023.102087.

[56] BFS. Bevölkerungsdaten im Zeitvergleich, 1950-2022. 2023. https://www.bfs.admin.ch/asset/de/27225422 (accessed September 10, 2024).

[57] Shokoohi A, Al-Hashami Z, Moore S, Pender A, Wong SK, Wang Y, et al. Effect of targeted therapy and immunotherapy on advanced nonsmall-cell lung cancer outcomes in the real world. Cancer Med 2022;11:86–93. https://doi.org/10.1002/cam4.4427.

[58] Järvholm B, Hedman L, Landström M, Liv P, Burdorf A, Torén K. Changing smoking habits and the occurrence of lung cancer in Sweden—a population analysis. Eur J Public Health 2024;34:566–71. https://doi.org/10.1093/eurpub/ckae050.

[59] Onkopedia. Lungenkarzinom, nicht-kleinzellig (NSCLC). https://www.onkopedia.com/de/onkopedia/guidelines/lungenkarzinom-nicht-kleinzellig-nsclc (accessed October 24, 2024).

[[Seite 101/102]]

[60] Stenger M. Neoadjuvant/Adjuvant Pembrolizumab in Resectable NSCLC n.d. https://ascopost.com/issues/december-25-2023/neoadjuvantadjuvant-pembrolizumab-in-resectable-nsclc/ (accessed November 5, 2024).

[61] Araghi M, Mannani R, Heidarnejad maleki A, Hamidi A, Rostami S, Safa SH, et al. Recent advances in non-small cell lung cancer targeted therapy; an update review. Cancer Cell Int 2023;23:1–26. https://doi.org/10.1186/s12935-023-02990-y.

[62] OECD. Access to oncology medicines in EU and OECD countries. 2024. https://www.oecd.org/en/publications/access-to-oncology-medicines-in-eu-and-oecd-countries_c263c014-en.html (accessed October 24, 2024).

[63] Schweizerischen Gesellschaft für Rheumatologie. Behandlungsempfehlungen der SRG. https://www.rheuma-net.ch/de/fachinformationen/behandlungsempfehlungen (accessed July 10, 2024).

[64] Gossec L, Kerschbaumer A, Ferreira RJO, Aletaha D, Baraliakos X, Bertheussen H, et al. EULAR recommendations for the management of psoriatic arthritis with pharmacological therapies: 2023 update. Ann Rheum Dis 2024;83:706–19. https://doi.org/10.1136/ard-2024-225531.

[65] AWMF. Leitlinienregister. https://register.awmf.org/de/leitlinien/detail/060-004 (accessed July 10, 2024).

[66] DGRh. Deutsche Gesellschaft für Rheumatologie. https://dgrh.de/Start/Publikationen/Empfehlungen/Medikation/Januskinase-Inhibitoren-(JAKi).html (accessed July 10, 2024).

[67] Thiele K, Albrecht K, Alexander T, Aringer M, Eidner T, Henes J, et al. Standardpräsentation 2021: Daten aus der Kerndokumentation. Charité - Universitätsmedizin Berlin; 2023. https://doi.org/10.17169/REFUBIUM-39305.

[68] Fleischmann R, Pangan AL, Song I-H, Mysler E, Bessette L, Peterfy C, et al. Upadacitinib Versus Placebo or Adalimumab in Patients With Rheumatoid Arthritis and an Inadequate Response to Methotrexate: Results of a Phase III, Double-Blind, Randomized Controlled Trial. Arthritis Rheumatol Hoboken NJ 2019;71:1788–800. https://doi.org/10.1002/art.41032.

[69] Combe B, Kivitz A, Tanaka Y, van der Heijde D, Simon JA, Baraf HSB, et al. Filgotinib versus placebo or adalimumab in patients with rheumatoid arthritis and inadequate response to methotrexate: a phase III randomised clinical trial. Ann Rheum Dis 2021;80:848–58. https://doi.org/10.1136/annrheumdis-2020-219214.

[70] AWMF. Leitlinienregister. https://register.awmf.org/de/leitlinien/detail/013-027 (accessed July 10, 2024).

[71] IQWiG. Upadacitinib (atopische Dermatitis) – Nutzenbewertung gemäß § 35a SGB V. https://www.iqwig.de/download/a21-116_upadacitinib_nutzenbewertung-35a-sgb-v_v1-0.pdf (accessed July 10, 2024).

[72] DÄG. Januskinase-Inhibitoren: Therapie mit Wermutstropfen: Reaktivierung von Herpes zoster. Dtsch Ärztebl 2019. https://www.aerzteblatt.de/archiv/209421/Januskinase-Inhibitoren-Therapie-mit-Wermutstropfen-Reaktivierung-von-Herpes-zoster (accessed July 10, 2024).

[73] Klein B, Treudler R, Simon JC. JAK Inhibitoren in der Dermatologie – kleine Moleküle, große Wirkung? Übersicht über Wirkmechanismus, Studienergebnisse und mögliche unerwünschte Wirkungen. JDDG J Dtsch Dermato‐l Ges 2022;20:19–25. https://doi.org/10.1111/ddg.14668_g.

[74] AWMF. Leitlinienregister. https://register.awmf.org/de/leitlinien/detail/021-009 (accessed July 10, 2024).

[75] Solitano V, Vuyyuru SK, MacDonald JK, Zayadi A, Parker CE, Narula N, et al. Efficacy and Safety of Advanced Oral Small Molecules for Inflammatory Bowel Disease: Systematic Review and Meta-Analysis. J Crohns Colitis 2023;17:1800–16. https://doi.org/10.1093/ecco-jcc/jjad100.

[[Seite 102/102 · Rückseite]]

## Mit unserem Engagement setzen wir uns nachhaltig für die Gesellschaft ein.

Helsana-Gruppe

Postfach

8081 Zürich

helsana.ch

Zur Helsana-Gruppe gehören Helsana Versicherungen AG, Helsana Zusatzversicherungen AG und Helsana Unfall AG.

---

— Ende Teil 8 von 8 · Kontrollwort Teil 8: DOM-18 · DOKUMENTENDE LAV-T03 —
