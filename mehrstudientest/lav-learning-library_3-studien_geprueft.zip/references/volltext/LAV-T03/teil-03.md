# LAV-T03 · Volltext · Teil 3 von 8 (PDF-Seiten 32–44 von 102)

Studie: Helsana-Report: Arzneimittel – Medikamente erstmals grösster Kostenblock der Grundversicherung · Quelldatei: arzneimittelreport-2024-31e5177c.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 8 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T03, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 32/102]]

Magenschutzmittel bekannte Wirkstoff Pantoprazol (Pantozol® und Generika, A02BC02) hatte daran den grössten Anteil. Die Kosten im Jahr 2023 lagen bei CHF 104.3 Millionen und überschritten damit die CHF 100 Millionen-Marke (Tabelle 9). Trotz vergleichsweise geringer Pro-Kopf-Kosten von CHF 82 ergab sich durch die hohe Anzahl an Bezügen (2.8 Millionen) eine hohe Kostenrelevanz. Die meisten anderen Protonenpumpeninhibitoren, wie beispielsweise Esomeprazol (Nexium® und Generika, A02BC05) und Omeprazol (Antramups® und Generika, A02BC01), hatten dagegen zumeist rückläufige Kosten aufgrund abfallender Bezüge. Seit einigen Jahren gibt es neue Hinweise für unerwünschte Wirkungen, weshalb eine strengere Indikationsstellung vermehrt in den Fokus rücken sollte. Ein Absetzen nach Wegfall medizinischer Notwendigkeit macht daher nicht nur aus ökonomischen, sondern auch aus medizinischen Gründen, Sinn [14,15].

In der therapeutischen Gruppe der Vitamine (A11) gab es im Jahr 2023 dagegen einen Rückgang der Kosten um CHF 3.5 Millionen (-8.7%) auf CHF 36.5 Millionen (Tabelle 6). Ein grosser Anteil dieses Rückgangs entfiel auf Vitamin D3-Monopräparate (Colecalciferol, A11CC05). Die Kosten für Vitamin D3 fielen auf CHF 30.8 Millionen (-7.3%), was auf einen Rückgang der Bezüge (-9.7%) zurückzuführen ist (Tabelle 9). Vitamin D3 ist für seine Rolle für die Knochengesundheit und Immunfunktion bekannt und wird häufig zur Vorbeugung und Behandlung von Vitamin-D-Mangel, Rachitis und Osteoporose eingesetzt. Expertinnen und Experten betonen zunehmend die Bedeutung einer bedarfsgerechten Supplementation, um unnötige Kosten und potenzielle Nebenwirkungen zu vermeiden [16–18]. Ein verändertes Bewusstsein für möglichen Übergebrauch von Vitamin D3 ohne klare medizinische Indikation könnte daher zu dieser Entwicklung beigetragen haben, sowie die Einführung einer Limitation der Kostenübernahme von Vitamin D3 bei Erkrankungen mit (Verdacht auf) Vitamin-D-Mangel im Juli 2022.

## 3.2.4 Herz-Kreislaufmittel (C)

Die Herz-Kreislaufmittel generierten im Jahr 2023 einen Gesamtumsatz von fast CHF 813 Millionen, was einer Kostensteigerung von CHF 22.2 Millionen (+2.8%) im Vergleich zum Vorjahr entspricht (Tabelle 5). Die durchschnittlichen Pro-Kopf-Kosten für Herz-Kreislaufmittel waren mit CHF 345 vergleichsweise hoch, nur übertroffen von den Krebs-/Immunsystemmitteln.

Mit Kosten von CHF 290.9 Millionen machten Lipidsenker (C10) den grössten Anteil unter den Herz-Kreislaufmitteln aus, dicht gefolgt von den Blutdruckmitteln mit Wirkung auf das Renin-Angiotensin-Aldosteron-System (RAAS) (C09) mit Kosten von CHF 281.1 Millionen. Während die Kosten für Blutdruckmittel RAAS nahezu konstant blieben (+0.4%), stiegen die Kosten für Lipidsenker deutlich an (+11.7%).

Bei den Lipidsenkern, die zur Therapie von Fettstoffwechselstörungen eingesetzt werden, gelten Statine als Mittel der ersten Wahl, um den Lipidgehalt im Blut zu senken (siehe auch Arzneimittelreport 2020 [8]). Insbesondere Rosuvastatin (Crestor® und Generika, C10AA07) konnte seine Bezüge deutlich steigern (+8.6%), was zu einem Kostenanstieg von CHF 3.2 Millionen auf CHF 51.9 Millionen im Jahr 2023 führte. Auch bei Pitavastatin (Livazo® und Generika, C10AA08) kam es zu einem Anstieg der Bezüge (+14.9%) und damit einhergehend der Gesamtkosten (+4.3%). Die Bezüge des am häufigsten genutzten Statins Atorvastatin (Sortis® und Generika, C10AA05) blieben tendenziell eher stabil (+1.7%), während die Nutzung von Fluvastatin (-5.2%), Simvastatin (-5.0%) und Pravastatin (-9.9%)

[[Seite 33/102]]

zurück ging. Bei einer unzureichenden Cholesterinsenkung unter alleiniger Gabe werden Statine häufig in Kombination mit Ezetimib verordnet. Auch hier kam es bei den entsprechenden Mitteln wie Ezetimib in Kombination mit Rosuvastatin (C10BA06), in Kombination mit Atorvastatin (C10BA05) und als Monopräparat (Ezetrol®, C10AX09) zu deutlichen Zuwächsen der Bezüge (+42.2%, +30.8%, +9.1%), was womöglich auf eine im Jahr 2021 erschienene Studie zurückzuführen ist, die eine zusätzliche Senkung des LDL-Cholesterinspiegels und verbesserte kardiovaskulären Ergebnisse bei Hinzunahme von Ezetimib zur Statintherapie aufzeigte [19]. Lediglich bei Ezetimib in Kombination mit Simvastatin (C10BA02) kam es zu einem Rückgang (-17.9%). PCSK9-Inhibitoren werden zumeist erst im späteren Verlauf der Therapie eingesetzt, wenn auch eine Kombinationstherapie aus Statinen und Ezetimib keine ausreichende Cholesterinsenkung bewirkt. Allerdings verzeichneten die PCSK9-Inhibitoren Repatha® (Evolocumab, C10AX13) und Praluent® (Alirocumab, C10AX14) aufgrund vermehrter Bezüge einen besonders grossen Kostenzuwachs (Tabelle 11). Die Kosten für Repatha® stiegen um CHF 8.3 Millionen (+50.2%) bei um 31.5% gesteigerten Bezügen und die Kosten für Praluent® um CHF 5.7 Millionen (+39.0%) bei 39.0% gesteigerten Bezügen. Der ungleiche Anstieg zwischen Kosten und Bezügen bei Repatha® lässt sich auf den verstärkten Bezug der grösseren (und damit teureren) Packung mit zwei statt einem Injektionspen zurückführen. Besonders ausgeprägt war der Kostenzuwachs von Leqvio® (Inclisiran, C10AX16) aus der Gruppe der Small interfering RNA (siRNA), das ähnlich wie die PCSK9-Inhibitoren wirkt. Dieses Präparat wurde erst im Jahr 2022 auf die SL aufgenommen und erzielte im Jahr 2023 bereits Kosten von CHF 8.1 Millionen (siehe auch Kapitel 3.3.2). Der Vorteil von Leqvio® gegenüber den PCSK9-Inhibitoren besteht darin, dass es nicht alle zwei bzw. vier Wochen gespritzt werden muss, sondern nach dem Therapiestart nur noch alle sechs Monate. Die ebenfalls neue Bempedoinsäure (als Monopräparat Nilemdo®, C10AX15, oder als Fixkombination mit Ezetimib Nustendi®, C10BA10) konnte sich ebenfalls weiter behaupten und steigerte die Bezüge um +99.8% (Nilemdo®) respektive +134% (Nustendi®).

## 3.2.5 Antiinfektiva (J)

Medikamente der anatomischen Hauptgruppe der Antiinfektiva werden zur Bekämpfung von Infektionen eingesetzt. Mit Kosten von knapp CHF 732 Millionen und einem Anteil an den Gesamtkosten von 8.1% im Jahr 2023 lagen die Antiinfektiva im oberen Mittelfeld der Hauptgruppen (Tabelle 5). Sowohl die Kosten (+8.3%), die Bezüge (+7.3%) als auch die Anzahl an Personen mit Bezügen (+5.2%) dieser Hauptgruppe waren steigend.

Die therapeutische Gruppe der Antiviralia (J05) verursachte bei den Antiinfektiva mit CHF 286.0 Millionen die höchsten Kosten (+0.5%), gefolgt von den Immunsera und Immunglobulinen (J06) mit CHF 166.2 Millionen (+14.0%, Tabelle 7). Auch der Gebrauch der systemischen Antibiotika (J01) nahm gegenüber dem Vorjahr zu (+CHF 5.2 Millionen, +5.8%). Den grössten Kostenzuwachs von CHF 26.2 Millionen (+19.6%) generierten die Impfstoffe (J07).

Der Zoster-Impfstoff Shingrix® (J07BK03) war mit einem Umsatzzuwachs von CHF 17.1 Millionen zwischen den Jahren 2022 und 2023 einer der fünf Wirkstoffe mit der grössten Kostensteigerung überhaupt (Tabelle 11). Mit über 240’000 Bezügen im Jahr 2023 generierte der Impfstoff aufgrund des relativ hohen Preises Gesamtkosten in Höhe von CHF 42.1 Millionen, obwohl er erst im Februar 2022 auf die SL kam. Shingrix® wird bei Erwachsenen zur Vorbeugung der Gürtelrose und ihrer

[Hinweis Transkription: Quellenwiderspruch: Der Fliesstext nennt für den Kostenanstieg von Praluent® (Alirocumab, C10AX14) +39.0%. Tabelle 11 auf Seite 27 nennt für Alirocumab eine Umsatzsteigerung zu 2022 von +47.7%. Beide Originalangaben unverändert übernommen.]

[[Seite 34/102]]

Komplikationen eingesetzt. Es wird im Schweizer Impfplan aufgrund der besseren Wirksamkeit und längeren Effektdauer statt des Lebendimpfstoffs Zostavax® empfohlen. Bei der Frühsommer-Meningo-Enzephalitis (FSME)-Impfung (J07BA01) gab es entgegen der Entwicklung im letzten Jahr wieder eine Zunahme der Bezüge (+6.0%). Die Gesamtkosten der Impfung beliefen sich mit CHF 20.8 Millionen auf etwa die Hälfte der Kosten von Shingrix®.

Die als Substitutionstherapie bei primären Immunmangelkrankheiten oder sekundären Immundefekten eingesetzten intravaskulären humanen Immunglobuline (Kiovig® und andere, J06BA02) waren mit einem Umsatzplus von CHF 13.8 Millionen (+11.5%) hauptverantwortlich für das Kostenwachstum der Immunsera und Immunglobuline (J06), welches CHF 20.4 Millionen betrug. Allerdings konnten auch die ähnlich eingesetzten extravaskulären humanen Immunglobuline (Hizentra® und andere, J06BA01) mit einem Plus von CHF 7.0 Millionen (+30.9%) einen starken Zuwachs verzeichnen.

Die grössten Veränderungen unter den Antiviralia (J05) betrafen die HIV-Mittel (für mehr Details siehe auch Helsana Arzneimittelreport 2023 [20]). Die Dreierkombination Biktarvy® (Emtricitabin, Tenofovir alafenamid, Bictegravir, J05AR20) und die Zweierkombination Dovato® (Lamivudin, Dolutegravir, J05AR25) konnten ihre Bezüge und damit ihren Umsatz um fast CHF 7.7 Millionen (+12.8%) respektive CHF 4.4 Millionen steigern. Allerdings zeigte die Betrachtung der Bezüge, dass diese zu grossen Teilen Personen betrafen, die von einem der älteren Präparate der jeweils selben Zulassungsinhaberinnen auf die neuere Kombination wechselten. Beispielsweise sanken die Bezüge von Descovy® (Emtricitabin, Tenofovir alafenamid, J05AR17), Genvoya® (Emtricitabin, Tenofovir alafenamid, Elvitegravir, Cobicistat, J05AR18) und Odefsey® (Emtricitabin, Tenofovir alafenamid, Rilpivirin, J05AR19) fast im selben Ausmass, wie die von Biktarvy® anstiegen. Auch der Rückgang der Bezüge bei Combivir® (Zidovudin, Lamivudin, J05AR01), Kivexa® und Generika (Lamivudin, Abacavir, J05AR02) und Triumeq® (Lamivudin, Abacavir, Dolutegravir, J05AR13) wurde durch den Zuwachs bei Dovato® kompensiert.

## 3.2.6 Blutsystemmittel (B)

Im Jahr 2023 wurden mehr Personen als 2022 mit Medikamenten der anatomischen Hauptgruppe mit Wirkung auf das Blutsystem behandelt (+2.2%), wobei dieser Zuwachs im Vergleich zu den anderen Gruppen moderat war (Tabelle 5). Aufgrund steigender Pro-Kopf-Kosten (+1.9%) stieg der Umsatz der Blutsystemmittel um 4.1% und erreichte etwa CHF 695 Millionen, was im Mittelfeld der Hauptgruppen lag.

Die Mittel zur Hemmung der Blutgerinnung (B01) erzielten mit CHF 375 Millionen die höchsten Kosten unter den Blutsystemmitteln. Nach einem stabilen Vorjahr aufgrund von Preissenkungen stiegen die Kosten dieser Gruppe dieses Mal wieder deutlich an (+CHF 14.9 Millionen, +4.4%; Tabelle 6). Das direkte orale Antikoagulanz (DOAK) Xarelto® (Rivaroxaban, B01AF01) verursachte mit CHF 148.5 Millionen (+1.6%) die höchsten Kosten der Blutgerinnungsmittel. DOAK sind mittlerweile Standardmedikamente zur Prävention und Behandlung tiefer Venenthrombosen, Lungenembolien und zur Schlaganfallprophylaxe bei Vorhofflimmern. Obwohl DOAK um ein Vielfaches teurer sind, bieten sie ein besseres Sicherheitsprofil als die traditionell eingesetzten Vitamin K-Antagonisten und erfordern ein weniger aufwändiges Therapiemonitoring, wodurch andere Kosten eingespart werden können. Neben Xarelto® gehört auch das DOAK Eliquis® (Apixaban, B01AF02) mit einem Umsatz von CHF 91.9

[Hinweis Transkription: Quellenwiderspruch: Der Fliesstext nennt für die Mittel zur Hemmung der Blutgerinnung (B01) CHF 375 Millionen. Tabelle 6 auf Seite 22 nennt Kosten von CHF 357’174’926. Beide Originalangaben unverändert übernommen.]

[[Seite 35/102]]

Millionen zu den 20 kostenintensivsten Präparaten (Tabelle 10). Eliquis® verzeichnete einen starken Anstieg der Bezüge (+16.1%), was zu einem erheblichen Kostenanstieg führte (+CHF 15.2 Millionen, +19.8%). Dies ist wahrscheinlich auf Studien zurückzuführen, die eine Überlegenheit bei Patientinnen und Patienten mit Vorhofflimmern im Vergleich zu Rivaroxaban bezüglich Wirksamkeit und Sicherheit zeigten [21,22].

Die Mittel gegen Blutarmut (B03) verzeichneten eine Kostenzunahme um rund CHF 10 Millionen (+7.2%). Etwa die Hälfte dieses Anstiegs entfiel auf parenteral verabreichtes Eisen (B03AC) (+CHF 4.4 Millionen, +5.5%). Eisen wird zur Vorbeugung und Behandlung von Eisenmangel und Eisenmangelanämie eingesetzt. Eisenmangel ist der einzige Nährstoffmangel, der auch in Industrieländern substanziell vorkommt. Die orale Eisengabe gilt als bevorzugte Therapie, während die parenterale Verabreichung nur in Ausnahmefällen vorgesehen ist [23]. Der beobachtete Anstieg lässt daher auf mögliche Fehlanreize schliessen. Für Ärztinnen und Ärzte ist die Verabreichung parenteralen Eisens lukrativer, da höhere Kosten abgerechnet werden können. Zudem sind Eiseninfusionen für die behandelten Personen oftmals angenehmer, da sie weniger Nebenwirkungen im Vergleich zu einer oralen Therapie haben. Weitere Mittel, nicht nur gegen Blutarmut, mit gestiegenen Kosten waren die Vitamin B12-Präparate Vitamin® (Cyanocobalamin, B03BA01) und Vitarubin® (Cyanocobalamin, B03BA01; Hydroxocobalamin, B03BA03). Die Bezüge dieser Präparate stiegen um 32.6% auf 276’000, während die Kosten um 81.8% auf CHF 6.2 Millionen anstiegen. Auffällig war, dass vermehrt grössere (und damit teurere) Packungen abgegeben wurden, sodass die Kosten stärker anstiegen als die Bezüge. Dieses verstärkte Wachstum könnte teilweise auf den Trend zu vegetarischer und veganer Ernährung zurückzuführen sein. Da Vitamin B12 nicht in pflanzlichen Lebensmitteln enthalten ist, wird bei bei veganer Ernährung ausdrücklich empfohlen, Vitamin B12 oral zu supplementieren oder angereicherte Produkte zu konsumieren, um einem Mangel vorzubeugen. Auch bei vegetarischer Ernährung kann eine Ergänzung sinnvoll sein [24]. Etwa die Hälfte der Kosten entstand jedoch durch Injektionen statt durch Tabletten, was auf vermehrte Diagnosen von Vitamin-B12-Mangel hinweisen könnte, beispielsweise bedingt durch die Zunahme chronischer Erkrankungen wie Magen-Darm-Erkrankungen (z.B. Morbus Crohn, Zöliakie) oder die Alterung der Bevölkerung.

Bei den Blutersatzmitteln (B05) fiel insbesondere ein Präparat für die parenterale Ernährung auf, eine aminosäure-, glucose- und lipidhaltige Kombinationslösung (B05BA10). Dieses Präparat steigerte seine Bezüge um 39.7%, was zu einem Umsatzwachstum von CHF 1.9 Millionen führte. Die Lösung wird intravenös verabreicht, wenn eine enterale Ernährung nicht möglich, unzureichend oder kontraindiziert ist. Vermutlich stieg die Zahl der abgerechneten Bezüge, da inzwischen immer mehr Leistungen ambulant durchgeführt werden.

## 3.2.7 Sinnesorgane (S)

Die Hauptgruppe der Sinnesorgane verzeichnete im Vergleich zum Vorjahr eine leichte Kostensenkung um CHF 2.2 Millionen (-0.5%), trotz eines Anstiegs der Bezüge um +3.7% und einem deutlichen Zuwachs der Personen mit Bezügen (+6.8%; Tabelle 5). Die Pro-Kopf-Kosten gingen dabei um 6.9% zurück. Diese Effekte wurden hauptsächlich durch die Augenmedikamente (S01) verursacht, während Otologika (S02), die zur Anwendung am Ohr dienen, keine Rolle spielten (Tabelle 6).

[[Seite 36/102]]

Das Augenmedikament Vabysmo® (Faricimab, S01LA09) verzeichnete mit einem Anstieg der Kosten um CHF 39.6 Millionen die höchste Kostensteigerung aller Medikamente überhaupt, noch vor dem Diabetesmedikament Semaglutid (+CHF 31.9 Millionen). Vabysmo® kam im Jahr 2022 neu auf die SL. Seitdem nahm der Verbrauch stark zu. Im Jahr 2023 resultierten bereits über 44’000 Bezüge, mit Kosten von CHF 44.4 Millionen bei Pro-Kopf-Kosten von etwa CHF 5’680. Vabysmo® wird zur Behandlung der feuchten Makuladegeneration eingesetzt und konkurriert mit Eylea® (Aflibercept; S01LA05) und Ranibizumab (Lucentis® und Biosimilars, S01LA04). Eylea® war mit einem Umsatz von CHF 160 Millionen das zweitkostenintensivste Präparat des Jahres 2023 (Tabelle 10) und erreichte Pro-Kopf-Kosten von CHF 5’120. Ranibizumab erzielte mit CHF 45.7 Millionen ebenfalls hohe Umsätze bei Pro-Kopf-Kosten von CHF 3’940. Aufgrund von Preissenkungen im Rahmen der BAG-Kostensenkungsrunde sanken die Pro-Kopf-Kosten beider Wirkstoffe um 14.3% bzw. 20.4%, und die Bezüge gingen um 4.1% bzw. 24.6% zurück, vermutlich aufgrund einer Verschiebung zugunsten Vabysmo®. Dies führte zu einer deutlichen Kostensenkung sowohl bei Eylea® (-10.4%) als auch bei Ranibizumab (-35.3%), die zusammengenommen höher ausfiel (CHF -43.5 Millionen) als der Kostenzuwachs bei Vabysmo®. Eine Studie zeigte, dass Faricimab-Injektionen, die in einem Abstand von 16 Wochen verabreicht werden, bezüglich der Verbesserung der Sehschärfe nicht unterlegen gegenüber Aflibercept (Eylea®) sind, das alle 8 Wochen verabreicht wird [25]. Daher könnte es in den nächsten Jahren zu einer weiteren Verschiebung der Behandlung von Patientinnen und Patienten mit feuchter Makuladegeneration hin zu Vabysmo® kommen.

## 3.2.8 Fazit

Im Jahr 2023 stiegen die ambulanten Medikamentenkosten in der Grundversicherung abermals deutlich an. Sie sind nun erstmals der grösste Kostenblock der Grundversicherung. Diese Kostensteigerung wurde unter anderem durch einen gesteigerten Marktanteil kostenintensiver Medikamente und eine generell erhöhte Nachfrage wegen des demografischen Wandels getrieben.

Ein wesentlicher Faktor für die jüngsten Kostensteigerungen sind die hohen Preise, insbesondere neuerer Medikamente und Mengenausweitungen bei bestehenden hochpreisigen Präparaten. Diese Mengenausweitungen sind oft das Ergebnis von Indikationserweiterungen oder geänderten Therapieempfehlungen. Eine automatische Überprüfung der Wirtschaftlichkeit unter Berücksichtigung der Menge und eine entsprechende Anpassung der Preise bei Mengenausweitungen könnten die Mehrkosten eindämmen. Auch der Preis von als Standardtherapie abgelösten Präparaten sollte systematisch überprüft und gesenkt werden, da diese Präparate ihren einstigen Innovationscharakter nicht mehr erfüllen.

Ein weiteres Problem ist der Preisanstieg durch den Markteintritt neuer, hochpreisiger Medikamente. Der gesetzlich vorgeschriebene Preisvergleich mit ähnlichen Präparaten im Inland (therapeutischer Quervergleich) und Schaufensterpreisen im Ausland (Auslandspreisvergleich) sowie gegebenenfalls ein Innovationszuschlag führen systembedingt zu steigenden Preisen, wenn neue Therapien auf den Markt kommen, unabhängig davon, ob ein echter klinischer Nutzen vorhanden ist oder es sich lediglich um eine Ergänzung des bestehenden Therapieangebotes handelt.

Zusätzlich erschwert die Anwendung von Preismodellen und die daraus resultierenden Rückforderungen die Situation (vgl. dazu Arzneimittelreport 2022 [9]). Diese Sondervereinbarungen

[[Seite 37/102]]

zwischen BAG und Industrie ergänzen die gesetzlich vorgesehenen Mechanismen zur Preisbildung. Erst nach Abzug des teils geheimen Rabatts auf den öffentlichen Publikumspreis der SL resultiert der als wirtschaftliche erachtete Preis. Die überhöhten Schaufensterpreise führen bei Preisvergleichen zu Verzerrungen. Um die Transparenz zu erhöhen und die Preisbildung nachhaltig zu gestalten, sollten die intransparenten Elemente dieser Preismodelle so weit wie möglich reduziert werden.

## 3.3 Neuheiten und potenzielle Innovationen

**[Kernaussagen]**

- Im Jahr 2023 wurden 28 neue Wirkstoffe in die Spezialitätenliste aufgenommen, darunter hauptsächlich Krebsmedikamente und Immunsuppressiva. Diese verursachten Gesamtkosten in Höhe von CHF 87 Millionen. Nur zwei basierten auf neuartigen Wirkmechanismen: das Enzymtherapeutikum Nexviadyme® (Wirkstoff Avalglucosidase alfa) und das Herzmittel Camzyos® (Wirkstoff Mavacamten).

- Das neue Brustkrebsmittel Enhertu® (Wirkstoff Trastuzumab-Deruxtecan) fiel bereits in den ersten Monaten nach seiner Aufnahme in die Spezialitätenliste durch besonders hohe Gesamtkosten auf, die etwa CHF 2.7 Millionen pro Monat betrugen.

- Von den 2022 neu eingeführten Präparaten zeigten insbesondere das Augenmedikament Vabysmo® (Wirkstoff Faricimab) und der Zoster-Impfstoff Shingrix® auffallend hohe durchschnittliche monatliche Kosten von über CHF 3.5 Millionen.

**[Ende Kernaussagen]**

## 3.3.1 Neuheiten und potenzielle Innovationen 2023

Der Arzneimittelmarkt befindet sich in einem ständigen Wandel, geprägt durch die regelmässige Zulassung neuer Produkte und die Verdrängung respektive Marktrücknahme bestehender Therapien. Bei den meisten Neuzulassungen handelte es sich jedoch nicht um Innovationen im Sinne neuer Wirkstoffe, sondern um Modifikationen bestehender Produkte. Diese Anpassungen können in verschiedenen Formen auftreten, wie zum Beispiel veränderten Verpackungsgrössen, neuen Darreichungsformen, unterschiedlichen Dosierungen oder geringfügigen Änderungen in der Rezeptur. Zudem gibt es auch administrative Änderungen, wie Wechsel des Herstellers oder Umbenennungen von Präparaten. Ausserdem kommen regelmässig Nachahmerprodukte wie Generika und Biosimilars auf den Markt, während die Einführung wirklich neuer Wirkstoffe weitaus seltener ist.

Die Wirkmechanismen neuer Arzneimittel wurden untersucht, um zu prüfen, ob es sich um eine potenzielle Innovation handeln könnte. Dabei wurde berücksichtigt, ob ein neuer Wirkmechanismus vorlag, ob es sich um den ersten zugelassenen Wirkstoff einer neuen Wirkstoffgruppe handelte und ob in der jeweiligen Indikation bereits zugelassene Medikamente existierten. Falls vergleichbare zugelassene Arzneimittel vorlagen, wurde keine Einstufung als potenzielle Innovation vorgenommen.

Im Jahr 2023 wurden insgesamt 28 neue Wirkstoffe in die SL aufgenommen (Tabelle 12). Diese neuen Wirkstoffe verursachten bereits im selben Jahr Kosten in Höhe von CHF 87.0 Millionen. Nur bei zwei dieser Wirkstoffe handelte es sich gemäss obiger Definition um potenzielle Innovationen, da sie jeweils einen neuen Wirkmechanismus aufweisen: Nexviadyme® (Avalglucosidase alfa, A16AB22) und Camzyos® (Mavacamten, C01EB24). Nexviadyme® ist eine Enzymtherapie der seltenen, genetisch

[[Seite 38/102]]

bedingten Enzymmangel-Erkrankung Morbus Pompe, während Camzyos® zur spezifischen Behandlung der hypertrophen Kardiomyopathie zugelassen wurde.

| Wirkstoff | Name | ATC Ebene 2 | SL-Aufnahme | Innovation? | Ø Kosten* [CHF pro Monat] | Publikumspreis** [CHF] |
|---|---|---|---|---|---|---|
| Trastuzumab-Deruxtecan | Enhertu® | L01 | 01.11.2023 | Nein | 2’612’727 | 1’765.20 |
| Darolutamid | Nubeqa® | L02 | 01.04.2023 | Nein | 1’772’928 | 3’392.05 |
| Nirmatrelvir, Ritonavir | Paxlovid® | J05 | 01.12.2023 | Nein | 1’468’619 | 1’113.95 |
| Mavacamten | Camzyos® | C01 | 01.12.2023 | Ja | 655’260 | 1’602.80 |
| Gilteritinib | Xospata® | L01 | 01.06.2023 | Nein | 579’000 | 16’804.10 |
| Pegcetacoplan | Aspaveli® | L04 | 01.06.2023 | Nein | 567’040 | 25’217.95 |
| Tezepelumab | Tezspire® | R03 | 01.02.2023 | Nein | 382’350 | 1’390.65 |
| Lurbinectedin | Zepzelca® | L01 | 01.09.2023 | Nein | 371’561 | 5’902.05 |
| Teclistamab | Tecvayli® | L01 | 01.09.2023 | Nein | 331’424 | 4’825.35 |
| Mogamulizumab | Poteligeo® | L01 | 01.01.2023 | Nein | 266’968 | 1’723.55 |
| Polatuzumabvedotin | Polivy® | L01 | 01.05.2023 | Nein | 227’646 | 10’492.05 |
| Isatuximab | Sarclisa® | L01 | 01.07.2023 | Nein | 185’376 | 2’830.00 |
| Mosunetuzumab | Lunsumio® | L01 | 01.03.2023 | Nein | 181’351 | 7’970.10 |
| Avalglucosidase alfa | Nexviadyme® | A16 | 01.01.2023 | Ja | 161’981 | 1’049.55 |
| Asciminib | Scemblix® | L01 | 01.01.2023 | Nein | 157’969 | 5’107.45 |
| Ponatinib | Iclusig® | L01 | 01.03.2023 | Nein | 147’270 | 3’628.85 |
| Givosiran | Givlaari® | A16 | 01.04.2023 | Nein | 144’489 | 45’597.45 |
| Natriumphenylbutyrat | Pheburane® | A16 | 01.11.2023 | Nein | 58’755 | 510.55 |
| Meningitis B Impfstoff | Bexsero® | J07 | 01.01.2023 | Nein | 43’056 | 114.00 |
| Finerenon | Kerendia® | C03 | 01.06.2023 | Nein | 17’301 | 64.35 |
| Oritavancin | Tenkasi® | J01 | 01.04.2023 | Nein | 16’440 | 2’445.45 |
| Azithromycin dihydridum | Azyter® | S01 | 01.07.2023 | Nein | 10’462 | 15.70 |
| Vericiguat | Verquvo® | C01 | 01.03.2023 | Nein | 7’238 | 57.45 |
| Chlormethin | Ledaga® | L01 | 01.01.2023 | Nein | 2’529 | 1’935.75 |
| Mobocertinib | Exkivity® | L01 | 01.03.2023 | Nein | 0 | 9’442.55 |
| Sapropterin dihydrochloridum | Sapropterin Dipharma® | A16 | 01.07.2023 | Nein | 0 | 2’088.41 |
| Selumetinib | Koselugo® | L01 | 01.06.2023 | Nein | 0 | 9’459.00 |
| Susoctocog alfa | Obizur® | B02 | 01.07.2023 | Nein | 0 | 1’298.85 |

[Fussnote *] durchschnittlich abgerechnete monatliche Kosten seit Aufnahme in die Spezialitätenliste (SL)

[Fussnote **] entspricht Publikumspreis der häufigsten abgegebenen Packung basierend auf SL (Stand 01.01.2024). Wenn keine Bezüge verzeichnet wurden, durchschnittlicher Publikumspreis aller verfügbaren Packungen

## Tabelle 12: Übersicht und monatliche Kosten der neuen Wirkstoffe im Jahr 2023, Hochrechnung

[[Seite 39/102]]

## Krebs- und Immunsystemmittel (L)

Die Behandlung von Krebserkrankungen erfordert eine Vielzahl von Wirkstoffen und wird intensiv erforscht. Daher ist es wenig überraschend, dass Krebsmedikamente (L01) mit 13 Neueinführungen die meisten neuen Wirkstoffe auf der SL stellten. Der umsatzstärkste neue Wirkstoff des Jahres 2023 gehörte ebenfalls zu den Krebsmedikamenten. Unter dem Markennamen Enhertu® (Trastuzumab-Deruxtecan, L01FD04) wird dieser Wirkstoff neben anderen Indikationen als Monotherapie zur Behandlung von Erwachsenen bei bestimmten Formen von Brustkrebs angewendet. Enhertu® ist ein Antikörper-Wirkstoff-Konjugat, bestehend aus dem Antikörper Trastuzumab, der mit einem Linker an Deruxtecan gebunden ist. Der Gemeinsame Bundesausschuss (G-BA) in Deutschland, der neue medikamentöse Therapien bewertet, bescheinigte Enhertu® im Vergleich zu Capecitabin, Eribulin, Paclitaxel oder Nab-Paclitaxel einen Hinweis auf einen beträchtlichen Zusatznutzen [26]. Diese positive Bewertung spiegelte sich auch in den Verbrauchszahlen wider: Obwohl Enhertu® im Jahr 2023 erst während zwei Monaten auf der SL gelistet war, verursachte es in diesem kurzen Zeitraum bereits Kosten von CHF 5.2 Millionen. Allerdings wurde das Medikament in vergleichsweise vielen Fällen schon vor November 2023 über Einzelfallvergütungen abgerechnet. Die Gesamtkosten für Enhertu® für das Jahr 2023 betrugen dadurch CHF 36.2 Millionen.

Zu den weiteren neuen Wirkstoffen gehören unter anderem:

Xospata® (Gilteritinib, L01EX13): Ein Kinasehemmer für die Behandlung von Patientinnen und Patienten mit rezidivierter oder refraktärer akuter myeloider Leukämie mit FLT3-Mutationen. Seit der SL-Aufnahme im Juni 2023 wurden durchschnittliche monatliche Kosten von CHF 579’000 erzeugt. Der Publikumspreis von Xospata® war mit CHF 16’900 pro Packung der höchste unter den Krebsmedikamenten.

Zepzelca® (Lurbinectedin, L01XX69): Ein zytotoxischer Wirkstoff zur Behandlung des metastasierten kleinzelligen Lungenkarzinoms (SCLC). Die monatlichen Kosten betrugen im Durchschnitt CHF 372’000 bei einem Publikumspreis von knapp CHF 6’000 pro Packung.

Tecvayli® (Teclistamab, L01FX24): Ein bispezifischer Antikörper für die Behandlung von erwachsenen Patientinnen und Patienten mit rezidiviertem oder refraktärem multiplem Myelom. Seit der SL-Aufnahme im September 2023 verzeichnete Tecvayli® durchschnittliche monatliche Kosten von CHF 331’000.

Sarclisa® (Isatuximab, L01FC02): Ein monoklonaler Antikörper zur Behandlung des multiplen Myeloms bei Erwachsenen. Sarclisa® verursachte seit Aufnahme in die SL im Juli 2023 durchschnittliche monatliche Kosten von CHF 185’000.

Ledaga® (Chlormethin, L01AA05): Dieses topische Medikament wird zur Behandlung des kutanen T-Zell-Lymphoms des Typs Mycosis fungoides bei Erwachsenen eingesetzt. Das Gel, das im Januar 2023 auf die SL kam, verursachte im Durchschnitt monatliche Kosten von CHF 2’500. Der Publikumspreis von etwa CHF 1’900 pro Packung war für ein neues Krebsmedikament vergleichsweise gering.

Weitere im Jahr 2023 neu eingeführte Krebsmedikamente umfassten Poteligeo® (Mogamulizumab), Polivy® (Polatuzumab vedotin), Lunsumio® (Mosunetuzumab), Scemblix® (Asciminib), Iclusig® (Ponatinib), Exkivity® (Mobocertinib) und Koselugo® (Selumetinib), wobei die beiden zuletzt aufgeführten Mittel noch keine abgerechneten Bezüge aufwiesen.

[Hinweis Transkription: Abweichende Originalangaben zum Publikumspreis von Xospata®: Auf dieser Seite stehen CHF 16’900 pro Packung, in Tabelle 12 auf Seite 38 CHF 16’804.10. Beide Angaben unverändert übernommen.]

[[Seite 40/102]]

Immunsuppressiva (L04) spielen im Bereich der Autoimmunerkrankungen und Transplantationsmedizin eine wichtige Rolle. Mit Aspaveli® (Pegcetacoplan, L04AJ03) kam hier ein neuer Wirkstoff hinzu. Aspaveli® wird zur Behandlung der paroxysmalen nächtlichen Hämoglobinurie eingesetzt. Durch die Therapie mit diesem Präparat sind bei den Betroffenen deutlich weniger Bluttransfusionen notwendig. Seit der Aufnahme in die SL im Juni 2023 verursachte es monatliche Kosten von CHF 567’000. Der Publikumspreis von CHF 25’200 pro am häufigsten abgegebener Packung war der zweithöchste unter allen neuen Wirkstoffen.

Auch bei den endokrinen Therapien (L02) gab es im Jahr 2023 einen neuen Wirkstoff. Nubeqa® (Darolutamid, L02BB06), ein Medikament zur Behandlung von nicht metastasiertem, kastrationsresistentem Prostatakarzinom, wurde im April 2023 in die SL aufgenommen und generierte seither durchschnittliche monatliche Kosten von CHF 1.8 Millionen bei einem Publikumspreis von CHF 3’400 pro Packung.

## Antiinfektiva (J)

In der ATC-Hauptgruppe der Antiinfektiva (J) wurden drei neue Medikamente in die SL aufgenommen: ein Impfstoff (J07), ein Antivirales Mittel (J05) und ein Antibiotikum (J01).

Bexsero® (Meningitis-B-Impfstoff, J07AH09) ist ein Impfstoff gegen Meningokokken der Gruppe B und enthält vier verschiedene Oberflächenbestandteile des Bakteriums Neisseria meningitidis Gruppe B. Der Impfstoff schützt vor Erkrankungen, die durch diese Bakterien verursacht werden, wie Meningitis (Hirnhaut- und Rückenmarksentzündung) und Sepsis (Blutvergiftung). Bexsero® stimuliert das Immunsystem, sodass ein Schutz vor diesen potenziell lebensbedrohlichen Erkrankungen entsteht. Die Impfung wird seit Mai 2022 definierten Personengruppen mit erhöhtem Erkrankungsrisiko ab dem Alter von 2 Monaten als ergänzende Impfung empfohlen, weshalb seitdem auch eine Kostenübernahme für diese Personengruppen erfolgt [27].

Paxlovid® (Nirmatrelvir, Ritonavir, J05AE30) ist eine Kombinationspräparat zur Behandlung von Covid-19. Nirmatrelvir ist ein antiviraler Wirkstoff aus der Gruppe der 3CL-Protease-Inhibitoren, der die Virusvermehrung stört. Ritonavir (ein CYP3A-Inhibitor) dient als pharmakokinetischer Booster. Obwohl der Wirkmechanismus von Paxlovid® nicht neu ist, spielt es eine wichtige Rolle in der Covid-19-Behandlung, denn es reduziert das Risiko für Hospitalisationen und Todesfälle bei Covid-19-Betroffenen. Seit es ab Dezember 2023 kostenpflichtig abgerechnet werden kann, wurden damit Kosten von etwa CHF 1.5 Millionen verursacht bei etwa 1’320 Betroffenen.

Tenkasi® (Oritavancin, J01XA05) ist ein Reserveantibiotikum, das bei akuten bakteriellen Haut- und Weichgewebeinfektionen eingesetzt wird. Tenkasi® ist seit April 2023 auf der SL und verursachte durchschnittliche monatliche Kosten von CHF 16’400.

## Stoffwechsel (A)

Im Jahr 2023 gab es insgesamt drei neue Wirkstoffe unter den Stoffwechselmitteln (A), die alle drei zur therapeutischen Medikamentengruppe der Enzyme und Aminosäuren (A16) gehören.

Patientinnen und Patienten mit Morbus Pompe leiden unter einem genetisch bedingten Mangel an saurer α-Glucosidase. Seit Januar 2023 steht ihnen Nexviadyme® (Avalglucosidase alfa, A16AB22)

[[Seite 41/102]]

für die langfristige Enzymersatztherapie zur Verfügung. Zuvor wurde Alglucosidase alfa bei dieser Erkrankung eingesetzt. Die neue Form des Enzyms kann jedoch leichter in die Muskelzellen und deren Lysosomen eindringen. Bei den Betroffenen wird eine Verbesserung der kardiologischen, respiratorischen und motorischen Funktionen beobachtet. Dieser verbesserte Wirkmechanismus stellt eine potenzielle Innovation dar. Die durchschnittlichen monatlichen Kosten betrugen rund CHF 162’000 und die jährlichen Pro-Kopf-Kosten betrugen etwa CHF 1’050.

Givlaari® (Givosiran, A16AX16) ist ein Wirkstoff aus der Gruppe der small interfering RNA (siRNA) und wird zur Behandlung der akuten hepatischen Porphyrie eingesetzt. Seine Wirkung beruht auf der Förderung des Abbaus der ALAS1-mRNA in den Leberzellen, wodurch die Blutspiegel neurotoxischer Metaboliten reduziert werden. Der Publikumspreis betrug CHF 45’700 pro Packung, was Givosiran zur teuersten Neuerung machte. Seit der Aufnahme in die SL im April 2023 wurden Kosten von monatlich rund CHF 144’500 verursacht.

Pheburane® (Natriumpheylbutyrat, A16AX03) ist als Zusatztherapie bei der Langzeitbehandlung von Stoffwechselstörungen des Harnstoffzyklus indiziert. Seit der Aufnahme in die SL wurden monatlich CHF 59’000 an Kosten generiert.

Sapropterin Dipharma® (Sapropterin dihydrochloridum, A16AX07) ist ein Aktivator der Phenylalaninhydroxylase und wird zur Behandlung einer Hyperphenylalaninämie infolge einer Phenylketonurie oder eines Tetrahydrobiopterin-Mangels eingesetzt. Sapropterin entspricht dem natürlichen Cofaktor der Phenylalaninhydroxylase und fördert den normalen Abbau der Aminosäure Phenylalanin. Auch wenn der Wirkstoff bereits im Jahr 2009 in der Schweiz zugelassen wurde, kam er erst im Juli 2023 auf die SL. Er wurde bisher noch nicht abgerechnet.

## Herz-Kreislauf (C)

In der therapeutischen Gruppe der Herztherapie (C01) wurden zwei neue Medikamente in die SL aufgenommen:

Camzyos® (Mavacamten, C01EB24) ist ein Myosin-Inhibitor, der die Kontraktilität und den Energieverbrauch im Herzen verbessert und damit auch den Blutfluss. Er gilt gemäss angewandter Systematik als potenzielle Innovation. Seit Dezember 2023 können Erwachsene mit hypertropher obstruktiver Kardiomyopathie damit behandelt werden. Das oral verfügbare Präparat bewirkt bei vielen Betroffenen eine Verbesserung der Symptomatik und der Leistungsfähigkeit. Die Kosten im Dezember 2023 beliefen sich auf CHF 655’000.

Verquvo® (Vericiguat, C01DX22) ein gefässerweiternder Wirkstoff aus der Gruppe der Guanylatzyklase-Stimulatoren zur Behandlung symptomatischer und chronischer Herzinsuffizienz. Der Wirkstoff entspannt unter anderem die glatte Muskulatur der Gefässe. Verquvo® ist seit März 2023 auf der SL und gehört mit einem Publikumspreis von CHF 57 für die am häufigsten abgegebene Packung zu den günstigsten Neuheiten.

Bei der therapeutischen Gruppe der Diuretika (C03) kam im Juni 2023 mit Kerendia® (Finerenon, C03DA05) ein neuer Wirkstoff auf die SL. Finerenon ist ein Aldosteron-Antagonist, der zur Verzögerung des Fortschreitens einer chronischen Nierenerkrankung bei erwachsenen Patientinnen und Patienten mit Typ-2-Diabetes zugelassen ist. Der Publikumspreis lag bei CHF 65 für die am häufigsten

[[Seite 42/102]]

abgegebene Packung, was weit unter dem durchschnittlichen Publikumspreis der Neuzulassungen von CHF 6’000 lag.

## Atmung (R)

Bei den Mitteln mit Wirkung auf das Atemsystem gab es eine Neuheit. Der gegen thymisches stromales Lymphopoietin gerichtete monoklonale Antikörper Tezspire® (Tezepelumab, R03DX11) ist als Add-on-Erhaltungstherapeutikum für Erwachsene und Jugendliche ab zwölf Jahren mit schwerem Asthma bronchiale geeignet. Die Substanz wird angewendet, wenn die Erkrankung unzureichend auf hoch dosierte inhalative Korticosteroide und weitere Arzneimittel zur Erhaltungstherapie anspricht. Bei den Betroffenen führt die Behandlung zu einer Reduktion der Asthma-Exazerbationen und einer verbesserten Kontrolle der Erkrankung. Tezspire® ist seit Februar 2023 auf der SL und verursachte seither durchschnittlich Kosten von CHF 382’000 pro Monat.

## Sinnesorgane (S)

Bei den Augenmedikamenten (S01) wurde mit Azyter® (Azithromycin, S01AA26) ein neues Medikament zur Behandlung von Augeninfektionen eingeführt. Der Wirkstoff Azithromycin ist zwar nicht neu, jedoch die spezifische Anwendung und Darreichungsform. Die durchschnittlichen monatlichen Kosten betrugen CHF 10’500. Mit einem Publikumspreis von CHF 16 pro Packung war Azyter® die günstigste Neuerung.

## Blut (B)

In der Hauptgruppe

Blut (B) wurde mit Obizur® (Susoctocog alfa, B02BD14) ein neues Präparat aufgenommen. Susoctocog alfa gehört zur Gruppe der Blutgerinnungsfaktoren und wird zur Behandlung von Blutungsepisoden bei Patientinnen und Patienten mit erworbener Hämophilie eingesetzt, die durch Antikörper gegen den Faktor VIII verursacht wird. Dieser Wirkstoff wurde im Juli 2023 in die SL aufgenommen, wurde jedoch bisher nicht bezogen.

## 3.3.2 Marktentwicklung der Neuheiten aus 2022

Im Jahr 2022 wurden 45 neue Wirkstoffe in die SL aufgenommen, vor allem Krebsmedikamente und Immunsuppressiva (Tabelle 13). Bei nur 15 dieser Wirkstoffe lag der öffentliche Preis unter CHF 1’000 pro meistverkaufter Packung (Stand 01.01.2023). Die meisten neuen Wirkstoffe kamen zu deutlich höheren Preisen auf den Markt. Die 45 neuen Wirkstoffe zusammen erzielten im Jahr 2022 einen Gesamtumsatz von CHF 10.3 Millionen pro Monat. Im Jahr 2023 stiegen die Kosten auf CHF 13.9 Millionen pro Monat.

Der Wirkstoff mit den höchsten monatlichen Durchschnittskosten im Jahr 2022 war der Zoster-Impfstoff Shingrix®. Die monatlichen Kosten betrugen knapp CHF 2.3 Millionen und stiegen 2023 um 55% auf CHF 3.5 Millionen. Das Bundesamt für Gesundheit (BAG) und die Eidgenössische Kommission für Impffragen (EKIF) empfehlen die Impfung gegen Herpes zoster (Gürtelrose) mit Shingrix® für gesunde Personen ab 65 Jahren sowie für immungeschwächte Patientinnen und Patienten ab 50 Jahren, bei schwerer Immundefizienz bereits ab 18 Jahren.

[[Seite 43/102]]

Cemiplimab (Libtayo®, L01FF06) verursachte 2022 die zweithöchsten monatlichen Durchschnittskosten von CHF 1.7 Millionen. Das Medikament wurde im November 2022 zur Behandlung bestimmter Hautkrebsformen (z. B. kutanes Plattenepithelkarzinom) und einer Form von Lungenkrebs zugelassen. Es stärkt das Immunsystem und unterstützt die gezielte Bekämpfung von Krebszellen. Im Jahr 2023 sanken die monatlichen Kosten um 74% auf CHF 450’000, was auf geringere Bezüge zurückzuführen war.

Andere Wirkstoffe wie Enfortumabvedotin (Padcev®, L01FX13), Pemigatinib (Pemazyre®, L01EN02), Tepotinib (Tepmetko®, L01EX21) und Propiverin (Mictonorm®, G04BD06) verzeichneten 2023 deutliche Einbussen im Vergleich zu 2022.

Im Gegensatz dazu stieg der Umsatz des Immunsuppressivums Bimekizumab (Bimzelx®, L04AC21), das bei Autoimmunerkrankungen wie Psoriasis und axialer Spondyloarthritis eingesetzt wird, um mehr als das Zehnfache auf CHF 145’000 pro Monat. Auch die Wirkstoffe Faricimab (Vabysmo®, S01LA09), Zanubrutinib (Brukinsa®, L01EL03), Tralokinumab (Adtralza®, D11AH07), Eptinezumab (Vyepti®, N02CD05), Esketamin (Spravato®, N06AX27) und Pralsetinib (Gavreto®, L01EX23) konnten ihre monatlichen Umsätze gegenüber dem Vorjahr mindestens verdoppeln.

| Wirkstoff | Name | ATC Ebene 2 | Ø Kosten* 2022 [CHF pro Monat] | Ø Kosten* 2023 [CHF pro Monat] | Trend |
|---|---|---|---|---|---|
| Faricimab | Vabysmo® | S01 | 977’568 | 3’703’361 | +279% |
| Varicella-Zoster-Virus-Glycoprotein-E | Shingrix® | J07 | 2’270’031 | 3’509’501 | +55% |
| Inclisiran | Leqvio® | C10 | 565’661 | 676’544 | +20% |
| Sacituzumab-Govitecan | Trodelvy® | L01 | 664’487 | 628’625 | -5% |
| Romosozumab | Evenity® | M05 | 221’821 | 556’694 | +151% |
| Zanubrutinib | Brukinsa® | L01 | 149’011 | 556’645 | +274% |
| Cabotegravir | Vocabria® | J05 | 205’296 | 493’982 | +141% |
| Cemiplimab | Libtayo® | L01 | 1’692’030 | 447’813 | -74% |
| Enfortumabvedotin | Padcev® | L01 | 1’437’479 | 327’372 | -77% |
| Tafasitamab | Minjuvi® | L01 | 463’615 | 276’076 | -40% |
| Colchicin | Colctab® | M04 | 170’724 | 259’178 | +52% |
| Tralokinumab | Adtralza® | D11 | 74’801 | 248’745 | +233% |
| Eptinezumab | Vyepti® | N02 | 56’034 | 203’595 | +263% |
| Esketamin | Spravato® | N06 | 56’328 | 193’925 | +244% |
| Bimekizumab | Bimzelx® | L04 | 10’966 | 145’719 | +1229% |
| Tirbanibulin | Klisyri® | D06 | 54’856 | 141’007 | +157% |
| Avatrombopag | Doptelet® | B02 | 56’594 | 139’752 | +147% |
| Bempedoinsäure | Nilemdo® | C10 | 78’289 | 138’156 | +76% |
| Berotralstat | Orladeyo® | B06 | 144’342 | 137’563 | -5% |
| Capmatinib | Tabrecta® | L01 | 74’838 | 129’474 | +73% |

[[Seite 44/102]]

[Fortsetzung Tabelle 13 von Seite 43; Spaltenüberschriften übernommen.]

| Wirkstoff | Name | ATC Ebene 2 | Ø Kosten* 2022 [CHF pro Monat] | Ø Kosten* 2023 [CHF pro Monat] | Trend |
|---|---|---|---|---|---|
| Ponesimod | Ponvory® | L04 | 0 | 103’888 | - |
| Dostarlimab | Jemperli® | L01 | 38’062 | 97’524 | +156% |
| Entrectinib | Rozlytrek® | L01 | 70’430 | 95’032 | +35% |
| Cenobamat | Ontozry® | N03 | 29’318 | 86’313 | +194% |
| Tepotinib | Tepmetko® | L01 | 247’087 | 84’768 | -66% |
| Satralizumab | Enspryng® | L04 | 50’431 | 67’889 | +35% |
| Obeticholsäure | Ocaliva® | A05 | 0 | 64’618 | - |
| Pralsetinib | Gavreto® | L01 | 13’245 | 55’482 | +319% |
| Amivantamab | Rybrevant® | L01 | 78’111 | 42’128 | -46% |
| Selpercatinib | Retsevmo® | L01 | 0 | 41’835 | - |
| Remdesivir | Veklury® | J05 | 13’413 | 37’865 | +182% |
| Pemigatinib | Pemazyre® | L01 | 171’481 | 35’859 | -79% |
| Calcifediol | Rayaldee® | H05 | 15’354 | 35’045 | +128% |
| Larotrectinib | Vitrakvi® | L01 | 78’269 | 34’796 | -56% |
| Osilodrostat | Isturisa® | H02 | 0 | 34’190 | - |
| Pelargonium sidoides | Kaloba® | R07 | 10’100 | 27’438 | +172% |
| Anifrolumab | Saphnelo® | L04 | 0 | 22’959 | - |
| Pentosanpolysulfat-Natrium | Elmiron® | G04 | 30’611 | 17’532 | -43% |
| Abrocitinib | Cibinqo® | D11 | 7’818 | 16’913 | +116% |
| Somatrogon | Ngenla® | H01 | 0 | 7’653 | - |
| Propiverin | Mictonorm® | G04 | 15’851 | 0 | -100% |
| Daunorubicin | Daunoblastin® | L01 | 625 | 308 | -51% |
| Belantamab mafodotin | Blenrep® | L01 | 0 | 0 | - |
| Eliglustat | Cerdelga® | A16 | 0 | 0 | - |
| Onasemnogen-Abeparvovec | Zolgensma® | M09 | 0 | 0 | - |

* entspricht den durchschnittlich abgerechneten monatlichen Kosten seit Aufnahme in die Spezialitätenliste (SL)

Tabelle 13: Entwicklung der durchschnittlichen monatlichen Kosten der neuen Wirkstoffe aus dem Jahr 2022, Hochrechnung für die gesamte Schweiz

---

— Ende Teil 3 von 8 · Kontrollwort Teil 3: KAMOR-82 · weiter mit teil-04.md —
