# LAV-T03 · Volltext · Teil 2 von 8 (PDF-Seiten 20–31 von 102)

Studie: Helsana-Report: Arzneimittel – Medikamente erstmals grösster Kostenblock der Grundversicherung · Quelldatei: arzneimittelreport-2024-31e5177c.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 8 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T03, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 20/102]]

## 3.2 Entwicklung der Kosten und Bezüge ausgewählter Therapiegebiete

**[Kernaussagen]**

- Im Jahr 2023 machten Krebs- und Immunsystemmittel mit CHF 2.8 Milliarden 31% der gesamten Medikamentenkosten aus, obwohl sie nur 2.7% aller Bezüge verzeichneten. Die Kostensteigerung von CHF 245 Millionen gegenüber dem Vorjahr war hauptsächlich auf ein gesteigertes Marktvolumen hochpreisiger Medikamente zurückzuführen. Zusätzlich trugen Mengenausweitungen infolge von Indikationserweiterungen zu den gestiegenen Kosten bei.

- Die durchschnittlichen Jahreskosten der fünf Krebsmedikamente mit den höchsten Pro-Kopf-Kosten betrugen beispielsweise etwa CHF 90’000 pro behandelter Person.

- Trotz nur gering gestiegener Bezüge (+0.5%) stiegen die Kosten der Nervensystemmittel um CHF 32 Millionen (+3%) ebenfalls wegen einer höheren Marktdurchdringung kostenintensiver Therapien. Beispielsweise wurden Medikamente zur Behandlung von Depressionen und Aufmerksamkeitsdefizit-/Hyperaktivitätsstörung vermehrt eingesetzt, was zu einem erheblichen Umsatzanstieg führte. Auch das Medikament Vyndaqel® für Amyloidose und das Cannabis-haltige Sativex® zeigten deutliche Kosten- und Mengenzuwächse.

- Lipidsenker verzeichneten insbesondere wegen eines Wachstums bei den PCSK9-Inhibitoren und des ähnlich wirkenden neuen Präparats Leqvio® einen auffälligen Kostenanstieg von CHF 31 Millionen (+12%).

- Die drei umsatzstärksten Präparate – das Krebsmittel Keytruda®, das Augenmedikament Eylea® und der Gerinnungshemmer Xarelto® – blieben im Jahr 2023 weiterhin Spitzenreiter der kostenintensivsten Präparate und verursachten zusammengenommen Kosten von fast CHF 478 Millionen (5.3% der Gesamtkosten). Eylea® verzeichnete aufgrund von Verlagerungen zum neuen Augenmedikament Vabysmo® jedoch rückläufige Bezüge und verlor seine Spitzenposition.

- Andere Präparate schlossen durch gesteigerte Bezüge zur Spitze auf, beispielsweise der monoklonale Antikörper Darzalex® (Wirkstoff Daratumumab), das Immunglobulin Privigen® (Wirkstoff intravenöses Immunglobulin), der Gerinnungshemmer Eliquis® (Wirkstoff Apixaban) oder das Diabetesmittel Ozempic® (Wirkstoff Semaglutid).

**[Ende Kernaussagen]**

Der Gesamtzuwachs der Medikamentenkosten zu Lasten der OKP gegenüber dem Vorjahr war erheblich (+CHF 502.8 Millionen). Die dafür hauptverantwortlichen anatomischen Hauptgruppen, therapeutischen Medikamentengruppen und spezifischen Wirkstoffe sind Bestandteil dieses Kapitels.

Tabelle 5 bis Tabelle 10 geben jeweils den aktuellen Stand im Jahr 2023 und die Entwicklung der Kosten, Bezüge, Personen mit Bezügen und Pro-Kopf-Kosten gegenüber 2020 und 2022 an. Während Tabelle 5 alle anatomischen Hauptgruppen betrachtet, beziehen sich Tabelle 6 und Tabelle 7 auf die jeweils 15 kostenintensivsten respektive meistbezogenen therapeutischen Medikamentengruppen. Tabelle 8 und Tabelle 9 zeigen die 20 kostenintensivsten und meistbezogenen Wirkstoffe. Tabelle 10 betrachtet zusätzlich die 20 kostenintensivsten Präparate. Einen Überblick über die Medikamente mit dem grössten Umsatzwachstum gibt Tabelle 11. Im Anschluss an die Tabellen erfolgt eine detaillierte Betrachtung für ausgewählte Therapiegebiete.

[Hinweis Transkription: Der Anteil der Krebs- und Immunsystemmittel an allen Bezügen steht hier mit 2.7%. Die Zusammenfassung auf Seite 4 nennt 1.9%. Beide Angaben sind unverändert aus dem Original übernommen.]

[[Seite 21/102]]

| Bezeichnung (ATC 1) | 2023 · Kosten [CHF] (Anteil [%])* | 2023 · Bezüge [N] (Anteil [%])* | 2023 · Personen [N] | 2023 · PKK [CHF] | Anstieg 2022 [%] · Kosten | Anstieg 2022 [%] · Bezüge | Anstieg 2022 [%] · Personen | Anstieg 2022 [%] · PKK | Ø Anstieg pro Jahr seit 2020 [%] · Kosten | Ø Anstieg pro Jahr seit 2020 [%] · Bezüge | Ø Anstieg pro Jahr seit 2020 [%] · Personen | Ø Anstieg pro Jahr seit 2020 [%] · PKK |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Krebs/Immunsystem (L) | 2’795’506’983 (31.0) | 3’746’862 (2.7) | 345’670 | 8’087 | +9.6 | +5.7 | +6.5 | +2.9 | +7.0 | +4.6 | +4.8 | +2.1 |
| Nervensystem (N) | 1’066’889’293 (11.8) | 27’679’168 (20.3) | 4’005’500 | 266 | +3.1 | +0.5 | +0.0 | +3.1 | +3.2 | +2.1 | +3.1 | +0.0 |
| Stoffwechsel (A) | 1’017’682’605 (11.3) | 23’227’574 (17.0) | 3’763’336 | 270 | +5.4 | +0.6 | +0.3 | +5.1 | +5.4 | +2.3 | +3.0 | +2.3 |
| Herz-Kreislauf (C) | 812’781’598 (9.0) | 15’649’097 (11.5) | 2’358’669 | 345 | +2.8 | +3.0 | +2.4 | +0.4 | +2.1 | +2.5 | +2.4 | -0.3 |
| Antiinfektiva (J) | 731’635’529 (8.1) | 7’471’189 (5.5) | 3’006’311 | 243 | +8.3 | +7.3 | +5.2 | +3.0 | +3.5 | +3.8 | +2.7 | +0.7 |
| Blut (B) | 695’463’731 (7.7) | 10’128’942 (7.4) | 2’658’026 | 262 | +4.1 | +4.1 | +2.2 | +1.9 | +4.2 | +4.3 | +3.5 | +0.7 |
| Atmung (R) | 425’411’738 (4.7) | 10’348’952 (7.6) | 2’806’268 | 152 | +3.0 | 0.0 | +0.5 | +2.5 | +9.6 | +5.3 | +6.8 | +2.6 |
| Sinnesorgane (S) | 395’438’725 (4.4) | 7’270’869 (5.3) | 1’642’190 | 241 | -0.5 | +3.7 | +6.8 | -6.9 | +4.1 | +4.4 | +6.9 | -2.6 |
| Bewegungsapparat (M) | 298’718’875 (3.3) | 10’715’718 (7.8) | 3’430’282 | 87 | +2.1 | +0.0 | -0.6 | +2.8 | +3.1 | +3.8 | +4.4 | -1.3 |
| Verschiedene (V) | 236’038’060 (2.6) | 4’501’100 (3.3) | 1’068’987 | 221 | +5.0 | +3.8 | +5.1 | -0.1 | +3.1 | +3.8 | +5.5 | -2.3 |
| Haut (D) | 203’986’092 (2.3) | 7’026’653 (5.1) | 2’293’743 | 89 | +8.0 | +0.5 | +1.7 | +6.2 | +7.0 | +0.6 | +1.9 | +5.0 |
| Geschlechtsorgane (G) | 193’796’737 (2.1) | 3’994’317 (2.9) | 1’089’645 | 178 | +5.0 | +5.8 | +5.0 | +0.0 | +2.7 | +4.2 | +4.0 | -1.3 |
| Hormone (H) | 101’679’862 (1.1) | 3’175’643 (2.3) | 1’206’122 | 84 | +7.7 | +1.9 | +0.6 | +7.1 | +2.9 | +1.8 | +3.9 | -1.0 |
| Parasiten (P) | 7’406’578 (0.1) | 469’389 (0.3) | 103’438 | 72 | +0.7 | +2.8 | +6.1 | -5.1 | +3.4 | +4.7 | +1.5 | +1.9 |

[Fussnote *] Total Kosten: CHF 9’021 Mio., Total Bezüge: 136.6 Mio.

## Tabelle 5: Anatomische Hauptgruppen (ATC 1). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz

[[Seite 22/102]]

| Bezeichnung (ATC 3) | 2023 · Kosten [CHF] (Anteil [%])* | 2023 · Bezüge [N] (Anteil [%])* | 2023 · Personen [N] | 2023 · PKK [CHF] | Anstieg 2022 [%] · Kosten | Anstieg 2022 [%] · Bezüge | Anstieg 2022 [%] · Personen | Anstieg 2022 [%] · PKK | Ø Anstieg pro Jahr seit 2020 [%] · Kosten | Ø Anstieg pro Jahr seit 2020 [%] · Bezüge | Ø Anstieg pro Jahr seit 2020 [%] · Personen | Ø Anstieg pro Jahr seit 2020 [%] · PKK |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Immunsuppressiva (L04) | 1’327’256’744 (14.7) | 2’213’954 (1.6) | 138’438 | 9’587 | +6.0 | +5.8 | +8.1 | -1.9 | +4.3 | +5.4 | +6.8 | -2.3 |
| Krebsmedikamente (L01) | 1’212’173’879 (13.4) | 1’194’587 (0.9) | 164’086 | 7’387 | +13.1 | +5.2 | +6.1 | +6.5 | +10.4 | +3.1 | +3.8 | +6.3 |
| Diabetesmedikamente (A10) | 455’204’557 (5.0) | 5’191’371 (3.8) | 555’513 | 819 | +10.6 | +8.9 | +11.2 | -0.5 | +10.6 | +7.4 | +9.4 | +1.1 |
| Augenmedikamente (S01) | 393’213’365 (4.4) | 7’048’560 (5.2) | 1’505’686 | 261 | -0.6 | +3.6 | +7.0 | -7.1 | +4.1 | +4.4 | +6.9 | -2.6 |
| Mittel zur Hemmung der Blutgerinnung (B01) | 357’174’926 (4.0) | 3’947’570 (2.9) | 1’078’854 | 331 | +4.4 | +1.2 | +1.2 | +3.1 | +2.9 | +1.1 | +1.8 | +1.1 |
| Psychoanaleptika (N06) | 316’012’449 (3.5) | 5’195’922 (3.8) | 1’012’785 | 312 | +5.4 | +5.2 | +4.0 | +1.3 | +3.4 | +4.2 | +3.5 | -0.2 |
| Lipidsenker (C10) | 290’928’737 (3.2) | 3’648’705 (2.7) | 1’020’623 | 285 | +11.7 | +8.4 | +5.8 | +5.6 | +6.8 | +7.7 | +5.4 | +1.3 |
| Antiviralia (J05) | 286’004’649 (3.2) | 551’961 (0.4) | 132’867 | 2’153 | +0.5 | +3.3 | +6.5 | -5.6 | -3.0 | +0.6 | +4.6 | -7.3 |
| Blutdruckmittel RAAS (C09) | 281’058’222 (3.1) | 4’902’890 (3.6) | 1’305’682 | 215 | +0.4 | +2.9 | +2.5 | -2.1 | +0.7 | +2.3 | +2.1 | -1.4 |
| Schmerzmittel (N02) | 279’194’355 (3.1) | 11’345’364 (8.3) | 2’861’521 | 98 | +1.6 | -1.8 | -1.6 | +3.3 | +1.0 | +2.1 | +3.4 | -2.3 |
| Atemwegserweiternde Mittel (R03) | 249’658’357 (2.8) | 3’059’584 (2.2) | 810’235 | 308 | +3.6 | +1.4 | +3.5 | +0.1 | +4.0 | +1.4 | +6.7 | -2.5 |
| Psycholeptika (N05) | 215’626’877 (2.4) | 7’185’402 (5.3) | 1’084’465 | 199 | +0.5 | +1.1 | +1.0 | -0.5 | -2.0 | +0.8 | +1.0 | -3.0 |
| Endokrine Therapie (L02) | 195’062’156 (2.2) | 262’286 (0.2) | 57’724 | 3’379 | +15.2 | +6.9 | +2.9 | +12.0 | +11.9 | +7.0 | +3.9 | +7.8 |
| Magensäureblocker (A02) | 175’594’968 (1.9) | 4’347’588 (3.2) | 1’699’667 | 103 | +1.2 | +1.1 | +1.8 | -0.6 | +1.2 | +1.4 | +2.7 | -1.4 |
| Immunsera und Immunglobuline (J06) | 166’192’987 (1.8) | 180’070 (0.1) | 17’792 | 9’341 | +14.0 | +12.5 | +3.0 | +10.7 | +10.4 | +6.2 | -0.1 | +10.5 |

[Fussnote *] Total Kosten: CHF 9’021 Mio., Total Bezüge: 136.6 Mio.

## Tabelle 6: Die 15 kostenintensivsten therapeutischen Medikamentengruppen (ATC 3). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz

[[Seite 23/102]]

| Bezeichnung (ATC 3) | 2023 · Kosten [CHF] (Anteil [%])* | 2023 · Bezüge [N] (Anteil [%])* | 2023 · Personen [N] | 2023 · PKK [CHF] | Anstieg 2022 [%] · Kosten | Anstieg 2022 [%] · Bezüge | Anstieg 2022 [%] · Personen | Anstieg 2022 [%] · PKK | Ø Anstieg pro Jahr seit 2020 [%] · Kosten | Ø Anstieg pro Jahr seit 2020 [%] · Bezüge | Ø Anstieg pro Jahr seit 2020 [%] · Personen | Ø Anstieg pro Jahr seit 2020 [%] · PKK |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Schmerzmittel (N02) | 279’194’355 (3.1) | 11’345’364 (8.3) | 2’861’521 | 98 | +1.6 | -1.8 | -1.6 | +3.3 | +1.0 | +2.1 | +3.4 | -2.3 |
| Psycholeptika (N05) | 215’626’877 (2.4) | 7’185’402 (5.3) | 1’084’465 | 199 | +0.5 | +1.1 | +1.0 | -0.5 | -2.0 | +0.8 | +1.0 | -3.0 |
| Antiphlogistika und Antirheumatika (M01) | 126’953’719 (1.4) | 7’048’560 (5.2) | 2’944’573 | 43 | -4.4 | +3.6 | -0.9 | -3.5 | -0.1 | +4.4 | +5.1 | -5.0 |
| Augenmedikamente (S01) | 393’213’365 (4.4) | 6’652’446 (4.9) | 1’505’686 | 261 | -0.6 | -0.3 | +7.0 | -7.1 | +4.1 | +5.2 | +6.9 | -2.6 |
| Psychoanaleptika (N06) | 316’012’449 (3.5) | 5’195’922 (3.8) | 1’012’785 | 312 | +5.4 | +5.2 | +4.0 | +1.3 | +3.4 | +4.2 | +3.5 | -0.2 |
| Blutdruckmittel RAAS (C09) | 281’058’222 (3.1) | 5’191’371 (3.8) | 1’305’682 | 215 | +0.4 | +8.9 | +2.5 | -2.1 | +0.7 | +7.4 | +2.1 | -1.4 |
| Blutersatzmittel (B05) | 32’101’821 (0.4) | 4’902’890 (3.6) | 1’476’799 | 22 | +11.2 | +2.9 | +4.1 | +6.8 | +7.6 | +2.3 | +6.7 | +0.9 |
| Magensäureblocker (A02) | 175’594’968 (1.9) | 4’347’588 (3.2) | 1’699’667 | 103 | +1.2 | +1.1 | +1.8 | -0.6 | +1.2 | +1.4 | +2.7 | -1.4 |
| Diabetesmedikamente (A10) | 455’204’557 (5.0) | 4’335’655 (3.2) | 555’513 | 819 | +10.6 | +6.4 | +11.2 | -0.5 | +10.6 | +7.8 | +9.4 | +1.1 |
| Mittel zur Hemmung der Blutgerinnung (B01) | 357’174’926 (4.0) | 3’947’570 (2.9) | 1’078’854 | 331 | +4.4 | +1.2 | +1.2 | +3.1 | +2.9 | +1.1 | +1.8 | +1.1 |
| Mineralstoffe (A12) | 133’550’708 (1.5) | 3’845’596 (2.8) | 1’162’144 | 115 | +2.4 | -9.7 | +4.0 | -1.5 | +0.9 | -2.6 | +3.3 | -2.3 |
| Lipidsenker (C10) | 290’928’737 (3.2) | 3’784’952 (2.8) | 1’020’623 | 285 | +11.7 | +5.7 | +5.8 | +5.6 | +6.8 | +7.0 | +5.4 | +1.3 |
| Systemische Antibiotika (J01) | 95’095’115 (1.1) | 3’768’785 (2.8) | 1’782’398 | 53 | +5.8 | +5.3 | +5.9 | -0.1 | +4.6 | +3.6 | +7.8 | -2.9 |
| Vitamine (A11) | 36’520’167 (0.4) | 3’648’705 (2.7) | 1’198’175 | 30 | -8.7 | +8.4 | -9.3 | +0.7 | -0.7 | +7.7 | -1.0 | +0.3 |
| Mittel gegen Blutarmut (B03) | 148’187’739 (1.6) | 3’059’584 (2.2) | 1’027’028 | 144 | +7.2 | +1.4 | +3.7 | +3.4 | +5.0 | +1.4 | +4.7 | +0.3 |

[Fussnote *] Total Kosten: CHF 9’021 Mio., Total Bezüge: 136.6 Mio.

## Tabelle 7: Die 15 meistbezogenen therapeutischen Medikamentengruppen (ATC 3). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz

[Hinweis Transkription: Quellenwiderspruch zwischen Tabelle 6 (Seite 22) und Tabelle 7 (Seite 23). Die folgenden Angaben zu denselben Medikamentengruppen unterscheiden sich im Original: Diabetesmedikamente (A10): Bezüge 2023 [N] (Anteil [%]): Tabelle 6 5’191’371 (3.8), Tabelle 7 4’335’655 (3.2); Anstieg 2022 Bezüge [%]: Tabelle 6 +8.9, Tabelle 7 +6.4; Ø Anstieg pro Jahr seit 2020 Bezüge [%]: Tabelle 6 +7.4, Tabelle 7 +7.8. Augenmedikamente (S01): Bezüge 2023 [N] (Anteil [%]): Tabelle 6 7’048’560 (5.2), Tabelle 7 6’652’446 (4.9); Anstieg 2022 Bezüge [%]: Tabelle 6 +3.6, Tabelle 7 -0.3; Ø Anstieg pro Jahr seit 2020 Bezüge [%]: Tabelle 6 +4.4, Tabelle 7 +5.2. Lipidsenker (C10): Bezüge 2023 [N] (Anteil [%]): Tabelle 6 3’648’705 (2.7), Tabelle 7 3’784’952 (2.8); Anstieg 2022 Bezüge [%]: Tabelle 6 +8.4, Tabelle 7 +5.7; Ø Anstieg pro Jahr seit 2020 Bezüge [%]: Tabelle 6 +7.7, Tabelle 7 +7.0. Blutdruckmittel RAAS (C09): Bezüge 2023 [N] (Anteil [%]): Tabelle 6 4’902’890 (3.6), Tabelle 7 5’191’371 (3.8); Anstieg 2022 Bezüge [%]: Tabelle 6 +2.9, Tabelle 7 +8.9; Ø Anstieg pro Jahr seit 2020 Bezüge [%]: Tabelle 6 +2.3, Tabelle 7 +7.4. Alle Angaben wurden am Seitenbild geprüft und unverändert übernommen.]

[[Seite 24/102]]

| Wirkstoff (ATC 5) | 2023 · Kosten [CHF] (Anteil [%])* | 2023 · Bezüge [N] (Anteil [%])* | 2023 · Personen [N] | 2023 · PKK [CHF] | Anstieg 2022 [%] · Kosten | Anstieg 2022 [%] · Bezüge | Anstieg 2022 [%] · Personen | Anstieg 2022 [%] · PKK | Ø Anstieg pro Jahr seit 2020 [%] · Kosten | Ø Anstieg pro Jahr seit 2020 [%] · Bezüge | Ø Anstieg pro Jahr seit 2020 [%] · Personen | Ø Anstieg pro Jahr seit 2020 [%] · PKK |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Pembrolizumab[§] | 169’103’302 (1.9) | - | - | - | +8.2 | +1.9 | +9.3 | -1.1 | +8.7 | -6.0 | +14.5 | -5.0 |
| Aflibercept | 160’006’621 (1.8) | 163’100 (0.1) | 31’263 | 5’118 | -10.4 | -4.1 | +4.6 | -14.3 | +4.2 | +6.9 | +9.0 | -4.4 |
| Rivaroxaban | 148’504’714 (1.6) | 736’449 (0.5) | 265’378 | 560 | +1.6 | +1.5 | +3.0 | -1.3 | +0.6 | +3.6 | +5.5 | -4.6 |
| Adalimumab | 139’505’750 (1.5) | 213’025 (0.2) | 13’995 | 9’968 | +3.3 | +6.9 | +9.2 | -5.4 | +4.8 | +4.8 | +9.1 | -4.0 |
| Infliximab | 133’205’915 (1.5) | 202’865 (0.1) | 7’623 | 17’474 | +7.9 | +9.7 | +11.4 | -3.2 | +1.5 | +7.0 | +5.1 | -3.3 |
| Humane Immunglobuline | 133’068’806 (1.5) | 100’028 (0.1) | 5’253 | 25’332 | +11.5 | +8.1 | +14.9 | -2.9 | +8.9 | +5.4 | +8.5 | +0.4 |
| Semaglutid | 113’039’553 (1.3) | 791’799 (0.6) | 107’597 | 1’051 | +39.4 | +34.6 | +41.4 | -1.4 | +55.1 | +52.6 | +52.3 | +1.8 |
| Daratumumab[§] | 104’982’072 (1.2) | - | - | - | +17.4 | +15.9 | +25.6 | -6.5 | +40.7 | +4.0 | +48.4 | -5.2 |
| Pantoprazol | 104’349’084 (1.2) | 2’834’035 (2.1) | 1’272’326 | 82 | +1.9 | +1.1 | +2.4 | -0.6 | +2.1 | +2.0 | +3.8 | -1.6 |
| Apixaban | 91’902’651 (1.0) | 490’240 (0.4) | 119’128 | 771 | +19.8 | +16.1 | +18.1 | +1.5 | +18.6 | +16.2 | +21.1 | -2.1 |
| Golimumab | 85’577’596 (0.9) | 59’131 (0.0) | 6’651 | 12’867 | +11.5 | +10.7 | +9.1 | +2.2 | +7.0 | +7.4 | +5.6 | +1.3 |
| Eisen, parenteral | 85’465’691 (0.9) | 329’295 (0.2) | 288’867 | 296 | +5.5 | +5.0 | +6.0 | -0.5 | +6.1 | +6.0 | +6.1 | 0.0 |
| Ustekinumab | 81’475’454 (0.9) | 24’061 (0.0) | 4’722 | 17’254 | +19.0 | +19.4 | +19.5 | -0.4 | +23.1 | +26.3 | +19.8 | +2.7 |
| Ocrelizumab | 79’414’245 (0.9) | 17’155 (0.0) | 5’206 | 15’254 | +7.6 | +20.7 | +20.7 | -10.9 | +9.3 | +15.1 | +15.6 | -5.4 |
| Atorvastatin | 75’414’835 (0.8) | 1’235’276 (0.9) | 405’266 | 186 | -3.4 | +1.7 | +0.8 | -4.2 | -2.0 | +2.8 | +1.4 | -3.4 |
| Nivolumab[§] | 69’486’742 (0.8) | - | - | - | +6.1 | +9.9 | +13.1 | -6.2 | +13.1 | +15.9 | +17.3 | -3.5 |
| Bictegravir, Kombi | 67’891’510 (0.8) | 58’587 (0.0) | 5’858 | 11’590 | +12.8 | +12.5 | +9.0 | +3.5 | +14.6 | +17.3 | +14.7 | -0.1 |
| Vedolizumab | 66’496’645 (0.7) | 37’167 (0.0) | 4’081 | 16’294 | +17.9 | +27.7 | +19.9 | -1.7 | +15.3 | +32.8 | +17.4 | -1.8 |
| Elexacaftor[§][†] | 64’232’548 (0.7) | - | - | - | - | - | - | - | - | - | - | - |
| Paracetamol | 60’372’561 (0.7) | 5’028’253 (3.7) | 2’356’609 | 26 | -2.6 | -3.3 | -2.1 | -0.6 | +2.2 | +3.5 | +4.2 | -1.9 |

[Fussnote *] Total Kosten: CHF 9’021 Mio., Total Bezüge: 136.6 Mio.

[Fussnote §] Mit geheimen Preismodell.

[Fussnote †] Aufgrund des Spezialkapitels im Vorjahresreport Anstiege gegenüber dem Jahr 2022 nicht angegeben.

## Tabelle 8: Die 20 kostenintensivsten Wirkstoffe (ATC 5). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz

[[Seite 25/102]]

| Wirkstoff (ATC 5) | 2023 · Kosten [CHF] (Anteil [%])* | 2023 · Bezüge [N] (Anteil [%])* | 2023 · Personen [N] | 2023 · PKK [CHF] | Anstieg 2022 [%] · Kosten | Anstieg 2022 [%] · Bezüge | Anstieg 2022 [%] · Personen | Anstieg 2022 [%] · PKK | Ø Anstieg pro Jahr seit 2020 [%] · Kosten | Ø Anstieg pro Jahr seit 2020 [%] · Bezüge | Ø Anstieg pro Jahr seit 2020 [%] · Personen | Ø Anstieg pro Jahr seit 2020 [%] · PKK |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Paracetamol | 60'372'561 (0.7) | 5'028'253 (3.7) | 2'356'609 | 26 | -2.6 | -3.3 | -2.1 | -0.6 | +2.2 | +3.5 | +4.2 | -1.9 |
| Elektrolytlösung | 20'462'304 (0.2) | 4'012'592 (2.9) | 1'433'764 | 14 | +3.7 | +6.0 | +4.1 | -0.3 | +5.3 | +7.8 | +6.7 | -1.4 |
| Ibuprofen | 28'754'689 (0.3) | 3'380'166 (2.5) | 2'006'617 | 14 | -16.9 | -0.2 | -0.1 | -16.8 | -0.5 | +11.0 | +10.3 | -9.8 |
| Künstliche Tränenflüssigkeit | 56'835'129 (0.6) | 3'324'205 (2.4) | 853'701 | 67 | +5.3 | +0.8 | +4.0 | +1.2 | +6.5 | +2.8 | +6.0 | +0.5 |
| Colecalciferol (Vit. D) | 30'825'101 (0.3) | 3'280'081 (2.4) | 1'111'093 | 28 | -7.3 | -9.7 | -9.8 | +2.7 | +0.4 | -2.8 | -1.3 | +1.8 |
| Pantoprazol | 104'349'084 (1.2) | 2'834'035 (2.1) | 1'272'326 | 82 | +1.9 | +1.1 | +2.4 | -0.6 | +2.1 | +2.0 | +3.8 | -1.6 |
| Metamizol | 16'855'366 (0.2) | 2'091'214 (1.5) | 879'876 | 19 | -0.5 | -1.4 | +1.4 | -1.9 | +1.6 | +2.5 | +4.8 | -3.1 |
| Acetylsalicylsäure | 27'521'538 (0.3) | 1'815'546 (1.3) | 573'620 | 48 | -0.5 | -0.5 | +0.0 | -0.5 | -1.2 | -0.7 | -0.2 | -1.0 |
| Diclofenac topisch | 31'211'973 (0.3) | 1'703'264 (1.2) | 701'819 | 44 | +0.9 | -2.1 | -0.9 | +1.9 | +6.5 | +0.4 | +2.7 | +3.7 |
| Calcium, Kombinationen | 55'623'513 (0.6) | 1'455'939 (1.1) | 510'111 | 109 | +4.5 | +2.4 | +3.3 | +1.1 | -1.1 | +3.4 | +2.8 | -3.8 |
| Metformin | 13'394'427 (0.1) | 1'400'697 (1.0) | 244'251 | 55 | +4.1 | +4.3 | +4.5 | -0.4 | -1.0 | +1.8 | +3.5 | -4.3 |
| Zolpidem | 12'599'303 (0.1) | 1'376'179 (1.0) | 232'152 | 54 | +1.0 | +2.1 | +1.4 | -0.5 | -3.1 | +2.1 | -0.1 | -2.9 |
| Levothyroxin-Na+ | 19'454'130 (0.2) | 1'259'133 (0.9) | 344'763 | 56 | +8.2 | +3.7 | +3.7 | +4.4 | +3.4 | +1.7 | +2.7 | +0.7 |
| Atorvastatin | 75'414'835 (0.8) | 1'235'276 (0.9) | 405'266 | 186 | -3.4 | +1.7 | +0.8 | -4.2 | -2.0 | +2.8 | +1.4 | -3.4 |
| Macrogol, Kombinationen | 25'258'802 (0.3) | 1'092'128 (0.8) | 570'581 | 44 | +3.3 | +3.3 | +5.1 | -1.7 | +1.7 | +2.9 | +5.5 | -3.6 |
| Amoxicillin und Enzyminhibitoren | 33'546'623 (0.4) | 1'067'856 (0.8) | 742'423 | 45 | +10.9 | +11.9 | +10.5 | +0.4 | +10.8 | +13.2 | +12.4 | -1.5 |
| Magnesiumaspartat | 31'673'781 (0.4) | 1'016'306 (0.7) | 377'991 | 84 | -6.3 | +10.5 | +7.8 | -13.1 | -1.2 | +3.5 | +4.0 | -5.0 |
| Rosuvastatin | 51'860'620 (0.6) | 1'003'427 (0.7) | 332'574 | 156 | +6.5 | +8.6 | +9.6 | -2.8 | +1.9 | +9.0 | +9.3 | -6.7 |
| Magnesiumcitrat | 36'657'578 (0.4) | 964'333 (0.7) | 359'250 | 102 | +8.8 | +8.4 | +7.0 | +1.6 | +7.5 | +7.2 | +7.2 | +0.3 |
| Vaselin- und fetthaltige Mittel | 16'557'493 (0.2) | 941'877 (0.7) | 485'822 | 34 | +1.6 | +0.6 | +1.6 | 0.0 | +3.2 | +2.3 | +3.2 | 0.0 |

[Fussnote *] Total Kosten: CHF 9’021 Mio., Total Bezüge: 136.6 Mio.

## Tabelle 9: Die 20 meistbezogenen Wirkstoffe (ATC 5). Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz

[[Seite 26/102]]

| Präparatname | 2023 · Kosten [CHF] (Anteil [%])* | 2023 · Bezüge [N] (Anteil [%])* | 2023 · Personen [N] | 2023 · PKK [CHF] | Anstieg 2022 [%] · Kosten | Anstieg 2022 [%] · Bezüge | Anstieg 2022 [%] · Personen | Anstieg 2022 [%] · PKK | Ø Anstieg pro Jahr seit 2020 [%] · Kosten | Ø Anstieg pro Jahr seit 2020 [%] · Bezüge | Ø Anstieg pro Jahr seit 2020 [%] · Personen | Ø Anstieg pro Jahr seit 2020 [%] · PKK |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Keytruda®[§] | 169’103’302 (1.9) | - | - | - | +8.2 | +1.9 | +9.3 | -1.1 | +8.7 | -6.0 | +14.5 | -5.0 |
| Eylea® | 160’006’621 (1.8) | 163’100 (0.1) | 31’263 | 5’118 | -10.4 | -4.1 | +4.6 | -14.3 | +4.2 | +6.9 | +9.0 | -4.4 |
| Xarelto® | 148’504’746 (1.6) | 736’450 (0.5) | 265’378 | 560 | +1.6 | +1.5 | +3.0 | -1.3 | +0.6 | +3.6 | +5.5 | -4.6 |
| Darzalex®[§] | 104’982’072 (1.2) | - | - | - | +17.4 | +15.9 | +25.6 | -6.5 | +40.7 | +4.0 | +48.4 | -5.2 |
| Privigen® | 99’105’981 (1.1) | 71’361 (0.1) | 4’016 | 24’678 | +13.2 | +12.5 | +16.4 | -2.7 | +8.7 | +5.3 | +8.1 | +0.6 |
| Pantoprazol® | 97’709’576 (1.1) | 2’648’701 (1.9) | 1’203’210 | 81 | +2.7 | +2.1 | +3.1 | -0.4 | +3.1 | +2.9 | +4.3 | -1.2 |
| Humira® | 96’864’731 (1.1) | 161’207 (0.1) | 8’387 | 11’549 | -5.9 | +1.7 | -1.4 | -4.6 | -4.4 | -0.9 | -3.4 | -1.0 |
| Eliquis® | 91’902’651 (1.0) | 490’240 (0.4) | 119’128 | 771 | +19.8 | +16.1 | +18.1 | +1.5 | +18.6 | +16.2 | +21.1 | -2.1 |
| Ozempic® | 85’728’940 (1.0) | 664’605 (0.5) | 81’408 | 1’053 | +23.9 | +24.6 | +26.7 | -2.2 | +42.7 | +44.9 | +41.9 | +0.6 |
| Simponi® | 85’577’596 (0.9) | 59’131 (0.0) | 6’651 | 12’867 | +11.5 | +10.7 | +9.1 | +2.2 | +7.0 | +7.4 | +5.6 | +1.3 |
| Stelara® | 81’475’454 (0.9) | 24’061 (0.0) | 4’722 | 17’254 | +19.0 | +19.4 | +19.5 | -0.4 | +23.1 | +26.3 | +19.8 | +2.7 |
| Ferinject® | 79’719’313 (0.9) | 294’606 (0.2) | 263’979 | 302 | +4.7 | +4.4 | +5.3 | -0.6 | +5.2 | +5.5 | +5.4 | -0.2 |
| Ocrevus® | 79’414’245 (0.9) | 17’155 (0.0) | 5’206 | 15’254 | +7.6 | +20.7 | +20.7 | -10.9 | +9.3 | +15.1 | +15.6 | -5.4 |
| Remicade® | 79’328’160 (0.9) | 115’432 (0.1) | 4’377 | 18’124 | -4.9 | -4.1 | -2.1 | -2.8 | -6.6 | -0.7 | -2.5 | -4.2 |
| Atorvastatin® | 71’895’834 (0.8) | 1’188’558 (0.9) | 394’821 | 182 | -1.9 | +2.7 | +2.1 | -3.9 | +0.6 | +4.3 | +2.9 | -2.2 |
| Opdivo® | 69’486’742 (0.8) | - | - | - | +6.1 | +9.9 | +13.1 | -6.2 | +13.1 | +15.9 | +17.3 | -3.5 |
| Biktarvy® | 67’883’495 (0.8) | 58’532 (0.0) | 5’840 | 11’624 | +12.7 | +12.5 | +8.8 | +3.7 | +14.6 | +17.2 | +14.6 | +0.0 |
| Entyvio® | 66’496’645 (0.7) | 37’167 (0.0) | 4’081 | 16’294 | +17.9 | +27.7 | +19.9 | -1.7 | +15.3 | +32.8 | +17.4 | -1.8 |
| Trikafta®[§][†] | 64’232’548 (0.7) | - | - | - | - | +19.7 | +19.0 | -8.8 | - | - | - | - |
| Vyndaqel®[§] | 59’281’645 (0.7) | - | - | - | +10.9 | +36.8 | +45.6 | -23.9 | +134 | +137 | +64.5 | +41.9 |

[Fussnote *] Total Kosten: CHF 9’021 Mio., Total Bezüge: 136.6 Mio.

[Fussnote §] Mit geheimen Preismodell.

[Fussnote †] Aufgrund des Spezialkapitels im Vorjahresreport Kostenanstieg gegenüber dem Jahr 2022 nicht angegeben.

## Tabelle 10: Die 20 kostenintensivsten Präparate. Kosten, Bezüge, Personen und Pro-Kopf-Kosten (PKK), 2023, Hochrechnung für die gesamte Schweiz

[[Seite 27/102]]

| Wirkstoff | ATC | Kosten 2023 (CHF) | Umsatzsteigerung zu 2022 (CHF) | Umsatzsteigerung zu 2022 (%) |
|---|---|---|---|---|
| **Krebsmedikamente (L01)** | | | | |
| Trastuzumab deruxtecan | L01FD04 | 36’225’890 | 28’343’799 | +359.6 |
| Durvalumab | L01FF03 | 37’883’911 | 20’959’314 | +123.8 |
| Daratumumab | L01FC01 | 104’982’072 | 15’525’868 | +17.4 |
| Pertuzumab/Trastuzumab | L01FY01 | 18’122’295 | 13’009’162 | +254.4 |
| Pembrolizumab | L01FF02 | 169’103’302 | 12’782’278 | +8.2 |
| **Immunsuppressiva (L04)** | | | | |
| Ustekinumab | L04AC05 | 81’475’454 | 13’012’216 | +19.0 |
| Risankizumab | L04AC18 | 36’454’210 | 12’365’157 | +51.3 |
| Vedolizumab | L04AG05 | 66’496’645 | 10’077’394 | +17.9 |
| Infliximab | L04AB02 | 133’205’915 | 9’726’924 | +7.9 |
| Upadacitinib | L04AF03 | 41’959’533 | 8’845’462 | +26.7 |
| **Diabetesmedikamente (A10)** | | | | |
| Semaglutid | A10BJ06 | 113’039’553 | 31’928’790 | +39.4 |
| Dapagliflozin | A10BK01 | 40’192’583 | 13’504’961 | +50.6 |
| Empagliflozin | A10BK03 | 30’564’020 | 4’100’605 | +15.5 |
| Empagliflozin, Kombination | A10BD20 | 25’314’606 | 3’444’015 | +15.7 |
| Metformin/Dapagliflozin | A10BD15 | 12’076’202 | 2’864’456 | +31.1 |
| **Lipidsenker (C10)** | | | | |
| Evolocumab | C10AX13 | 24’956’175 | 8’339’416 | +50.2 |
| Rosuvastatin/Ezetimib | C10BA06 | 26’570’161 | 7’799’657 | +41.6 |
| Inclisiran | C10AX16 | 8’118’522 | 6’987’199 | +617.6 |
| Alirocumab | C10AX14 | 17’602’556 | 5’687’097 | +47.7 |
| Atorvastatin/Ezetimib | C10BA05 | 28’542’239 | 3’214’453 | +12.7 |
| **Impfstoffe (J07)** | | | | |
| Zoster-Impfstoff | J07BK03 | 42’114’014 | 17’143’669 | +68.7 |
| MMRV-Impfstoff | J07BD54 | 9’864’505 | 6’440’300 | +188.1 |
| Varicella-Impfstoff | J07BK01 | 8’129’985 | 5’705’477 | +235.3 |
| FSME, inaktiviert | J07BA01 | 20’789’795 | 1’136’809 | +5.8 |
| Influenza, inaktiviert | J07BB02 | 12’953’930 | 1’084’638 | +9.1 |

## Tabelle 11: Umsatzsteigerung der jeweils fünf Wirkstoffe mit dem grössten absoluten Wachstum innerhalb der wachstumsstärksten therapeutischen Medikamentengruppen, 2023, Hochrechnung für die gesamte Schweiz

## 3.2.1 Krebs- und Immunsystemmittel (L)

Die Medikamentengruppe der Krebs- und Immunsystemmittel lag erneut an der Spitze der kostenintensivsten anatomischen Hauptgruppen. Im Vergleich zum Vorjahr stiegen die Kosten um über CHF 245 Millionen (+9.6%), sodass die Gesamtkosten im Jahr 2023 fast CHF 2.8 Milliarden betrugen (Tabelle 5). Dies entspricht nahezu einem Drittel aller Medikamentenkosten. Der Anteil der Krebs- und

[[Seite 28/102]]

Immunsystemmittel an den Gesamtbezügen war jedoch mit 2.7% der drittniedrigste aller Hauptgruppen, nach den Mitteln gegen Parasiten und den Hormonen. Die Pro-Kopf-Kosten für Personen mit mindestens einem Bezug eines Krebs- und Immunsystemmittels lagen mit über CHF 8’000 um ein Vielfaches höher als die Pro-Kopf-Kosten der anderen Hauptgruppen, wobei die Heterogenität zwischen den einzelnen Krebs- und Immunsystempräparaten jedoch sehr gross war. Sie lagen beispielsweise bei den fünf Krebsmedikamenten mit den höchsten jährlichen Pro-Kopf-Kosten (Rydapt®, Poteligeo®, Xospata®, Vitrakvi®, Qinlock®) gegen CHF 90’000 pro behandelter Person. Sowohl die Bezüge als auch die Anzahl der Personen mit Bezügen der Krebs- und Immunsystemmittel stiegen weniger stark als die Kosten, was zu einem Anstieg der Pro-Kopf-Kosten gegenüber 2022 führte (+2.9%).

Vier therapeutische Gruppen gehören zur anatomischen Hauptgruppe der Krebs- und Immunsystemmittel. Mit Ausnahme der Immunstimulanzien (L03) befanden sich alle in den Top 15 der kostenintensivsten therapeutischen Medikamentengruppen. Immunsuppressiva (L04), die einen oder mehrere Faktoren des Immunsystems vollständig oder teilweise unterdrücken, werden beispielsweise zur Behandlung von Autoimmunerkrankungen und allergischen Erkrankungen oder zur Vorbeugung gegen eine Transplantatabstossung eingesetzt. Im Jahr 2023 verursachten Immunsuppressiva Kosten von über CHF 1.3 Milliarden, was einem Anteil von 14.7% an den Gesamtkosten aller therapeutischen Gruppen entspricht, obwohl der Anteil an den Bezügen nur 1.6% betrug (Tabelle 6). Die Kosten der Immunsuppressiva stiegen im Vergleich zum Vorjahr um CHF 75 Millionen (+6.0%). Wie schon im Vorjahresreport beobachtet, sanken die Pro-Kopf-Kosten etwas (-1.9%), was vor allem auf Wechsel zu preisgünstigeren Alternativen zurückzuführen ist (siehe hierzu auch Kapitel 3.4). Im Gegensatz dazu stiegen die Pro-Kopf-Kosten der Krebsmedikamente (L01) aufgrund eines steigenden Marktanteils kostenintensiver Therapien zwischen 2022 und 2023 deutlich an (+6.5%; Tabelle 6). Dies führte, auch wegen der Zunahme der Personen mit Bezügen (+6.1%) und entsprechend steigender Bezüge (+5.2%), zu einer starken Kostensteigerung um CHF 140 Millionen (+13.1%) und resultierte in Gesamtkosten für Krebsmedikamente von CHF 1.2 Milliarden für das Jahr 2023. Auch bei den endokrinen Therapeutika (L02) – Östrogene und Gestagene, die speziell zur Behandlung von neoplastischen Erkrankungen eingesetzt werden – stiegen neben der Anzahl der Personen mit Bezügen (+2.9%) und der Bezüge (+6.9%) insbesondere die Pro-Kopf-Kosten (+12.0%) und somit die Gesamtkosten (+CHF 25.7 Millionen, +15.2%).

Zu den kostenintensivsten Wirkstoffen der letzten Jahre zählt der monoklonale Antikörper Keytruda® (Pembrolizumab, L01FF02), welcher die Immunantwort gegen Krebszellen anregt und zuerst zur Behandlung von malignen Melanomen eingesetzt wurde. Er hat seit seiner Zulassung im Jahr 2015 für nicht resezierbare oder metastasierte Melanome bei Erwachsenen mehrere Indikationserweiterungen erfahren, so auch beispielsweise im Jahr 2022 für die Behandlung des klassischen Hodgkin-Lymphoms bei Personen ab 3 Jahren und 2023 für Triple-negatives Mammakarzinom, Zervixkarzinom sowie fortgeschrittenes Nierenzellkarzinom in Kombination mit Lenvatinib. Dies resultierte in einem deutlichen Anstieg der Personen mit Bezügen (+9.3%) und der Bezüge (+1.9), was folglich zu einem starken Kostenwachstum (+8.2%) von fast CHF 13 Millionen führte (Tabelle 8, Tabelle 11). Auch im Jahr 2024 kamen neue Indikationserweiterungen hinzu, wodurch mit einer erneuten Kostensteigerung zu rechnen ist, die sich voraussichtlich im nächsten Report zeigen wird. Zu den Wirkstoffen mit den höchsten

[[Seite 29/102]]

absoluten Kostenanstiegen zwischen 2022 und 2023 zählte beispielsweise Imfinzi® (Tabelle 11). Imfinzi® (Durvalumab, L01FF03) wird unter anderem bei nicht-kleinzelligem Lungenkrebs verwendet und ist bereits seit 2018 auf der SL. Im Jahr 2021 erfolgte eine Indikationserweiterung für die Erstlinienbehandlung von Patientinnen und Patienten mit fortgeschrittenem kleinzelligem Lungenkarzinom. Seitdem stiegen die Bezüge und Kosten deutlich an, und allein zwischen 2022 und 2023 verzeichnete Imfinzi® einen Zuwachs von mehr als 6’000 Bezügen und CHF 21 Millionen. Die Gesamtkosten für Imfinzi® betrugen damit insgesamt CHF 37.9 Millionen im Jahr 2023. Bei dem Präparat Opdivo® (Nivolumab, L01FF01), das zur Behandlung verschiedener Krebserkrankungen eingesetzt wird, gab es im Jahr 2023 ebenfalls eine starke Zunahme der Bezüge (+9.9%; Tabelle 8) aufgrund diverser Indikationserweiterungen. Dabei stiegen auch die Kosten um 6.1% auf CHF 69.5 Millionen. Auch Enhertu® (Trastuzumab deruxtecan, L01FD04), eingesetzt zur Behandlung von HER2-positivem Brustkrebs und bei Magenkrebs, verzeichnete einen deutlichen Anstieg der Bezüge um fast das Fünffache. Da das Medikament erst seit Ende 2023 auf der SL geführt wird und zuvor nur über die Einzelfallvergütung abgerechnet wurde, belegt dieses Wachstum vor allem eine schnelle Etablierung auf dem Markt. Das Krebsmittel Darzalex® (Daratumumab, L01FC01), das beim Multiplen Myelom eingesetzt wird, verzeichnete einen Kostenzuwachs von 17.4% gegenüber dem Vorjahr. Die Kostenzunahme wurde durch einen Zuwachs der Anzahl Personen mit Bezügen und der Bezüge verursacht. Für dieses Präparat gab es nach der Zulassung als Erstlinientherapie in Kombination mit anderen Wirkstoffen im Januar 2019 bisher keine Indikationserweiterung, jedoch wurde es in der im Februar 2022 erschienenen S3-Leitlinie Multiples Myelom [7] ebenfalls als Erstlinientherapie in Kombination mit anderen Wirkstoffen aufgeführt, was vermutlich zu den wachsenden Bezügen führte.

Der Kostenanstieg der endokrinen Therapeutika lässt sich unter anderem durch eine Indikationserweiterung des teuren Medikamentes Xtandi® (Enzalutamid, L02BB04) erklären, das seit Ende 2020 auch bei nicht-metastasierendem Prostatakarzinom eingesetzt werden darf. Durch die steigenden Bezüge kam es so auch im Jahr 2023 zu einer anhaltenden Kostensteigerung (+CHF 5.9 Millionen) auf insgesamt CHF 58.7 Millionen. Einen noch grösseren Anteil am Kostenzuwachs der endokrinen Therapeutika hatte Erleada® (Apalutamid, L02BB05), das ebenfalls bei Prostatakarzinomen eingesetzt wird. Dieses Medikament kam erst im November 2021 neu auf die SL und wurde im Jahr 2023 bereits von über 1’600 Personen verwendet. Aufgrund der gestiegenen Bezüge und des hohen Preises entstand eine Kostenzunahme zwischen 2022 und 2023 von CHF 15.6 Millionen auf CHF 47.1 Millionen.

## 3.2.2 Nervensystemmittel (N)

Die anatomische Hauptgruppe der Nervensystemmittel verursachte im Jahr 2023 Kosten von über CHF 1 Milliarde, wobei rund 4 Millionen Personen entsprechende Bezüge hatten (Tabelle 5). Trotz einer nur geringen Zunahme der Bezüge um 0.5% und einer konstanten Anzahl der Personen mit Bezügen stiegen die Kosten im Vergleich zum Vorjahr um CHF 32.2 Millionen (+3.1%). Dieser Anstieg ist vor allem auf eine erhöhte Marktdurchdringung kostenintensiverer Therapien zurückzuführen.

Das Kostenwachstum der Nervensystemmittel wurde zur Hälfte (CHF 16.2 Millionen) durch die therapeutische Medikamentengruppe der Psychoanaleptika (N06) getragen, die einen Anstieg um 5.4% verzeichnete. Etwas kleinere Anteile am Kostenanstieg hatten die Medikamentengruppe «Andere

[[Seite 30/102]]

Nervensystemmittel» (N07; +CHF 5.5 Millionen) und die Schmerzmittel (N02; +CHF 4.4 Millionen). Die letzten beiden Gruppen wiesen sinkende Bezüge auf, jedoch bei steigenden Pro-Kopf-Kosten, was zu den jeweiligen Kostenzunahmen führte (Tabelle 6).

Die Psychoanaleptika mit dem höchsten und dritthöchsten Kostenwachstum waren Methylphenidat (Concerta®, Ritalin® und Generika, N06BA04) mit CHF 4.0 Millionen (+18.0%) und Elvanse® (Lisdexamfetamin, N06BA12) mit CHF 2.4 Millionen (+18.8%). Diese Medikamente, die hauptsächlich bei Aufmerksamkeitsdefizit-/Hyperaktivitätsstörung (ADHS) eingesetzt werden, verzeichneten eine weitere starke Zunahme der Personen mit Bezügen von über 20%, und damit der Bezüge. Dies ist vermutlich auf den anhaltenden Trend einer medikamentösen ADHS-Therapie auch bei Erwachsenen zurückzuführen (siehe auch Arzneimittelreport 2020 [8]). Der Wirkstoff Sertralin (Zoloft® und Generika, N06AB06), der zur Behandlung von Depressionen, Angst-, Zwangs- und Panikstörungen genutzt wird, verzeichnete das zweitgrösste Kostenwachstum von CHF 3.2 Millionen (+12.0%). Auch dieser Wirkstoff wurde von deutlich mehr Personen bezogen (+11.7%), was zu einem Anstieg der Bezüge führte (+8.4%), vermutlich aufgrund eines Lieferengpasses des ähnlich wirkenden Wirkstoffs Citalopram. Das erst Ende 2022 auf die SL aufgenommene Präparat Spravato® (Esketamin, N06AX27), das zur Behandlung schwerer Depressionen bei Erwachsenen eingesetzt wird, konnte sich weiter auf dem Markt behaupten und erzielte ein Umsatzwachstum von CHF 2.2 Millionen (siehe auch Kapitel 3.3.2).

Ebenfalls gestiegen sind die Bezüge von Trazodon (Trittico® und Generika, N06AX05) (+7.8%), einem weiteren Mittel gegen Depressionen. Hier gab es teilweise Lieferschwierigkeiten des einzigen verfügbaren Generikums, weshalb vermehrt auf das Originalprodukt zurückgegriffen werden musste, was zu einem Anstieg der Pro-Kopf-Kosten (+2.0%) führte.

Das mit Abstand kostenintensivste Medikament der therapeutischen Gruppe «Andere Nervensystemmittel» (N07) war Vyndaqel® (Tafamidis, N07XX08), das bei Amyloidose-Betroffenen mit Kardiomyopathie angewendet wird. Mit Kosten von CHF 59.3 Millionen zählte es zu den Top 20 der kostenintensivsten Präparate im Jahr 2023. Die Anzahl der Bezüge und Personen mit Bezügen stieg seit der Aufnahme in die SL im Dezember 2021 stetig an. Das Wachstum der Personen mit Bezügen betrug gegenüber dem Vorjahr mehr als 40%. Aufgrund einer Preissenkung Anfang 2023 fiel die Kostensteigerung jedoch weniger stark aus (+10.9%).

Ein starkes Kostenwachstum um CHF 1.9 Millionen (+60.6%) innerhalb der therapeutischen Gruppe der Schmerzmittel (N02) verzeichnete Sativex® (Cannabinoide, N02BG10), ein Cannabis-haltiges Mundspray zur Symptomverbesserung bei Multipler Sklerose. Obwohl Cannabis in der Schweiz als Betäubungsmittel gilt und offiziell verboten ist, wurde das Verbot für medizinische Zwecke im August 2022 aufgehoben. Seitdem benötigt die ärztliche Verschreibung von Cannabis-haltigen Arzneimitteln keine Bewilligung des BAG mehr. Sativex® ist weiterhin nicht auf der SL gelistet, kann aber in Ausnahmefällen mittels Einzelfallvergütung durch die OKP vergütet werden. Diese Ausnahme wurde im Jahr 2023 über 1’200 Personen gestattet. Die insgesamt grössten Kostentreiber unter den Schmerzmitteln waren die CGRP-Antikörper, die zur Migräneprophylaxe eingesetzt werden und erst relativ neu auf der SL gelistet sind. Beispielsweise steigerten die CGRP-Antikörper Aimovig® (Erenumab, N02CD01), Ajovy® (Fremanezumab, N02CD03) und Vyepti® (Eptinezumab, N02CD05) ihre Kosten um CHF 2.1 Millionen (+13.7%), CHF 1.8 Millionen (+43.5%) und CHF 2.0 Millionen

[[Seite 31/102]]

(+445%). Im Helsana Arzneimittelreport 2022 [9] findet sich eine Übersicht zu dieser Wirkstoffgruppe und deren Vor- und Nachteilen, auch bezogen auf die Kosten im Vergleich zu den therapeutischen Alternativen. Vertreter dieser neuen Medikamentengruppe scheinen gut verträglich zu sein, und auch ihre Wirksamkeit bei gewissen Migräneformen ist belegt. Jedoch gibt es aus pharma-ökonomischer Sicht Bedenken, da die Jahreskosten einer Therapie mit CGRP-Antikörpern die Kosten einer herkömmlichen Standard-Prophylaxe um ein Vielfaches überschreiten. Wie in den Vorjahren blieb das Schmerz- und Fiebermittel Paracetamol (N02BE01) auch im Jahr 2023 der mit Abstand meistbezogene Wirkstoff mit etwa 5.0 Millionen Bezügen (-3.3%; Tabelle 9). Trotz tiefem Preis wurden durch die vielen Bezüge Kosten von CHF 60.4 Millionen (-CHF 1.6 Millionen) generiert.

## 3.2.3 Stoffwechselmittel (A)

An dritter Stelle der kostenintensivsten anatomischen Hauptgruppen im Jahr 2023 lagen die Stoffwechselmittel mit einem Umsatz von erstmals mehr als CHF 1 Milliarde. Im Vergleich zum Vorjahr zeigte sich eine Zunahme der Kosten um CHF 51.9 Millionen (+5.4%; Tabelle 5), während die Zahl der Bezüge (+0.6%) und die Anzahl Personen mit Bezügen (+0.3%) gegenüber dem Vorjahr nur leicht stiegen. Daraus resultierte ein Anstieg der Pro-Kopf-Kosten (+5.1%), was auf eine gesteigerte Verwendung teurer Medikamente schliessen lässt.

Der Kostenzuwachs um CHF 43.5 Millionen (+10.6%) auf inzwischen CHF 455.2 Millionen bei den Diabetesmedikamenten (A10) war dabei besonders auffällig (Tabelle 6). Von zentraler Bedeutung war der Wirkstoff Semaglutid (Ozempic®, Rybelsus® und Wegovy®, A10BJ06). Er verursachte mit CHF 113 Millionen (+CHF 31.9 Millionen, +39.4%) die höchsten Kosten aller Diabetesmedikamente (Tabelle 8). Semaglutid ist ein GLP-1-Rezeptor-Agonist und wird zur Therapie des Diabetes mellitus Typ 2 und zur Gewichtsreduktion bei Adipositas angewendet. Während Ozempic® und Rybelsus® offiziell nur für die Therapie des Diabetes mellitus Typ 2 zugelassen sind, verfügt das wirkstoffidentische Wegovy® über eine Zulassung zur Behandlung von Adipositas. Es ist unklar, wie sich der Markt im Bereich Adipositas und Diabetes ohne die verbreiteten Lieferprobleme entwickelt hätte. Das ebenfalls zu den GLP1-Agonisten zählende Liraglutid (Saxenda® und Victoza®, A10BJ02) generierte die dritthöchsten Kosten unter den Diabetesmedikamenten. Aufgrund eines Rückgangs der Bezüge (-7.0%) und einer Preissenkung im Rahmen der alle drei Jahre stattfindenden Preisüberprüfungen durch das BAG sanken die Liraglutid-Gesamtkosten um CHF 3.3 Millionen (-8.3%). Ebenfalls eine wichtige Rolle beim Kostenwachstum der Gruppe der Diabetesmedikamente spielten die SGLT2-Inhibitoren. Positive Studiendaten bezüglich der Behandlung und Prävention von Herz- und Niereninsuffizienz bei Patientinnen und Patienten mit Diabetes mellitus Typ 2 führten zu einer Leitlinienanpassung und einem insgesamt deutlich breiteren Einsatz der SGLT2-Inhibitoren [10–13]. Beispielsweise verzeichneten Dapagliflozin-haltige SGLT-2 Inhibitoren (als Monopräparat Forxiga®, A10BK01, und in Kombination mit Metformin als Xigduo® XR, A10BD15) ein Kostenwachstum von mehr als CHF 16 Millionen aufgrund stark wachsender Bezüge. Auch die Kosten Empagliflozin-haltiger SGLT-2 Inhibitoren (als Monopräparat Jardiance®, A10BK03, und in Kombination mit Metformin als Jardiance Met®, A10BD20) stiegen um CHF 7.5 Millionen (Tabelle 11).

Bei der therapeutischen Gruppe der Magensäureblocker (A02) gab es eine Kostensteigerung um CHF 2.1 Millionen (+1.2%) auf CHF 175.6 Millionen. Der Protonenpumpeninhibitoren und als

---

— Ende Teil 2 von 8 · Kontrollwort Teil 2: WILDSTRUBEL-82 · weiter mit teil-03.md —
