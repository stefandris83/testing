# LAV-T03 · Volltext · Teil 7 von 8 (PDF-Seiten 80–92 von 102)

Studie: Helsana-Report: Arzneimittel – Medikamente erstmals grösster Kostenblock der Grundversicherung · Quelldatei: arzneimittelreport-2024-31e5177c.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 8 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T03, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 80/102]]

steht. Kosten für zielgerichtete Therapien stiegen dagegen (2013: CHF 24 Millionen, 2023: CHF 52 Millionen; +146%), was wiederum mit den höheren Bezügen in dieser Kategorie und hohen Preisen für neue Therapien in Zusammenhang steht.

[Hinweis Transkription: Die Originalangaben CHF 24 Millionen (2013), CHF 52 Millionen (2023) und +146% sind rechnerisch nicht miteinander vereinbar. Alle Angaben unverändert übernommen.]

**[Grafik 21] Abbildung 21: Gesamtkosten von Onkologika bei Lungenkrebs aufgeteilt nach Kategorien, 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Gestapeltes Flächendiagramm, 2013–2023. Y-Achse: Kosten [Mio CHF], 0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200. Legendenreihenfolge: Immuno bordeauxrot, Targeted gelb, Chemo beige. Die Flächen sind von unten nach oben Chemo, Targeted, Immuno gestapelt. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±2 Mio CHF je Segment. Angegeben sind Segmentwerte, nicht kumulierte Oberkanten. Textlich bezifferte Anfangs- und Endwerte sind entsprechend gekennzeichnet und stimmen innerhalb der Ablesegenauigkeit mit der Grafik überein. – bedeutet kein gesondert sichtbares Segment, nicht gesichert null. Die Summe der textlich angegebenen Kosten 2023 ist mit dem auf ganze Millionen gerundeten Gesamtwert CHF 146 Millionen vereinbar.

| Jahr | Immuno | Targeted | Chemo |
|---|---|---|---|
| 2013 | – | 24 (Fliesstext derselben Seite) | 39 (Fliesstext Seite 79) |
| 2014 | – | ca. 18 | ca. 40 |
| 2015 | ca. 2 | ca. 22 | ca. 42 |
| 2016 | ca. 31 | ca. 22 | ca. 40 |
| 2017 | ca. 91 | ca. 26 | ca. 36 |
| 2018 | ca. 84 | ca. 31 | ca. 37 |
| 2019 | ca. 90 | ca. 30 | ca. 26 |
| 2020 | ca. 101 | ca. 37 | ca. 30 |
| 2021 | ca. 112 | ca. 42 | ca. 30 |
| 2022 | ca. 98 | ca. 46 | ca. 16 |
| 2023 | 81 (Fliesstext Seite 79) | 52 (Fliesstext derselben Seite) | 12.6 (Fliesstext Seite 79) |

Anmerkung: Chemo = Chemotherapie, Targeted = zielgerichtete Therapie, Immuno = Immuntherapie

**[Ende Grafik 21]**

Die jährlichen Durchschnittskosten pro Person mit Bezügen erreichten bei den zielgerichteten Therapien ein ähnliches Niveau wie bei den Immuntherapien (Abbildung 22). Während sie im Jahr 2013 bei den zielgerichteten Therapien noch bei CHF 11’600 lagen, betrugen sie im Jahr 2023 CHF 19’300 (+66%). Bei den Immuntherapien beliefen sich die Pro-Kopf-Kosten seit 2017 auf etwa CHF 20'000. Diese Summen zeigen allerdings nicht die Kosten der Gesamttherapie einer Person, da die Kosten von Kombinationstherapien (z.B. von Chemo- mit Immuntherapien) und mehreren aufeinanderfolgenden Therapielinien nicht berücksichtigt wurden. Weiterhin ist die individuelle Spannbreite bei den Kosten sehr hoch, was auch damit zusammenhängt, wann im Jahr der Therapiestart erfolgte, wie lange eine Person eine Therapie erhielt oder wie lange das Überleben einzelner Personen war. Im Jahr 2023, zum Beispiel, lagen die höchsten Kosten für eine einzelne Person bei rund CHF 140’000, während es auch andere Personen gab, die nur einen einzigen Bezug einer Chemotherapie hatten.

**[Grafik 22] Abbildung 22: Onkologikakosten pro Person mit Lungenkrebs nach Kategorien, 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Liniendiagramm, 2013–2023. Y-Achse: Pro-Kopf-Kosten [CHF], 0, 5’000, 10’000, 15’000, 20’000, 25’000, 30’000. Chemo beige, Targeted gelb, Immuno bordeauxrot. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±300 CHF. Die Targeted-Werte CHF 11’600 (2013) und CHF 19’300 (2023) stehen im Fliesstext derselben Seite und stimmen mit der Kurve überein. – bedeutet kein dargestellter Kurvenabschnitt, nicht gesichert null. Der Fliesstext nennt für Immuno seit 2017 etwa CHF 20'000; die Grafik zeigt jedoch unter anderem 2017 ca. 25500 und 2023 ca. 17400. Beide Darstellungen sind unverändert wiedergegeben.

| Jahr | Chemo | Targeted | Immuno |
|---|---|---|---|
| 2013 | ca. 3400 | 11’600 (Fliesstext) | – |
| 2014 | ca. 3300 | ca. 12100 | – |
| 2015 | ca. 3600 | ca. 13000 | ca. 8000 |
| 2016 | ca. 3400 | ca. 12500 | ca. 16300 |
| 2017 | ca. 3400 | ca. 15800 | ca. 25500 |
| 2018 | ca. 3400 | ca. 19000 | ca. 21200 |
| 2019 | ca. 3000 | ca. 19500 | ca. 21700 |
| 2020 | ca. 3300 | ca. 18300 | ca. 20700 |
| 2021 | ca. 3100 | ca. 16500 | ca. 21900 |
| 2022 | ca. 1900 | ca. 18100 | ca. 20700 |
| 2023 | ca. 1800 | 19’300 (Fliesstext) | ca. 17400 |

Anmerkung: Chemo = Chemotherapie, Targeted = zielgerichtete Therapie, Immuno = Immuntherapie

**[Ende Grafik 22]**

[[Seite 81/102]]

## Kosten und Bezüge nach Präparat

Spitzenreiter unter den 20 kostenintensiven zielgerichteten und Immuntherapien, welche im Jahr 2023 bei Lungenkrebs angewendet wurden, war das Immuntherapeutikum Keytruda® (Pembrolizumab) mit Gesamtkosten von etwa CHF 37 Millionen (Tabelle 23). Keytruda® verzeichnete zudem die meisten Bezüge und die höchste Anzahl Personen mit Bezügen. Das Medikament kam auch in der ersten Therapielinie zum Einsatz, insbesondere beim nicht-kleinzelligen Bronchialkarzinom. Keytruda® wird in der Regel beim Lungenkrebs im fortgeschrittenen Stadium allein oder in Kombination mit Chemotherapie verwendet, was mit für den hohen Einsatz verantwortlich ist. Es wird auch breit bei anderen Krebsarten verwendet, aber diese Kosten sind hier nicht berücksichtigt. Auf Platz zwei befindet sich Tagrisso®, eine zielgerichtete Therapie aus der Gruppe der TKI-Inhibitoren mit dem Wirkstoff Osimertinib, das ebenfalls beim nicht-kleinzelligen Bronchialkarzinom angewendet wird. Die Gesamtkosten beliefen sich auf CHF 16 Millionen. Auf Platz drei lag mit Opdivo® (Nivolumab) wieder ein Immuntherapeutikum, mit Gesamtkosten von CHF 9.5 Millionen bei etwa 3’000 Bezügen.

| Wirkstoff | Präparatname | 2023 Kosten (CHF) | 2023 Bezüge | 2023 Personen | 2013 Kosten (CHF) | 2013 Bezüge | 2013 Personen |
|---|---|---|---|---|---|---|---|
| Pembrolizumab | Keytruda®§ | 37’278’260 | - | - | - | - | - |
| Osimertinib | Tagrisso®§ | 16’371’605 | - | - | - | - | - |
| Nivolumab | Opdivo® | 9’366’616 | 3’005 | 573 | - | - | - |
| Durvalumab | Imfinzi®§ | 6’199’470 | - | - | - | - | - |
| Alectinib | Alecensa® | 5’882’556 | 1’028 | 222 | - | - | - |
| Atezolizumab | Tecentriq® | 4’808’730 | 1’481 | 497 | - | - | - |
| Bevacizumab | Avastin®, * | 3’483’745 | 2’709 | 571 | 6’621’787 | 2’956 | 570 |
| Lorlatinib | Lorviqua® | 3’079’640 | 539 | 111 | - | - | - |
| Ipilimumab | Yveroy® | 2’726’034 | 316 | 165 | - | - | - |
| Trametinib | Mekinist® | 1’178’913 | 255 | 58 | - | - | - |
| Capmatinib | Tabrecta®§ | 948’480 | - | - | - | - | - |
| Crizotinib | Xalkori® | 830’678 | 109 | 33 | 1'290’015 | 185 | 70 |
| Afatinib | Giotrif® | 791’650 | 298 | 42 | - | - | - |
| Dabrafenib | Tafinlar® | 781’337 | 176 | 49 | - | - | - |
| Tepotinib | Tepmetko®§ | 722’099 | - | - | - | - | - |
| Cemiplimab | Libtayo® | 557’907 | 134 | 34 | - | - | - |
| Everolimus | Afinitor® | 539’784 | 229 | 56 | 794’899 | 183 | 68 |
| Erlotinib | Tarceva® | 424’827 | 179 | 21 | 3’715’162 | 1’086 | 419 |
| Entrectinib | Rozlytrek® | 266’308 | 50 | 22 | - | - | - |
| Gefitinib | Iressa® | 257’147 | 94 | 25 | 1’543’590 | 370 | 86 |

* oder Biosimilars, § mit geheimen Preismodell.

Tabelle 23: Top 20 zielgerichtete Therapien und Immuntherapien für Lungenkrebs, 2013 und 2023, Hochrechnung für die gesamte Schweiz

[[Seite 82/102]]

Fast alle Medikamente, die im Jahr 2023 auf der Top 20-Liste erscheinen, waren im Jahr 2013 noch nicht verfügbar. Lediglich fünf Wirkstoffe der Top 20 des Jahres 2023 wurden damals bereits eingesetzt: Bevacizumab, Everolimus, Crizotinib, Erlotinib und Gefitinib, allesamt zielgerichtete Therapien. Immuntherapien kamen erst ab dem Jahr 2015 hinzu und veränderten seitdem die Behandlungslandschaft. Die meisten Immuntherapien sind im oberen Bereich der Liste zu finden (Keytruda® Platz1, Opdivo® Platz 3, Imfinzi® Platz 4, Tecentriq® Platz 6). Auffällig war, dass die zielgerichtete Therapie Bevacizumab mit Gesamtkosten von CHF 6.6 Millionen im Jahr 2013, trotz vermehrter Bezüge im Jahr 2023, geringere Gesamtkosten aufwies. Diese lagen bei CHF 3.5 Millionen, was einer Kostenreduktion von 47% entspricht. Der Grund dafür ist die Einführung von Biosimilars im Jahr 2020, welche zu erheblichen Preissenkungen geführt hat (siehe Kapitel 3.4.3).

## Begleitmedikamente

Neben der primären Krebstherapie hat uns die Verwendung von

Begleitmedikamenten für Personen mit Lungenkrebs interessiert. Diese Medikamente können verschiedene Funktionen erfüllen, von der Linderung von Nebenwirkungen bis hin zur Unterstützung der allgemeinen Gesundheit.

Bei den sonstigen Medikamentenbezügen der Personen mit Lungenkrebs, die mit zielgerichteter Therapie behandelt wurden (Tabelle 24), standen die ATC-Gruppen «Blutersatzmittel und Perfusionslösungen» und auch «Kontrastmittel» (je 76%) an erster Stelle. Diese

Begleitmedikamente werden eigentlich häufig zusammen mit intravenösen Therapien und diagnostischen Tests abgegeben. Da zielgerichtete Therapien jedoch meist in Tablettenform verabreicht werden, könnten im selben Jahr erfolgte Chemotherapien teilweise ursächlich gewesen sein. Sowohl bei den Personen mit zielgerichteten Therapien als auch bei denen mit Immuntherapien waren Bezüge von Schmerz- und Beruhigungsmitteln sehr häufig, was unter anderem mit der Grunderkrankung in Zusammenhang stehen kann. Die ATC-Gruppen «Analgetika» (60% bei der zielgerichteten Therapie, 67% bei der Immuntherapie) und «Mittel bei säurebedingten Erkrankungen» (54% bei der zielgerichteten Therapie, 55% bei der Immuntherapie), welche auf den weiteren Rängen folgen, weisen darauf hin, dass ein erheblicher Teil der Patienten mit Lungenkrebs neben ihrer Hauptbehandlung auch auf Schmerzmittel zur Linderung akuter oder chronischer Schmerzen sowie auf Medikamente zur Kontrolle von säurebedingten Beschwerden angewiesen ist.

Bei den Immuntherapien wiesen fast 100% aller Personen Bezüge von «Blutersatzmittel und Perfusionslösungen» auf, da diese alle intravenös verabreicht werden. Der Prozentsatz der Personen mit Bezügen von «Corticosteroiden zur systemischen Anwendung» war mit 66% wesentlich höher als bei den Patientinnen und Patienten mit zielgerichteter Therapie (44%). Diese werden häufig zur Minderung von entzündlichen Nebenwirkungen eingesetzt und bei Chemotherapien zur Nauseaprophylaxe (relevant bei Kombinationstherapien). Bei zielgerichteten Therapien werden diese Medikamente weniger häufig benötigt als bei Immuntherapien.

Weiterhin bezogen bei der Immuntherapie viele Personen «Antiemetika und Mittel gegen Übelkeit» (53%). Dies könnte auf eventuelle Nebenwirkungen der Immuntherapien hinweisen. Es ist allerdings zu berücksichtigen, dass Immuntherapien häufig in Kombination mit Chemotherapien (siehe auch «Behandlungsmuster und Therapielinien») gegeben werden, bei denen Übelkeit häufig vorkommt.

[Hinweis Transkription: Der Fliesstext spricht bei Bevacizumab von vermehrten Bezügen im Jahr 2023. Tabelle 23 auf Seite 81 nennt dagegen 2’956 Bezüge für 2013 und 2’709 für 2023. Beide Originalangaben unverändert übernommen.]

[[Seite 83/102]]

## (a) Zielgerichteten Therapie

| ATC-Gruppe | Personen |
|---|---|
| Blutersatzmittel u Perfusionslösungen | 76% |
| Kontrastmittel | 76% |
| Analgetika | 60% |
| Mittel bei säurebedingten Erkrankungen | 54% |
| Antithrombotische Mittel | 45% |
| Corticosteroide zur systemischen Anwendung | 44% |
| Mineralstoffe | 42% |
| Anästhetika | 40% |
| Antibiotika zur systemischen Anwendung | 37% |
| Psycholeptika | 37% |
| Emmolientia und Hautschutzmittel | 33% |
| Mittel bei funktionellen GI-Störungen | 33% |
| Laxantien | 32% |
| Ophthalmika | 30% |
| Antiphlogistika und Antirheumatika | 30% |
| Antianämika | 28% |
| Mittel mit Wirkung auf das RAAS | 27% |
| Vitamine | 25% |
| Husten- und Erkältungspräparate | 24% |
| Mittel bei obstruktiven Atemwegserkrankungen | 23% |

## (b) Immuntherapie

| ATC-Gruppe | Personen |
|---|---|
| Blutersatzmittel und Perfusionslösungen | 99% |
| Kontrastmittel | 75% |
| Analgetika | 67% |
| Corticosteroide zur systemischen Anwendung | 66% |
| Mittel bei säurebedingten Erkrankungen | 55% |
| Antiemetika und Mittel gegen Übelkeit | 53% |
| Antithrombotische Mittel | 53% |
| Anästhetika | 51% |
| Mittel bei funktionellen GI-Störungen | 49% |
| Laxantien | 44% |
| Antianämika | 43% |
| Mittel bei obstruktiven Atemwegserkrankungen | 40% |
| Antibiotika zur systemischen Anwendung | 39% |
| Psycholeptika | 37% |
| Mittel mit Wirkung auf das RAAS | 36% |
| Mittel, die den Lipidstoffwechsel beeinflussen | 34% |
| Husten- und Erkältungspräparate | 33% |
| Mineralstoffe | 33% |
| Antiphlogistika und Antirheumatika | 33% |
| Antihistaminika zur systemischen Anwendung | 28% |

Anmerkung: Es wurden nur die jeweils 20 grössten Kategorien nach dreistelligem ATC-Code berücksichtigt.

Tabelle 24: Anteil Personen mit zielgerichteter und Immuntherapie mit Bezügen sonstiger Medikamentengruppen, 2023, Hochrechnung für die gesamte Schweiz

## Behandlungsmuster

## Behandlungsmuster bei Diagnose im Jahr 2021

Abbildung 23 zeigt die Behandlungsmuster von Lungenkrebspatientinnen und -patienten, die im Jahr 2021 diagnostiziert wurden und eine erste medikamentöse Therapie erhalten haben. Aus der Abbildung lässt sich nicht ableiten, in welchem zeitlichen Abstand die Therapien zueinander standen oder wie lange behandelt wurde. So könnte eine weitere medikamentöse Therapie erst nach vielen Monaten erfolgt sein. Zudem wird mangels klinischer Informationen nicht dargestellt, ob die Therapien bis zum Ende durchgeführt oder beispielsweise aufgrund von Nebenwirkungen abgebrochen wurden. Dazu gibt es keine Information über das Stadium der Erkrankung oder die Art des Lungenkrebses. Allerdings wird die Anzahl der Patientinnen und Patienten gezeigt, die nach Therapieende verstorben sind. Im Fall der ersten Therapie waren das beispielsweise etwa 20% der Patientinnen und Patienten.

[[Seite 84/102]]

Die Hälfte der Personen mit Lungenkrebs (50%) bekam als erste medikamentöse Therapie eine Chemotherapie; wobei diese Zahl auch adjuvante und neoadjuvante Chemotherapien beinhaltet. Adjuvante Therapien werden gegeben, um mögliche noch im Körper vorhandene Krebszellen zu zerstören und das Rückfallrisiko zu senken. Weiter ist es möglich, dass Chemotherapie bereits neoadjuvant vor der Operation gegeben wurde, um die Tumorgrösse zu reduzieren. Diese Situationen sind in der Abbildung jedoch nicht unterscheidbar. Zwei Drittel der Personen mit einer Chemotherapie (70%) erhielten im Zeitraum unserer Abrechnungsdaten keine weiteren Onkologika. Zwanzig Prozent von diesen verstarben bei Therapiestopp. Bei denjenigen, welche weiter behandelt wurden, bekamen die wenigsten Personen eine weitere Chemotherapie (30%). Weit häufiger war eine Immuntherapie (42%) oder Immuntherapie in Kombination mit Chemotherapie (23%). Eine dritte Therapielinie kam nur sehr selten vor.

Zielgerichtete Therapien in der ersten Therapielinie erhielten 13% der Personen. Immuntherapie als Monotherapie oder in Kombination mit Chemotherapie kam bei 14% respektive 23% der Personen zum Einsatz. Die Immuntherapie wird häufig Patienten mit fortgeschrittenem Lungenkrebs angeboten, insbesondere solchen mit hohem PD-L1-Ausdruck, einem Biomarker, der anzeigt, dass die Krebszellen bestimmte Eigenschaften besitzen, die die Behandlung effektiver machen können; während die Immun-Chemo-Kombinationstherapie für Patienten mit niedrigem PD-L1-Ausdruck in Betracht gezogen wird.

Die grosse Mehrheit wurde bisher nur einmal behandelt. Dies kann verschiedene Gründe haben. Einerseits sind ein Teil der Patienten verstorben, andere Patienten können sich auch in einem stabilen Zustand befinden, ohne dass eine weitere Behandlung im Moment vonnöten ist.

**[Grafik 23] Abbildung 23: Behandlungsmuster beim Lungenkrebs bei Personen mit Diagnose und Therapiebeginn im Jahr 2021**

Darstellung: Sankey-Diagramm mit vier Knotenspalten; Flussrichtung von links nach rechts. Knotenspalte 1 zeigt die erste medikamentöse Therapie, die weiteren Spalten jeweils die nächste dargestellte Therapie oder stop. Knoten sind in ihrer sichtbaren Reihenfolge von oben nach unten erfasst. Der Verlauf zeigt Reihenfolge, keine Zeitabstände und keine Therapiedauern. Graue Bänder verbinden die Knoten; ihre Breiten repräsentieren relative Personenzahlen. stop ist bordeauxrot, sein schwarzroter unterer Teil markiert Verstorbene. Wertstatus: keine Zahlen direkt im Diagramm beschriftet. Explizit gekennzeichnete Werte stammen aus dem Fliesstext derselben Seite; sonst am Seitenbild abgelesen ca., Genauigkeit ±2 Prozentpunkte für Knotenanteile bezogen auf die Gesamtbreite der ersten Therapiespalte und ±5 Prozentpunkte für den Verstorbenenanteil innerhalb des jeweiligen stop-Knotens. Sehr schmale Knoten und die Breiten einzelner sich überlagernder Bänder sind nicht eindeutig ablesbar. – bedeutet für diese Zelle nicht anwendbar, nicht null. Rundungen und Ableseunsicherheit werden nicht durch Anpassung der Summen ausgeglichen.

| Knotenspalte | Beschriftung | Anteil an der Ausgangsgruppe | Verstorben innerhalb dieses stop-Knotens |
|---|---|---|---|
| 1 | chemo | 50% (Fliesstext) | – |
| 1 | targeted | 13% (Fliesstext) | – |
| 1 | chemo_immuno | 23% (Fliesstext) | – |
| 1 | immuno | 14% (Fliesstext) | – |
| 1 | targeted_immuno | nicht eindeutig ablesbar | – |
| 1 | chemo_targeted | ca. 1% | – |
| 2 | stop | ca. 73% | ca. 20% |
| 2 | immuno | ca. 11% | – |
| 2 | chemo_immuno | ca. 5% | – |
| 2 | chemo | ca. 9% | – |
| 2 | targeted | ca. 1% | – |
| 2 | chemo_targeted | ca. 1% | – |
| 3 | stop | ca. 21% | ca. 20% |
| 3 | chemo_targeted | nicht eindeutig ablesbar | – |
| 3 | targeted | ca. 1% | – |
| 3 | chemo | ca. 3% | – |
| 3 | chemo_immuno | ca. 1% | – |
| 4 | stop | ca. 5% | ca. 33% |
| 4 | chemo | nicht eindeutig ablesbar | – |

Sicher erkennbare Verbindungen bzw. im Fliesstext bezifferte Übergänge:

| Übergang | Ausgangsknoten | Zielknoten | Anteil / Wertstatus |
|---|---|---|---|
| 1 → 2 | chemo | stop | 70% der Personen mit erster Chemotherapie; 20% dieser Stop-Gruppe verstarben (Fliesstext) |
| 1 → 2 | chemo | immuno | 42% der nach erster Chemotherapie Weiterbehandelten (Fliesstext) |
| 1 → 2 | chemo | chemo_immuno | 23% der nach erster Chemotherapie Weiterbehandelten (Fliesstext) |
| 1 → 2 | chemo | chemo | 30% der nach erster Chemotherapie Weiterbehandelten (Fliesstext) |
| 1 → 2 | targeted | stop | nicht eindeutig ablesbar |
| 1 → 2 | chemo_immuno | stop | nicht eindeutig ablesbar |
| 1 → 2 | immuno | stop | nicht eindeutig ablesbar |
| 2 → 3 | immuno | stop | nicht eindeutig ablesbar |
| 2 → 3 | chemo_immuno | stop | nicht eindeutig ablesbar |
| 2 → 3 | chemo | stop | nicht eindeutig ablesbar |
| 3 → 4 | chemo | stop | nicht eindeutig ablesbar |
| 3 → 4 | targeted | stop | nicht eindeutig ablesbar |
| 3 → 4 | chemo_immuno | stop | nicht eindeutig ablesbar |

[Hinweis Transkription: Zusätzlich sind schmale graue Bänder zu den weiteren in der Knotentabelle aufgeführten Therapieknoten sichtbar. Ihre vollständige paarweise Zuordnung an den Überkreuzungen und ihre individuellen Anteile sind nicht eindeutig ablesbar. Die Verbindungstabelle ist deshalb keine vollständige numerische Übergangsmatrix; fehlende Zuordnungen bedeuten nicht, dass ein Übergang ausgeschlossen ist.]

Anmerkung: Chemo = Chemotherapie; Targeted = zielgerichtete Therapie; Immuno = Immuntherapie; Stop = Verstorben, Best supportive care, Behandlungsstopp; schwarzroter Kasten = Anteil verstorben bei ‘Stop’

[Hinweis Transkription: Der Fliesstext auf dieser Seite nennt 14% Immuntherapie als erste Monotherapie; Seite 73 nennt hierfür 12%. Beide Angaben unverändert. Die vier gerundeten Hauptanteile der ersten Therapie summieren sich im Fliesstext bereits zu 100%, obwohl im Diagramm zusätzlich schmale Knoten targeted_immuno und chemo_targeted vorkommen; keine Anpassung vorgenommen.]

**[Ende Grafik 23]**

[[Seite 85/102]]

## Behandlungsmuster bei Diagnose im Jahr 2016

Die Behandlungsmuster von Lungenkrebspatientinnen und -patienten, die im Jahr 2016 diagnostiziert wurden und eine erste medikamentöse Therapie erhielten (Abbildung 24), unterschieden sich deutlich von denen aus dem Jahr 2021. Damals spielte die Immuntherapie in der ersten Therapielinie kaum eine Rolle (2%) und wurde erst in der zweiten Linie nach einer Vorbehandlung mit Chemotherapie eingesetzt, entsprechend der damaligen Zulassung. Es ist auch möglich, dass die wenigen Patientinnen und Patienten, die eine Immuntherapie in der ersten Linie erhielten, keine Erstlinien-Patienten waren, sondern erst nach einer Chemotherapie zu Helsana wechselten oder zuvor lange in Remission waren.

Als erste Behandlung erhielten damals 81% der Personen eine Chemotherapie. 13% der Patientinnen und Patienten wurden mit einer zielgerichteten Therapie behandelt. Dieser Anteil änderte sich auch im Jahr 2021 nicht. Zielgerichtete Therapien werden bei bestimmten genetischen Veränderungen in den Krebszellen eingesetzt, was darauf hinweist, dass der Anteil der Betroffenen mit diesen Mutationen relativ konstant geblieben ist. Etwa 30% der mit Chemotherapie Behandelten erhielten eine zweite Behandlung, davon etwa 50% eine Immuntherapie als Monotherapie oder in Kombination mit Chemotherapie, wobei die Kombinationstherapie selten war. Insgesamt waren die Behandlungspfade im Jahr 2016 weniger komplex als im Jahr 2021. Seitdem haben zahlreiche neue Studien und entsprechende Aktualisierungen der Leitlinien zur Anwendung von Immuntherapien bei Lungenkrebs dazu beigetragen, dass deren Einsatz differenzierter gestaltet werden konnte.

**[Grafik 24] Abbildung 24: Behandlungsmuster beim Lungenkrebs bei Personen mit Diagnose und Therapiebeginn im Jahr 2016**

Darstellung: Sankey-Diagramm mit vier Knotenspalten; Flussrichtung von links nach rechts. Knotenspalte 1 zeigt die erste medikamentöse Therapie, die weiteren Spalten jeweils die nächste dargestellte Therapie oder stop. Knoten sind in ihrer sichtbaren Reihenfolge von oben nach unten erfasst. Der Verlauf zeigt Reihenfolge, keine Zeitabstände und keine Therapiedauern. Graue Bänder verbinden die Knoten; ihre Breiten repräsentieren relative Personenzahlen. stop ist bordeauxrot, sein schwarzroter unterer Teil markiert Verstorbene. Wertstatus: keine Zahlen direkt im Diagramm beschriftet. Explizit gekennzeichnete Werte stammen aus dem Fliesstext derselben Seite; sonst am Seitenbild abgelesen ca., Genauigkeit ±2 Prozentpunkte für Knotenanteile bezogen auf die Gesamtbreite der ersten Therapiespalte und ±5 Prozentpunkte für den Verstorbenenanteil innerhalb des jeweiligen stop-Knotens. Sehr schmale Knoten und die Breiten einzelner sich überlagernder Bänder sind nicht eindeutig ablesbar. – bedeutet für diese Zelle nicht anwendbar, nicht null. Rundungen und Ableseunsicherheit werden nicht durch Anpassung der Summen ausgeglichen.

| Knotenspalte | Beschriftung | Anteil an der Ausgangsgruppe | Verstorben innerhalb dieses stop-Knotens |
|---|---|---|---|
| 1 | chemo | 81% (Fliesstext) | – |
| 1 | targeted | 13% (Fliesstext) | – |
| 1 | immuno | 2% (Fliesstext) | – |
| 1 | chemo_targeted | ca. 2% | – |
| 1 | chemo_immuno | ca. 1% | – |
| 2 | stop | ca. 73% | ca. 21% |
| 2 | chemo | ca. 11% | – |
| 2 | immuno | ca. 10% | – |
| 2 | chemo_immuno | ca. 3% | – |
| 2 | chemo_targeted | ca. 1% | – |
| 2 | targeted | ca. 1% | – |
| 3 | stop | ca. 21% | ca. 38% |
| 3 | immuno | ca. 3% | – |
| 3 | chemo | ca. 3% | – |
| 3 | chemo_immuno | ca. 1% | – |
| 4 | stop | ca. 5% | ca. 58% |
| 4 | chemo | ca. 1% | – |
| 4 | targeted | nicht eindeutig ablesbar | – |

Sicher erkennbare Verbindungen bzw. im Fliesstext bezifferte Übergänge:

| Übergang | Ausgangsknoten | Zielknoten | Anteil / Wertstatus |
|---|---|---|---|
| 1 → 2 | chemo | stop | nicht eindeutig ablesbar |
| 1 → 2 | chemo | chemo | nicht eindeutig ablesbar |
| 1 → 2 | chemo | immuno | nicht eindeutig ablesbar |
| 1 → 2 | chemo | chemo_immuno | nicht eindeutig ablesbar |
| 1 → 2 | targeted | stop | nicht eindeutig ablesbar |
| 2 → 3 | chemo | stop | nicht eindeutig ablesbar |
| 2 → 3 | immuno | stop | nicht eindeutig ablesbar |
| 2 → 3 | chemo | chemo | nicht eindeutig ablesbar |
| 3 → 4 | immuno | stop | nicht eindeutig ablesbar |
| 3 → 4 | chemo | stop | nicht eindeutig ablesbar |

[Hinweis Transkription: Zusätzlich sind schmale graue Bänder zu den weiteren in der Knotentabelle aufgeführten Therapieknoten sichtbar. Ihre vollständige paarweise Zuordnung an den Überkreuzungen und ihre individuellen Anteile sind nicht eindeutig ablesbar. Die Verbindungstabelle ist deshalb keine vollständige numerische Übergangsmatrix; fehlende Zuordnungen bedeuten nicht, dass ein Übergang ausgeschlossen ist.]

Anmerkung: Chemo = Chemotherapie, Targeted = zielgerichtete Therapie, Immuno = Immuntherapie, Stop = Verstorben, Best supportive care, Behandlungsstopp; schwarzroter Kasten = Anteil verstorben bei ‘Stop’

[Hinweis Transkription: Der Fliesstext nennt für die zweite Behandlung etwa 30% der zuerst mit Chemotherapie Behandelten; davon erhielten etwa 50% Immuntherapie allein oder in Kombination mit Chemotherapie. Diese Angaben beziehen sich nicht auf alle Personen und wurden nicht in unbeschriftete Einzelpfade umgerechnet.]

**[Ende Grafik 24]**

## Durchschnittskosten

Im Jahr 2021 waren die durchschnittlichen Behandlungskosten über einen Zeitraum von zwei Jahren bei Lungenkrebspatientinnen und -patienten am höchsten, wenn mit einer Immuntherapie begonnen wurde (CHF 52’000), während ein Beginn mit einer Kombinationstherapie aus Immuntherapie und

[[Seite 86/102]]

Chemotherapie mit geringeren Kosten assoziiert war (CHF 41’000; Tabelle 25). Die Durchschnittskosten bei einem Start mit Chemotherapie beliefen sich auf etwa CHF 18’000, während sie bei einem Beginn mit einer zielgerichteten Therapie etwa CHF 44’000 betrugen.

Bei der Interpretation dieser Kosten ist zu beachten, dass die Beträge sowohl die Kosten für die erste medikamentöse Therapie als auch für alle weiteren Therapiephasen innerhalb der ersten zwei Jahre umfassen. Patientinnen und Patienten können unterschiedliche Therapien und Therapieformen erhalten, und die Durchschnittskosten werden über alle Personen berechnet, die mit diesen Therapien begonnen haben. Nicht berücksichtigt wird dabei, wie viele und wie schnell Personen in diesem Zeitraum verstorben sind oder zu unterstützenden (BSC) und palliativen Behandlungen gewechselt haben. Es ist daher möglich, dass Durchschnittskosten für sehr teure Therapien dadurch niedriger scheinen als für günstigere Optionen. Zudem werden ausschliesslich die Kosten für Onkologika dargestellt; die Gesamtkosten einer Krebsbehandlung können jedoch deutlich höher ausfallen, da zusätzlich Kosten für beispielsweise Spitalaufenthalte, Operationen, Diagnostik, Laboruntersuchungen und Arztbesuche hinzukommen.

Im Jahr 2016 waren die Durchschnittskosten über einen Zeitraum von zwei Jahren für Personen, die mit einer Chemotherapie begannen, leicht geringer als 2021 (CHF 16’000, -14.2%). Die Durchschnittskosten für den Beginn mit einer zielgerichteten Therapie lagen (CHF 31’000), lagen ebenfalls niedriger als 2021 (-30%). Da Immuntherapien und weitere Therapieformen im Jahr 2016 praktisch nicht vertreten waren, werden die Durchschnittskosten dieser Behandlungen nicht weiter ausgewiesen, da der Einfluss statistischer Ausreisser sehr hoch sein könnte und das Bild dadurch stark verzerrt wäre.

| Jahr | Behandlungsstart | Anteil | Weitere Linie(n) | Anteil | Durchschnittskosten über 2 Jahre (in CHF) |
|---|---|---|---|---|---|
| 2021 | Chemo | 50% | ja | 30% | 18’279 |
|  | Targeted | 13% | ja | 9% | 43’649 |
|  | Immuno | 14% | ja | 10% | 52’916 |
|  | Kombination | 23% | ja | 39% | 40’647 |
| 2016 | Chemo | 81% | ja | 29% | 15’687 |
|  | Targeted | 13% | ja | 13% | 30’562 |

Anmerkung: Chemo = Chemotherapie; Targeted = zielgerichtete Therapie; Immuno = Immuntherapie; Kombination = Immuntherapie und Chemotherapie in Kombination; Durchschnittskosten pro Person berechnet auf alle Personen mit Start in dieser Therapie, Kosten für zwei Jahre

Tabelle 25: Zahlen und Kosten zu Therapielinien 2016 vs. 2021

## 4.2.4 Fazit

Die Gesamtkosten für onkologische Medikamente sind in den letzten Jahren stark angestiegen, wie es sich exemplarisch für den Lungenkrebs zeigen lässt. In diesem Indikationsgebiet ist die Entwicklung besonders ausgeprägt, da Lungenkrebs eine der häufigsten Krebsarten ist. Dabei sind nicht steigende Krebsfälle für den starken Kostenanstieg verantwortlich, sondern die hohen Preise neuer Therapien, welche die bisherigen oft ergänzen, nicht ersetzen. Vor allem die Zulassung und zunehmende

[[Seite 87/102]]

Verwendung von Immuntherapeutika stehen im Zentrum der Kostenproblematik. Diese innovativen Therapien, die das Immunsystem des Körpers nutzen, um Krebszellen zu bekämpfen, werden zunehmend auch in der Erstlinienbehandlung eingesetzt. Dadurch kommen sie für eine grössere Anzahl von Patientinnen und Patienten zum Einsatz, was sich deutlich in den steigenden Behandlungskosten widerspiegelt, wie in diesem Report gezeigt. Allerdings sollte an dieser Stelle nicht unerwähnt bleiben, dass die neuen Therapien Patientinnen und Patienten mit Lungenkrebs auch neue Überlebensperspektiven bieten [57]. Die Fragen aber, ob die hohen Kosten für das öffentliche Gesundheitssystem gerechtfertigt sind und ob die neuen Therapien kosteneffizient sind, bleiben bestehen.

In den kommenden Jahren werden die Kosten voraussichtlich noch weiter steigen. Ein Grund dafür ist die erwartete Zunahme von Lungenkrebsfällen, insbesondere durch die steigende Zunahme des Rauchens bei Frauen vor einigen Jahrzehnten. Da sich die negativen Auswirkungen des Rauchens oft erst nach langer Zeit manifestieren [58], wird in den nächsten Jahren mit einem Anstieg der Neuerkrankungen gerechnet, obwohl mittel- bis langfristig auch bei den Frauen mit einem Rückgang zu rechnen ist [59]. Ein weiterer Grund für die Kostensteigerung wird die erweiterte Anwendung von Immuntherapien sein, die nun auch in adjuvanten und neoadjuvanten Situationen eingesetzt werden können [60]. Darüber hinaus werden neue Entwicklungen im Bereich der zielgerichteten Therapien erwartet [61].

Der Medikamentenmarkt beim Lungenkrebs, aber auch in der Onkologie insgesamt, steht vor grossen Herausforderungen. Insgesamt wird der Markt in den nächsten Jahren voraussichtlich mit Bezug auf die Anzahl der behandelten Patientinnen und Patienten weiter wachsen. Die kontinuierliche Entwicklung und Anwendung neuer, teurerer Therapieansätze im Bereich der personalisierten Medizin und der Immuntherapien treiben die Kosten weiter in die Höhe. Die Einführung weiterer Biosimilars und ein gezielterer Einsatz kosteneffektiver Therapieoptionen können und müssen einen Beitrag zur Eindämmung des Kostenwachstums leisten [62], ebenso adäquate Preismechanismen bei Neuzulassungen und Präparaten mit hohem Umsatz. Andererseits besteht die Hoffnung, dass die Forschung im Bereich der Prävention und Früherkennung Fortschritte macht, was langfristig Neuerkrankungen und somit die Inzidenz von Lungenkrebs reduzieren und somit auch die Behandlungskosten senken könnte. Wirksamere Therapien und die Möglichkeit einer langfristigen Remission oder sogar Heilung für bestimmte Patientinnen und Patienten bieten, können kosteneffektiv sein, wenn sie wiederum besser die Rückfallquote besser verringern als bisherige Therapieschemen.

[[Seite 88/102]]

## Danksagung

Die Autoren danken Andrea Studer (USB) für ihr Feedback zum allgemeinen Teil in Bezug auf die pharmazeutischen Korrektheit sowie für die Interpretation der Ursachen einiger beobachteter Trends.

Ebenso danken die Autoren Daniel Sarbach (Sandoz) für die Prüfung der Fakten und generikabezogenen Aussagen in Kapitel 3.4.

[[Seite 89/102]]

## 5 Anhang

## 5.1 Überblick über Leitlinien und Therapiealternativen im Bereich der drei JAKi Indikationsgebiete Rheumatologie, Dermatologie und Gastroenterologie

## 5.1.1 JAKi bei rheumatologischen Erkrankungen

## Aktuelle Empfehlungen und Leitlinien

Gemäss den Empfehlungen der Schweizerischen Gesellschaft für Rheumatologie kommen JAKi bei verschiedenen Formen rheumatischer Erkrankungen zum Einsatz [63]. Sie sind eine Option für Patientinnen und Patienten mit schwerer oder mittelschwerer rheumatoider Arthritis, nachdem eine Therapie mit nichtbiologischen krankheitsmodifizierenden antirheumatischen Medikamente (Disease-Modifying Antirheumatic Drugs, DMARDs), wie beispielsweise Methotrexat, versagt hat oder nicht vertragen wurde. Sie können auch in Kombination mit klassischen Basistherapien eingesetzt werden. Ebenso werden sie für Personen mit aktiver Psoriasis-Arthritis empfohlen, entweder in Kombination oder allein, wenn diese nicht ausreichend auf eine vorherige DMARD-Therapie angesprochen oder sie nicht vertragen haben. Auch die European League Against Rheumatism (EULAR), eine Organisation zur Förderung der wissenschaftlichen Forschung und Ausbildung auf dem Gebiet der Rheumatologie, schlägt vor, JAKi für das Management der Psoriasis-Arthritis primär nach dem Versagen von Biologika (biologisch hergestellten DMARDs) zu verwenden oder wenn diese keine geeignete Wahl darstellen, wobei relevante Risikofaktoren berücksichtigt werden sollten [64]. In Fällen von aktiver ankylosierender Spondylitis kann Upadacitinib bei Betroffenen eingesetzt werden, die nicht ausreichend auf NSAR ansprechen. Die S2e-Leitlinie «Therapie der rheumatoiden Arthritis mit krankheitsmodifizierenden Medikamenten» von 2018 empfiehlt nach unzureichendem Ansprechen zweier konventioneller synthetischer DMARD-Therapien eine Therapie mit Biologika oder JAKi [65].

In einer Empfehlung zum Umgang mit JAKi schrieb die Deutsche Gesellschaft für Rheumatologie, dass sich die JAKi vor allem bei der rheumatoiden Arthritis aufgrund ihrer guten Wirksamkeit in den letzten Jahren einen festen Stellenwert erworben haben [66]. Nach der letzten Auswertung aus der Kerndokumentation des Deutschen Rheumaforschungszentrums (DRFZ) standen 2021 knapp 10% der Personen mit rheumatoider Arthritis unter dieser Therapie, darunter rund zwei Drittel in Monotherapie [67]. Zu den positiven Eigenschaften dieser Substanzgruppe zählen neben der oralen Verabreichung die gute Wirkung in Monotherapie und, aufgrund der kurzen Halbwertszeit, die gute Steuerbarkeit mit kurzer Ausschleichphase falls eine Therapiepause z.B. wegen unerwünschter Wirkungen oder geplanter operativer Eingriffe nötig ist. In einigen kontrollierten rheumatoider Arthritis-Studien waren die JAKi in der Wirksamkeit Adalimumab bzw. Abatacept überlegen [66,68,69].

## Therapeutische Alternativen

Neben den JAKi stehen für die Behandlung rheumatischer Erkrankungen verschiedene therapeutische Alternativen zur Verfügung. Dies sind in erster Linie konventionelle synthetische DMARDs, zu den zum Beispiel Methotrexat, Sulfasalazin, Leflunomid, Azathioprin und Hydroxychloroquin gehören. Ihr Ziel ist, den Verlauf der Erkrankung zu verlangsamen und Symptome wie Gelenkschmerzen und Schwellungen zu lindern. Biologika stellen eine weitere wichtige therapeutische Option dar und zielen darauf ab,

[[Seite 90/102]]

spezifische Moleküle des Immunsystems zu blockieren, die an der Entzündungsreaktion beteiligt sind. Beispiele hierfür sind TNF-Inhibitoren wie Adalimumab, Etanercept und Infliximab sowie IL-Inhibitoren wie Tocilizumab und Sarilumab. Diese Medikamente haben sich als wirksam erwiesen, insbesondere bei Patientinnen und Patienten, die auf konventionelle synthetische DMARDs nicht ausreichend ansprechen. Darüber hinaus werden auch andere Therapieansätze wie physikalische Therapie, Ergotherapie und Nahrungsergänzungsmittel eingesetzt, um die Symptome zu lindern und die Lebensqualität der Betroffenen zu verbessern.

## 5.1.2 JAKi bei dermatologischen Erkrankungen

## Aktuelle Empfehlungen und Leitlinien

Laut der deutschen Organisation Arbeitsgemeinschaft der Wissenschaftlichen Medizinischen Fachgesellschaften e.V. (AWMF; awmf.org) sind JAKi für die Behandlung der atopischen Dermatitis für die Langzeittherapie zugelassen und können auch in besonderen Verlaufsformen als Intervalltherapie eingesetzt werden [70]. Obwohl bisher keine Studien veröffentlicht wurden, in denen der Einsatz von Upadacitinib oder Baricitinib zusammen mit anderen systemischen Therapien bei atopischer Dermatitis untersucht wurden, hat sich die Kombinationstherapie von Upadacitinib mit Methotrexat als Kombinationsschema etabliert. Im März 2021 erhielt Upadacitinib in der Schweiz eine Zulassung für die atopische Dermatitis und im Dezember 2021 die positive Nutzenbewertung des Institut für Qualität und Wirtschaftlichkeit im Gesundheitswesen (IQWiG) [71]. Upadacitinib sei der zweckmässigen Vergleichstherapie mit Dupilumab, das als Standard in der deutschen Leitlinie zur atopischen Dermatitis aufgeführt ist, überlegen. Im April 2022 erhielt auch der JAKi Abrocitinib eine Zulassung der European Medical Agency (EMA) für die mittelschwere und schwere atopische Dermatitis. Studien zeigten auch für dieses Biologikum eine stärkere Wirksamkeit als für Dupalimab [70]. Bei der Anwendung von JAKi kann die Infektabwehr stärker beeinträchtigt sein als bei TNF-α-Agonisten. Gefürchtet sind vor allem Herpes-zoster-Erkrankungen [72]. Vor Therapiebeginn sollte deshalb der Impfstatus vervollständigt werden und auch bei einem Alter unter 50 Jahren eine Indikationsimpfung gegen Herpes zoster empfohlen werden. Wenn eine Infektion – sei es der Atem- oder Harnwege, der Haut oder eines anderen Organsystems – akut ist, sollte die Therapie pausiert werden [73].

## Therapeutische Alternativen

Für die Behandlung von dermatologischen Erkrankungen gibt es ebenfalls verschiedene therapeutische Alternativen. Zu den konventionellen Behandlungsmöglichkeiten gehören topische Steroide, die häufig zur Behandlung von entzündlichen Hauterkrankungen wie Psoriasis und atopischer Dermatitis eingesetzt werden. Darüber hinaus werden auch topische Calcineurin-Inhibitoren wie Tacrolimus und Pimecrolimus verwendet, um die Entzündung zu reduzieren und den Juckreiz zu lindern. Bei schwereren oder therapieresistenten Fällen von Psoriasis können systemische Therapien erforderlich sein, darunter traditionelle systemische Medikamente wie Methotrexat und Cyclosporin sowie biologische Therapien wie TNF-Inhibitoren (z.B. Adalimumab, Etanercept, Infliximab), IL-Inhibitoren (z.B. Secukinumab, Ixekizumab) und IgG4-Antikörper (z.B. Dupilumab). Bei Formen der Psoriasis kommt oftmals auch eine Phototherapie zum Einsatz.

[Hinweis Transkription: Hier nennt der Fliesstext März 2021 als Schweizer Zulassung von Upadacitinib für atopische Dermatitis. Tabelle 19 auf Seite 58 nennt für diese Indikation 26.11.2021. Beide Originalangaben unverändert übernommen.]

[[Seite 91/102]]

## 5.1.3 JAKi bei gastrointestinalen Erkrankungen

## Aktuelle Empfehlungen und Leitlinien

Die aktuell bei Colitis ulcerosa zugelassenen JAKi sind Filgotinib, Tofacitinib und Upadacitinib. Gemäss der deutschen S3-Leitlinie Colitis ulcerosa wird eine generelle Priorisierung der JAKi in der Therapiewahl zum gegenwärtigen Zeitpunkt nicht empfohlen [74]. Die im Rahmen der Oral Surveillance Studie bei Personen mit rheumatoider Arthritis beobachteten Nebenwirkungen konnten für Patientinnen und Patienten mit Colitis ulcerosa in den bisher vorliegenden Studien und auch in Post-Marketing-Registerstudien nicht beobachtet werden, so dass denkbar ist, dass die beobachteten Daten bei Personen mit rheumatoider Arthritis nicht auf Personen mit Colitis ulcerosa übertragbar sind [34,75]. Nichtsdestotrotz sollte der Einsatz der JAKi unter den oben genannten Aspekten mit der gebotenen Vorsicht erfolgen und auf weitere klinische Daten im Indikationsbereich Colitis ulcerosa gewartet werden [74].

## Therapeutische Alternativen

Im Bereich der gastrointestinalen Erkrankung Colitis ulcerosa umfassen konventionelle Behandlungsmöglichkeiten die Verwendung von entzündungshemmenden Medikamenten wie 5-Aminosalicylsäure (5-ASA), die oral oder rektal verabreicht werden. Bei schwereren Fällen können Glukokortikoide wie Prednison oder Budesonid eingesetzt werden, um die Entzündung zu kontrollieren. Zudem werden auch Immunsuppressiva wie Thiopurine (z.B. Azathioprin, Mercaptopurin) und Methotrexat verwendet. Biologika wie TNF-Inhibitoren (z.B. Infliximab, Adalimumab) und IL-Inhibitoren (z.B. Ustekinumab) sind ebenfalls eine Option, insbesondere bei mangelndem Ansprechen auf konventionelle Therapien oder bei schweren Verläufen der Erkrankung.

[[Seite 92/102]]

## 5.2 Tabellen Therapien beim Lungenkrebs

| Jahr | Geschätzte Anzahl Fälle Krebsregister CH | Geschätzte Anzahl Fälle Helsana |
|---|---|---|
| 2012 | - | 6’156 |
| 2013 | 4’416 | 4’291 |
| 2014 | 4’383 | 4’623 |
| 2015 | 4’566 | 4’753 |
| 2016 | 4’783 | 4’668 |
| 2017 | 4’890 | 4’835 |
| 2018 | 4’895 | 4’654 |
| 2019 | 4’936 | 4’374 |
| 2020 | 4’900 | 4’846 |
| 2021 | - | 4’970 |
| 2022 | - | 4’400 |
| 2023 | - | 3’853 |

Tabelle 26: Vergleich geschätzte Fallzahlen Nationales Krebsregister Schweiz vs. Helsanadaten

[Hinweis Transkription: Die geschätzten Helsana-Fallzahlen in Tabelle 26 weichen von den Inzidenzwerten in Tabelle 22 auf Seite 76 ab. Die Originalwerte sind unverändert übernommen; die Abweichungen sind nachstehend vollständig aufgeführt.]

| Jahr | Tabelle 26: Geschätzte Anzahl Fälle Helsana | Tabelle 22: Inzidenz |
|---|---|---|
| 2012 | 6’156 | 6’889 |
| 2013 | 4’291 | 4’662 |
| 2014 | 4’623 | 4’859 |
| 2015 | 4’753 | 4’844 |
| 2016 | 4’668 | 4’724 |
| 2017 | 4’835 | 4’902 |
| 2018 | 4’654 | 4’652 |
| 2019 | 4’374 | 4’470 |
| 2020 | 4’846 | 4’869 |
| 2021 | 4’970 | 4’940 |
| 2022 | 4’400 | 4’413 |
| 2023 | 3’853 | 4’165 |

| Wirkstoff | Präparatname | Typ | Lungenkrebs-spezifisch | Datum Aufnahme SL |
|---|---|---|---|---|
| Cyclophosphamid | Endoxan® | Zytostatikum | Nein | 15.03.1960 |
| Ifosfamid | Holoxan® | Zytostatikum | Nein | 15.03.1982 |
| Gemcitabin | Gemcitabin | Zytostatikum | Nein | 01.07.2009 |
| Vincristin | Oncovin®, Generika | Zytostatikum | Nein | 15.03.1984 |
| Vinorelbin | Navelbine®, Generika | Zytostatikum | Nein | 01.08.1996 |
| Etoposid | Etopophos®, Vepesid®, Generika | Zytostatikum | Nein | 15.03.1981 |
| Paclitaxel | Taxol®, Generika | Zytostatikum | Nein | 15.03.1995 |
| Docetaxel | Taxotere®, Generika | Zytostatikum | Nein | 01.11.2011 |
| Topotecan | Hycamtin®, Generika | Zytostatikum | Nein | 15.03.1998 |
| Doxorubicin | Adriblastin®, Generika | Zytostatikum | Nein | 15.03.1991 |
| Carboplatin | Paraplatin®, Generika | Zytostatikum | Nein | 15.03.1987 |
| Cisplatin | Cisplatin | Zytostatikum | Nein | 15.03.1999 |
| Methotrexat | Metoject® | Zytostatikum | Nein | 01.04.2002 |
| Vindesin | Eldisine® | Zytostatikum | Nein | 15.03.1997 |
| Epirubicin | Farmorubicin®, Generika | Zytostatikum | Nein | 15.03.1991 |
| Pemetrexed | Alimta®, Generika | Zytostatikum | Nein | 01.02.2007 |
| Lurbinectedin | Zepzelca® | Zytostatikum | Ja | 01.09.2023 |
| Dabrafenib | Tafinlar® | zielgerichete Therapie | Nein | 01.02.2014 |
| Crizotinib | Xalkori® | zielgerichete Therapie | Nein | 01.06.2013 |
| Trametinib | Mekinist® | zielgerichete Therapie | Nein | 01.07.2016 |

---

— Ende Teil 7 von 8 · Kontrollwort Teil 7: CHASSERAL-20 · weiter mit teil-08.md —
