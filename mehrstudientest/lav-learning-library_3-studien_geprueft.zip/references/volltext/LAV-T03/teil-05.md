# LAV-T03 · Volltext · Teil 5 von 8 (PDF-Seiten 57–67 von 102)

Studie: Helsana-Report: Arzneimittel – Medikamente erstmals grösster Kostenblock der Grundversicherung · Quelldatei: arzneimittelreport-2024-31e5177c.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 8 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T03, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 57/102]]

dabei eine heterogene Gruppe von Arzneistoffen. Ihnen ist gemeinsam, dass sie bestimmte intrazelluläre Enzyme, die Januskinasen, hemmen und dadurch die Immunantwort und das Zellwachstum beeinflussen. Die bekanntesten JAKi sind Tofacitinib (Xeljanz®), Baricitinib (Olumiant®) und Upadacitinib (Rinvoq®).

Konventionelle entzündungshemmende Medikamente, die nach Möglichkeit eher kurzfristig zur Symptomkontrolle chronisch-entzündlicher Erkrankungen eingesetzt werden, sind die nichtsteroidalen Antirheumatika (NSAR) und Glukokortikoide. Im Gegensatz zu diesen zielen die sogenannten Disease-Modifying Antirheumatic Drugs (DMARDs), wie z.B. Methotrexat, auf spezifische Komponenten des Immunsystems ab und werden vor allem in der Behandlung von rheumatologischen und dermatologischen Erkrankungen breit und langfristig angewendet. Biologika sind eine weitere wichtige therapeutische Option und zielen darauf ab, spezifische Moleküle des Immunsystems zu blockieren, die an der Entzündungsreaktion beteiligt sind. Beispiele hierfür sind Tumor-Nekrose-Faktor-Inhibitoren (TNFi) sowie Interleukin-Inhibitoren (ILi) (siehe Anhang). Die Indikationen für JAKi überlappen stark mit den Indikationen für diese Medikamente. Ihr Einsatz bietet gewisse Vorteile gegenüber diesen Therapiemöglichkeiten. Studienergebnisse bescheinigen den JAKi in manchen Situationen nicht nur eine langanhaltende Wirksamkeit, sondern – im Vergleich zu den Biologika – auch einen schnelleren Wirkeintritt. Ein weiterer Vorteil gegenüber den Biologika ist die Verabreichung in Tablettenform.

Konventionelle DMARDS, z.B. Methotrexat, sind in der Regel relativ kostengünstig, können aber nicht für alle Indikationen eingesetzt werden und sind oft weniger gut wirksam als die Biologika oder die JAKi. Biologika sind aufgrund ihrer komplexen und teuren Entwicklungskosten sowie ihrer Verabreichung durch Injektion oder Infusion oftmals sehr hochpreisig. Im Vergleich dazu haben JAKi trotz ihrer ebenfalls hohen Preise und vergleichbar hohen, substantiellen Gesamtkosten das Potential, eine kosteneffektive Alternative darzustellen, auch aufgrund ihrer oralen Verabreichung und der langanhaltenden Wirksamkeit.

Parallel zu ihrer breiten Wirkung gehen JAKi jedoch auch mit einem grossen Nebenwirkungsspektrum einher. Ungeachtet ihrer Vorteile sind in den letzten Jahren vermehrt Sicherheitsbedenken aufgekommen, insbesondere bei älteren Patientinnen und Patienten mit kardialen Risikofaktoren. Langzeitstudien legen nahe, dass die Einnahme von Tofacitinib mit einem erhöhten Risiko für schwerwiegende Infektionen, thromboembolische Ereignisse und Malignome sowie einer erhöhten Gesamtmortalität verbunden sein kann [34–38]. Infolgedessen haben weltweit verschiedene Zulassungsbehörden Sicherheitswarnungen herausgegeben und Herstellerfirmen Empfehlungen zur Überwachung möglicher unerwünschter Wirkungen während der Einnahme von JAKi abgegeben.

Die vorliegende Studie zielt darauf ab, die Entwicklung der Verwendung von JAKi im Kontext der Sicherheitsbedenken und der damit verbundenen Warnungen zu beschreiben. Es wird untersucht, wie gut sich die Effektivität der JAKi in der Schweiz darstellt und welche negativen Effekte sich nach deren Einnahme gehäuft zeigen. Zusätzlich wird untersucht, ob die Warnungen mit einem relevanten Rückgang der Verwendung der betroffenen JAKi einhergeht, insbesondere des zuerst betroffenen Wirkstoffs Tofacitinib. Wenn ja, welche Auswirkungen dies auf die Verwendung anderer JAKi und auf die Nutzung weiterer medikamentöser Behandlungsmöglichkeiten hat. Sind die Auswirkungen auf bestimmte Risikogruppen beschränkt, oder betrifft es auch andere Personengruppen? Zudem werden

[[Seite 58/102]]

die Preise der betreffenden Medikamente und verschiedene zusätzliche Kosten und Folgekosten den weiteren Behandlungsmöglichkeiten gegenübergestellt, um detaillierter auf die Kosten-Nutzen-Situation einzugehen.

## 4.1.2 Methoden

## Allgemein

Es handelt sich um eine retrospektive, deskriptive Studie zur Untersuchung des zeitlichen Verlaufs des JAKi-Verbrauchs, klinischer Ereignisse und der damit zusammenhängenden Behandlungskosten. Die Basis hierfür bilden auf die gesamte Schweizer Bevölkerung hochgerechnete anonymisierte Abrechnungsdaten von Grundversicherten aller Altersgruppen, die zwischen dem 01.01.2013 und dem 31.12.2023 bei Helsana versichert waren.

## Januskinase-Inhibitoren (JAKi)

In der Schweiz sind derzeit sechs verschiedene JAKi zugelassen (Stand: Dezember 2023). Es handelt sich um die Wirkstoffe Abrocitinib, Baricitinib, Fedratinib, Ruxolitinib, Tofacitinib und Upadacitinib. Jedes dieser Medikamente hat spezifische Anwendungsgebiete und kann zur Behandlung unterschiedlicher Erkrankungen eingesetzt werden. Eine Auflistung der Wirkstoffe und ihrer Anwendungsbereiche, inklusive der Zulassungsdaten, findet sich in Tabelle 19. Die JAKi Ruxolitinib und Fedratinib, die bei Krankheiten wie Myelofibrose oder der Graft-versus-Host-Reaktion eingesetzt werden, sind nicht von den Sicherheitswarnungen der Behörden betroffen.

| Wirkstoff | ATC | Indikation(en) | Zulassung nach Indikation | SL Erstaufnahme |
|---|---|---|---|---|
| Abrocitinib (Cibinqo®) | D11AH08 | Atopische Dermatitis | 06.04.2022 | 01.06.2022 |
| Baricitinib (Olumiant®) | L04AF02 (L04AA37) | Rheumatoide Arthritis,<br>Atopische Dermatitis,<br>COVID-19,<br>Alopecia areata | 19.06.2017<br>09.02.2021<br>10.08.2021<br>26.05.2023 | 01.09.2017 |
| Fedratinib (Inrebic®) | L01EJ02 | Myelofibrose | 01.07.2021 | 01.09.2021 |
| Ruxolitinib (Jakavi®) | L01EJ01 (L01XE18) | Myelofibrose,<br>Polycythaemia vera,<br>Graft-versus-Host-Reaktion (GvHD) | 27.12.2012<br>27.12.2012<br>28.07.2022 | 01.01.2017 |
| Tofacitinib (Xeljanz®) | L04AF01 (L04AA29) | Rheumatoide Arthritis,<br>Psoriasis-Arthritis,<br>Colitis ulcerosa,<br>Ankylosierende Spondylitis (M. Bechterew) | 12.07.2013<br>06.09.2018<br>26.06.2019<br>17.04.2023 | 01.08.2013 |
| Upadacitinib (Rinvoq®) | L04AF03 (L04AA44) | Rheumatoide Arthritis,<br>Psoriasis-Arthritis,<br>Ankylosierende Spondylitis (M. Bechterew),<br>Atopische Dermatitis | 20.01.2020<br>23.03.2021<br>23.03.2021<br>26.11.2021 | 01.04.2020 |

Hinweis: grau hinterlegt sind die von den späteren Sicherheitswarnungen betroffenen Wirkstoffe.

Quellen: Spezialitätenliste, Swissmedic, Compendium [39–41].

Tabelle 19: Zugelassene JAKi (Stand: Dezember 2023)

[Hinweis Transkription: Die im Originalhinweis genannte graue Hinterlegung ist im vorliegenden Seitenbild nicht eindeutig erkennbar. Eine Markierung einzelner Tabellenzeilen allein aufgrund der Hintergrundfarbe wurde daher nicht ergänzt. Indikationen und zugehörige Zulassungsdaten stehen innerhalb einer Tabellenzeile in derselben Reihenfolge.]

[[Seite 59/102]]

| Indikationsgebiet | Indikation(en) |
|---|---|
| Rheumatische Erkrankung | Rheumatoide Arthritis<br>Psoriasis-Arthritis<br>Ankylosierende Spondylitis (Morbus Bechterew) |
| Dermatologische Erkrankung | Atopische Dermatitis<br>Alopecia areata |
| Gastrointestinale Erkrankung | Colitis ulcerosa |
| Bluterkrankung | Myelofibrose<br>Polycythaemia vera |
| Immunologische Komplikation | Graft-versus-Host-Reaktion (GvHD) |
| Infektionskrankheit* | COVID-19 |

Hinweis: grau hinterlegt sind die von den späteren Sicherheitswarnungen betroffenen Indikationsgebiete.

* Es konnten auf Basis der Helsana-Abrechnungsdaten keine entsprechenden Zuweisungen zu diesem Indikationsgebiet gemacht werden. Daher wird dieses Indikationsgebiet nachfolgend nicht näher betrachtet.

Tabelle 20: Einteilung der Indikationsgebiete

[Hinweis Transkription: Die im Originalhinweis genannte graue Hinterlegung ist im vorliegenden Seitenbild nicht eindeutig erkennbar. Die Zuordnung der Hinterlegung zu einzelnen Indikationsgebieten wurde deshalb nicht geraten.]

Viele JAKi sind für verschiedene Anwendungsbereiche zugelassen. Sie lassen sich grob sechs Indikationsgebieten zuordnen: rheumatischen, dermatologischen, gastrointestinalen und Blut-Erkrankungen, Infektionskrankheiten sowie immunologischen Komplikationen (Tabelle 20). In den Abrechnungsdaten der Grundversicherung sind keine Diagnosen enthalten, weshalb eine Unterscheidung nach Indikationsgebiet im Rahmen dieser Studie nur annäherungsweise getroffen werden konnte. Deswegen wurde eine hierarchische Unterteilung vorgenommen, die in einem ersten Schritt das Zulassungsdatum berücksichtigte. Sofern zum ersten Bezugszeitpunkt eines Wirkstoffs nur in einem Indikationsgebiet eine Zulassung bestand, wurde der Wirkstoff (und wurden alle nachfolgenden Bezüge anderer Wirkstoffe durch die versicherte Person) diesem Gebiet zugeordnet. Eventuelle Off-Label-Verwendungen in anderen Gebieten wurden vernachlässigt. In einem zweiten Schritt wurden die begleitend abgegebenen Medikamente betrachtet. Wenn andere indikationsspezifische Medikamente zum Einsatz kamen, dann wurde der JAKi dieser Indikation zugeordnet (z.B. galt eine Therapie mit Etanercept vor/nach der Einnahme von Tofacitinib als Indikator für eine rheumatologische Indikation). Im dritten Schritt erfolgte die Zuordnung aufgrund der Häufigkeit von Spezialistenbesuchen, wie beispielsweise einer überdurchschnittlichen Anzahl von Konsultationen der Rheumatologie. Die noch verbliebenen, bis dahin nicht zugeordneten JAKi wurden nach Betrachtung aller Medikamentenbezüge, Spezialistenbesuche und Komplikationen in einem vierten Schritt bestmöglich manuell zugeordnet. Die Kombination von Indikationsgebieten wurde in dieser Analyse ausgeschlossen, obwohl solche Kombinationen in der Praxis durchaus vorkommen.

Für einen besseren Vergleich wurde zudem ein Datenset gebildet, welches Personen mit rheumatischen Beschwerden umfasste, die über den Untersuchungszeitraum DMARDs (inklusive Methotrexat) oder Biologika bezogen, keine indikationsspezifischen Medikamente anderer Gebiete erhielten und eine überdurchschnittliche Anzahl von Konsultationen der Rheumatologie aufwiesen, aber niemals JAKi bezogen.

[[Seite 60/102]]

## Therapieansprechen, Behandlungswechsel und Behandlungsabbrüche

Am Beispiel von Tofacitinib bei rheumatoiden Erkrankungen wurde die Effektivität und Sicherheit untersucht. Das Datum der ersten Verschreibung von Tofacitinib legte den Behandlungsbeginn fest. In einem approximativen ad hoc Vorgehen wurde die Therapie als wirksam betrachtet, wenn die folgenden Kriterien im ersten Jahr der Nachbeobachtung erfüllt wurden: fortlaufende Bezüge, kein Wechsel zu oder Zusatz von konventionellen DMARDs oder Biologika (z.B. ILi, oder TNFi). Es wurde von einem Therapiewechsel ausgegangen, wenn nach einem Tofacitinib-Bezug innerhalb von 60 Tagen eine Behandlung mit einem anderen Medikamententyp erfolgte. Die Behandlung galt dagegen als abgebrochen, wenn innerhalb des sechzigtägigen Zeitraums kein weiterer Bezug eines JAKi und keine medikamentöse Behandlungsmöglichkeit erfolgten.

## Gefährdete Personengruppen und Sicherheit

Neben dem Therapieansprechen wurde zusätzlich das Auftreten von potenziell assoziierten negativen Effekten (basierend auf den entsprechenden ICD10-Codes), wie schwerwiegenden kardiovaskulären Ereignissen (MACE), Infektionen, Thromboembolien und einer erhöhten Gesamtmortalität für Tofacitinib im Bereich einer rheumatischen Indikation untersucht. Dafür wurden Personen mit JAKi-Bezügen über eine Zeitdauer von wenigstens einem halben Jahr (klassifiziert als «Fälle») verglichen mit Personen mit demografisch ähnlichem Profil aus dem Vergleichsdatensatz ohne JAKi-Bezüge, aber mit mindestens halbjährlichen TNFi-Bezügen (klassifiziert als «Kontrollen»). Die Kontrollgruppe wurde dabei mittels Propensity Scores im Verhältnis 1:1 bestimmt. Die Gefährdungsquotienten (Hazard ratios) wurden auf Grundlage von Cox-Proportional-Hazard-Modellen mit Gewichtungen analog zu den Hochrechnungsfaktoren geschätzt, wobei Alter, Geschlecht und Wohnkanton als Kontrollvariablen einbezogen wurden. Die Zeitdauer im Modell entsprach der Zeit des ersten Bezugs bis zum Auftreten des ersten negativen Ereignisses. Wenn kein Ereignis auftrat wurden die Daten zum Ende des Versicherungszeitraums zensiert.

Als Personen mit einem erhöhten Risiko für MACE galten jene, die aufgrund von Vorerkrankungen wie Hyperlipidämie, Bluthochdruck oder Diabetes bereits ein erhöhtes kardiovaskuläres Risiko aufwiesen. Diese wurden anhand ihrer jeweiligen spezifischen Medikationen bestimmt, beispielsweise durch die Verwendung von PCSK9-Inhibitoren, NOAKs, Insulinen oder Betablockern. Als Personen mit einem erhöhten Risiko für Infektionen wurden auf Basis der bezogenen Medikamente jene definiert, die aufgrund von Erkrankungen vermutlich ein geschwächtes Immunsystem hatten oder chronische Erkrankungen aufwiesen, die zu häufigeren oder schwereren Infektionen führen. Dazu zählten unter anderem Personen mit antiretroviralen Therapien, Biologika zur Behandlung von Autoimmunerkrankungen, Immunsuppressiva oder Medikamenten bei chronischen Lungenkrankheiten.

Als Personen mit einem erhöhten Risiko für Thromboembolien (oder MACE) galten jene, die beispielsweise Antikoagulanzien, Thrombozytenaggregationshemmer, oder Medikamente bei venösen Thromboembolien einnahmen.

[[Seite 61/102]]

## 4.1.3 Resultate und Diskussion

## Sicherheitswarnungen

Die Wirksamkeit der verschiedenen JAKi galt ursprünglich als grundsätzlich gut, jedoch kamen aufgrund von Langzeitstudien Bedenken hinsichtlich der Sicherheitsprofile auf, insbesondere bei älteren Personen mit kardialen Risikofaktoren [34–38]. Diese Patientengruppe zeigte in der ORAL Surveillance Study, einer randomisierten Sicherheitsstudie zum JAKi Tofacitinib, erhöhte Risiken für schwerwiegende kardiovaskuläre Ereignisse (MACE) (Hazard Ratio: 1.3), Malignome (1.5), schwerwiegende Infektionen (1.3), schwere Thromboembolien (2.6) und Gesamtmortalität (1.9) im Vergleich zu Biologika auf [34]. Daraufhin veranlassten die Zulassungsbehörden verschiedener Länder (EU, Vereinigtes Königreich, USA, Kanada, Australien, Neuseeland, Singapur, Schweiz) im Jahr 2019

Sicherheitswarnungen und die Herstellerfirmen gaben Empfehlungen an die Ärzteschaft heraus, die Patientinnen und Patienten während der Einnahme von JAKi genau auf mögliche unerwünschte Wirkungen zu überwachen und individuelle Nutzen-Risiko-Abwägungen zu machen.

| Datum DHPC | Präparat(e) | Thema |
|---|---|---|
| 26.04.2019 | Tofacitinib (Xeljanz®) | Erhöhtes Risiko von Lungenembolie und Mortalität bei rheumatoider Arthritis bei 10 mg 2x täglich |
| 04.06.2019 | Tofacitinib (Xeljanz®) | Einschränkung der 10 mg 2x täglichen Anwendung bei erhöhtem Risiko einer Lungenembolie |
| 29.01.2021 | Tofacitinib (Xeljanz®) | Streichung der 10 mg 2x täglich Dosis bei rheumatoider Arthritis aufgrund erhöhter Risiken;<br>Erhöhtes Risiko für venöse Thromboembolien und Gesamtmortalität |
| 25.06.2021 | Tofacitinib (Xeljanz®) | Erhöhtes Risiko für schwerwiegende unerwünschte kardiovaskuläre Ereignisse und maligne Erkrankungen (ohne NMSC) im Vergleich zu TNF-alpha-Inhibitoren |
| 15.09.2021 | Tofacitinib (Xeljanz®) | Erhöhtes Risiko für schwerwiegende unerwünschte kardiovaskuläre Ereignisse und maligne Erkrankungen im Vergleich zu TNF-alpha-Inhibitoren |
| 01.03.2023 | Abrocitinib (Cibinqo®)<br>Baricitinib (Olumiant®)<br>Tofacitinib (Xeljanz®)<br>Upadacitinib (Rinvoq®) | Klasseneffekt in Bezug auf erhöhtes Risiko für Malignome, schwerwiegende kardiovaskuläre Ereignisse (MACE), schwerwiegende Infektionen, Thrombosen und Gesamtmortalität |

Abkürzungen: NMSC = Non-Melanoma Skin Cancer (Nicht-Melanom-Hautkrebs), MACE = major adverse cardiovascular event (schwerwiegende kardiovaskuläre Ereignisse).

Quelle: Swissmedic [39].

Tabelle 21: Direct-Healthcare-Professional-Communications (DHPC) zu JAKi in der Schweiz

Die ersten Warnschreiben an die Schweizer Ärzteschaft (Tabelle 21), sogenannte Direct-Healthcare-Professional-Communications (DHPC), wurden durch die Hersteller in Absprache mit Swissmedic Mitte 2019 herausgegeben und bezogen sich auf ein erhöhtes Risiko für venöse Thromboembolien und eine gesteigerte Gesamtmortalität bei Einnahme des JAKi Tofacitinib mit einer 10 mg Dosis zweimal täglich. Nach Abschluss der ORAL Surveillance Study erfolgte dann ein Entzug dieser Dosierungszulassung in der Indikation rheumatoide Arthritis im Jahr 2021 [42,43]. Im selben Jahr folgten nach Veröffentlichung weiterer Studienergebnisse zusätzliche Warnschreiben zu Tofacitinib mit erweiterten Risiken [44–46]. Im März 2023 wurden dann die Risiken als Klasseneffekte eingestuft und es erfolgte eine entsprechende

[[Seite 62/102]]

Warnung für alle bei entzündlichen und dermatologischen Erkrankungen zugelassenen JAKi (Abrocitinib, Baricitinib, Tofacitinib, Upadacitinib) [47]. Die anderen JAKi (Ruxolitinib und Fedratinib) waren von den Warnungen ausgenommen.

Die aktuellen Fach- sowie Patienteninformationen der JAKi weisen die Risiken deutlich aus, und verweisen ausserdem darauf, dass angesichts des erhöhten Risikos für schwere Infektionen, Myokardinfarkt und maligne Erkrankungen bei Patientinnen und Patienten über 65 Jahre JAKi für die Behandlung von chronisch-entzündlichen und dermatologischen Erkrankungen nur angewendet werden sollten, wenn keine geeigneten Behandlungsmöglichkeiten zur Verfügung stehen. Zudem sollten Ärztinnen und Ärzte JAKi bei Patientinnen und Patienten mit kardiovaskulären Risikofaktoren, Rauchern oder ehemaligen Rauchern sowie bei Patientinnen und Patienten mit (aktuellen oder früheren) bösartigen Erkrankungen nur dann anwenden, wenn keine geeigneten therapeutischen Alternativen vorhanden sind. Zusätzlich zu den Warnhinweisen fasst ein Boxed warning (besonders hervorgehobener Warnhinweis zu Beginn der Fach- und Patienteninformation) die Risiken zusammen und hebt diese auch optisch hervor.

Ein Überblick über die aktuellen Leitlinien und mögliche therapeutische Behandlungsmöglichkeiten der drei von den Warnungen betroffenen JAKi-Indikationsgebiete Rheumatologie, Dermatologie und Gastroenterologie findet sich im Anhang.

## Häufigkeit der JAKi-Verwendung und Demographie der Patientinnen und Patienten

Basierend auf den hochgerechneten Helsana-Daten beträgt die Anzahl Personen, die im Jahr 2023 in der Schweiz mindestens einmal einen JAKi eingenommen haben, schätzungsweise 10’400. Dies entsprach rund 115 pro 100’000 Personen. Personen mit rheumatischen Erkrankungen machten mit knapp 8’000 Personen (79%) die grösste Gruppe aus (Abbildung 11). Weitere 11% der Patientinnen und Patienten bezogen JAKi aufgrund einer Bluterkrankung (Myelofibrose oder Polycythaemia vera) und 7% wegen einer dermatologischen Erkrankung. Gastrointestinale Erkrankungen spielten bei 3% der Personen eine Rolle und immunologische Komplikationen (Graft-versus-Host-Krankheit) bei 1%. Eine Verwendung für Infektionen (COVID-19) kam laut den Helsana-Daten nicht vor (auch nicht über den gesamten Zeitraum von 2013-2023), daher wird auf Infektionskrankheiten nachfolgend nicht mehr eingegangen.

**[Grafik 11] Abbildung 11: Anzahl der Personen mit Verwendung von JAKi nach Indikationsgebiet und Geschlecht, 2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Gruppierte Säulen. X-Achse: Indikationsgebiet. Y-Achse: Anzahl Personen, – (Nulllinie), 1’000, 2’000, 3’000, 4’000, 5’000, 6’000. Frauen bordeauxrot, Männer beige. Wertstatus: abgelesen ca.; Genauigkeit ±100 Personen, bei den kleinen Säulen ±50 Personen. Die rheumatischen Säulen sind mit knapp 8’000 Personen im Fliesstext vereinbar. Die Prozentangaben im Fliesstext sind unverändert übernommen; ihre Summe beträgt 101% (Rundungsabweichung).

| Indikationsgebiet | Frauen | Männer |
|---|---|---|
| Rheumatisch | ca. 5700 | ca. 2200 |
| Bluterkrankung | ca. 500 | ca. 600 |
| Dermatologisch | ca. 400 | ca. 300 |
| Gastrointestinal | ca. 100 | ca. 150 |
| Immunologisch | ca. 50 | ca. 50 |

**[Ende Grafik 11]**

[[Seite 63/102]]

JAKi wurden insgesamt häufiger von Frauen als von Männern verwendet, wobei das Verhältnis etwa 2:1 betrug. Diese Ungleichverteilung zeigte sich insbesondere bei den rheumatischen und dermatologischen Erkrankungen, was auf die generellen geschlechtsspezifischen Unterschiede in der Häufigkeit dieser Indikationsgebiete zurückzuführen ist, bei denen Frauen zumeist häufiger betroffen sind. Bei gastrointestinalen Indikationen war das Geschlechterverhältnis annähernd ausgeglichen und bei Bluterkrankungen war dagegen die Anzahl der Männer etwas häufiger, was der generellen Prävalenz der Erkrankungen entspricht.

Etwa ein Drittel der behandelten Personen war über 65 Jahre alt. Diejenigen, die JAKi aufgrund von gastrointestinalen Erkrankungen einnahmen, waren im Durchschnitt deutlich jünger als diejenigen, die eine dermatologische oder rheumatische Indikation aufwiesen. Personen mit Bluterkrankungen gehörten zu den ältesten JAKi-Nutzenden in der Stichprobe.

## Trend der Medikamentenbezüge

## Nach Wirkstoff:

Die Bezüge von JAKi insgesamt stiegen im Untersuchungszeitraum nahezu kontinuierlich an (Abbildung 12). Der Anteil von Fedratinib und Abrocitinib war dabei mit jeweils weniger als 60 Bezügen pro Quartal vernachlässigbar.

**[Grafik 12] Abbildung 12: JAKi-Bezüge pro Quartal nach Wirkstoff und Zeitpunkte der DHPCs, 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Liniendiagramm, Quartale 2013–2023. X-Achse beschriftet mit 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023. Y-Achse: Anzahl vierteljährliche Bezüge, 0, 5’000, 10’000, 15’000, 20’000, 25’000. Serien in Legendenreihenfolge: bordeauxrot, beige, gelb, blau, orange, grün, schwarz. Gestrichelte senkrechte Linien markieren die Zeitpunkte der DHPCs; die sechs Daten sind in Tabelle 21 auf Seite 61 aufgeführt. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±250 Bezüge. Quartale anhand gleichmässiger Punkteabstände zwischen den Jahresticks zugeordnet. Überlagerungen mit Warnlinien und die nahe der Nulllinie liegenden Fedratinib- und Abrocitinib-Kurven sind nicht eindeutig ablesbar. Der Fliesstext beziffert letztere mit jeweils weniger als 60 Bezügen pro Quartal. – bedeutet kein getrennt sichtbarer Kurvenabschnitt vor bzw. nach dem dargestellten Verlauf, nicht zwingend null Bezüge.

| Quartal | Tofacitinib (Xeljanz®) | Ruxolitinib (Jakavi®) | Baricitinib (Olumiant®) | Upadacitinib (Rinvoq®) | Fedratinib (Inrebic®) | Abrocitinib (Cibinqo®) | Total |
|---|---|---|---|---|---|---|---|
| 2013 Q1 | – | – | – | – | – | – | ca. 0 |
| 2013 Q2 | – | – | – | – | – | – | ca. 0 |
| 2013 Q3 | – | – | – | – | – | – | ca. 100 |
| 2013 Q4 | ca. 300 | ca. 100 | – | – | – | – | ca. 500 |
| 2014 Q1 | ca. 800 | ca. 500 | – | – | – | – | ca. 1300 |
| 2014 Q2 | ca. 1400 | ca. 600 | – | – | – | – | ca. 1900 |
| 2014 Q3 | ca. 1500 | ca. 600 | – | – | – | – | ca. 2000 |
| 2014 Q4 | ca. 1700 | ca. 700 | – | – | – | – | ca. 2500 |
| 2015 Q1 | ca. 1800 | ca. 800 | – | – | – | – | ca. 2600 |
| 2015 Q2 | ca. 2000 | ca. 1000 | – | – | – | – | ca. 2900 |
| 2015 Q3 | ca. 2500 | ca. 1000 | – | – | – | – | ca. 3500 |
| 2015 Q4 | ca. 3100 | ca. 1100 | – | – | – | – | ca. 4200 |
| 2016 Q1 | ca. 3100 | ca. 1200 | – | – | – | – | ca. 4200 |
| 2016 Q2 | ca. 3600 | ca. 1300 | – | – | – | – | ca. 4900 |
| 2016 Q3 | ca. 3800 | ca. 1400 | – | – | – | – | ca. 5200 |
| 2016 Q4 | ca. 4500 | ca. 1500 | – | – | – | – | ca. 5900 |
| 2017 Q1 | ca. 4500 | ca. 1500 | – | – | – | – | ca. 6000 |
| 2017 Q2 | ca. 4900 | ca. 1600 | ca. 0 | – | – | – | ca. 6500 |
| 2017 Q3 | ca. 5000 | ca. 1800 | ca. 100 | – | – | – | ca. 6800 |
| 2017 Q4 | ca. 5400 | ca. 1800 | ca. 600 | – | – | – | ca. 7700 |
| 2018 Q1 | ca. 4700 | ca. 2000 | ca. 1400 | – | – | – | ca. 7900 |
| 2018 Q2 | ca. 4800 | ca. 1900 | ca. 2200 | – | – | – | ca. 8800 |
| 2018 Q3 | ca. 4800 | ca. 2000 | ca. 2800 | – | – | – | ca. 9400 |
| 2018 Q4 | ca. 5300 | ca. 1900 | ca. 3200 | – | – | – | ca. 10400 |
| 2019 Q1 | ca. 4800 | ca. 2000 | ca. 3300 | – | – | – | ca. 10000 |
| 2019 Q2 | ca. 5300 | ca. 2100 | ca. 3800 | – | – | – | nicht eindeutig ablesbar |
| 2019 Q3 | ca. 5600 | ca. 2100 | ca. 3900 | – | – | – | ca. 11600 |
| 2019 Q4 | ca. 5900 | ca. 2300 | ca. 4300 | – | – | – | ca. 12400 |
| 2020 Q1 | ca. 5500 | ca. 2600 | ca. 4300 | ca. 0 | – | – | ca. 12300 |
| 2020 Q2 | ca. 5100 | ca. 2200 | ca. 4000 | ca. 200 | – | – | ca. 11600 |
| 2020 Q3 | ca. 6000 | ca. 2600 | ca. 4500 | ca. 1000 | – | – | ca. 14000 |
| 2020 Q4 | ca. 6600 | ca. 2600 | ca. 5000 | ca. 1400 | – | – | ca. 15600 |
| 2021 Q1 | ca. 5400 | ca. 2400 | ca. 4600 | ca. 2000 | – | – | ca. 14500 |
| 2021 Q2 | ca. 6000 | ca. 2600 | ca. 5000 | ca. 3200 | nicht eindeutig ablesbar | – | ca. 16800 |
| 2021 Q3 | ca. 5500 | ca. 2600 | ca. 5200 | ca. 4200 | nicht eindeutig ablesbar | – | nicht eindeutig ablesbar |
| 2021 Q4 | ca. 5100 | ca. 2800 | ca. 5300 | ca. 5700 | nicht eindeutig ablesbar | – | ca. 18900 |
| 2022 Q1 | ca. 4000 | ca. 2500 | ca. 4400 | ca. 6300 | nicht eindeutig ablesbar | – | ca. 17100 |
| 2022 Q2 | ca. 4100 | ca. 2700 | ca. 5100 | ca. 7600 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 19400 |
| 2022 Q3 | ca. 4200 | ca. 2800 | ca. 5200 | ca. 7900 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 20200 |
| 2022 Q4 | ca. 4100 | ca. 2900 | ca. 5600 | ca. 9100 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 21700 |
| 2023 Q1 | ca. 3600 | ca. 3000 | ca. 5100 | ca. 9200 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2023 Q2 | ca. 3700 | ca. 3100 | ca. 5000 | ca. 10000 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 21900 |
| 2023 Q3 | ca. 3300 | ca. 3100 | ca. 5100 | ca. 10300 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 21700 |
| 2023 Q4 | ca. 3700 | ca. 3200 | ca. 5300 | ca. 10600 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 22700 |

**[Ende Grafik 12]**

Bei Tofacitinib kam es nach einer stetigen Wachstumsphase seit der Marktzulassung in 2013 im Jahr 2018 zu einem ersten Plateau der Bezüge bei etwa 4’700 Bezügen pro Quartal. Im Folgejahr stiegen die Bezüge etwas an, trotz der beiden ersten im April und Juni 2019 veröffentlichten offiziellen DHPC in der Schweiz (die aber nur eine Einschränkung der Dosierung bei Patientinnen und Patienten mit einem

[[Seite 64/102]]

erhöhten Risiko einer Lungenembolie betrafen). Sie schwankten im Zeitraum 2019 bis 2021 zwischen gut 5’000 und 6’700 Bezügen pro Quartal. Danach kam es – vermutlich im Zusammenhang mit den drei weiteren DHPC im Jahr 2021 und der weiteren Konkretisierung der Risiken verbunden mit einer konkreten Anwendungseinschränkung – zu einer deutlichen Abnahme auf unter 3’800 Tofacitinib-Bezüge pro Quartal im Jahr 2023.

Bei Baricitinib zeigte sich nach einem anfänglich starken Wachstum bis etwa Ende 2020 eine Phase stabiler Bezüge zwischen den Jahren 2021 und 2023 mit etwa 4’300-5’400 Bezügen pro Quartal. Trotz Veröffentlichung der JAKi-Klassenwarnung im März 2023 kam es in der Folge jedoch zu keinem Rückgang der Bezüge.

Obwohl Upadacitinib erst Anfang 2020 zugelassen wurde, war es seit Ende 2021 der am häufigsten abgegebene JAKi in der Schweiz und überholte damit sowohl Tofacitinib als auch Baricitinib. Obschon Upadacitinib auch von der Klassenwarnung betroffen war, stiegen die Bezüge weiter an, auf mehr als 10’500 im letzten Quartal 2023.

Der JAKi Ruxolitinib war nicht von der Klassenwarnung betroffen. Das Wachstum des Medikaments verlief stetig über den Untersuchungszeitraum und auch im Jahr 2023 verzeichnete es weitere Zuwächse. Ende 2023 erzielte Ruxolitinib 3’200 Bezüge pro Quartal, was etwa den Bezügen von Tofacitinib entsprach.

## Nach Indikationsgebiet:

Im rheumatologischen Bereich verringerte sich der durchschnittliche Anstieg der Bezüge im Jahr 2023 gegenüber den Vorjahren etwas (Abbildung 13), hauptsächlich bedingt durch den deutlichen Rückgang der Bezüge von Tofacitinib. Auch im Bereich der Blutkrankheiten gab es eine Stagnation, die allerdings bereits im Jahr 2020 begann. Das Wachstum der JAKi-Bezüge im dermatologischen Bereich setzte sich trotz stabiler Baricitinib-Bezüge fort, aufgrund von gestiegenen Bezügen bei Upadacitinib. Auch im gastrointestinalen und immunologischen Bereich gab es Zuwächse, jedoch auf einem deutlich niedrigeren Ausgangsniveau.

**[Grafik 13] Abbildung 13: JAKi-Bezüge pro Quartal nach Indikationsgebiet, 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Liniendiagramm, Quartale 2013–2023. X-Achse beschriftet mit 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023. Y-Achse: Anzahl vierteljährliche Bezüge, 0, 2’000, 4’000, 6’000, 8’000, 10’000, 12’000, 14’000, 16’000, 18’000. Serien in Legendenreihenfolge: magenta, rot, braun, blau, grün. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±200 Bezüge. Quartale anhand gleichmässiger Punkteabstände zwischen den Jahresticks zugeordnet. Überlagerte bzw. nahe der Nulllinie nicht trennbare Abschnitte sind nicht eindeutig ablesbar. – bedeutet kein getrennt sichtbarer Kurvenabschnitt, nicht zwingend null Bezüge.

| Quartal | Immunologisch | Bluterkrankung | Gastro-intestinal | Dermatologisch | Rheumatologisch |
|---|---|---|---|---|---|
| 2013 Q1 | – | – | – | – | – |
| 2013 Q2 | – | – | – | – | ca. 0 |
| 2013 Q3 | – | – | – | – | ca. 100 |
| 2013 Q4 | – | ca. 100 | – | – | ca. 400 |
| 2014 Q1 | – | ca. 500 | – | – | ca. 800 |
| 2014 Q2 | – | ca. 600 | – | – | ca. 1400 |
| 2014 Q3 | – | ca. 600 | – | – | ca. 1500 |
| 2014 Q4 | – | ca. 800 | – | – | ca. 1800 |
| 2015 Q1 | – | ca. 800 | – | – | ca. 1800 |
| 2015 Q2 | – | ca. 1000 | – | – | ca. 2000 |
| 2015 Q3 | – | ca. 1000 | – | – | ca. 2500 |
| 2015 Q4 | – | ca. 1100 | – | – | ca. 3200 |
| 2016 Q1 | – | ca. 1200 | – | – | ca. 3100 |
| 2016 Q2 | – | ca. 1300 | – | – | ca. 3700 |
| 2016 Q3 | – | ca. 1400 | – | – | ca. 3800 |
| 2016 Q4 | – | ca. 1500 | – | – | ca. 4500 |
| 2017 Q1 | – | ca. 1500 | – | – | ca. 4500 |
| 2017 Q2 | – | ca. 1600 | – | – | ca. 5000 |
| 2017 Q3 | – | ca. 1800 | – | – | ca. 5100 |
| 2017 Q4 | – | ca. 1800 | – | – | ca. 6000 |
| 2018 Q1 | – | ca. 2000 | – | – | ca. 6000 |
| 2018 Q2 | – | ca. 2000 | – | – | ca. 6900 |
| 2018 Q3 | – | ca. 2000 | – | – | ca. 7500 |
| 2018 Q4 | – | ca. 2000 | – | – | ca. 8500 |
| 2019 Q1 | – | ca. 2000 | – | – | ca. 8100 |
| 2019 Q2 | – | ca. 2100 | – | – | ca. 9000 |
| 2019 Q3 | – | ca. 2200 | – | – | ca. 9500 |
| 2019 Q4 | – | ca. 2300 | – | – | ca. 10200 |
| 2020 Q1 | – | ca. 2600 | ca. 100 | – | ca. 9800 |
| 2020 Q2 | – | ca. 2300 | nicht eindeutig ablesbar | – | ca. 9300 |
| 2020 Q3 | – | ca. 2600 | nicht eindeutig ablesbar | – | ca. 11400 |
| 2020 Q4 | – | ca. 2600 | ca. 100 | – | ca. 13000 |
| 2021 Q1 | – | ca. 2400 | ca. 200 | ca. 100 | ca. 12000 |
| 2021 Q2 | – | ca. 2600 | ca. 400 | ca. 200 | ca. 13800 |
| 2021 Q3 | – | ca. 2500 | ca. 500 | ca. 200 | ca. 14200 |
| 2021 Q4 | – | ca. 2800 | ca. 200 | ca. 400 | ca. 15400 |
| 2022 Q1 | – | ca. 2500 | nicht eindeutig ablesbar | ca. 500 | ca. 13800 |
| 2022 Q2 | ca. 100 | ca. 2700 | ca. 500 | ca. 800 | ca. 15500 |
| 2022 Q3 | ca. 100 | ca. 2800 | ca. 600 | ca. 1000 | ca. 15900 |
| 2022 Q4 | ca. 100 | ca. 2600 | ca. 500 | ca. 1000 | ca. 17600 |
| 2023 Q1 | ca. 200 | ca. 2700 | ca. 600 | ca. 1100 | ca. 16600 |
| 2023 Q2 | ca. 200 | ca. 2800 | ca. 600 | ca. 1200 | ca. 17300 |
| 2023 Q3 | ca. 200 | ca. 2700 | ca. 600 | ca. 1400 | ca. 17000 |
| 2023 Q4 | ca. 200 | ca. 2800 | ca. 800 | ca. 1400 | ca. 17800 |

**[Ende Grafik 13]**

[[Seite 65/102]]

Insgesamt betrachtet scheint die Klassenwarnung bisher nur einen geringen Einfluss auf die Bezüge der JAKi gehabt zu haben. Zwar gingen die Bezüge von Tofacitinib nach den spezifischen Warnungen für dieses Medikament deutlich zurück, stattdessen stiegen aber die Upadacitinib-Bezüge an, obwohl die Klassenwarnung auch diesen Wirkstoff einschloss. Dies könnte unter anderem an einem Mangel von Studien direkt zu Upadacitinib, und an mangelnden weiteren Behandlungsmöglichkeiten bei gleichzeitig hoher Wirksamkeit des Wirkstoffs liegen.

## Gefährdete Personengruppen

In der Klassenwarnung zu den JAKi wurde unter anderem vor einem erhöhten Risiko für schwerwiegende kardiovaskuläre Ereignisse (MACE), schwerwiegende Infektionen, und Thromboembolien gewarnt. Deshalb sollten Personen mit kardiovaskulären Risikofaktoren (einschliesslich Personen die rauchen oder geraucht haben) oder einem Risiko für bösartige Erkrankungen, sowie generell Personen über 65 Jahre, JAKi nicht respektive nicht mehr einnehmen, sofern andere geeignete Behandlungsmöglichkeiten zur Verfügung stehen.

Ein Vergleich der Nutzenden von Tofacitinib in den Jahren 2018 und 2023 zeigt, dass der Anteil an Personen mit Risikofaktoren innerhalb dieses 5-Jahres-Zeitraums leicht zurückging. Zwar war der Rückgang bei Personen mit einem Risiko für schwere Infektionen im Vergleich zu den anderen Faktoren verhältnismässig gross (Anteil 55% vs. 42%), jedoch blieben der Anteil der über 65-Jährigen (35% vs. 34%) und der Personen mit Risiko für MACE (67% vs. 66%) stabil. Der Anteil an Personen mit Risikofaktoren bei den ab 2022 neu mit Tofacitinib behandelten Personen lag zumeist unter dem Anteil derer mit einem Therapiestart vor 2022 (MACE: 54% vs. 70%; 65+: 10% vs. 42%) mit Ausnahme für schwere Infektionen (61% vs. 36%).

Da JAKi in den Leitlinien zur Behandlung für die meisten Indikationen nicht die erste Wahl darstellen (siehe Anhang), ist es denkbar, dass es den behandelnden Ärztinnen und Ärzten an weiteren geeigneten Behandlungsmöglichkeiten mangelte und dass sie JAKi trotz der bekannten Risiken als letzte Option weiter bewusst verschrieben, solange die Patientinnen und Patienten positiv auf die Therapie ansprachen und keine zusätzlichen Probleme auftraten. Eine weitere mögliche Interpretation wäre, dass die behandelnden Ärztinnen und Ärzte noch nicht ausreichend über die herausgegebenen Sicherheitswarnungen Bescheid wussten, was jedoch eher unwahrscheinlich ist.

## Weitere medikamentöse Behandlungsmöglichkeiten

Neben den JAKi gibt es unterschiedliche therapeutische Möglichkeiten respektive Alternativen für die verschiedenen Indikationsgebiete. Bei Personen mit einer rheumatischen JAKi-Indikation kam es über die Jahre 2013 bis 2023 zu verschiedenen Veränderungen (Abbildung 14A). Beispielsweise gingen die relativen Bezüge der JAKi zurück und die der Biologika stiegen. Dies geschah jedoch unabhängig von den herausgegebenen Warnungen. Der Anteil des Chemotherapeutikums Methotrexat folgte dagegen keinem klaren Trend. Die Nutzung der DMARDs im Verhältnis zu den Bezügen der anderen Gruppen blieb dagegen relativ stabil.

Im Bereich der gastrointestinalen Indikation zeigte sich, seit der Einführung von JAKi auf diesem Gebiet im Jahr 2019, ein Trend zu einem häufigeren Einsatz von Biologika bei einem gleichzeitigen Rückgang von Methotrexat (Abbildung 14B). Allerdings begann dieser Trend auch hier bereits vor der

[[Seite 66/102]]

Klassenwarnung. Bei den anderen betrachteten Medikamentengruppen zeigten sich keine deutlichen Effekte. Auch bei Patientinnen und Patienten mit JAKi-Gebrauch aufgrund dermatologischer Indikation scheinen Biologika seit der JAKi-Zulassung für dieses Indikationsgebiet im Jahr 2021 häufiger eingesetzt zu werden, während die Verwendung von topischen Steroiden abnahm (Abbildung 14C).

Einen deutlichen Effekt aufgrund der Klassenwarnung auf die Häufigkeit der Verwendung anderer medikamentöser Behandlungsmöglichkeiten in den drei betroffenen Indikationsgebieten scheint es eher nicht gegeben zu haben. Lediglich die Biologika werden häufiger verwendet, aber hierbei handelt es sich um eine Korrelation. Ob auch ein kausaler Zusammenhang besteht, also einen direkten Wechsel von den JAKi zu Biologika aufgrund der Sicherheitswarnungen, oder ob es nur einen anhaltenden allgemeinen Trend hin zu einer vermehrten Verwendung gab, ist aus dieser Analyse nicht ersichtlich.

**[Grafik 14] Abbildung 14: Verhältnis der Bezüge medikamentöser Behandlungsmöglichkeiten bei Personen mit mindestens einmaliger JAKi-Einnahme bei rheumatischer (A), gastrointestinaler (B) und dermatologischer Indikation (C), 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Drei horizontale 100%-Balkendiagramme. Y-Achse: Jahr; X-Achsen in Prozent, je Teilgrafik unten angegeben. Legendenfarben in Tabellenreihenfolge: beige, gelb, blau, orange, braun, violett, grün, bordeauxrot. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±0.5 Prozentpunkte. – bedeutet kein gesondert sichtbares Segment, nicht gesichert null. Die Summen der abgelesenen sichtbaren Segmente liegen aufgrund der Ablesung und Rundung zwischen 99.9% und 100.1%; die Werte wurden nicht auf 100% angepasst.

## (A) Rheumatisch

X-Achse: 0%, 10%, 20%, 30%, 40%, 50%, 60%, 70%, 80%, 90%, 100%.

| Jahr | Methotrexat | DMARDs | Biologika | Glukokortikoide | topische Steroide | topische Calcineurin-Inhibitoren | 5-Aminosalicylsäure | JAKi |
|---|---|---|---|---|---|---|---|---|
| 2023 | ca. 29.9% | ca. 8.6% | ca. 30.7% | – | – | – | – | ca. 30.7% |
| 2022 | ca. 31.2% | ca. 8.6% | ca. 28% | – | – | – | – | ca. 32.2% |
| 2021 | ca. 32.6% | ca. 8.8% | ca. 25.5% | – | – | – | – | ca. 33.1% |
| 2020 | ca. 30.9% | ca. 10% | ca. 26.3% | – | – | – | – | ca. 32.8% |
| 2019 | ca. 31.4% | ca. 9.1% | ca. 25.6% | – | – | – | – | ca. 33.9% |
| 2018 | ca. 34.9% | ca. 8.8% | ca. 24.5% | – | – | – | – | ca. 31.8% |
| 2017 | ca. 30.7% | ca. 9.7% | ca. 28% | – | – | – | – | ca. 31.5% |
| 2016 | ca. 26.6% | ca. 10.5% | ca. 26.4% | – | – | – | – | ca. 36.5% |
| 2015 | ca. 30.6% | ca. 11.3% | ca. 20.4% | – | – | – | – | ca. 37.7% |
| 2014 | ca. 30.1% | ca. 9.1% | ca. 12.4% | – | – | – | – | ca. 48.4% |
| 2013 | ca. 23.2% | ca. 11.8% | ca. 12.6% | – | – | – | – | ca. 52.4% |

## (B) Gastrointestinal

X-Achse: 0%, 10%, 20%, 30%, 40%, 50%, 60%, 70%, 80%, 90%, 100%.

| Jahr | Methotrexat | DMARDs | Biologika | Glukokortikoide | topische Steroide | topische Calcineurin-Inhibitoren | 5-Aminosalicylsäure | JAKi |
|---|---|---|---|---|---|---|---|---|
| 2023 | ca. 7% | – | ca. 20.5% | ca. 17.5% | – | – | ca. 19.6% | ca. 35.4% |
| 2022 | ca. 15.3% | – | ca. 11.3% | ca. 27.4% | – | – | ca. 16.6% | ca. 29.5% |
| 2021 | ca. 20.9% | – | ca. 3.5% | ca. 24% | – | – | ca. 11.1% | ca. 40.4% |
| 2020 | ca. 43% | – | – | ca. 29.6% | – | – | – | ca. 27.4% |

## (C) Dermatologisch

X-Achse: 0%, 10%, 20%, 30%, 40%, 50%, 60%, 70%, 80%, 90%, 100%.

| Jahr | Methotrexat | DMARDs | Biologika | Glukokortikoide | topische Steroide | topische Calcineurin-Inhibitoren | 5-Aminosalicylsäure | JAKi |
|---|---|---|---|---|---|---|---|---|
| 2023 | ca. 11.1% | – | ca. 17.7% | – | ca. 13.9% | ca. 8% | – | ca. 49.4% |
| 2022 | ca. 14.2% | – | ca. 10.5% | – | ca. 23.6% | ca. 4.3% | – | ca. 47.5% |
| 2021 | ca. 10% | – | ca. 12.3% | – | ca. 25.5% | ca. 1.8% | – | ca. 50.5% |

Abkürzungen: DMARDs = konventionelle Basistherapeutika (exkl. Methotrexat), JAKi = Januskinase-Inhibitoren.

**[Ende Grafik 14]**

[[Seite 67/102]]

## Therapieansprechen, Behandlungswechsel und Behandlungsabbrüche

Im Bereich der rheumatischen Erkrankungen, die mit Tofacitinib behandelt wurden, scheint es eine zeitliche Korrelation der jährlichen Abbruchrate zu den Warnungen gegeben zu haben (Abbildung 15). Zwischen den Jahren 2013 bis 2020 waren Abbrüche (bis auf einen kleineren Anstieg im Jahr2017) rückläufig und betrugen zu diesem Zeitpunkt nur noch etwa 4%. Ab der ersten umfassenderen DHPC im Jahr 2021 bezüglich eines erhöhten Risikos für schwerwiegende unerwünschte kardiovaskuläre Ereignisse und maligne Erkrankungen, auch bei einer geringeren Dosierung von Tofacitinib, steigerte sich die Abbruchrate auf 8%. Sie sank im Folgejahr ohne neue Warnung zurück auf 4%. Im darauffolgenden Jahr der Klassenwarnung, 2023, erreichte die Abbruchrate dann wieder 8%.

Der überwiegende Teil der Personen, deren Therapie umgestellt wurde, startete mit einem Biologikum. Während um das Jahr 2017 herum DMARDs noch vergleichsweise häufig bei einem Wechsel als Option gewählt wurden, sank deren Anteil in den Folgejahren. Ebenfalls sank der Anteil eines Therapiestarts mit Methotrexat zum Ende einer Tofacitinib-Behandlung.

Insgesamt betrachtet schien das Therapieansprechen (keine Therapiewechsel oder -abbrüche) unter Tofacitinib-Einnahme relativ gut zu sein, mit etwa 85% an Patientinnen und Patienten pro Jahr, die die Einnahme auch nach den erfolgten Warnungen fortsetzten. In Anbetracht dessen, dass relativ viele Personen auf Grundlage der uns zur Verfügung stehenden Daten zu einer der genannten Risikogruppen gehörten, sollte das Fortsetzen der Behandlung für jeden Einzelfall hinterfragt werden, um eventuelle Folgeschäden zu minimieren.

**[Grafik 15] Abbildung 15: Anteil an mit Tofacitinib (Xeljanz®)-behandelten Personen mit Behandlungsabbrüchen und solchen mit Start anderer medikamentöser Behandlungsmöglichkeiten im rheumatischen Bereich, 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Liniendiagramm, 2013–2023. Y-Achse 0%, 2%, 4%, 6%, 8%, 10%, 12%. Abbruch bordeauxrot, DMARDs gelb, Biologika blau, Methotrexat beige. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±0.5 Prozentpunkte. DMARDs im Jahr 2022 sind wegen der Überlagerung nahe der Nulllinie nicht eindeutig ablesbar. Die im Fliesstext für 2020–2023 genannten Abbruchraten 4%, 8%, 4% und 8% sind mit den abgelesenen Kurvenwerten innerhalb der Ablesegenauigkeit vereinbar.

| Jahr | Abbruch | DMARDs | Biologika | Methotrexat |
|---|---|---|---|---|
| 2013 | ca. 11.9% | ca. 3.6% | ca. 6.3% | ca. 0% |
| 2014 | ca. 8.3% | ca. 2.2% | ca. 4.6% | ca. 3.1% |
| 2015 | ca. 7.7% | ca. 3.9% | ca. 7.4% | ca. 1.1% |
| 2016 | ca. 6.9% | ca. 3.5% | ca. 8.8% | ca. 0.7% |
| 2017 | ca. 8.5% | ca. 3.4% | ca. 11.3% | ca. 2.1% |
| 2018 | ca. 8.3% | ca. 2.5% | ca. 5.5% | ca. 1.3% |
| 2019 | ca. 5.7% | ca. 1.6% | ca. 5.8% | ca. 0.9% |
| 2020 | ca. 4.2% | ca. 3% | ca. 8.2% | ca. 2% |
| 2021 | ca. 7.9% | ca. 2.5% | ca. 6.3% | ca. 1.7% |
| 2022 | ca. 4.5% | nicht eindeutig ablesbar | ca. 7.1% | ca. 0.3% |
| 2023 | ca. 7.8% | ca. 0.5% | ca. 7.6% | ca. 0.3% |

Abkürzungen: DMARDs = konventionelle Basistherapeutika (exklusive Methotrexat).

**[Ende Grafik 15]**

## Sicherheit

Insgesamt bezogen hochgerechnet knapp 10’000 Personen im Untersuchungszeitraum einen JAKi über eine Zeitdauer von mindestens einem halben Jahr für eine rheumatische Indikation. Diese Personen wurden mit einer etwa gleich grossen Gruppe mit rheumatischen Beschwerden und TNFi-Bezügen anstelle von JAKi verglichen. Bei einer medianen Nachbeobachtungszeit von etwa 3.0 Jahren waren

---

— Ende Teil 5 von 8 · Kontrollwort Teil 5: ALVIER-95 · weiter mit teil-06.md —
