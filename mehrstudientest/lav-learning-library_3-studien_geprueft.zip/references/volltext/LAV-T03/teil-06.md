# LAV-T03 · Volltext · Teil 6 von 8 (PDF-Seiten 68–79 von 102)

Studie: Helsana-Report: Arzneimittel – Medikamente erstmals grösster Kostenblock der Grundversicherung · Quelldatei: arzneimittelreport-2024-31e5177c.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 8 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T03, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 68/102]]

die Inzidenzen für ein kritisches Ereignis bei den Personen mit JAKi-Bezügen höher (3.5 pro 100 Personenjahre [1’899 Personen]) als bei Personen mit TNFi-Bezügen (2.5 pro 100 Personenjahre [941 Personen]). Dies bedeutet, dass Personen, die JAKi einnahmen, ein höheres Risiko für ein kritisches Ereignis wie kardiovaskuläre Komplikationen oder schwerwiegende Nebenwirkungen aufwiesen als jene, die mit TNFi behandelt wurden. Des Weiteren betrugen die Gefährdungsquotienten (Hazard Ratios) für ein kritisches Ereignis allgemein 1.60 (95% Konfidenzintervall: 1.29-1.99), 1.88 (1.40-2.52) für Mortalität, 1.65 (1.06-2.57) für schwerwiegende Infektionen, 1.35 (1.02-1.79) für schwerwiegende kardiovaskuläre Ereignisse, und 1.93 (0.96-3.86) für schwere thrombotische Ereignisse. Diese Ereignisse waren also bei den Personen mit JAKi-Nutzung etwa 60% häufiger als bei Personen ohne Nutzung.

Die Ergebnisse ähneln stark den Resultaten früherer Studien [34] und scheinen die erhöhten Risiken für die genannten Ereignisse auch für den Schweizer Kontext zu bestätigen. Allerdings beruht die vorliegende Auswertung nicht auf exakten klinischen Diagnosen für eine rheumatische Erkrankung, sondern lediglich auf einer Abschätzung des Indikationsgebietes aufgrund verschiedener Faktoren. Ausserdem wurden die Personen mit kritischen Ereignissen ebenfalls nur mithilfe der vorhandenen Daten abgeschätzt und es wurden lediglich Alter, Geschlecht und Wohnkanton als Kontrollvariablen einbezogen. Dies könnte die Effekte über- oder unterschätzt haben.

## Kosten

Die Gesamtkosten für JAKi stiegen im Zeitraum von 2013 bis 2023 stetig an und lagen bei etwa CHF 122 Millionen im Jahr 2023 (Abbildung 16). Dies ist vor allem auf die häufigere Verwendung der JAKi zurückzuführen, denn die jährlichen Pro-Kopf-Kosten waren in den letzten Jahren eher rückläufig. Im Jahr 2023 kostete die Verwendung rund CHF 12’100 pro Person, im Gegensatz zu über CHF 19’400 im Jahr 2016. Dieser Rückgang ist insbesondere auf Preissenkungen bei Tofacitinib in den Jahren 2018, 2019 und 2023 zurückzuführen und auf eine vermehrte Verwendung des im Vergleich zu Tofacitinib kostengünstigeren Upadacitinib. Der mit abgerechneten jährlichen Pro-Kopf-Kosten von CHF 32’300 teuerste JAKi im Jahr 2023 war Ruxolitinib, gefolgt von Fedratinib mit CHF 16’900. Die Pro-Kopf-Kosten der anderen JAKi lagen dagegen bei unter CHF 10’000.

**[Grafik 16] Abbildung 16: Medikamentöse Gesamtkosten der JAKi-Nutzenden über alle Indikationsgebiete, 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Gestapeltes Flächendiagramm, 2013–2023. Y-Achse: Kosten (in Mio CHF), 0, 50, 100, 150, 200. Segmentwerte, keine kumulierten Oberkanten. Farben in Legendenreihenfolge: bordeauxrot, beige, grau, grün, orange, violett, rot. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±3 Mio CHF je Segment. Sehr kleine oder nicht getrennt sichtbare Segmente sind mit – gekennzeichnet und nicht als null interpretiert. Die Summe der abgelesenen JAKi-Segmente 2023 ist mit etwa CHF 122 Millionen im Fliesstext innerhalb der Ablesegenauigkeit vereinbar. Die oberste rote Fläche enthält zusätzlich weitere Behandlungen und gehört nicht zu den reinen JAKi-Kosten.

| Jahr | Tofacitinib (Xeljanz®) | Ruxolitinib (Jakavi®) | Baricitinib (Olumiant®) | Upadacitinib (Rinvoq®) | Fedratinib (Inrebic®) | Abrocitinib (Cibinqo®) | Weitere Behandlungen |
|---|---|---|---|---|---|---|---|
| 2013 | – | – | – | – | – | – | – |
| 2014 | ca. 10 | ca. 9 | – | – | – | – | ca. 4 |
| 2015 | ca. 17 | ca. 14 | – | – | – | – | ca. 6 |
| 2016 | ca. 27 | ca. 23 | – | – | – | – | ca. 9 |
| 2017 | ca. 37 | ca. 23 | – | – | – | – | ca. 14 |
| 2018 | ca. 30 | ca. 27 | ca. 14 | – | – | – | ca. 17 |
| 2019 | ca. 28 | ca. 31 | ca. 20 | – | – | – | ca. 20 |
| 2020 | ca. 28 | ca. 35 | ca. 23 | ca. 3 | – | – | ca. 23 |
| 2021 | ca. 27 | ca. 35 | ca. 23 | ca. 17 | – | – | ca. 31 |
| 2022 | ca. 20 | ca. 37 | ca. 23 | ca. 33 | – | – | ca. 35 |
| 2023 | ca. 16 | ca. 43 | ca. 21 | ca. 41 | – | – | ca. 43 |

**[Ende Grafik 16]**

[[Seite 69/102]]

Die Kosten für alle weiteren medikamentösen Behandlungen bei Patienten und Patientinnen mit mindestens einem JAKi-Bezug im jeweiligen Jahr stiegen parallel zu den JAKi-Kosten an und summierten sich auf gut CHF 42 Millionen im Jahr 2023. Dies entsprach Pro-Kopf-Kosten von etwa CHF 4’200. Die jährlichen Gesamtkosten pro Person mit JAKi-Bezügen summierten sich dadurch auf CHF 16’300. Im Vergleich dazu kostete eine Person ohne JAKi-Bezüge im Jahr 2023 (aber mit JAKi-Bezügen in früheren Jahren) «nur» CHF 10’300 und verursachte somit CHF 6’000 (37%) weniger Kosten. Allerdings sind JAKi oral verfügbare Medikamente und können von den Patientinnen und Patienten allein eingenommen werden. Im Gegensatz dazu müssen beispielsweise einige Biologika als Infusionen oder Injektionen verabreicht werden und werden daher manchmal in medizinischen Einrichtungen oder Arztpraxen abgegeben, falls die Patientinnen und Patienten sich nicht selbst injizieren können. Diese zusätzlichen Verabreichungskosten sind in den hier aufgeführten reinen Medikamentenkosten nicht inkludiert.

**[Grafik 17] Abbildung 17: Gesamtkosten der JAKi und weiteren medikamentösen Behandlungen im rheumatologischen Bereich für Personen mindestens einem JAKi-Bezug im jeweiligen Jahr (A) und ohne jemalige JAKi-Bezüge (B), 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Zwei gestapelte Flächendiagramme, 2013–2023. Y-Achse: Kosten (in Mio CHF). Panel A: 0, 20, 40, 60, 80, 100, 120, 140, 160. Panel B: 0, 100, 200, 300, 400, 500, 600. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±3 Mio CHF je Segment in A und ±6 Mio CHF je Segment in B. Segmentwerte, keine kumulierten Oberkanten. – bedeutet kein getrennt sichtbares Segment, nicht gesichert null. Farben A in Legendenreihenfolge: bordeauxrot, grau, grün, gelb, beige, blau, rot; B: gelb, beige, blau, rot. Die im fortgesetzten Fliesstext auf Seite 70 genannten CHF 39 Millionen für Upadacitinib 2023 und CHF 526 Millionen Gesamtkosten in B 2023 sind innerhalb der Ablesegenauigkeit mit der Grafik vereinbar.

## (A)

| Jahr | Tofacitinib (Xeljanz®) | Baricitinib (Olumiant®) | Upadacitinib (Rinvoq®) | DMARDs | Methotrexat | Biologika | Sonstige |
|---|---|---|---|---|---|---|---|
| 2013 | – | – | – | – | – | ca. 2 | – |
| 2014 | ca. 9 | – | – | – | – | ca. 3 | ca. 1 |
| 2015 | ca. 17 | – | – | – | ca. 1 | ca. 4 | ca. 3 |
| 2016 | ca. 27 | – | – | ca. 1 | – | ca. 9 | ca. 4 |
| 2017 | ca. 37 | – | – | ca. 1 | ca. 1 | ca. 15 | ca. 7 |
| 2018 | ca. 30 | ca. 12 | – | ca. 1 | ca. 2 | ca. 16 | ca. 9 |
| 2019 | ca. 29 | ca. 19 | ca. 1 | – | ca. 2 | ca. 20 | ca. 11 |
| 2020 | ca. 28 | ca. 21 | ca. 3 | ca. 1 | ca. 2 | ca. 27 | ca. 15 |
| 2021 | ca. 25 | ca. 22 | ca. 16 | ca. 1 | ca. 2 | ca. 31 | ca. 19 |
| 2022 | ca. 17 | ca. 20 | ca. 31 | ca. 1 | ca. 3 | ca. 38 | ca. 23 |
| 2023 | ca. 13 | ca. 19 | ca. 38 | ca. 1 | ca. 3 | ca. 48 | ca. 26 |

## (B)

| Jahr | DMARDs | Methotrexat | Biologika | Sonstige |
|---|---|---|---|---|
| 2013 | – | ca. 4 | ca. 184 | ca. 22 |
| 2014 | – | ca. 6 | ca. 204 | ca. 34 |
| 2015 | – | ca. 6 | ca. 224 | ca. 46 |
| 2016 | – | ca. 6 | ca. 266 | ca. 60 |
| 2017 | ca. 4 | ca. 4 | ca. 304 | ca. 76 |
| 2018 | – | ca. 6 | ca. 296 | ca. 88 |
| 2019 | – | ca. 6 | ca. 294 | ca. 96 |
| 2020 | – | ca. 6 | ca. 290 | ca. 104 |
| 2021 | – | ca. 6 | ca. 296 | ca. 116 |
| 2022 | – | ca. 6 | ca. 324 | ca. 128 |
| 2023 | – | ca. 6 | ca. 366 | ca. 150 |

**[Ende Grafik 17]**

Im rheumatologischen Bereich waren die Gesamtkosten bei JAKi-Nutzenden im jeweiligen Jahr im Vergleich zu den anderen Indikationsbereichen am höchsten. Ursprünglich machte Tofacitinib den grössten Teil der Gesamtkosten in diesem Bereich aus, verlor aber seit 2017 stetig an Bedeutung

[[Seite 70/102]]

(Abbildung 17A). Im Jahr 2023 waren die Kosten von CHF 39 Millionen für Upadacitinib auffällig. Das Verhältnis der Kosten der JAKi im Vergleich zu den weiteren Medikamenten von JAKi-Nutzenden (mindestens ein Bezug zwischen 2012 und 2023) war über den Untersuchungszeitraum rückläufig. Betrug es vor dem Jahr 2015 noch über 3:1, sank es bis zum Jahr 2023 auf etwa 1:1 ab. Bei Personen mit einer rheumatischen Indikation, welche nie ein JAKi bezogen haben, stiegen die Gesamtkosten zwischen 2013 und 2023 von fast CHF 215 Millionen auf CHF 526 Millionen an (Abbildung 17B). Dies insbesondere aufgrund ansteigender Kosten für Biologika, aber auch wegen der Kosten der sonstigen Medikamente. Die Pro-Kopf-Kosten zwischen den beiden Personengruppen lagen für Biologika höher bei Personen mit rheumatologischen Beschwerden aber ohne jemalige JAKi-Bezüge als bei JAKi-Nutzenden, während sie für DMARs, Methotrexat und sonstige Medikamente vergleichbar waren (Abbildung 18A und Abbildung 18B). Die durchschnittlichen Pro-Kopf-Gesamtkosten waren für Personen mit mindestens einem JAKi-Bezug im jeweiligen Jahr zumeist etwa CHF 2’000 höher als bei Personen ohne JAKi-Bezüge und betrugen im Jahr 2023 CHF 13’000 für JAKi-Nutzende und CHF 11’200 für Personen ohne jemalige JAKi-Bezüge.

**[Grafik 18] Abbildung 18: Jährliche Pro-Kopf-Kosten der JAKi und weiteren medikamentösen Behandlungen im rheumatologischen Bereich zwischen Personen mit mindestens einem JAKi-Bezug im jeweiligen Jahr (A) und ohne jemalige JAKi-Bezüge (B), 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Zwei Liniendiagramme, 2013–2023. Y-Achse jeweils Pro-Kopf-Kosten (in CHF): – (Nulllinie), 2’000, 4’000, 6’000, 8’000, 10’000, 12’000, 14’000, 16’000, 18’000. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±250 CHF. Die Gesamtwerte 2023 von CHF 13’000 und CHF 11’200 sind dem Fliesstext derselben Seite entnommen und stimmen innerhalb der Ablesegenauigkeit mit den Kurven überein. Panel A: Tofacitinib dunkelrot, Baricitinib gelb, Upadacitinib grün, DMARDs gelb, Methotrexat beige, Biologika orange, Sonstige rot, Gesamt schwarz. Panel B: DMARDs gelb, Methotrexat beige, Biologika orange, Sonstige rot, Gesamt schwarz. DMARDs und Baricitinib verwenden in A dieselbe gelbe Farbe; die obere gelbe Kurve ab 2018 ist Baricitinib zugeordnet. Nahe der Nulllinie überlagerte oder nicht trennbare Kurven sind nicht eindeutig ablesbar; daraus werden keine Nullwerte abgeleitet.

## (A)

| Jahr | Tofacitinib (Xeljanz®) | Baricitinib (Olumiant®) | Upadacitinib (Rinvoq®) | DMARDs | Methotrexat | Biologika | Sonstige | Gesamt |
|---|---|---|---|---|---|---|---|---|
| 2013 | ca. 4400 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 900 | ca. 500 | ca. 5700 |
| 2014 | ca. 12500 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 200 | ca. 1900 | ca. 1500 | ca. 15800 |
| 2015 | ca. 11500 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 200 | ca. 2700 | ca. 1700 | ca. 16000 |
| 2016 | ca. 12000 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 200 | ca. 3300 | ca. 1900 | ca. 17400 |
| 2017 | ca. 11200 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 300 | ca. 4300 | ca. 2200 | ca. 17900 |
| 2018 | ca. 6800 | ca. 2900 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 300 | ca. 3600 | ca. 2000 | ca. 15300 |
| 2019 | ca. 5100 | ca. 3600 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | ca. 200 | ca. 3400 | ca. 2000 | ca. 13900 |
| 2020 | ca. 4100 | ca. 3200 | ca. 500 | nicht eindeutig ablesbar | ca. 200 | ca. 3800 | ca. 2200 | ca. 13500 |
| 2021 | ca. 3000 | ca. 2600 | ca. 1900 | nicht eindeutig ablesbar | ca. 200 | ca. 3500 | ca. 2200 | ca. 13100 |
| 2022 | ca. 1800 | ca. 2000 | ca. 3200 | nicht eindeutig ablesbar | ca. 200 | ca. 3800 | ca. 2300 | ca. 13100 |
| 2023 | ca. 1300 | ca. 1800 | ca. 3500 | nicht eindeutig ablesbar | ca. 300 | ca. 4300 | ca. 2400 | 13’000 (Fliesstext) |

## (B)

| Jahr | DMARDs | Methotrexat | Biologika | Sonstige | Gesamt |
|---|---|---|---|---|---|
| 2013 | nicht eindeutig ablesbar | ca. 300 | ca. 13800 | ca. 1800 | ca. 15900 |
| 2014 | nicht eindeutig ablesbar | ca. 300 | ca. 12200 | ca. 2000 | ca. 14500 |
| 2015 | nicht eindeutig ablesbar | ca. 300 | ca. 11500 | ca. 2400 | ca. 14300 |
| 2016 | nicht eindeutig ablesbar | ca. 300 | ca. 11200 | ca. 2600 | ca. 14200 |
| 2017 | nicht eindeutig ablesbar | ca. 200 | ca. 10900 | ca. 2800 | ca. 14000 |
| 2018 | nicht eindeutig ablesbar | ca. 200 | ca. 9800 | ca. 2900 | ca. 12900 |
| 2019 | nicht eindeutig ablesbar | ca. 200 | ca. 9000 | ca. 3000 | ca. 12100 |
| 2020 | nicht eindeutig ablesbar | ca. 200 | ca. 8500 | ca. 3000 | ca. 11700 |
| 2021 | nicht eindeutig ablesbar | ca. 200 | ca. 8100 | ca. 3100 | ca. 11500 |
| 2022 | nicht eindeutig ablesbar | ca. 200 | ca. 8100 | ca. 3200 | ca. 11500 |
| 2023 | nicht eindeutig ablesbar | ca. 200 | ca. 7800 | ca. 3200 | 11’200 (Fliesstext) |

**[Ende Grafik 18]**

[[Seite 71/102]]

## In Entwicklung befindliche Medikamente

Derzeit befinden sich mehrere JAKi in verschiedenen Stadien der Medikamentenentwicklung. Die Herausforderung bei der Entwicklung von JAKi liegt in der langfristigen Sicherheitsbewertung. Die Hemmung von JAK2 soll aufgrund der damit verbundenen Nebenwirkungen, wie Blutbildveränderungen und thromboembolischen Ereignissen, eher vermieden werden. Die Entwicklung selektiver JAKi steht daher im Fokus der aktuellen Forschung, insbesondere die gezielte Hemmung von JAK1 und Tyrosinkinase 2. Diese Selektivität ist entscheidend, um das Nebenwirkungsprofil zu verbessern und gleichzeitig eine effektive Unterbrechung entzündlicher Signalwege zu gewährleisten [48]. Ein Beispiel hierfür ist der Wirkstoff Brepocitinib, der zur Behandlung von Psoriasis, atopischer Dermatitis und anderen entzündlichen Erkrankungen getestet wird [49,50]. Weitere Kandidaten sind Itacitinib und Deucravacitinib. Itacitinib zielt spezifisch auf JAK1 ab und wird zur Behandlung von Graft-versus-Host-Disease sowie anderen Erkrankungen untersucht [51]. Deucravacitinib konzentriert sich auf die selektive Hemmung von Tyrosinkinase 2 und wird zur Behandlung von Psoriasis getestet [52]. Seine Selektivität für Tyrosinkinase 2 könnte zu einem günstigeren Nebenwirkungsprofil im Vergleich zu weniger selektiven JAKi führen.

## 4.1.4 Fazit

Das stetig wachsende Indikationsspektrum der JAKi zeigt ihr Innovationspotenzial und die breite pharmakologische Anwendbarkeit. Die orale Einnahme ist ein Vorteil gegenüber den Biologika. Nachteilig sind die hohen Kosten und teilweise schweren Nebenwirkungen, die international zu Sicherheitswarnungen führten. Zwar sind die JAKi-Preise im Verlauf der Zeit gesunken, dennoch bleiben die direkten Kosten für die Medikamente hoch. In Kombination mit den erst im Verlauf der Anwendung bekanntgewordenen Kosten aufgrund von zusätzlich nötigen Kontrolluntersuchungen und unerwünschten Nebenwirkungen beeinflussen diese Faktoren die ursprüngliche Wirtschaftlichkeitsbeurteilung und erfordern eine sorgfältige Ressourcenallokation.

Die Ergebnisse legen nahe, dass sich die Risiken bezüglich schwerwiegender Ereignisse auch mit den Abrechnungsdaten für die Schweiz nachweisen lassen. In zeitlichem Zusammenhang mit den Sicherheitswarnungen, die hierzulande vier der insgesamt sechs derzeit verfügbaren JAKi betreffen, sowie mit geänderten klinischen Leitlinien, zeigten sich Änderungen der Verschreibungsmuster, wobei ein Kausalzusammenhang nicht belegbar ist. Insbesondere gingen die Bezüge von Tofacitinib zurück, während Biologika häufiger verwendet wurden. Die beobachteten Änderungen im Verschreibungsmuster betrafen Personen mit Risikofaktoren nur im leichten Ausmass. Trotz der Klassenwarnung 2023 wurde Upadacitinib weiterhin vergleichsweise häufig verschrieben, was möglicherweise auf begrenzte therapeutische Behandlungsmöglichkeiten bei den betreffenden Patientinnen und Patienten hinweist.

Die Sicherheitsprobleme beeinträchtigen jedoch die Benefit-Harm-Balance der JAKi für die Patientinnen und Patienten, die einer Risikogruppe angehören, deutlich. Eine sorgfältige Risikobewertung ist wichtig, um die Sicherheit der Patientinnen und Patienten zu gewährleisten, und bestmögliche Behandlungsentscheidungen zu treffen.

Strukturelle Optimierungen bei neueren JAKi könnten die Selektivität der JAK-Hemmung erhöhen und damit zu weniger schwerwiegenden Effekten führen. Daher und aufgrund der begrenzten therapeutischen Alternativen erscheint es plausibel, dass JAKi trotz der momentanen

[[Seite 72/102]]

Sicherheitsbedenken weiterhin eine wichtige Rolle in der Behandlung verschiedener Erkrankungen spielen werden.

Die Kostenanalyse zeigte, dass zumindest im rheumatologischen Bereich JAKi-Nutzende im Vergleich zu Personen ohne jemalige JAKi-Bezüge etwas höhere Pro-Kopf-Kosten für die medikamentöse Behandlung verursachen. Die Auswirkungen potenziell gravierender Nebenwirkungen und die zusätzliche Überwachung der behandelten Patientinnen und Patienten könnte jedoch zu erhöhten Folgekosten führen, die die Wirtschaftlichkeit der JAKi beeinträchtigen und eine sorgfältige Ressourcenallokation erfordern. Detaillierte Kosten-Effektivitätsanalysen für die einzelnen Wirkstoffe waren im Rahmen dieses Reports jedoch nicht durchführbar. Sie sollten aber dringend durchgeführt werden, um die langfristigen finanziellen Auswirkungen der Therapien vollumfänglich bewerten zu können und die Marktpreise gegebenenfalls nach unten zu korrigieren.

[[Seite 73/102]]

## 4.2 Zielgerichtete Therapien und Immuntherapien beim Lungenkrebs

**[Kernaussagen]**

- Die Behandlung von Lungenkrebs hat sich seit der Einführung der sogenannten zielgerichteten Therapien und Immuntherapien stark gewandelt. Mittlerweile sind mehr zielgerichtete Therapien und Immuntherapien zugelassen als klassische Chemotherapien.

- Im Jahr 2016 erhielten 81% der Personen mit Lungenkrebs eine Chemotherapie und 13% eine zielgerichtete Therapie als erste medikamentöse Behandlung, während Immuntherapien in der ersten Therapielinie praktisch nicht vertreten waren. Sie kamen erst in der zweiten Linie nach Behandlung mit einer Chemotherapie vor, was der damaligen Zulassung entsprach. Etwa 50% der Personen mit einer weiteren Therapie erhielten eine Immuntherapie.

- Im Jahr 2021 bekam noch knapp die Hälfte der Personen mit Lungenkrebs (50%) als erste medikamentöse Behandlung eine Chemotherapie. In der ersten Linie kam jetzt auch die Immuntherapie als Monotherapie (12%) und in Kombination mit Chemotherapie (23%) zum Einsatz, welche mittlerweile auch als Erstlinientherapie zugelassen war. Zielgerichtete Therapien in der ersten Therapielinie erhielten - wie im Jahr 2016 - etwa 13% der Personen.

- Die deutlich höheren Preise für zielgerichtete Therapien und Immuntherapien spiegeln sich in hohen Gesamtkosten für Onkologika bei Lungenkrebs wider. Die Kosten stiegen von CHF 63 Millionen im Jahr 2013 auf CHF 146 Millionen in 2023 (+169%). Der Kostenzuwachs basierte zu grossen Teilen auf der Einführung der Immuntherapien.

- Im Jahr 2023 lagen die Gesamtkosten der Chemotherapeutika bei CHF 12.6 Millionen, der zielgerichteten Therapien bei CHF 52 Millionen und der Immuntherapien bei CHF 81 Millionen.

- Die Frage, ob die hohen Kosten für das öffentliche Gesundheitssystem durch die Überlebensvorteile der neuen Therapien gerechtfertigt sind und ob diese Therapien tatsächlich kosteneffizient sind, bleibt weiterhin offen.

**[Ende Kernaussagen]**

[Hinweis Transkription: Die Originalangaben CHF 63 Millionen (2013), CHF 146 Millionen (2023) und +169% sind rechnerisch nicht miteinander vereinbar. Alle drei Angaben wurden unverändert übernommen.]

## 4.2.1 Einleitung

Lungenkrebs ist ein bösartiger Tumor, der sich in der Lunge oder den Atemwegen entwickelt. Dies bedeutet ein unkontrolliertes Wachstum abnormaler Zellen, welche sich auch auf andere Teile des Körpers ausbreiten können. Es gibt zwei Haupttypen: das kleinzellige Bronchialkarzinom (small cell lung cancer, SCLC) und das nicht-kleinzellige Bronchialkarzinom (non-small cell lung cancer, NSCLC). Kleinzellige Neubildungen sind sehr aggressiv und breiten sich sehr schnell aus, machen jedoch nur etwa 10-15% aller Lungenkrebsfälle aus. Beim nicht-kleinzelligen Bronchialkarzinom sind Adenokarzinome gefolgt von Plattenepithelkarzinomen die grössten Untergruppen. Häufig kommen auch Veränderungen (Mutationen) im Erbgut vor, welche das Wachstum des Tumors antreiben. Besonders hervorzuheben sind hier die Mutationen des Epidermalen Wachstumsfaktor-Rezeptors (EGFR), des Kirsten Rat Sarcoma Viral Oncogene (KRAS) und der Anaplastic Lymphoma Kinase (ALK).

Lungenkrebs ist mit einem Anteil von 11.9% aller Krebserkrankungen bei Männern und 9.3% bei Frauen in der Schweiz eine der häufigsten Krebsarten. Er ist bei Männern die zweithäufigste (nach Prostatakrebs) und bei Frauen die dritthäufigste (nach Brust- und Dickdarmkrebs) diagnostizierte Krebsart. Das Risiko, im Leben an Lungenkrebs zu erkranken, beträgt 5.9% für Männer und 3.7% für

[[Seite 74/102]]

Frauen [53]. Bei den Todesursachen liegt Lungenkrebs bei den Männern mit 21.3% aller Krebstodesfälle auf dem ersten Platz und bei den Frauen mit 16.2% auf dem zweiten Platz (nach Brustkrebs). Rauchen ist dabei ein zentraler Risikofaktor. Menschen, die nicht rauchen, können ebenfalls an Lungenkrebs erkranken, wenn auch weit seltener.

Die Behandlung von Lungenkrebs hat sich in den letzten 20 Jahren seit der Einführung der sogenannten zielgerichteten Therapien und Immuntherapien stark gewandelt. Im Jahr 2004, kurz nach der Zulassung durch die US-amerikanische Arzneimittelbehörde, wurde die erste zielgerichtete Therapie für Lungenkrebs in der Schweiz zugelassen. Es handelte sich um Iressa® (Gefitinib), einen EGFR-Tyrosinkinase-Inhibitor (TKI), der auf Tumore mit EGFR-Mutationen abzielt. Im Jahr 2016 folgte mit Opdivo® (Nivolumab), einem Checkpoint-Inhibitor, der auf das PD-1-Protein abzielt, die Zulassung der ersten Immuntherapie für das Lungenkarzinom in der Schweiz. Seitdem sind weitere zielgerichtete Therapien und Immuntherapien hinzugekommen. Die zielgerichteten Therapien beim Lungenkrebs konzentrieren sich hauptsächlich auf die bereits erwähnten Mutationen EGFR oder ALK, während bei den Immuntherapien, die bereits angesprochenen Checkpoint-Inhibitoren zum Einsatz kommen.

Klassische onkologische Chemotherapien (Zytostatika) greifen alle sich teilenden Zellen an. Ihre Wirksamkeit beruht darauf, dass Krebszellen sich in der Regel rasch teilen und dann vernichtet werden. Die Wirkung ist jedoch nicht spezifisch. Es werden sowohl entartete als auch gesunde Zellen vernichtet, was zu einer Reihe von Nebenwirkungen führen kann, unter anderem zu Haarausfall, Übelkeit oder erhöhter Infektionsanfälligkeit. Während eine Chemotherapie also wirksam sein kann, um Krebszellen abzutöten, führt ihre mangelnde Spezifität oft zu erheblicher Toxizität und unterschiedlicher Wirkung bei einzelnen Patientinnen und Patienten.

Im Gegensatz dazu stellen zielgerichtete Therapien einen Paradigmenwechsel in der Onkologie dar, indem sie von einem allgemeinen zu einem individuelleren Behandlungsansatz übergehen. Dies sind Behandlungen, die spezifisch auf genetische Mutationen oder abnorme Moleküle in Krebszellen abzielen, um deren Wachstum zu stoppen und gleichzeitig gesunde Zellen zu schonen. Dabei werden bestimmte Moleküle oder Signalwege blockiert, die für das Überleben der Krebszellen entscheidend sind. Diese Therapien werden auf der Grundlage der genetischen Beschaffenheit des Tumors ausgewählt. Diese Präzision kann das Auftreten von Nebenwirkungen reduzieren, die typischerweise mit der klassischen Chemotherapie verbunden sind, und dabei die Lebensqualität und das Überleben der Betroffenen verbessern.

Immuntherapien stellen einen weiteren innovativen Ansatz dar, der sich sowohl von dem der Chemotherapien als auch von dem der zielgerichteten Therapien unterscheidet. Immuntherapien wirken, indem sie das Immunsystem des Körpers dazu anregen, Krebszellen zu erkennen und anzugreifen. Hauptsächlich werden Immun-Checkpoint-Inhibitoren verwendet, welche Proteine blockieren, die das Immunsystem daran hindern, den Krebs anzugreifen. Durch die Blockierung dieses Weges ermöglichen es diese Medikamente dem Immunsystem, stärker auf die Krebszellen zu reagieren, was bei einigen Patientinnen und Patienten zu dauerhaften Remissionen und langfristigen Überlebensvorteilen führt. Allerdings sprechen nicht alle Betroffenen auf Immuntherapie an und sie kann auch zu spezifischen Nebenwirkungen führen.

[[Seite 75/102]]

Auch wenn das Überleben mit Lungenkrebs deutlich gesteigert werden konnte, wird bei den neuen Krebstherapien der ökonomische Aspekt häufig thematisiert. Neue teure Krebsmedikamente sind mit für den starken Anstieg der Medikamentenkosten in den letzten Jahren verantwortlich [54]. Die hohen Kosten für das Gesundheitssystem und die steigenden Prämien in der Grundversicherung im Speziellen sind seit Jahren ein dominantes Thema in den Schweizer Medien.

Zusätzlich als kritisch angesehen werden geheime Preisabsprachen zwischen Zulassungsinhaberinnen und den für die Vergütungsentscheide verantwortlichen Behörden in der Schweiz und international. Auch Neuzulassungen mit speziell hohen Preisforderungen sind von geheimen Absprachen betroffen und die resultierenden Preise stehen möglicherweise nicht immer in einem angemessenen Verhältnis zum therapeutischen Nutzen. Hierbei scheint es sogar eine «Krebsprämie» in verschiedenen Ländern – einschliesslich der Schweiz – zu geben [55], also einen Aufpreis für neu zugelassene Onkologika im Vergleich zu anderen neu zugelassenen Medikamenten.

Onkologika wurden zuletzt detailliert im Helsana-Arzneimittelreport 2016 analysiert. Die Untersuchung zeigt den verstärkten Fokus auf personalisierte Therapieansätze und Immuntherapien mithilfe der Abrechnungsdaten der Helsana beispielhaft für den Lungenkrebs auf.

## 4.2.2 Methoden

## Allgemein

Die Analysen zur Entwicklung der zielgerichteten Therapien und Immuntherapien beim Lungenkrebs in der Schweiz berücksichtigen die Jahre 2012 bis 2023. Um valide Aussagen über die gesamte Schweizer Bevölkerung zu treffen, wurden die Daten mittels entsprechender Korrekturfaktoren auf die Gesamtpopulation der Schweiz hochgerechnet, um die Unterschiede in der Altersstruktur und dem Geschlechterverhältnis im Wohnkanton auszugleichen.

## Identifikation von Personen mit Lungenkrebs

Neu an Lungenkrebs erkrankte Personen wurden approximativ identifiziert, da die Abrechnungsdaten der Helsana keine Diagnosen beinhalten.

Eingeschlossen wurden dabei Personen,

- a) welche wegen Lungenkrebs hospitalisiert wurden (ICD-10-Codes C33 und C34), oder

- b) welche Lungenkrebs-spezifische Medikamente einnahmen (laut Arzneimittelkompendium und Spezialitätenliste, Stand Dezember 2023), oder

- c) welche unspezifische für Lungenkrebs zugelassene Medikamente (laut Arzneimittelkompendium und Spezialitätenliste, Stand Dezember 2023) einnahmen, sofern sie Pneumologen häufiger besuchten als andere Spezialisten (nicht Onkologie) und nicht aufgrund von e) ausgeschlossen werden konnten, oder

- d) bei denen bestimmte diagnostische Massnahmen an Lunge und Bronchus abgerechnet wurden (Thorax-MRI oder CT) und welche zugleich häufige Spezialistenbesuche hatten, die auf Lungenkrebs hinwiesen (Onkologie und Pneumologie) und häufige Bezüge von Medikamenten, die laut dem ATC-Klassifikationssystem zur Behandlung von obstruktiven Atemwegserkrankungen und Hustenerkrankungen verwendet werden, hatten (R03 und R05) und nicht aufgrund von e) und f) ausgeschlossen werden konnten.

[[Seite 76/102]]

Ausgeschlossen wurden Personen,

- e) welche bei Einschlusskriterien c) und d) spezifische Medikamente für andere häufige Krebsarten (Brust, Prostata, Darm) einnahmen oder

- f) wenn bei Einschlusskriterium d) nach diagnostischen Tests keine weiteren Behandlungen erfolgten (Tumorboard, Arztbesuche, Bestrahlung).

Zu den Schätzungen der Inzidenz der Nationalen Krebsregistrierungsstelle ergaben sich mit den gewählten Identifikationskriterien keine massgeblichen Abweichungen, respektive diese bewegten sich in einem akzeptablen Rahmen (Tabelle 26 im Anhang).

## Prävalenz und Inzidenz von Lungenkrebs

Die Inzidenz weist die Neuerkranktenzahl pro Jahr aus. Bei der Prävalenz handelt es sich im Folgenden um die Summe der inzidenten Fälle aus den Vorjahren, die nicht verstorben waren. Es handelt sich dabei also um eine rein statistische Kennzahl. Beide Kennzahlen (Inzidenz und Prävalenz) konnten wir auch für Personen ausweisen, welche im entsprechenden Jahr mit Onkologika behandelt wurden.

Tabelle 22 zeigt die geschätzte Inzidenz und Prävalenz. Die Inzidenz (mit Onkologika) stellt dabei alle Neuerkrankten, welche auch medikamentös behandelt wurden, dar. Die Prävalenz (mit Onkologika) enthält dabei auch noch erkrankte Personen aus Vorjahren, deren Behandlung noch anhält oder welche wieder behandelt wurden. Die in der Tabelle präsentierten Zahlen stellen die Grundlage aller Berechnungen in diesem Kapitel dar.

| Jahr | Prävalenz* | Prävalenz (mit Onkologika)* | Inzidenz | Inzidenz (mit Onkologika) |
|---|---|---|---|---|
| 2012 | 6’889 | 6’443 | 6’889 | 6’443 |
| 2013 | 9’899 | 6’456 | 4’662 | 3’700 |
| 2014 | 11’919 | 6’369 | 4’859 | 3’417 |
| 2015 | 13’676 | 6’470 | 4’844 | 3’621 |
| 2016 | 15’226 | 6’642 | 4’724 | 3’492 |
| 2017 | 16’904 | 7’013 | 4’902 | 3’508 |
| 2018 | 17’905 | 6’936 | 4’652 | 3’318 |
| 2019 | 18’737 | 7’065 | 4’470 | 3’191 |
| 2020 | 19’909 | 7’547 | 4’869 | 3’452 |
| 2021 | 21’413 | 8’259 | 4’940 | 3’513 |
| 2022 | 21’905 | 8’047 | 4’413 | 3’134 |
| 2023 | 18’415 | 7’576 | 4’165 | 3’049 |

Anmerkung: Liste der Onkologika vergleiche Tabelle 27.

* Nur Fälle seit 2012.

Tabelle 22: Inzidenz und Prävalenz von Lungenkrebs bei Personen mit und ohne Onkologikabezug, 2012-2023, Hochrechnung für die gesamte Schweiz

Die durchschnittliche Inzidenz gemittelt über alle eingeschlossenen Jahre lag bei etwa 4’900 Personen pro Jahr, was mit der nationalen Krebsregistrierungsstelle vergleichbar ist (Tabelle 26 im Anhang). Etwa 75% der Neuerkrankten wurden im Jahr 2023 auch mit Onkologika behandelt. Die beobachtete Prävalenz stieg über die Jahre zunächst weit stärker als die Inzidenz, da alle Personen, welche ab 2012 diagnostiziert wurden und nicht verstarben, nachgeführt wurden. Prävalente Fälle (Überlebende), die in

[[Seite 77/102]]

früheren Jahren diagnostiziert wurden, konnten nicht berücksichtigt werden, da keine Informationen vor 2012 verfügbar waren. Aus diesem Grund sind die Inzidenz und Prävalenz im ersten Jahr der Datenreihe gleich; hierbei handelt es sich also um ein statistisches Artefakt. Weniger als die Hälfte der prävalenten Fälle wurde mit Medikamenten behandelt. Dies kann unterschiedliche Gründe haben (z.B. Therapieabschluss, nur noch palliative Behandlung), die ohne klinische Informationen nicht ermittelbar waren.

## Analysen nach Onkologika

Die Anzahl der Personen, die Anzahl der Bezüge und die Kosten von Onkologika wurden in den drei Kategorien Chemotherapie, zielgerichtete Therapie und Immuntherapie pro Jahr ausgewertet. Die Daten des Jahres 2012 wurden dabei nicht dargestellt, da keine Abrechnungen aus dem Vorjahr vorlagen, um Personen mit Lungenkrebs zu identifizieren. Die Werte wären so unterschätzt worden.

Dazu muss beachtet werden, dass Personen gleichzeitig aus mehreren Kategorien Bezüge aufweisen konnten (z.B. Chemotherapie und Immuntherapie) und daher in den Statistiken mehrfach auftauchen können. Dadurch kann die Anzahl Personen in diesen Analysen die Prävalenz übersteigen. Nicht berücksichtigt wurde das Bevölkerungswachstum der Schweiz zwischen den Jahren 2012 und 2023. Dieses betrug durchschnittlich 0.93% pro Jahr (eigene Berechnung, basierend auf den Zahlen des Bundesamts für Statistik [56]). Es muss daher beachtet werden, dass eine höhere Anzahl Personen mit Bezügen in Folgejahren zu einem geringen Anteil auch mit der steigenden Wohnbevölkerung oder demografischen Faktorenzusammenhängen kann.

## Behandlungsmuster

Die Analyse der Therapieverläufe von Patientinnen und Patienten, die in den Jahren 2016 respektive 2021 diagnostiziert wurden, zeigt, welche der drei Gruppen von Onkologika verwendet wurden. Eine Auswertung früherer Jahre war nicht möglich, da hier nicht gut zwischen prävalenten und inzidenten Fällen unterschieden werden konnte. Das bedeutet zum Beispiel, das unklar war, ob eine Person mit Onkologikabezügen im Jahr 2012 bereits in den Jahren davor Bezüge aufwies. Die Bezüge im Jahr 2012 hätten somit fälschlicherweise als erste Behandlung klassifiziert werden können, obwohl möglicherweise bereits früher eine Behandlung stattfand. Solche Fehlklassifikationen konnten auch in späteren Jahren vorkommen, insbesondere, wenn Patientinnen und Patienten die Grundversicherung gewechselt haben. Um dieses Risiko zu minimieren, wurden in den betreffenden Analysen nur Personen berücksichtigt, die mindestens seit einem Jahr bei Helsana versichert waren. Es ist ausserdem möglich, dass aufgrund der Schätzung der Diagnose Lungenkrebs aus Abrechnungsdaten Fehlklassifikationen bezüglich der diagnostizierten Krebsart aufgetreten sind.

Eine neue Therapie wurde pragmatisch definiert als (i) einen neuen Therapieanfang nach mindestens 40 Tagen und/oder (ii) einen Wechsel der Therapie (z.B. von Immuntherapie zu Chemotherapie). Einzelfälle mit Therapienschemas, welche im nicht-hochgerechneten Datensatz nur bei einer Person vorkamen, wurden von der Analyse ausgeschlossen. Keine weitere Therapielinie konnte bedeuten, dass (i) die Person innerhalb von 60 Tagen nach der Therapie verstarb, (ii) die Behandlung abgeschlossen war, (iii) die Behandlung noch andauerte, oder (iv) die Person weiter mit einer bestmöglichen unterstützenden Therapie (best supportive care, BSC) behandelt wurde. Ein Wechsel

[[Seite 78/102]]

der Grundversicherung als eine weitere Möglichkeit war nur bei sehr wenigen Personen der Fall und konnte vernachlässigt werden. Chemotherapien wurden zusammenfassend als eine Therapielinie klassifiziert, die Kategorie beinhaltet aber auch neoadjuvante (vor einer Operation) zur Reduktion der Tumormasse und adjuvante (nach einer Operation) Therapien, mit dem Ziel einer Reduktion des Risikos von späteren Rezidiven oder Fernmetastasen. Des Weiteren zeigt die Darstellung der Behandlungsmuster die reine Reihenfolge der Behandlungen an und kann keine Aussagen über den zeitlichen Abstand zwischen diesen machen, welcher mehrere Jahre betragen kann.

Zusätzlich wurden die Durchschnittskosten für Onkologia über zwei Jahre für Personen mit Start in unterschiedlichen Therapiearten berechnet. Hier wurden auch Kosten für alle Folgetherapien mit Onkologika mit einberechnet. Bei der Interpretation ist zu beachten, dass Personen mit unterschiedlichen Subtypen und Stadien von Lungenkrebs andere Therapien erhalten. Auch deshalb kann das Überleben in verschiedenen Therapieformen unterschiedlich lang sein. Dies beeinflusst wiederum auch die Durchschnittskosten.

## 4.2.3 Resultate und Diskussion

## Einteilung der Onkologika

Die Aufteilung der Onkologika in Chemotherapeutika (Zytostatika), zielgerichtete Therapien und Immuntherapien findet sich in Tabelle 27 im Anhang. Es gab 17 Chemotherapeutika, 19 zielgerichtete Therapien und 5 Immuntherapien. Es waren nur 14 Onkologika spezifisch für Lungenkrebs zugelassen. Alle Immuntherapien waren auch für andere Indikationen zugelassen.

## Personen und Bezüge nach Jahr

Abbildung 19 zeigt die Anzahl der Personen mit Medikamentenbezug in einer der drei Kategorien Chemotherapie, zielgerichtete Therapie und Immuntherapie, für die Jahre 2013-2023. Chemotherapien wurden 2023 nach wie vor von den meisten Personen bezogen, aber seltener als früher (2023: 4’510; -2.2% pro Jahr). Die Anzahl der Personen mit zielgerichteter Therapie nahm dagegen zu (2023: 1’864; +4.5% pro Jahr). Der Anteil der Personen mit zielgerichteter Therapie stieg dagegen sehr schwach an (2023: 19%; +0.01% pro Jahr). Die Nutzung der Immuntherapie – zugelassen in der Schweiz seit Ende 2015 – stieg steil an und erreichte ab dem Jahr 2021 ein Plateau (2023: 3’403 Personen), scheint aber keinen grossen Einfluss auf die Nutzung der anderen beiden Therapieoptionen gehabt zu haben. Dies liegt unter anderem daran, dass Immuntherapien häufig in Kombination mit einer Chemotherapie gegeben werden. Ebenfalls können mehrere, aufeinanderfolgende Therapielinien pro Jahr und Person vorgekommen sein.

[[Seite 79/102]]

**[Grafik 19] Abbildung 19: Anzahl Personen mit Medikamentenbezügen nach Kategorie und Jahr, 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Liniendiagramm, 2013–2023. Y-Achse: Anzahl Personen, 0, 1’000, 2’000, 3’000, 4’000, 5’000, 6’000. Chemo beige, Targeted gelb, Immuno bordeauxrot. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±100 Personen. Die Werte 2023 sind aus dem Fliesstext auf Seite 78 übernommen und stimmen innerhalb der Ablesegenauigkeit mit den Kurven überein. Der erste Immuno-Punkt 2015 nahe der Nulllinie ist nicht eindeutig ablesbar. – bedeutet kein dargestellter Kurvenabschnitt, nicht gesichert null.

| Jahr | Chemo | Targeted | Immuno |
|---|---|---|---|
| 2013 | ca. 5650 | ca. 1200 | – |
| 2014 | ca. 5600 | ca. 1150 | – |
| 2015 | ca. 5450 | ca. 1250 | nicht eindeutig ablesbar |
| 2016 | ca. 5200 | ca. 1300 | ca. 750 |
| 2017 | ca. 5100 | ca. 1300 | ca. 1250 |
| 2018 | ca. 4650 | ca. 1300 | ca. 1650 |
| 2019 | ca. 4500 | ca. 1250 | ca. 2350 |
| 2020 | ca. 4700 | ca. 1400 | ca. 2650 |
| 2021 | ca. 5000 | ca. 1650 | ca. 3400 |
| 2022 | ca. 4700 | ca. 1700 | ca. 3450 |
| 2023 | 4’510 (Fliesstext Seite 78) | 1’864 (Fliesstext Seite 78) | 3’403 (Fliesstext Seite 78) |

Anmerkung: Chemo = Chemotherapie, Targeted = zielgerichtete Therapie, Immuno = Immuntherapie

**[Ende Grafik 19]**

Die Analyse der Bezüge ergab ein ähnliches Bild (Abbildung 20). Die Bezüge von Chemotherapeutika gingen von 2013 bis 2023 um insgesamt 32% zurück. Die Bezüge zielgerichteter Therapien, welche im Jahr 2013 noch bei deutlich unter 10’000 lagen, stiegen auf etwa 12’000 im Jahr 2023. Immuntherapeutika verzeichneten innerhalb weniger Jahre einen starken Zuwachs und blieben seit 2021 auf einem stabilen Niveau. Auch hier muss beachtet werden, dass die Anzahl der behandelten Personen über die Jahre nicht konstant war und dass eine Person in einem Jahr Bezüge mehrerer Kategorien aufweisen konnte. Die Gesamtanzahl der Bezüge war im Jahr 2021 mit etwa 93’000 Bezügen am höchsten und im Jahr 2014 mit etwa 69’000 Bezügen am niedrigsten. Im Jahr 2023 lag sie bei 73’000.

**[Grafik 20] Abbildung 20: Jährliche Bezüge in den Kategorien Chemotherapie, zielgerichtete Therapie und Immuntherapie bei Personen mit Lungenkrebs, 2013-2023, Hochrechnung für die gesamte Schweiz**

Darstellung: Liniendiagramm, 2013–2023. Y-Achse: Bezüge, 0, 10’000, 20’000, 30’000, 40’000, 50’000, 60’000, 70’000. Chemo beige, Targeted gelb, Immuno bordeauxrot. Wertstatus: pixelgestützt am Seitenbild abgelesen ca.; Genauigkeit ±1000 Bezüge. Der erste Immuno-Punkt 2015 nahe der Nulllinie ist nicht eindeutig ablesbar. – bedeutet kein dargestellter Kurvenabschnitt, nicht gesichert null. Die Summen der abgelesenen Serien sind mit den Fliesstextangaben etwa 69’000 (2014), etwa 93’000 (2021) und 73’000 (2023) vereinbar. Die Grafik zeigt für Immuno 2023 einen Rückgang gegenüber 2021 und 2022; die Aussage im Fliesstext über ein seit 2021 stabiles Niveau wurde unverändert übernommen.

| Jahr | Chemo | Targeted | Immuno |
|---|---|---|---|
| 2013 | ca. 64000 | ca. 6500 | – |
| 2014 | ca. 62500 | ca. 6500 | – |
| 2015 | ca. 63500 | ca. 8000 | nicht eindeutig ablesbar |
| 2016 | ca. 62500 | ca. 8000 | ca. 9000 |
| 2017 | ca. 61500 | ca. 8000 | ca. 20500 |
| 2018 | ca. 54500 | ca. 7500 | ca. 20000 |
| 2019 | ca. 49500 | ca. 7500 | ca. 20500 |
| 2020 | ca. 55000 | ca. 8500 | ca. 21000 |
| 2021 | ca. 56500 | ca. 12000 | ca. 24000 |
| 2022 | ca. 49000 | ca. 11500 | ca. 24000 |
| 2023 | ca. 43000 | ca. 12000 | ca. 18000 |

Anmerkung: Chemo = Chemotherapie, Targeted = zielgerichtete Therapie, Immuno = Immuntherapie

**[Ende Grafik 20]**

## Gesamtkosten und Durchschnittskosten pro Jahr

Die Gesamtkosten stiegen von CHF 63 Millionen im Jahr 2013 auf CHF 146 Millionen in 2023 an, was einem deutlichen Zuwachs von 169% entspricht. Dies ging insbesondere auf die Immuntherapien zurück (Abbildung 21), die in den letzten Jahren Kosten um CHF 100 Millionen pro Jahr verursachten (2023: 81 Millionen). Die Kosten für Chemotherapien und zielgerichtete Therapien waren deutlich niedriger. Die Chemotherapiekosten waren sogar rückläufig (2013: CHF 39 Millionen, 2023: CHF 12.6 Millionen; -56%), was hauptsächlich mit den abnehmenden Bezügen (Abbildung 20) in Zusammenhang

[Hinweis Transkription: Die Originalangaben CHF 63 Millionen (2013), CHF 146 Millionen (2023) und 169% sind rechnerisch nicht miteinander vereinbar. Ebenfalls sind CHF 39 Millionen (2013), CHF 12.6 Millionen (2023) und -56% rechnerisch nicht miteinander vereinbar. Sämtliche Originalangaben wurden unverändert übernommen.]

---

— Ende Teil 6 von 8 · Kontrollwort Teil 6: ARNIKA-28 · weiter mit teil-07.md —
