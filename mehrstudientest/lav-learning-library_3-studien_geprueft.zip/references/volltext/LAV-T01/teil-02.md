# LAV-T01 · Volltext · Teil 2 von 2 (PDF-Seiten 10–19 von 19)

Studie: Das Wichtigste in Kürze zum GESUNDHEITSMONITOR 2024 – Zunehmende Reformbereitschaft in der Romandie · Quelldatei: LY-IPH.01.24.001-_-Gesundheitsmonitor-2024_d_web-07824a40.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 2 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T01, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 10/19 · Druckseiten 16–17]]

Um eine Kostensenkung zu erwirken, sind Massnahmen unausweichlich. Jedoch nimmt die Bereitschaft der Bevölkerung, diese Massnahmen in Kauf zu nehmen, in den vergangenen Jahren ab. Die höchste Bereitschaft zeigt sich mit minderheitlichen 37 Prozent bei der freien Spitalwahl. Ein steigendes Einverständnis zeigt sich hinsichtlich einer Einschränkung beim Zugang zu neuen Medikamenten (+10%P). Aktuell würde ein Drittel der Befragten Vorbehalte in Kauf nehmen (33%). Die tiefste Zustimmung erzielt eine mögliche Kürzung des Leistungskatalogs in der Grundversicherung. Drei Viertel der Befragten würden diese Massnahme auf keinen Fall in Kauf nehmen (75%).

Die Bereitschaft, Massnahmen zur Kostensenkung in Kauf zu nehmen, ist in der Romandie deutlich höher als in der deutschsprachigen und der italienischsprachigen Schweiz. Je nach Höhe der Kostensenkung würde sich bei allen abgefragten Massnahmen eine klare Mehrheit in der französischsprachigen Schweiz finden lassen. Zwei Drittel der Befragten sind gegenüber einer Kürzung des Leistungskatalogs (66%) oder einem eingeschränkten Zugang zu neuen Medikamenten (66%) offen eingestellt. Über 70 Prozent der Stimmberechtigten aus der Romandie können sich vorstellen, auf die Verschreibungsfreiheit (72%), auf die freie Wahl des Arztes oder der Ärztin (74%) und die freie Spitalwahl (75%) zu verzichten.

**[Grafik 11] Haltung Massnahmen zur Kostensenkung**

Frage: «Welche der folgenden Massnahmen wären Sie selbst bereit, für sich in Kauf zu nehmen, wenn dadurch die Kosten im Gesundheitswesen sinken würden? Sagen Sie mir bitte jeweils, ob Sie auf jeden Fall bereit wären, ob Sie dazu bereit wären, je nachdem wie hoch die Kostensenkung wäre, oder ob Sie auf keinen Fall dazu bereit wären.»

Darstellung: Liniendiagramm, 2015–2024, In % Stimmberechtigter; Anteil auf jeden Fall und je nach Höhe Kostensenkung. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Übrige dargestellte Jahreswerte berechnet aus den Vektorpfaden der PDF mit vektoren.py und grafikwerte.py; lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf ganze Prozentpunkte (Rundungsgenauigkeit ± 0.5 Prozentpunkte). Es werden nur tatsächlich gezeichnete Stützpunkte übernommen, keine interpolierten Zusatzpunkte.

| Jahr | Keine freie Spitalwahl | Eingeschränkter Zugang zu neuen Medikamenten | Keine freie Arztwahl | Keine Verschreibungsfreiheit (bis 2020: keine Therapiefreiheit) | Kürzung Leistungskatalog |
|---|---|---|---|---|---|
| 2015 | ca. 62 | ca. 32 | ca. 43 | ca. 56 | ca. 47 |
| 2016 | ca. 67 | ca. 36 | ca. 59 | ca. 52 | ca. 50 |
| 2017 | ca. 66 | ca. 43 | ca. 51 | ca. 60 | ca. 55 |
| 2018 | ca. 54 | ca. 19 | ca. 38 | ca. 54 | ca. 31 |
| 2019 | ca. 58 | ca. 38 | ca. 27 | ca. 47 | ca. 26 |
| 2020 | ca. 41 | ca. 25 | ca. 25 | ca. 33 | ca. 20 |
| 2021 | ca. 54 | ca. 26 | ca. 33 | ca. 32 | ca. 24 |
| 2022 | ca. 37 | ca. 27 | ca. 22 | ca. 28 | ca. 19 |
| 2023 | ca. 39 | ca. 23 | ca. 30 | ca. 27 | ca. 19 |
| 2024 (beschriftet) | 37 | 33 | 31 | 30 | 23 |

[Hinweis Transkription: Der Fliesstext nennt 75% auf keinen Fall bereit zur Kürzung des Leistungskatalogs, die Grafik 23% auf jeden Fall oder je nach Höhe der Kostensenkung bereit. Die unterschiedlichen Antwortkategorien werden nicht gleichgesetzt oder auf 100 ergänzt. Der Zuwachs beim eingeschränkten Zugang zu neuen Medikamenten stimmt überein: berechnet ca. 23 für 2023, beschriftet 33 für 2024, im Text +10%P.]



© gfs.bern, Gesundheitsmonitor 2024 (N = 1’200)

**[Ende Grafik 11]**

**[Grafik 12] Haltung Massnahmen zur Kostensenkung: Romandie**

Frage: «Welche der folgenden Massnahmen wären Sie selber bereit, für sich in Kauf zu nehmen, wenn dadurch die Kosten im Gesundheitswesen sinken würden? Sagen Sie mir bitte jeweils, ob Sie auf jeden Fall bereit wären, ob Sie dazu bereit wären, je nachdem wie hoch die Kostensenkung wäre, oder ob Sie auf keinen Fall dazu bereit wären.»

Darstellung: Liniendiagramm, 2015–2024, In % Stimmberechtigter Romandie; Anteil Auf jeden Fall und je nach Höhe Kostensenkung. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Übrige dargestellte Jahreswerte berechnet aus den Vektorpfaden der PDF mit vektoren.py und grafikwerte.py; lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf ganze Prozentpunkte (Rundungsgenauigkeit ± 0.5 Prozentpunkte). Es werden nur tatsächlich gezeichnete Stützpunkte übernommen, keine interpolierten Zusatzpunkte.

| Jahr | Keine freie Spitalwahl | Keine freie Arztwahl | Keine Verschreibungsfreiheit (bis 2020: keine Therapiefreiheit) | Eingeschränkter Zugang zu neuen Medikamenten | Kürzung Leistungskatalog |
|---|---|---|---|---|---|
| 2015 | ca. 51 | ca. 33 | ca. 47 | ca. 38 | ca. 52 |
| 2016 | ca. 61 | ca. 47 | ca. 46 | ca. 36 | ca. 45 |
| 2017 | ca. 75 | ca. 62 | ca. 61 | ca. 53 | ca. 55 |
| 2018 | ca. 71 | ca. 44 | ca. 64 | ca. 12 | ca. 36 |
| 2019 | ca. 79 | ca. 49 | ca. 59 | ca. 48 | ca. 35 |
| 2020 | ca. 74 | ca. 57 | ca. 59 | ca. 42 | ca. 51 |
| 2021 | ca. 82 | ca. 67 | ca. 59 | ca. 22 | ca. 61 |
| 2022 | ca. 65 | ca. 54 | ca. 56 | ca. 53 | ca. 60 |
| 2023 | ca. 88 | ca. 72 | ca. 68 | ca. 62 | ca. 64 |
| 2024 (beschriftet) | 75 | 74 | 72 | 66 | 66 |



© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 300)

**[Ende Grafik 12]**

[[Seite 11/19 · Druckseiten 18–19]]

Das Obligatorium in der Grundversicherung wird von einer breiten Mehrheit der Bevölkerung unterstützt. Rund drei Viertel möchten die Pflicht beibehalten (76%).

Hinsichtlich des Leistungskatalogs, der durch die Grundversicherung abgedeckt wird, haben wir bereits aufgezeigt, dass eine Kürzung schweizweit wahrscheinlich nicht mehrheitsfähig ist. Einen Ausbau des Leistungskatalogs wünschen die Befragten ebenfalls nicht. Lediglich ein Drittel der Befragten spricht sich dafür aus (33%). Die Mehrheit der Bevölkerung möchte den aktuellen Leistungskatalog beibehalten (60%). Über die vergangenen Jahre hinweg betrachtet, nimmt die Befürwortung eines Ausbaus ab. Die Unterstützung der aktuellen Ausgestaltung wächst an. Einen Abbau begrüsst nur ein einstelliger Prozentsatz der Befragten.

Welche Leistungen in der Grundversicherung vergütet werden sollen und welche Leistungen Versicherte vollumfänglich selbst tragen müssen, führt stets zu Diskussionen. Bei einer Abhängigkeit von Drogen (21%), bei Schäden, die durch Rauchen oder Alkohol entstehen (40%), und bei der Vorbeugung von Geschlechtskrankheiten (46%) – wozu unter anderem die medikamentöse Prophylaxe gegen eine HIV-Ansteckung oder die HPV-Impfung gezählt werden – findet sich in der Bevölkerung keine Mehrheit für eine vollständige Kostenübernahme seitens der Krankenkassen.

**[Kernaussagen]**

Erkennt die Bevölkerung eine mögliche Selbstverschuldung, soll die Krankenkassenleistung tendenziell geringer ausfallen. Es gibt auch vereinzelte Ausnahmen: Bei der Vorbeugung von Geschlechtskrankheiten sprechen sich Personen, die unter 30 Jahre alt sind, deutlich für eine Krankenkassenleistung aus (64%).

**[Ende Kernaussagen]**

**[Grafik 13] Selbst bezahlte Leistungen/Krankenkassenleistungen**

Frage: «Ich nenne Ihnen im Folgenden ein paar Situationen, wo Leistungen in der Grundversicherung vergütet werden können. Bitte sagen Sie mir bei jeder, wann Ihrer Ansicht nach der Betroffene selbst die Leistungen bezahlen sollte und wann Sie der Ansicht sind, dass die Kassen dies tun sollten.»

Darstellung: horizontal gestapelte Balken (100 %), In % Stimmberechtigter. Wertstatus: beschriftet; Segmente anhand der Lage und Farben der Legende zugeordnet. – = kein beschriftetes Segment. Die Summe der beschrifteten Werte ergibt je Zeile 100. Spalten in Legendenreihenfolge.

| Situation | Selbst zahlen | Beides etwa gleich | Kassenzahlung | Weiss nicht / keine Antwort |
|---|---|---|---|---|
| Abhängigkeit von Drogen | 40 | 38 | 21 | 1 |
| Schäden durch Rauchen oder Alkohol | 17 | 43 | 40 | – |
| Vorbeugung von Geschlechtskrankheiten | 36 | 17 | 46 | 1 |
| Ärztlich verordnete Heroinabgabe | 17 | 23 | 59 | 1 |
| Gewichtsbedingte Beschwerden | 3 | 25 | 70 | 2 |
| Beschwerden durch Stress | 2 | 23 | 74 | 1 |
| Ungewollte Kinderlosigkeit | 8 | 8 | 84 | – |
| Psychische Beschwerden | 2 | 11 | 87 | – |
| Vorbeugung von Herz-Kreislauf-Krankheiten | 5 | 5 | 90 | – |
| Früherkennung von Krebs | 2 | 2 | 96 | – |
| Behinderung Familienangehörige | 1 | 1 | 97 | 1 |
| Seltene Krankheiten | – | 1 | 98 | 1 |

© gfs.bern, Gesundheitsmonitor 2024 (N = 1’200)

**[Ende Grafik 13]**

[[Seite 12/19 · Druckseiten 20–21]]

Die Kopfprämie ist in der Bevölkerung weiterhin mehrheitsfähig (82%). Jedoch befindet sich die Zustimmung in einem leichten Abwärtstrend (–4%P) und ist in diesem Jahr auf einem Tiefstwert angelangt. Rund zwei Drittel der Befragten sind damit einverstanden, wenn die Krankenkassen Medikamente für Bagatellen nicht mehr übernehmen (68%) oder einen Bonus an Personen, die keine Leistungen beziehen, ausbezahlen (68%). Ebenfalls mehr als die Hälfte der Befragten spricht sich für automatische Massnahmen zur Kostenbegrenzung – z.B. durch eine Deckelung der Leistungen – aus (60%). Die Stimmbevölkerung spricht sich mehrheitlich – mit Ausnahme von 2018 – für eine Kostenbremse aus. Da kostendämpfende Massnahmen mit hoher Wahrscheinlichkeit zu Leistungseinschränkungen führen werden, ist es fraglich, ob die Bevölkerung solche Anpassungen im Leistungsumfang tatsächlich befürwortet.

Aktuell nicht mehrheitsfähig, aber in einem klaren Aufwärtstrend befindet sich die Forderung nach einer einkommensabhängigen Prämie (42%, +8%P).

**[Grafik 14] Forderungen zu den Krankenkassen**

Frage: «Aktuell werden in der Politik rund um Krankenkassen verschiedene Vorschläge diskutiert. Sagen Sie mir bitte jeweils, ob Sie damit sehr einverstanden, eher, eher nicht oder gar nicht einverstanden sind?»

Darstellung: horizontal gestapelte Balken (100 %), In % Stimmberechtigter. Wertstatus: alle Werte beschriftet; Spalten in Legendenreihenfolge. Alle Zeilensummen ergeben 100.

| Forderung | Sehr einverstanden | Eher einverstanden | Weiss nicht / keine Antwort | Eher nicht einverstanden | Gar nicht einverstanden |
|---|---|---|---|---|---|
| Prämiensystem Krankenversicherung | 18 | 64 | 2 | 12 | 4 |
| Medikamente für Bagatellen nicht bezahlen | 9 | 59 | 3 | 23 | 6 |
| Bonus bei Nichtnutzung von Leistungen | 13 | 55 | 1 | 22 | 9 |
| Automatische Massnahmen zur Kostenbegrenzung | 10 | 50 | 2 | 12 | 26 |
| Günstigere Behandlungen im Ausland bezahlen | 14 | 34 | 4 | 36 | 12 |
| Prämien einkommensabhängig | 12 | 30 | 3 | 39 | 16 |
| Einheitskasse | 10 | 26 | 6 | 25 | 33 |
| Minimale Franchise erhöhen | 5 | 24 | 1 | 56 | 14 |
| Budgetkrankenkasse | 7 | 20 | 7 | 32 | 34 |
| Minimale Franchise an Kostenentwicklung anpassen | 5 | 20 | 2 | 50 | 23 |
| Maximalfranchise erhöhen | 5 | 13 | 3 | 64 | 15 |

© gfs.bern, Gesundheitsmonitor 2024 (N = 1’200)

**[Ende Grafik 14]**

[[Seite 13/19 · Druckseiten 22–23]]

## 4 Ausgewählte Trendanalysen

## 4.1 Pharmaindustrie

Die pharmazeutische Industrie geniesst in der Bevölkerung hohes Ansehen. Knapp drei Viertel der Befragten stufen sie als sehr bedeutend für die Wirtschaftskraft der Schweiz ein (73%). Weitere 26 Prozent finden die Branche ziemlich bedeutend.

Über die Jahre hinweg ist der Anteil der Befragten, die die pharmazeutische Industrie als sehr bedeutend einstuften, auf einem neuen Höchststand angelangt (+3%P).

Dieses positive Bild der Pharmabranche lässt sich auch bei näherer Betrachtung bestätigen: Die Befragten sehen in der Pharmaindustrie eine wichtige Arbeitgeberin (97%) und einen Exportmotor für die Schweizer Wirtschaft (96%). Darüber hinaus schreiben sie der Pharmaindustrie einen professionellen Ruf im Ausland (92%) und das vorhandene Interesse am Standort Schweiz zu (86%).

54 Prozent (+5%P) stufen die Informationspolitik der Pharmaindustrie in der Schweiz als transparent ein. Nachdem dieser Wert in den vergangenen Jahren stark schwankte, ist nun das zweite Jahr in Folge ein Aufwärtstrend erkennbar. Der Wert von über 50 Prozent liegt oberhalb von Transparenzmessungen, wie sie für Banken oder Versicherungen gemessen werden. Zentral ist, dass im Normalfall einzelne Unternehmen, zu denen Befragte einen direkten Bezug haben, als transparenter eingestuft werden als ganze Branchen.

60 Prozent der Befragten erkennen die Relevanz von grossen Gewinnen für die Finanzierung von Forschung innerhalb der Pharmaindustrie. Die Kritik, die seit dem Jahr 2018 diesbezüglich zugenommen hat, scheint vorläufig ausgebremst zu sein.

**[Grafik 15] Bedeutung Branchen: pharmazeutische Industrie**

Frage: «Wie stark ist Ihrer Meinung nach der Einfluss der folgenden Branchen auf die Wirtschaftskraft der Schweiz als Standort? Ist er sehr bedeutend, ziemlich bedeutend, es geht so, unbedeutend oder ganz unbedeutend?»

Darstellung: Gestapeltes Flächendiagramm, 2015–2024, In % Stimmberechtigter. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: nicht beschriftet, berechnet aus den Vektorflächen der PDF mit vektoren.py und grafikwerte.py. Kumulative Flächengrenzen werden an der 0–100-Skala kalibriert und voneinander subtrahiert. Ausgabe als ca. auf ganze Prozentpunkte, Rundungsgenauigkeit ± 0.5 Prozentpunkte. Alle Zeilensummen ergeben 100. Spalten in Legendenreihenfolge.

| Jahr | Weiss nicht / keine Antwort | Ganz unbedeutend | Unbedeutend | Es geht so | Ziemlich bedeutend | Sehr bedeutend |
|---|---|---|---|---|---|---|
| 2015 | ca. 0 | ca. 0 | ca. 1 | ca. 6 | ca. 45 | ca. 48 |
| 2016 | ca. 1 | ca. 1 | ca. 2 | ca. 8 | ca. 42 | ca. 46 |
| 2017 | ca. 0 | ca. 1 | ca. 1 | ca. 6 | ca. 41 | ca. 51 |
| 2018 | ca. 0 | ca. 0 | ca. 0 | ca. 4 | ca. 36 | ca. 60 |
| 2019 | ca. 0 | ca. 0 | ca. 0 | ca. 4 | ca. 32 | ca. 64 |
| 2020 | ca. 0 | ca. 0 | ca. 1 | ca. 5 | ca. 32 | ca. 62 |
| 2021 | ca. 0 | ca. 0 | ca. 0 | ca. 1 | ca. 33 | ca. 66 |
| 2022 | ca. 0 | ca. 0 | ca. 1 | ca. 3 | ca. 42 | ca. 54 |
| 2023 | ca. 0 | ca. 0 | ca. 0 | ca. 3 | ca. 27 | ca. 70 |
| 2024 | ca. 0 | ca. 0 | ca. 0 | ca. 1 | ca. 26 | ca. 73 |

© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 1’200)

**[Ende Grafik 15]**

**[Grafik 16] Aussagen zur Pharmaindustrie**

Frage: «Hier sind einige allgemeine Aussagen zur Pharmaindustrie in der Schweiz. Sagen Sie mir bitte zu jeder Aussage, wie stark sie aufgrund von dem, was Sie wissen, für die Pharmaindustrie zutrifft.»

Darstellung: Liniendiagramm, 2015–2024, In % Stimmberechtigter; Anteil voll/eher zutreffend. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Übrige dargestellte Jahreswerte berechnet aus den Vektorpfaden der PDF mit vektoren.py und grafikwerte.py; lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf ganze Prozentpunkte (Rundungsgenauigkeit ± 0.5 Prozentpunkte). Keine interpolierten Zusatzpunkte.

| Jahr | Wichtige Arbeitgeberin in der Schweiz | Exportmotor | Guter Ruf | Standort Schweiz | Grosse Gewinne zur Forschungsfinanzierung nötig | Transparente Information |
|---|---|---|---|---|---|---|
| 2015 | ca. 94 | ca. 90 | ca. 92 | ca. 78 | ca. 80 | ca. 55 |
| 2016 | ca. 91 | ca. 84 | ca. 89 | ca. 79 | ca. 81 | ca. 45 |
| 2017 | ca. 92 | ca. 83 | ca. 86 | ca. 76 | ca. 78 | ca. 56 |
| 2018 | ca. 96 | ca. 93 | ca. 88 | ca. 88 | ca. 80 | ca. 43 |
| 2019 | ca. 93 | ca. 92 | ca. 90 | ca. 88 | ca. 65 | ca. 50 |
| 2020 | ca. 96 | ca. 95 | ca. 89 | ca. 94 | ca. 55 | ca. 43 |
| 2021 | ca. 97 | ca. 96 | ca. 98 | ca. 92 | ca. 62 | ca. 55 |
| 2022 | ca. 94 | ca. 93 | ca. 94 | ca. 88 | ca. 49 | ca. 43 |
| 2023 | ca. 95 | ca. 95 | ca. 91 | ca. 89 | ca. 50 | ca. 49 |
| 2024 (beschriftet) | 97 | 96 | 92 | 86 | 60 | 54 |

© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 1’200)

**[Ende Grafik 16]**

[[Seite 14/19 · Druckseiten 24–25]]

Bei Fragen rund um das Gesundheitswesen schreibt die Schweizer Stimmbevölkerung der Pharmaindustrie höchste Kompetenz zu: Auf einer Skala von 0 bis 10, wobei 0 für keine Kompetenz und 10 für hohe Kompetenz steht, erreicht die Pharmaindustrie im Mittel einen Wert von 7.4. Im Vergleich mit dem Vorjahr ist der Wert leicht rückläufig (–0.3). Die zweitbeste Bewertung erzielen die Ärztinnen und Ärzte (7.1). Auf Platz drei folgen Wissenschaftlerinnen und Wissenschaftler (6.9).

**[Kernaussagen]**

Personen aus der deutschsprachigen Schweiz schreiben der Pharmaindustrie eine höhere Kompetenz zu als Personen aus der lateinischen Schweiz. Insbesondere bei Personen aus der französischen Schweiz fällt die zugeschrieben Kompetenz im Mittel tiefer aus (6.5). Bei den Ärztinnen und Ärzten (6.6) und den Wissenschaftlerinnen und Wissenschaftlern (5.6) zeigt sich ein ähnliches Bild. Wiederum andere Akteure (z.B. Konsumentenorganisationen) erzielen in der französischsprachigen Schweiz deutlich höhere Werte (FCH: 5.9, DCH: 4.5).

**[Ende Kernaussagen]**

## 4.2 Medikamente

Drei Viertel der Befragten stufen die Medikamentenpreise in der Schweiz als zu hoch ein (75%). Knapp ein Viertel findet die Preise angemessen (23%).

**[Kernaussagen]**

Männer kritisieren die Medikamentenpreise im Vergleich zu den Frauen tendenziell stärker (79% «zu hoch»). Diese Ansicht teilen – in einem noch grösseren Ausmass – Personen, die jünger als 30 Jahre alt sind (92%). Weniger Kritik erfahren die Medikamentenpreise bei Personen, die in ländlichen Gebieten wohnhaft sind (63%) oder mit der SVP sympathisieren (50%).

**[Ende Kernaussagen]**

Die Kritik an den Medikamentenpreisen ist seit Jahren auf einem hohen Niveau relativ stabil. Während der Covid-19-Pandemie flachte die Kritik etwas ab, seit vergangenem Jahr sind die Werte wieder auf dem Stand von vor der Pandemie.

**[Grafik 17] Kompetenz Akteure Gesundheitswesen**

Frage: «Verschiedene Gruppen nehmen in der Öffentlichkeit Stellung, wenn es um Fragen der Gesundheitspolitik geht. Wir möchten gerne wissen, was Sie über diese denken. Sagen Sie mir bitte anhand dieser Skala, wie hoch Sie in Fragen des Gesundheitswesens die Kompetenz bei den nachfolgenden Organisationen einschätzen. ‹0› bedeutet ‹keine Kompetenz›, ‹10› bedeutet ‹hohe Kompetenz›. Mit den Werten dazwischen können Sie Ihre Meinung abstufen. Wenn Sie eine der folgenden Organisationen nicht kennen, sagen Sie mir das bitte.»

Darstellung: Liniendiagramm, 2015–2024, In Mittelwerten Stimmberechtigter. Sichtbare Achsenmarken: 4, 5, 6, 7, 8, 9; die Frage definiert die Skala 0–10. Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Übrige dargestellte Jahreswerte berechnet aus den Vektorpfaden der PDF mit vektoren.py und grafikwerte.py; lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf eine Dezimalstelle (Rundungsgenauigkeit ± 0.05 Skalenpunkte). Keine interpolierten Zusatzpunkte.

| Jahr | Pharmaindustrie | Wissenschaftlerinnen und Wissenschaftler | Ärztinnen und Ärzte | Bundesrat | Apothekerinnen und Apotheker | Krankenkassen | Bundesämter | Gesundheitspolitikerinnen und Gesundheitspolitiker | Patientenorganisationen | Leute wie Sie und ich | Konsumentenorganisationen |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 2015 | ca. 7.4 | ca. 8.0 | ca. 6.4 | ca. 6.8 | ca. 7.2 | ca. 6.7 | ca. 6.8 | ca. 6.2 | ca. 6.5 | ca. 5.4 | ca. 6.0 |
| 2016 | ca. 6.8 | ca. 7.4 | ca. 6.1 | ca. 6.6 | ca. 6.1 | ca. 6.8 | ca. 6.9 | ca. 7.1 | ca. 6.7 | ca. 4.7 | ca. 6.6 |
| 2017 | ca. 6.7 | ca. 7.1 | ca. 6.8 | ca. 6.5 | ca. 6.6 | ca. 6.3 | ca. 6.8 | ca. 6.2 | ca. 6.3 | ca. 5.3 | ca. 6.0 |
| 2018 | ca. 7.2 | ca. 7.6 | ca. 6.7 | ca. 5.8 | ca. 6.8 | ca. 5.8 | ca. 6.1 | ca. 5.6 | ca. 5.3 | ca. 4.6 | ca. 5.0 |
| 2019 | ca. 7.3 | ca. 7.6 | ca. 6.9 | ca. 6.8 | ca. 6.8 | ca. 6.7 | ca. 6.5 | ca. 6.1 | ca. 6.3 | ca. 5.6 | ca. 5.9 |
| 2020 | ca. 7.0 | ca. 7.1 | ca. 6.6 | ca. 6.9 | ca. 6.1 | ca. 6.3 | ca. 5.9 | ca. 5.5 | ca. 5.3 | ca. 5.2 | ca. 4.9 |
| 2021 | ca. 7.2 | ca. 7.0 | ca. 6.9 | ca. 7.1 | ca. 6.2 | ca. 6.3 | ca. 6.0 | ca. 5.7 | ca. 5.5 | ca. 5.1 | ca. 5.1 |
| 2022 | ca. 7.3 | ca. 7.4 | ca. 7.1 | ca. 6.8 | ca. 6.4 | ca. 5.8 | ca. 5.7 | ca. 5.4 | ca. 5.3 | ca. 5.2 | ca. 5.0 |
| 2023 | ca. 7.7 | ca. 7.1 | ca. 7.2 | ca. 7.0 | ca. 6.2 | ca. 5.9 | ca. 5.6 | ca. 5.6 | ca. 5.3 | ca. 5.0 | ca. 5.0 |
| 2024 (beschriftet) | 7.4 | 7.1 | 6.9 | 6.5 | 6.2 | 5.9 | 5.6 | 5.4 | 5.3 | 5.1 | 4.9 |

[Hinweis Transkription: Widerspruch im Original: Im Fliesstext werden Ärztinnen und Ärzte mit 7.1 und Wissenschaftlerinnen und Wissenschaftler mit 6.9 genannt. Die Grafik ordnet nach Linienfarbe und Legende 7.1 den Wissenschaftlerinnen und Wissenschaftlern und 6.9 den Ärztinnen und Ärzten zu. Beide Originalangaben werden unverändert erhalten; menschliche Sichtprüfung vorgemerkt.]

© gfs.bern, Gesundheitsmonitor 2024 (N = 1’140)

**[Ende Grafik 17]**

**[Grafik 18] Haltung Medikamentenpreise**

Frage: «Sprechen wir noch etwas von den Medikamenten in der Schweiz. Sind die Medikamentenpreise in der Schweiz Ihrer Meinung nach alles in allem zu hoch, angemessen oder zu tief?»

Darstellung: Gestapeltes Flächendiagramm, 2015–2024, In % Stimmberechtigter. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: nicht beschriftet, berechnet aus den Vektorflächen der PDF mit vektoren.py und grafikwerte.py. Kumulative Flächengrenzen werden an der 0–100-Skala kalibriert und voneinander subtrahiert. Ausgabe als ca. auf ganze Prozentpunkte, Rundungsgenauigkeit ± 0.5 Prozentpunkte. Alle Zeilensummen ergeben 100. Spalten in Legendenreihenfolge.

| Jahr | Weiss nicht / keine Antwort | Zu tief | Angemessen | Zu hoch |
|---|---|---|---|---|
| 2015 | ca. 5 | ca. 0 | ca. 24 | ca. 71 |
| 2016 | ca. 1 | ca. 1 | ca. 29 | ca. 69 |
| 2017 | ca. 3 | ca. 1 | ca. 28 | ca. 68 |
| 2018 | ca. 4 | ca. 0 | ca. 20 | ca. 76 |
| 2019 | ca. 4 | ca. 0 | ca. 18 | ca. 78 |
| 2020 | ca. 4 | ca. 1 | ca. 19 | ca. 76 |
| 2021 | ca. 2 | ca. 1 | ca. 38 | ca. 59 |
| 2022 | ca. 2 | ca. 2 | ca. 32 | ca. 64 |
| 2023 | ca. 1 | ca. 3 | ca. 22 | ca. 74 |
| 2024 | ca. 1 | ca. 1 | ca. 23 | ca. 75 |

© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 1’200)

**[Ende Grafik 18]**

[[Seite 15/19 · Druckseiten 26–27]]

Um den steigenden Kosten entgegenzuwirken, hat der Bundesrat eine Förderung der Generika beschlossen. Ab 2024 müssen Versicherte, die sich für Originalpräparate auf Rezept – trotz verfügbarer Generikaalternativen – entscheiden, einen Selbstbehalt von 40 Prozent bezahlen. Im Gegensatz dazu liegt der Selbstbehalt für die meisten Generika und Biosimilars in der Regel bei 10 Prozent. Mit einem Entscheid für Generika unterstützen somit versicherte Personen die Kostendämpfung im Gesundheitswesen.[4]

Trotz der Erhöhung des Selbstbehalts bei Originalpräparaten würde sich weiterhin eine klare Mehrheit der Stimmberechtigten für das Originalmedikament (62%) und somit gegen das Generikum entscheiden.

[Fussnote 4] BAG, Arzneimittel: Wichtige Neuerung für Versicherte ab dem 1. Januar 2024: https://www.bag.admin.ch/bag/de/home/das-bag/aktuell/news/news-05-01-2024.html#:~:text=Januar%202024%20%E2%80%93%20Versicherte%20zahlen%20ab,Alternative%20zur%20Verf%C3%BCgung%20stehen%20w%C3%BCrde.

**[Grafik 19] Haltung Original/Generika**

Frage: «Wenn Sie die Auswahl haben, würden Sie eher das Originalmedikament oder Nachahmerprodukt, auch Generikum oder Biosimilar genannt, kaufen?»

Darstellung: Gestapeltes Flächendiagramm, 2015–2024, In % Stimmberechtigter. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: nicht beschriftet, berechnet aus den Vektorflächen der PDF mit vektoren.py und grafikwerte.py. Kumulative Flächengrenzen werden an der 0–100-Skala kalibriert und voneinander subtrahiert. Ausgabe als ca. auf ganze Prozentpunkte, Rundungsgenauigkeit ± 0.5 Prozentpunkte. Alle Zeilensummen ergeben 100. Spalten in Legendenreihenfolge.

| Jahr | Generikum | Weiss nicht/keine Antwort | Originalmedikament |
|---|---|---|---|
| 2015 | ca. 38 | ca. 10 | ca. 52 |
| 2016 | ca. 40 | ca. 7 | ca. 53 |
| 2017 | ca. 40 | ca. 8 | ca. 52 |
| 2018 | ca. 29 | ca. 14 | ca. 57 |
| 2019 | ca. 35 | ca. 9 | ca. 56 |
| 2020 | ca. 40 | ca. 10 | ca. 50 |
| 2021 | ca. 25 | ca. 8 | ca. 67 |
| 2022 | ca. 35 | ca. 10 | ca. 55 |
| 2023 | ca. 35 | ca. 8 | ca. 57 |
| 2024 | ca. 29 | ca. 10 | ca. 61 |

[Hinweis Transkription: Abweichung zwischen Fliesstext und Vektorgrafik im Original: Der Fliesstext nennt 62% für das Originalmedikament. Die gezeichnete Fläche für 2024 ergibt berechnet ca. 61% für das Originalmedikament. Die Textangabe wird nicht korrigiert; menschliche Sichtprüfung vorgemerkt.]

© gfs.bern, Gesundheitsmonitor 2024 (N = 1’200)

**[Ende Grafik 19]**

[[Seite 16/19 · Druckseiten 28–29]]

## 5 Thesen

Zusammengefasst zeichnet sich das Meinungsbild der Schweizer Stimmberechtigten rund um Gesundheitsfragen durch 7 Entwicklungen aus:

**[Kernaussagen]**

Die Zufriedenheit mit dem Gesundheitswesen fällt auch im Jahr 2024 äusserst hoch aus. Die wahrgenommene hohe Qualität begünstigt die positive Bewertung. Wobei es zu beachten gilt, dass nicht in allen Regionen die Qualität gleich hoch beurteilt wird: In der französischsprachigen Schweiz wird die Qualität schlechter wahrgenommen als in der übrigen Schweiz.

**[Ende Kernaussagen]**

**[Kernaussagen]**

Langfristig und schweizweit betrachtet, ist die wahrgenommene Kostenbelastung auf einem unterdurchschnittlichen Stand. Der Problemdruck wurde in den vergangenen Jahrzehnten deutlich höher wahrgenommen als heute: Beispielsweise bekundete rund um das Jahr 2011 etwa die Hälfte der Befragten gelegentliche oder dauerhafte Probleme beim Bezahlen der Krankenkassenprämien. Jedoch zeigen sich grosse regionale Unterschiede: In der Romandie steigt die wahrgenommene Kostenbelastung seit 2020 stark an.

**[Ende Kernaussagen]**

**[Kernaussagen]**

Die Wunschvorstellung vom Schweizer Gesundheitswesen bleibt über die Jahre hinweg stabil: Trotz der finanziellen Belastung durch die hohen Gesundheitskosten möchte die Bevölkerung nicht auf den vorherrschenden Leistungsstandard verzichten. Die Stimmberechtigten wünschen sich eine Grundversicherung, die alle Leistungen abdeckt, ein gemeinwohlorientiertes Gesundheitswesen, das Qualität und Quantität höher als die Kosten gewichtet und eine freie Wahl der Ärztin oder des Arztes ermöglicht sowie staatlich auf der Ebene des Bundes gestaltet wird.

**[Ende Kernaussagen]**

**[Kernaussagen]**

Seit 2022 sprechen sich die Stimmberechtigten – insbesondere in der Deutschschweiz und in der italienischsprachigen Schweiz – vermehrt für ein Gesundheitswesen aus, welches eher durch den Staat als den Markt gesteuert wird. Die Wunschvorstellung hat sich somit seit Beginn der 2000er-Jahre klar verändert: Zuvor wünschte sich die Bevölkerung tendenziell ein Gesundheitswesen, das durch den Markt reguliert wird. Erfahrungsgemäss ist eine solche Verschiebung die Folge eines zunehmenden Misstrauens gegenüber den Marktkräften, die Kostenproblematik marktwirtschaftlich zu lösen.

**[Ende Kernaussagen]**

**[Kernaussagen]**

Bei der Gestaltung der Krankenkassen möchten die Befragten im Grossen und Ganzen an Bewährtem festhalten. Die Kopfprämie, die durch Verbilligungen für einkommensschwächere Personen subventioniert wird, ist weiterhin klar mehrheitsfähig. Die Idee, Prämien einkommensabhängig zu gestalten, erfährt vermehrt Zuspruch – wenn auch weiterhin bei einer Minderheit der Stimmberechtigten.

**[Ende Kernaussagen]**

**[Kernaussagen]**

Das Ansehen der Pharmabranche ist in der Bevölkerung sehr hoch. Im Jahr 2024 bewerten rund drei Viertel der Befragten – was einem Höchstwert gleichkommt – die Pharmaindustrie als sehr bedeutend für den Wirtschaftsstandort Schweiz. Dies, obwohl die Medikamentenpreise seit Jahren in der Kritik stehen. Drei Viertel der Stimmberechtigten stufen die Medikamentenpreise als zu hoch ein. Um die Medikamentenkosten zu dämpfen, wurde eine Erhöhung des Selbstbehalts bei Originalpräparaten beschlossen – sofern Generika verfügbar sind. Bei den Befragten zeigt diese Änderung aktuell noch nicht die gewünschte Wirkung. Knapp zwei Drittel der Befragten bevorzugen weiterhin das Originalmedikament.

**[Ende Kernaussagen]**

**[Kernaussagen]**

Der Graben zwischen der Deutschschweiz und der Romandie wird in der Beurteilung des Gesundheitswesens tiefer. Der wahrgenommene Problemdruck in Bezug auf Kosten ist in der Romandie gegenüber der Deutschschweiz sichtbar höher. Personen aus der französischsprachigen Schweiz zeigen sich deutlich reformfreudiger als Personen aus der deutschsprachigen Schweiz. Massnahmen zur Kostensenkung – wie beispielsweise Einschränkungen bei der Wahl der Ärztin oder des Arztes und Kürzungen des Leistungskatalogs – sind bereits heute in der Romandie mehrheitsfähig. In der übrigen Schweiz herrscht hingegen ein Reformstau.

**[Ende Kernaussagen]**

[[Seite 17/19 · Druckseiten 30–31]]

## 6 Datenbasis der aktuellen Welle

Die Ergebnisse der Befragung zum Gesundheitsmonitor 2024 basieren auf einer repräsentativen Befragung von 1’200 Stimmberechtigten aus der ganzen Schweiz, welche gfs.bern im Auftrag von Interpharma durchgeführt hat. Die Befragung wurde zwischen dem 19. Februar und dem 17. März 2024 (Mean-Day: 3. März 2024) mittels persönlicher Face-to-Face-Interviews realisiert. Der jeweilige statistische Fehler für die Stichprobengrösse bei den ausgewiesenen Gruppen beträgt:

## Tabelle 1: Stichprobenfehler

Ausgewählte statistische Stichprobenfehler nach Stichprobengrösse und Basisverteilung

| Stichprobengrösse | Fehlerquote Basisverteilung 50% zu 50% | Fehlerquote Basisverteilung 20% zu 80% |
|---|---|---|
| N = 1 200 | ± 2.9 Prozentpunkte | ± 2.3 Prozentpunkte |
| N = 1 000 | ± 3.2 Prozentpunkte | ± 2.5 Prozentpunkte |
| N = 600 | ± 4.1 Prozentpunkte | ± 3.3 Prozentpunkte |
| N = 100 | ± 10.0 Prozentpunkte | ± 8.1 Prozentpunkte |
| N = 50 | ± 14.0 Prozentpunkte | ± 11.5 Prozentpunkte |

Lesebeispiel: Bei rund 1’200 Befragten und einem ausgewiesenen Wert von 50 Prozent liegt der effektive Wert bei 50 Prozent ± 2.9 Prozentpunkten, bei einem Basiswert von 20 Prozent bei 20 Prozent ± 2.3 Prozentpunkten. Dabei setzt man in der Umfrageforschung zumeist ein Sicherheitsmass von 95 Prozent, das heisst, man akzeptiert eine Irrtumswahrscheinlichkeit von 5 Prozent, dass der nachgewiesene statistische Zusammenhang so in der Bevölkerung nicht vorhanden ist.

[Hinweis Transkription: Die rechte Seitenhälfte ist leer und ohne gedruckte Seitenzahl; Druckseite 31 aus den Nachbarseiten fortgezählt.]

[leere Seite]

[[Seite 18/19 · Druckseiten 32–33]]

## 7 Anhang

## 7.1 Das Team von gfs.bern

## URS BIERI

urs.bieri@gfsbern.ch

[Bild: Porträt von Urs Bieri]

Co-Leiter und Mitglied des Verwaltungsrats gfs.bern, Politik- und Medienwissenschafter (lic. rer. soc.), Executive MBA FH in strategischem Management, Dozent am VMI der Universität Fribourg und an der ZHAW Winterthur

## Schwerpunkte

Themen- und Issue-Monitoring, Image- und Reputationsanalysen, Risikotechnologien, Abstimmungsanalysen, Kampagnenvorbereitung und -begleitung, integrierte Kommunikationsanalysen, qualitative Methoden

Publikationen in Buchform, in Sammelbänden, in Fachmagazinen, in der Tagespresse und im Internet, aktuelle Publikation: Bieri, U et al. Digitalisierung der Schweizer Demokratie, Technologische Revolution trifft auf traditionelles Meinungsbildungssystem. Vdf 2021.

## TOBIAS KELLER

tobias.keller@gfsbern.ch

[Bild: Porträt von Tobias Keller]

Projektleiter und Teamleader Data Analytics, Kommunikationswissenschafter, Dr. phil.

## Schwerpunkte

politische Kommunikation, Wahlen, Abstimmungen, (digitale) Kampagnen, Issue Monitoring, Image- und Reputationsanalysen, Medienanalysen, Digitalisierung, Social Media, computergestützte Methoden, quantitative Analysen

Publikationen in internationalen und nationalen Fachmagazinen, in der Tagespresse und im Internet

## CORINA SCHENA

corina.schena@gfsbern.ch

[Bild: Porträt von Corina Schena]

Junior Projektleiterin

## Schwerpunkte

Wahlen, Abstimmungen, Gesundheitspolitik, Gesundheitskampagnen, Image- und Reputationsanalysen, qualitative und quantitative Methoden sowie Moderation

## SARA RELLSTAB

sara.rellstab@gfsbern.ch

[Bild: Porträt von Sara Rellstab]

Data Scientist

Ökonomin PhD

## Schwerpunkte

Datenanalyse, Programmierungen, Visualisierungen, Recherchen, quantitative und qualitative Methoden

## JENNY ROBERTS

jenny.roberts@gfsbern.ch

[Bild: Porträt von Jenny Roberts]

Data Scientist (Praktikantin)

## Schwerpunkte

Datenanalyse, Programmierungen, Visualisierungen, Recherchen, quantitative und qualitative Methoden

## ROLAND REY

roland.rey@gfsbern.ch

[Bild: Porträt von Roland Rey]

Projektmitarbeiter/Administration

## Schwerpunkte

Desktop-Publishing, Visualisierungen, Projektadministration, Vortragsadministration

[[Seite 19/19 · Rückseite]]

## Interpharma

Petersgraben 35, Postfach

CH-4009 Basel

Telefon +41 (0)61 264 34 00

info@interpharma.ch

www.interpharma.ch

---

— Ende Teil 2 von 2 · Kontrollwort Teil 2: MURMELTIER-62 · DOKUMENTENDE LAV-T01 —
