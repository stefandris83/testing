# LAV-T01 · Volltext · Teil 1 von 2 (PDF-Seiten 1–9 von 19)

Studie: Das Wichtigste in Kürze zum GESUNDHEITSMONITOR 2024 – Zunehmende Reformbereitschaft in der Romandie · Quelldatei: LY-IPH.01.24.001-_-Gesundheitsmonitor-2024_d_web-07824a40.pdf · Transkript-Version 1.0 · 2026-11-05
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 2 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T01, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 1/19 · Umschlag]]

[Bild: Logo interpharma]

## Das Wichtigste in Kürze zum GESUNDHEITSMONITOR 2024

## Zunehmende Reformbereitschaft in der Romandie

[Bild: Logo gfs.bern]

## Projektteam

Urs Bieri, Co-Leiter

Tobias Keller, Projektleiter und Teamleader Data Analytics

Corina Schena, Junior Projektleiterin

Sara Rellstab, Wissenschaftliche Mitarbeiterin Data Science

Jenny Roberts, Data Scientist (Praktikantin)

[[Seite 2/19 · Druckseite 1 und unnummerierte linke Seite]]

Eine Studie im Auftrag von Interpharma.

Der Gesundheitsmonitor will die Einstellung der Schweizer Stimmberechtigten zum Gesundheitswesen zuverlässig ermitteln.

Die Repräsentativbefragung wird seit 1996 einmal jährlich durchgeführt. 2024 wurden 1’200 Stimmberechtigte in allen Sprachregionen hierfür in Face-to-Face-Interviews befragt.

Nachfolgend berichten wir über die Hauptergebnisse.

Interpharma Verband der forschenden pharmazeutischen Firmen der Schweiz

Petersgraben 35 Postfach 4009 Basel

Telefon 061 264 34 00 E-Mail info@interpharma.ch

Die Inhalte der Broschüre finden Sie auch auf der Website von Interpharma unter www.interpharma.ch. Grafiken der jeweils aktuellsten Version können Sie zu Ihrer freien Verwendung unter Quellenangabe herunterladen.

Disponible en traduction française

© Interpharma, 2024, Basel
Abdruck mit Quellenangabe erwünscht

## Inhaltsverzeichnis

| Kapitel | Titel | Seite |
|---|---|---|
| 1 | Vorwort | 2 |
| 2 | Executive Summary | 4 |
| 3 | Schwerpunktthemen 2024 | 5 |
| 4 | Ausgewählte Trendanalysen | 22 |
| 4.1 | Pharmaindustrie | 22 |
| 4.2 | Medikamente | 24 |
| 5 | Thesen | 28 |
| 6 | Datenbasis der aktuellen Welle | 30 |
| 7 | Anhang | 32 |
| 7.1 | gfs.bern-Team | 32 |

[[Seite 3/19 · Druckseiten 2–3]]

## 1 Vorwort

Sehr geehrte Leserinnen und Leser

[Bild: Porträt von Dr. René Buholzer]

Innovative Forschung ist die Grundlage eines fortschrittlichen, qualitativ hochwertigen Gesundheitswesens und somit einer gesunden Bevölkerung – sowohl heute als auch in Zukunft. Seine hohe Qualität wird auch von den Stimmberechtigten erkannt und geschätzt. So empfinden knapp drei Viertel der Bürgerinnen und Bürger das Gesundheitswesen als «gut» oder «sehr gut» – ein Höchstwert seit Erhebungsbeginn. Eine erstklassige Gesundheitsversorgung ist jedoch keine Selbstverständlichkeit und mit hohen Forschungs- und Entwicklungskosten verbunden. Eine Mehrheit der Bevölkerung erkennt die Relevanz der Finanzierung solcher Bemühungen und schreibt der Pharmaindustrie nach wie vor eine hohe Kompetenz zu. Nichtsdestotrotz stellen die Gesundheitskosten für einen Teil der Menschen in der Schweiz eine Belastung dar. Diese Wahrnehmung ist besonders stark im Zusammenhang mit dem Anstieg der Krankenkassenprämien zu sehen. Zudem ist sie in der Romandie stärker ausgeprägt als in den anderen Landesteilen. Obwohl die Thematik in den aktuellen politischen Debatten stark hervorgehoben wird, braucht es einen differenzierteren Blick: Betrachtet man die letzten zehn Jahre, ist faktisch kein Anstieg der wahrgenommenen Belastung bei den Befragten zu beobachten. Auffällig ist hier der «Rösti-Graben», der auch bei anderen Gesundheitsfragen erkennbar ist. Trotz Kostenbelastung im Gesundheitswesen sind die Bürgerinnen und Bürger in der Schweiz nicht bereit, auf Leistungen zu verzichten, und gehen von einem weiteren Anstieg der Gesundheitskosten aus. Betrachtet man jedoch die Romandie isoliert, ist sowohl eine optimistischere Einstellung gegenüber der Kostenentwicklung als auch eine höhere Kompromissbereitschaft bei einem möglichen Leistungsabbau zu verzeichnen. Gesamtschweizerisch gesehen reicht dies aber nicht, um einen mehrheitsfähigen Konsens zu finden. Es ist nun an der Politik, konstruktive Lösungen über die Sprachgrenze hinaus zu präsentieren.

Eine nachhaltig angelegte Gesundheitsversorgung sollte alle Patientinnen und Patienten sowie die Leistungen in den Mittelpunkt stellen und auf ein ausgewogenes Verhältnis von Kosten und Nutzen achten. Interpharma hat hierfür bereits zahlreiche Lösungsansätze skizziert. Allen Patientinnen und Patienten muss ein unverzüglicher Zugang zu innovativen Arzneimitteln ab dem Tag der Erteilung der Marktzulassung garantiert werden. In diesem Punkt hat sich bis heute zu wenig getan: Aufgrund eines veralteten Preisbildungssystems für Medikamente erreichte die Verzögerung von der Marktzulassung bis zur Aufnahme in die Spezialitätenliste, welche eine Erstattung durch die Krankenkasse ermöglicht, im Jahr 2023 ein ernüchterndes Allzeithoch von 301 Tagen im Median. Die Modernisierung des Preisbildungssystems für innovative Arzneimittel und die Förderung der Digitalisierung im Gesundheitswesen bieten Chancen, um das Gesundheitswesen fit für die Zukunft zu machen. Interpharma fordert, dass die Politik die Anliegen der Bevölkerung ernst nimmt. Eine gemeinsame Vision muss erarbeitet und wirkungsvolle Strategien müssen umgesetzt werden – denn nur so kann die Qualität des Gesundheitswesens für betroffene Patientinnen und Patienten nachhaltig sichergestellt werden. Genau dafür setzen wir uns tagtäglich ein.

[Bild: Unterschrift R. Buholzer]

Dr. René Buholzer

Geschäftsführer und Delegierter des Vorstandes

[[Seite 4/19 · Druckseiten 4–5]]

## 2 Executive Summary

## Trotz hoher Kosten keine Einschränkungen gewünscht

Eine hohe Leistungsfülle ist für die Mehrheit der Befragten wichtiger als die Senkung der Gesundheitskosten. Das Schweizer Gesundheitswesen soll durch eine obligatorische Grundversicherung geprägt sein, die alle Leistungen abdeckt, gemeinwohlorientiert, qualitativ hochwertig und quantitativ umfangreich ist.

## Befragte wünschen sich mehr Staat und weniger Markt

In den letzten Jahren hat sich die Wunschvorstellung hinsichtlich der Aufgabenteilung zwischen Markt und Staat innerhalb des Gesundheitswesens verändert. Die Befragten – allen voran in der Deutschschweiz und in der italienischsprachigen Schweiz – sprechen sich aktuell für ein Gesundheitswesen aus, das vermehrt durch den Staat und weniger durch den Markt geregelt wird. In der Romandie halten sich Staat und Markt die Waage.

## Positive Wahrnehmung der Pharmabranche

Trotz der langjährigen Kritik an den Medikamentenpreisen, geniesst die Pharmabranche in der Bevölkerung ein sehr hohes Ansehen. Sie wird als äusserst kompetente Akteurin im Gesundheitswesen anerkannt. Zudem stufen die Befragten die Pharmaindustrie als wichtige Arbeitgeberin, Exportmotor und bedeutsam für den Wirtschaftsstandort Schweiz ein. Darüber hinaus sind die Befragten der Meinung, dass die Schweizer Pharmaindustrie im Ausland einen guten Ruf geniesst.

## Zunehmende Unterschiede zwischen Deutschschweiz und Romandie

Das Schweizer Gesundheitswesen wird in den Sprachregionen unterschiedlich wahrgenommen. Die Beurteilungen in den deutsch- und italienischsprachigen Landesteilen fallen hinsichtlich der meisten Dimensionen beinahe identisch aus. In der Romandie zeigt sich hingegen ein anderes Bild: Der wahrgenommene Problemdruck in Bezug auf die Kosten ist deutlich höher. Zudem zeigen sich Personen aus der französischsprachigen Schweiz deutlich reformfreudiger als Personen aus der übrigen Schweiz. Leistungseinschränkungen zugunsten einer Kostensenkung sind in der Romandie mehrheitsfähig. Demgegenüber zeichnet sich in der übrigen Schweiz ein Reformstau ab.

## 3 Schwerpunktthemen 2024

Rund drei Viertel der Befragten beurteilen die Qualität des Schweizer Gesundheitswesens als sehr gut oder gut (73%). Weitere 24 Prozent stufen das Schweizer Gesundheitswesen als eher gut ein. Negative Äusserungen sind weiterhin beinahe nicht vorhanden (3%). Die Bewertung «sehr gut» vergeben 25 Prozent der Befragten. Dieser Wert ist – wie bereits im Jahr 2022 – der höchste seit Erhebungsbeginn. Die Stimmberechtigten sind somit mit der Qualität des Gesundheitswesens äusserst zufrieden.

**[Kernaussagen]**

Bei am Gesundheitswesen interessierten Personen, fällt die Bewertung stärker zugunsten einer sehr guten Qualität aus. Auch Personen, die über 60 Jahre alt sind oder in ländlichen Gebieten wohnen, vergeben tendenziell häufiger die höchstmögliche Bewertung.

**[Ende Kernaussagen]**

**[Grafik 1] Qualität Gesundheitswesen**

Frage: «Wie schätzen Sie ganz allgemein die Qualität des schweizerischen Gesundheitswesens ein? Glauben Sie, es ist qualitativ sehr gut, gut, eher gut, eher schlecht, schlecht oder sehr schlecht?»

Darstellung: gestapeltes Flächendiagramm, 2015–2024, In % Stimmberechtigter. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: nicht beschriftet, berechnet aus den Vektorflächen der PDF mit vektoren.py und grafikwerte.py. Kumulative Flächengrenzen werden an der 0–100-Skala kalibriert und voneinander subtrahiert. Ausgabe als ca. auf ganze Prozentpunkte, Rundungsgenauigkeit ± 0.5 Prozentpunkte. Alle Zeilensummen ergeben 100. Spalten in Legendenreihenfolge.

| Jahr | Sehr schlecht | Schlecht | Eher schlecht | Weiss nicht / keine Antwort | Eher gut | Gut | Sehr gut |
|---|---|---|---|---|---|---|---|
| 2015 | ca. 0 | ca. 1 | ca. 2 | ca. 1 | ca. 27 | ca. 48 | ca. 21 |
| 2016 | ca. 1 | ca. 1 | ca. 1 | ca. 0 | ca. 22 | ca. 51 | ca. 24 |
| 2017 | ca. 0 | ca. 0 | ca. 2 | ca. 0 | ca. 28 | ca. 51 | ca. 19 |
| 2018 | ca. 0 | ca. 0 | ca. 0 | ca. 1 | ca. 19 | ca. 57 | ca. 23 |
| 2019 | ca. 0 | ca. 0 | ca. 1 | ca. 1 | ca. 37 | ca. 41 | ca. 20 |
| 2020 | ca. 0 | ca. 0 | ca. 2 | ca. 1 | ca. 32 | ca. 49 | ca. 16 |
| 2021 | ca. 0 | ca. 0 | ca. 3 | ca. 0 | ca. 32 | ca. 48 | ca. 17 |
| 2022 | ca. 0 | ca. 1 | ca. 3 | ca. 0 | ca. 31 | ca. 40 | ca. 25 |
| 2023 | ca. 0 | ca. 0 | ca. 1 | ca. 0 | ca. 26 | ca. 57 | ca. 16 |
| 2024 | ca. 0 | ca. 1 | ca. 2 | ca. 0 | ca. 24 | ca. 48 | ca. 25 |

[Hinweis Transkription: Gegenprüfung 2024 am Fliesstext: gut/sehr gut 73%, eher gut 24%, negative Äusserungen 3%, sehr gut 25%. Sehr gut 2022 ebenfalls 25%. Die aus der Vektorgrafik berechneten Werte stimmen damit überein.]

© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 1’200)

**[Ende Grafik 1]**

[[Seite 5/19 · Druckseiten 6–7]]

Mit Blick auf die Sprachregionen der Schweiz zeigen sich Unterschiede: Während Personen aus der Deutschschweiz und der italienischsprachigen Schweiz die Qualität des Gesundheitswesens klar mehrheitlich mit «gut» bis «sehr gut» bewerten (DCH: 83%, ICH: 76%), stufen Personen aus der Romandie die Qualität des Gesundheitswesens verhältnismässig tiefer ein (46% gut/sehr gut).

Die Stimmberechtigten wünschen sich weiterhin Transparenz seitens der Leistungserbringer (81%). Sie möchten die spezifischen Qualitätsdaten des Erbringers oder der Erbringerin kennen, bevor sie sich für die Behandlung entscheiden (90%). Ebenfalls hohen Zuspruch erhalten der allgemeine öffentliche Zugang zu Qualitätsdaten (79%) und die Überweisung der Patientinnen und Patienten nach Überprüfung der Qualitätsdaten durch die erstbehandelnde Ärztin oder den erstbehandelnden Arzt (77%). Die Bevölkerung erhofft sich durch die Sichtung der Qualitätsdaten der Leistungserbringer eine Verbesserung der Qualität der medizinischen Leistungen. Rund die Hälfte der Befragten ist der Meinung, qualitativ gute Erbringer soll die öffentliche Hand belohnen (51%). Eine ausschliessliche Finanzierung von Behandlungen mit hoher Qualität durch die Krankenkassen findet unter den Befragten keine Mehrheit (37%).

Zusammengefasst möchten die Befragten von den erhobenen Qualitätsdaten profitieren und erkennen den möglichen Nutzen. Die Finanzierung von Behandlungen von tiefer Qualität soll aber weiterhin bestehen bleiben.

**[Grafik 2] Qualität Gesundheitswesen: Romandie**

Frage: «Wie schätzen Sie ganz allgemein die Qualität des schweizerischen Gesundheitswesens ein? Glauben Sie, es ist qualitativ sehr gut, gut, eher gut, eher schlecht, schlecht oder sehr schlecht?»

Darstellung: gestapeltes Flächendiagramm, 2015–2024, In % Stimmberechtigter Romandie. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: nicht beschriftet, berechnet aus den Vektorflächen der PDF mit vektoren.py und grafikwerte.py. Kumulative Flächengrenzen werden an der 0–100-Skala kalibriert und voneinander subtrahiert. Ausgabe als ca. auf ganze Prozentpunkte, Rundungsgenauigkeit ± 0.5 Prozentpunkte. Alle Zeilensummen ergeben 100. Spalten in Legendenreihenfolge.

| Jahr | Sehr schlecht | Schlecht | Eher schlecht | Weiss nicht / keine Antwort | Eher gut | Gut | Sehr gut |
|---|---|---|---|---|---|---|---|
| 2015 | ca. 0 | ca. 1 | ca. 2 | ca. 0 | ca. 37 | ca. 42 | ca. 18 |
| 2016 | ca. 1 | ca. 1 | ca. 2 | ca. 0 | ca. 35 | ca. 41 | ca. 20 |
| 2017 | ca. 0 | ca. 1 | ca. 2 | ca. 0 | ca. 35 | ca. 47 | ca. 15 |
| 2018 | ca. 0 | ca. 0 | ca. 0 | ca. 1 | ca. 17 | ca. 70 | ca. 12 |
| 2019 | ca. 0 | ca. 1 | ca. 2 | ca. 3 | ca. 46 | ca. 37 | ca. 11 |
| 2020 | ca. 1 | ca. 0 | ca. 8 | ca. 0 | ca. 27 | ca. 52 | ca. 12 |
| 2021 | ca. 0 | ca. 2 | ca. 8 | ca. 0 | ca. 39 | ca. 37 | ca. 14 |
| 2022 | ca. 1 | ca. 2 | ca. 6 | ca. 0 | ca. 30 | ca. 37 | ca. 24 |
| 2023 | ca. 0 | ca. 0 | ca. 3 | ca. 1 | ca. 28 | ca. 43 | ca. 25 |
| 2024 | ca. 0 | ca. 2 | ca. 8 | ca. 1 | ca. 42 | ca. 32 | ca. 15 |

[Hinweis Transkription: Abweichung zwischen Fliesstext und Vektorgrafik im Original: Der Fliesstext derselben PDF-Seite nennt 46% gut/sehr gut in der Romandie. Die gezeichneten Flächen für 2024 ergeben berechnet ca. 32% gut und ca. 15% sehr gut, zusammen ca. 47%. Die Textangabe wird nicht korrigiert. Diese Abweichung ist zur menschlichen Sichtprüfung vorgemerkt.]

© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 300)

**[Ende Grafik 2]**

**[Grafik 3] Aussagen zur Qualitätsdaten**

Frage: «Reden wir nun über die Qualität unseres Gesundheitswesens. Es gibt verschiedene Daten, mit denen die Qualität unseres Gesundheitswesens sichtbar gemacht werden kann, zum Beispiel wie häufig es nach einer Operation zu Komplikationen kommt. Sagen Sie mir bitte jeweils, ob Sie mit folgenden Aussagen sehr einverstanden, eher, eher nicht oder gar nicht einverstanden sind.»

bis 2018: Spitäler und Klinken, ab 2019: Gesundheitswesen

Darstellung: Liniendiagramm, 2015–2024, In % Stimmberechtigter; Sehr/eher einverstanden. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Die übrigen dargestellten Jahreswerte sind mit vektoren.py und grafikwerte.py aus den Vektorpfaden berechnet: lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf ganze Prozentpunkte, Rundungsgenauigkeit ± 0.5 Prozentpunkte. Keine interpolierten Zusatzpunkte.

| Jahr | Qualitätsdaten kennen vor Entscheid | Öffentliche Qualitätsdaten erhöhen Qualität | Überweisung der Patienten nach Qualitätsprüfung | Gute Erbringer von medizinischer Leistung finanziell belohnen | Nur Behandlungen mit hoher Qualität bezahlen | Transparenz verwirrt |
|---|---|---|---|---|---|---|
| 2015 | ca. 85 | ca. 75 | ca. 72 | ca. 41 | ca. 31 | ca. 45 |
| 2016 | ca. 82 | ca. 74 | ca. 73 | ca. 62 | ca. 46 | ca. 59 |
| 2017 | ca. 82 | ca. 73 | ca. 68 | ca. 61 | ca. 49 | ca. 60 |
| 2018 | ca. 73 | ca. 76 | ca. 63 | ca. 48 | ca. 35 | ca. 39 |
| 2019 | ca. 88 | ca. 72 | ca. 75 | ca. 58 | ca. 45 | ca. 41 |
| 2020 | ca. 91 | ca. 86 | ca. 89 | ca. 55 | ca. 53 | ca. 27 |
| 2021 | ca. 92 | ca. 86 | ca. 78 | ca. 54 | ca. 41 | ca. 31 |
| 2022 | ca. 90 | ca. 76 | ca. 78 | ca. 43 | ca. 31 | ca. 33 |
| 2023 | ca. 93 | ca. 91 | ca. 82 | ca. 50 | ca. 38 | ca. 19 |
| 2024 (beschriftet) | 90 | 79 | 77 | 51 | 37 | 19 |

[Hinweis Transkription: Die beschrifteten Werte 2024 stimmen mit den entsprechenden Angaben des Fliesstexts überein. Die Textangabe 81% zur Transparenz ist keine zusätzliche Serie dieser Grafik.]

© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 1’200)

**[Ende Grafik 3]**

[[Seite 6/19 · Druckseiten 8–9]]

Ein hoher Qualitätsstandard ist mit hohen Kosten verbunden. In der Schweiz steigen die Kosten für das Gesundheitswesen über die Jahre an. Dies zeigt sich sowohl am zunehmenden prozentualen Anteil des Bruttoinlandprodukts (BIP) als auch an den steigenden Ausgaben pro Kopf und Monat[1]. Die Kostenbelastung pro Kopf setzt sich hierbei aus den Prämien der obligatorischen Krankenpflegeversicherung (OKP), den Steuern und den selbst zu tragenden Kosten zusammen.[2] Gemessen am BIP ist die Schweiz im Vergleich mit anderen Ländern hinsichtlich der Gesundheitskosten jedoch keineswegs die Spitzenreiterin. In den USA, Deutschland, Frankreich, Japan, Österreich und Grossbritannien sind die Ausgaben im Gesundheitswesen höher als in der Schweiz.[3]

Diese finanzielle Belastung nimmt die Bevölkerung auch in ihrem Alltag wahr: Knapp ein Drittel bekundet Mühe, die Steuern zu begleichen (29%). Die Krankenkassenprämien (27%), Arztrechnungen und Ausgaben für Medikamente (23%) sowie Zahnarztrechnungen (23%) zu bezahlen, ist für rund ein Viertel der Bevölkerung ein dauerhaftes oder gelegentliches Problem. Neben der finanziellen Belastung durch das Gesundheitswesen belasten auch weitere Ausgabenbereiche das Haushaltseinkommen: Die Miete für die Wohnung resp. die Zinsen für das Wohneigentum (18%) und sonstige Versicherungen (18%) belasten knapp ein Fünftel der Befragten stark.

Langfristig betrachtet, ist die wahrgenommene Kostenbelastung in der Deutschschweiz und in der italienischsprachigen Schweiz unterdurchschnittlich. Hingegen ist in der französischsprachigen Schweiz die Wahrnehmung der finanziellen Probleme in allen Ausgabenbereichen deutlich stärker vorhanden. Besonders spürbar ist die Situation bei den Steuern und den Krankenkassenprämien. Bereits in der Vergangenheit zeigten sich hinsichtlich des Problemdrucks sprachregionale Unterschiede. Seit 2021 steigt die wahrgenommene finanzielle Belastung in der Romandie im Vergleich zur Deutschschweiz und zur Svizzera italiana deutlich stärker an.

[Fussnote 1] BFS, Ausgaben für das Gesundheitswesen: https://www.bfs.admin.ch/bfs/de/home/statistiken/querschnittsthemen/wohlfahrtsmessung/alle-indikatoren/gesellschaft/gesundheitsausgaben.assetdetail.24525224.html

[Fussnote 2] BFS, Kosten und Finanzierung des Gesundheitssystems im Jahr 2021: https://www.bfs.admin.ch/asset/de/24468750

[Fussnote 3] OECD (2024), Health spending (indicator): https://data.oecd.org/healthres/health-spending.

**[Grafik 4] Dauerhaftes oder gelegentliches Problem**

Frage: «Sagen Sie mir bitte für jeden der folgenden Ausgabenbereiche Ihres Haushalts, ob er für Sie ein dauerhaftes oder gelegentliches Problem ist, welche Ausgaben halten Sie für hoch, aber tragbar und welche Ausgaben sind für Sie gar kein Problem?»

Darstellung: Liniendiagramm, In % Stimmberechtigter; Dauerhaftes/gelegentliches Problem. Gleitender Mittelwert über 3 Jahre. Achsenbeschriftungen: 97, 00, 02, 04, 06, 08, 10, 12, 14, 16, 18, 20, 22, 24; 0, 20, 40, 60, 80, 100. Dargestellte Jahresstützpunkte: 1998–2024; Zahnarztrechnungen erst ab 2003 (– = kein dargestellter Punkt). Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Übrige dargestellte Jahreswerte berechnet aus den Vektorpfaden der PDF mit vektoren.py und grafikwerte.py; lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf ganze Prozentpunkte (Rundungsgenauigkeit ± 0.5 Prozentpunkte). Es werden nur tatsächlich gezeichnete Stützpunkte übernommen, keine interpolierten Zusatzpunkte.

| Jahr | Steuern | Krankenkassenprämien | Zahnarztrechnungen | Arztrechnungen, Ausgaben für Medikamente | Sonstige Versicherungen | Miete für Wohnung/Zinsen für Wohneigentum |
|---|---|---|---|---|---|---|
| 1998 | ca. 37 | ca. 33 | – | ca. 24 | ca. 23 | ca. 16 |
| 1999 | ca. 37 | ca. 34 | – | ca. 25 | ca. 24 | ca. 17 |
| 2000 | ca. 36 | ca. 33 | – | ca. 23 | ca. 23 | ca. 15 |
| 2001 | ca. 38 | ca. 35 | – | ca. 24 | ca. 24 | ca. 15 |
| 2002 | ca. 36 | ca. 38 | – | ca. 21 | ca. 22 | ca. 13 |
| 2003 | ca. 40 | ca. 44 | ca. 36 | ca. 24 | ca. 25 | ca. 17 |
| 2004 | ca. 41 | ca. 48 | ca. 37 | ca. 25 | ca. 25 | ca. 17 |
| 2005 | ca. 44 | ca. 48 | ca. 39 | ca. 30 | ca. 27 | ca. 19 |
| 2006 | ca. 44 | ca. 48 | ca. 41 | ca. 31 | ca. 27 | ca. 18 |
| 2007 | ca. 42 | ca. 45 | ca. 40 | ca. 29 | ca. 27 | ca. 19 |
| 2008 | ca. 44 | ca. 46 | ca. 38 | ca. 28 | ca. 29 | ca. 22 |
| 2009 | ca. 44 | ca. 47 | ca. 40 | ca. 26 | ca. 28 | ca. 24 |
| 2010 | ca. 40 | ca. 50 | ca. 37 | ca. 24 | ca. 26 | ca. 23 |
| 2011 | ca. 34 | ca. 52 | ca. 34 | ca. 22 | ca. 25 | ca. 21 |
| 2012 | ca. 32 | ca. 50 | ca. 32 | ca. 22 | ca. 23 | ca. 20 |
| 2013 | ca. 40 | ca. 47 | ca. 41 | ca. 26 | ca. 24 | ca. 24 |
| 2014 | ca. 45 | ca. 43 | ca. 42 | ca. 28 | ca. 21 | ca. 24 |
| 2015 | ca. 48 | ca. 41 | ca. 42 | ca. 29 | ca. 22 | ca. 24 |
| 2016 | ca. 46 | ca. 40 | ca. 38 | ca. 31 | ca. 23 | ca. 24 |
| 2017 | ca. 43 | ca. 38 | ca. 38 | ca. 30 | ca. 22 | ca. 26 |
| 2018 | ca. 33 | ca. 30 | ca. 36 | ca. 25 | ca. 17 | ca. 21 |
| 2019 | ca. 27 | ca. 28 | ca. 30 | ca. 19 | ca. 10 | ca. 16 |
| 2020 | ca. 20 | ca. 23 | ca. 26 | ca. 15 | ca. 9 | ca. 11 |
| 2021 | ca. 23 | ca. 28 | ca. 23 | ca. 16 | ca. 10 | ca. 14 |
| 2022 | ca. 22 | ca. 22 | ca. 22 | ca. 15 | ca. 10 | ca. 13 |
| 2023 | ca. 24 | ca. 26 | ca. 23 | ca. 18 | ca. 11 | ca. 13 |
| 2024 (beschriftet) | 24 | 24 | 23 | 21 | 14 | 13 |

[Hinweis Transkription: Der Fliesstext nennt die aktuellen Befragungswerte 29%, 27%, 23%, 23%, 18% und 18%. Die Grafik bezeichnet ihre Werte ausdrücklich als gleitenden Mittelwert über 3 Jahre und beschriftet für 2024 24, 24, 23, 21, 14 und 13 in der Reihenfolge der Legende. Die unterschiedlichen Zeitbezüge werden nicht gleichgesetzt.]



© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 1’180)

**[Ende Grafik 4]**

**[Grafik 5] Dauerhaftes oder gelegentliches Problem: Romandie**

Frage: «Sagen Sie mir bitte für jeden der folgenden Ausgabenbereiche Ihres Haushalts, ob er für Sie ein dauerhaftes oder gelegentliches Problem ist. Welche Ausgaben halten Sie für hoch, aber tragbar und welche Ausgaben sind für Sie gar kein Problem?»

Darstellung: Liniendiagramm, In % Stimmberechtigter; Dauerhaftes/gelegentliches Problem. Gleitender Mittelwert über 3 Jahre. Achsenbeschriftungen: 97, 00, 02, 04, 06, 08, 10, 12, 14, 16, 18, 20, 22, 24; 0, 20, 40, 60, 80, 100. Dargestellte Jahresstützpunkte: 1998–2024; Zahnarztrechnungen erst ab 2003 (– = kein dargestellter Punkt). Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Übrige dargestellte Jahreswerte berechnet aus den Vektorpfaden der PDF mit vektoren.py und grafikwerte.py; lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf ganze Prozentpunkte (Rundungsgenauigkeit ± 0.5 Prozentpunkte). Es werden nur tatsächlich gezeichnete Stützpunkte übernommen, keine interpolierten Zusatzpunkte.

| Jahr | Krankenkassenprämien | Steuern | Arztrechnungen, Ausgaben für Medikamente | Zahnarztrechnungen | Sonstige Versicherungen | Miete für Wohnung/Zinsen für Wohneigentum |
|---|---|---|---|---|---|---|
| 1998 | ca. 45 | ca. 49 | ca. 38 | – | ca. 36 | ca. 28 |
| 1999 | ca. 47 | ca. 53 | ca. 41 | – | ca. 38 | ca. 29 |
| 2000 | ca. 50 | ca. 54 | ca. 42 | – | ca. 39 | ca. 26 |
| 2001 | ca. 52 | ca. 56 | ca. 44 | – | ca. 41 | ca. 23 |
| 2002 | ca. 50 | ca. 53 | ca. 41 | – | ca. 39 | ca. 19 |
| 2003 | ca. 57 | ca. 58 | ca. 43 | ca. 54 | ca. 41 | ca. 26 |
| 2004 | ca. 63 | ca. 63 | ca. 45 | ca. 57 | ca. 46 | ca. 30 |
| 2005 | ca. 73 | ca. 71 | ca. 54 | ca. 58 | ca. 55 | ca. 38 |
| 2006 | ca. 69 | ca. 68 | ca. 53 | ca. 60 | ca. 55 | ca. 36 |
| 2007 | ca. 71 | ca. 68 | ca. 56 | ca. 63 | ca. 58 | ca. 42 |
| 2008 | ca. 67 | ca. 67 | ca. 55 | ca. 61 | ca. 56 | ca. 44 |
| 2009 | ca. 72 | ca. 70 | ca. 55 | ca. 61 | ca. 58 | ca. 50 |
| 2010 | ca. 71 | ca. 65 | ca. 51 | ca. 56 | ca. 56 | ca. 47 |
| 2011 | ca. 71 | ca. 61 | ca. 49 | ca. 55 | ca. 56 | ca. 43 |
| 2012 | ca. 65 | ca. 54 | ca. 49 | ca. 54 | ca. 50 | ca. 38 |
| 2013 | ca. 58 | ca. 55 | ca. 47 | ca. 55 | ca. 42 | ca. 38 |
| 2014 | ca. 53 | ca. 54 | ca. 46 | ca. 53 | ca. 35 | ca. 38 |
| 2015 | ca. 49 | ca. 54 | ca. 45 | ca. 49 | ca. 33 | ca. 37 |
| 2016 | ca. 45 | ca. 53 | ca. 49 | ca. 48 | ca. 32 | ca. 35 |
| 2017 | ca. 43 | ca. 50 | ca. 48 | ca. 48 | ca. 29 | ca. 33 |
| 2018 | ca. 39 | ca. 44 | ca. 38 | ca. 47 | ca. 24 | ca. 31 |
| 2019 | ca. 36 | ca. 35 | ca. 29 | ca. 42 | ca. 17 | ca. 23 |
| 2020 | ca. 31 | ca. 31 | ca. 25 | ca. 41 | ca. 20 | ca. 22 |
| 2021 | ca. 45 | ca. 47 | ca. 35 | ca. 40 | ca. 25 | ca. 34 |
| 2022 | ca. 49 | ca. 55 | ca. 43 | ca. 46 | ca. 32 | ca. 42 |
| 2023 | ca. 64 | ca. 61 | ca. 56 | ca. 52 | ca. 39 | ca. 47 |
| 2024 (beschriftet) | 65 | 63 | 60 | 57 | 50 | 45 |



© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 300)

**[Ende Grafik 5]**

[[Seite 7/19 · Druckseiten 10–11]]

Im Vergleich zur Befragung im vergangenen Jahr hat die wahrgenommene finanzielle Belastung durch Steuern (+9%P), Wohnkosten (+8%P) und sonstige Versicherungen (+4%P) zugenommen. Die anderen Ausgabenbereiche werden als stabil eingestuft. Die Werte, die zu Beginn der Studie 1996 erhoben wurden, relativieren jedoch den aktuellen Problemdruck. Zu Beginn der 2000er-Jahre stieg die Kostenbelastung der Befragten stark an. Die Krankenkassenprämien fanden rund um das Jahr 2011 ihren Höhepunkt. Rund die Hälfte der Befragten bekundete gelegentlich oder dauerhaft Mühe bei der Begleichung der Prämien. Seit 2018 ist die Anzahl der Personen, die ein Problem mit der Bezahlung der Prämien haben, auf weniger als ein Drittel gesunken. Dennoch ist die hohe finanzielle Belastung nach wie vor ein Thema in der Öffentlichkeit. Inwiefern sich die wahrgenommene Belastung mit der tatsächlichen Belastung deckt, kann in dieser Untersuchung nicht abschliessend dargelegt werden.

Trotz der finanziellen Belastung durch die hohen Gesundheitskosten möchte die Bevölkerung nicht auf den vorherrschenden Leistungsstandard verzichten. Die Wertvorstellungen rund um das Gesundheitswesen bleiben überwiegend stabil: Die Qualitäts- und Quantitätsorientierung sowie den freien Zugang zu Medikamenten bevorzugt die Bevölkerung gegenüber der Kostenorientierung. Weiterhin ist die freie Arztwahl ein klar vorhandener Wunsch. Zudem nimmt die Bevölkerung den Staat (vs. Markt) und den Bund (vs. Kantone) in die Verantwortung. Sie wünschen sich tendenziell eher ein Gesundheitswesen, das staatlich geregelt ist und wo der Bund die Entscheide trifft. Die Gemeinschaftsverantwortung wird über die Einzelverantwortung gestellt. Darüber hinaus wünschen sich die Stimmberechtigten eine Grundversicherung, die alle Leistungen abdeckt und nicht nur die vorwiegend hohen Risiken.

Die ideale Ausgestaltung des Gesundheitswesens wird über die Sprachregionen hinweg abweichend beurteilt. In der deutschsprachigen und der italienischsprachigen Schweiz teilen die Befragten grösstenteils ihre Wunschvorstellungen. Personen aus der Romandie wünschen sich hingegen eher ein Gesundheitswesen, das durch die Kantone gestaltet wird, verhältnismässig mehr marktwirtschaftliche Züge hat und vorwiegend die hohen Risiken deckt. Zudem werden Einschränkungen bei der Wahl der Ärztin oder des Arztes deutlich weniger kritisch bewertet. Das Kostenbewusstsein ist stärker ausgeprägt als in der übrigen Schweiz.

**[Grafik 6] Wunschvorstellung Gesundheitswesen in der Schweiz**

Frage: «Bitte sagen Sie mir, was für ein Gesundheitswesen Sie sich in der Schweiz wünschen. Wenn Sie mit dem ersten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 1 oder eine Zahl nahe bei 1. Wenn Sie mit dem zweiten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 6 oder eine Zahl nahe bei 6.»

Darstellung: Liniendiagramm, 2015–2024, in Mittelwerten Stimmberechtigter; Werte 1–3 respektive 4–6. Achse: 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5. Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Übrige dargestellte Jahreswerte berechnet aus den Vektorpfaden der PDF mit vektoren.py und grafikwerte.py; lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf eine Dezimalstelle (Rundungsgenauigkeit ± 0.05 Skalenpunkte). Zugang zu Medikamenten (vs. Kosten) ist erst ab 2019 dargestellt; – = kein dargestellter Punkt. Keine interpolierten Zusatzpunkte.

| Jahr | Risiko (vs. sämtliche Leistungen) | Markt (vs. Staat) | Kantone (vs. Bund) | Gemeinschaftsverantwortung (vs. Eigenverantwortung) | Quantität Leistungen (vs. Kosten) | Zugang zu Medikamenten (vs. Kosten) | Qualität Leistungen (vs. Kosten) | Freie Arztwahl (vs. vorgegebene Arztwahl) |
|---|---|---|---|---|---|---|---|---|
| 2015 | ca. 3.3 | ca. 3.2 | ca. 3.1 | ca. 3.2 | ca. 2.4 | – | ca. 2.1 | ca. 2.1 |
| 2016 | ca. 3.6 | ca. 3.0 | ca. 3.0 | ca. 3.3 | ca. 2.8 | – | ca. 2.3 | ca. 2.5 |
| 2017 | ca. 3.8 | ca. 3.3 | ca. 3.5 | ca. 3.3 | ca. 2.6 | – | ca. 2.3 | ca. 2.4 |
| 2018 | ca. 4.4 | ca. 3.3 | ca. 3.6 | ca. 3.6 | ca. 2.3 | – | ca. 1.9 | ca. 2.0 |
| 2019 | ca. 3.7 | ca. 3.6 | ca. 3.5 | ca. 3.1 | ca. 2.6 | ca. 2.1 | ca. 2.2 | ca. 2.1 |
| 2020 | ca. 4.0 | ca. 3.5 | ca. 3.9 | ca. 4.0 | ca. 2.4 | ca. 2.2 | ca. 2.3 | ca. 2.1 |
| 2021 | ca. 4.1 | ca. 3.5 | ca. 3.5 | ca. 3.1 | ca. 2.3 | ca. 2.2 | ca. 2.2 | ca. 2.3 |
| 2022 | ca. 3.9 | ca. 3.6 | ca. 3.6 | ca. 3.1 | ca. 2.3 | ca. 2.3 | ca. 2.2 | ca. 2.2 |
| 2023 | ca. 4.3 | ca. 3.9 | ca. 3.9 | ca. 2.8 | ca. 2.3 | ca. 2.0 | ca. 1.9 | ca. 2.0 |
| 2024 (beschriftet) | 4.3 | 3.9 | 3.8 | 2.9 | 2.2 | 2.2 | 2.0 | 2.0 |



© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 1’170)

**[Ende Grafik 6]**

**[Grafik 7] Wunschvorstellung Gesundheitswesen in der Schweiz: Romandie**

Frage: «Bitte sagen Sie mir, was für ein Gesundheitswesen Sie sich in der Schweiz wünschen. Wenn Sie mit dem ersten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 1 oder eine Zahl nahe bei 1. Wenn Sie mit dem zweiten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 6 oder eine Zahl nahe bei 6.»

Darstellung: Liniendiagramm, 2015–2024, in Mittelwerten Stimmberechtigter Romandie; Werte 1–3 respektive 4–6. Achse: 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5. Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Übrige dargestellte Jahreswerte berechnet aus den Vektorpfaden der PDF mit vektoren.py und grafikwerte.py; lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf eine Dezimalstelle (Rundungsgenauigkeit ± 0.05 Skalenpunkte). Zugang zu Medikamenten (vs. Kosten) ist erst ab 2019 dargestellt; – = kein dargestellter Punkt. Keine interpolierten Zusatzpunkte.

| Jahr | Markt (vs. Staat) | Risiko (vs. sämtliche Leistungen) | Kantone (vs. Bund) | Gemeinschaftsverantwortung (vs. Eigenverantwortung) | Zugang zu Medikamenten (vs. Kosten) | Quantität Leistungen (vs. Kosten) | Qualität Leistungen (vs. Kosten) | Freie Arztwahl (vs. vorgegebene Arztwahl) |
|---|---|---|---|---|---|---|---|---|
| 2015 | ca. 3.1 | ca. 3.5 | ca. 3.0 | ca. 3.2 | – | ca. 2.4 | ca. 2.0 | ca. 2.2 |
| 2016 | ca. 3.1 | ca. 3.8 | ca. 2.9 | ca. 3.5 | – | ca. 2.5 | ca. 2.1 | ca. 2.3 |
| 2017 | ca. 3.5 | ca. 3.7 | ca. 3.2 | ca. 3.3 | – | ca. 3.0 | ca. 2.9 | ca. 3.0 |
| 2018 | ca. 2.8 | ca. 4.6 | ca. 3.4 | ca. 3.6 | – | ca. 2.9 | ca. 1.9 | ca. 1.9 |
| 2019 | ca. 3.4 | ca. 4.1 | ca. 3.5 | ca. 3.9 | ca. 2.4 | ca. 2.9 | ca. 2.5 | ca. 2.3 |
| 2020 | ca. 3.3 | ca. 4.0 | ca. 3.3 | ca. 3.7 | ca. 3.0 | ca. 3.2 | ca. 3.0 | ca. 2.8 |
| 2021 | ca. 3.2 | ca. 3.4 | ca. 3.1 | ca. 3.4 | ca. 3.1 | ca. 3.0 | ca. 3.1 | ca. 3.1 |
| 2022 | ca. 3.5 | ca. 3.5 | ca. 3.4 | ca. 3.6 | ca. 2.7 | ca. 2.9 | ca. 2.8 | ca. 2.7 |
| 2023 | ca. 3.2 | ca. 3.4 | ca. 3.2 | ca. 3.2 | ca. 3.0 | ca. 3.0 | ca. 2.6 | ca. 2.7 |
| 2024 (beschriftet) | 3.5 | 3.4 | 3.3 | 3.3 | 3.3 | 3.0 | 3.0 | 2.9 |

Lesehilfe Grafik 6 und 7: Bei jeder Wertepolarität war es möglich, sich zwischen dem einen und dem anderen Pol auf einer ganzzahligen Skala von 1 bis 6 zu positionieren. Werte von 3.5 bedeuten, dass die Stimmberechtigten im Durchschnitt genau zwischen den Polen stehen. Je grösser die Abweichung davon auf die eine oder andere Seite ist, desto klarer neigen die Befragten zu dem entsprechenden Wertepol zu.

© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 300)

**[Ende Grafik 7]**

[[Seite 8/19 · Druckseiten 12–13]]

Über die Jahre hinweg betrachtet, nimmt der Wunsch nach einem Gesundheitswesen, in dem der Staat mehr als der Markt regelt, zu. Ebenfalls wachsend ist die Forderung, in der Grundversicherung sämtliche Leistungen abzudecken. Nach einem Auf und Ab wünschen sich die Stimmberechtigten seit dem Jahr 2021 Kompetenzen tendenziell eher beim Bund als bei den Kantonen anzusiedeln. Gemeinschafts- und Eigenverantwortung hielten sich lange die Waage. In den vergangenen Jahren ist dieses ausgeglichene Verhältnis allerdings zugunsten der Gemeinschaftsverantwortung gekippt.

Der Kostenentwicklung des Gesundheitswesens steht die Bevölkerung weiterhin skeptisch gegenüber: Grossmehrheitliche 85 Prozent der Befragten gehen davon aus, dass die Kosten des Gesundheitswesens weiterhin zunehmen werden, 14 Prozent glauben an eine Stabilisierung und lediglich 1 Prozent rechnet mit einem baldigen Rückgang der Kosten.

**[Kernaussagen]**

Auch bei der Entwicklung der Kosten zeigt sich der Rösti-Graben: In der Deutschschweiz sind 97 Prozent der Befragten der Meinung, dass die Kosten weiterhin zunehmen werden. In der französischsprachigen Schweiz zeigen sich die Befragten hinsichtlich der Kostenentwicklung optimistisch. Verhältnismässig geringe 49 Prozent glauben an ein Kostenwachstum. 45 Prozent sind der Meinung, die Kosten werden sich stabilisieren können.

**[Ende Kernaussagen]**

Bei einer Umverteilung der Finanzen innerhalb des Gesundheitswesens sieht die Bevölkerung das grösste Sparpotenzial bei der Verwaltung der Krankenkassen und bei den Spezialärztinnen und Spezialärzten.

Die Bevölkerung nimmt die Krankenkassen auch in die Verantwortung für die Kostendämpfung: 35 Prozent der Befragten sprechen den Krankenkassen – an erster oder zweiter Stelle – eine Hauptverantwortung für die Kostendämpfung im Gesundheitswesen zu. Die Pharmaindustrie sehen knapp ein Drittel in der Verantwortung (31%). An dritter Stelle folgen der Bund (26%) und die Ärzteschaft (26%). Ein knapper Viertel der Befragten nennt die Spitäler (24%) und die Patientinnen und Patienten (22%). Eine tiefere Verantwortung fordern die Befragten bei den Kantonen (16%).

**[Grafik 8] Aussagen zum schweizerischen Gesundheitswesen**

Frage: «Wie schätzen Sie ganz allgemein die Qualität des schweizerischen Gesundheitswesens ein? Glauben Sie, es ist qualitativ sehr gut, gut, eher gut, eher schlecht, schlecht oder sehr schlecht?»

Darstellung: Gestapeltes Flächendiagramm, 2015–2024, In % Stimmberechtigter. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: nicht beschriftet, berechnet aus den Vektorflächen der PDF mit vektoren.py und grafikwerte.py. Kumulative Flächengrenzen werden an der 0–100-Skala kalibriert und voneinander subtrahiert. Ausgabe als ca. auf ganze Prozentpunkte, Rundungsgenauigkeit ± 0.5 Prozentpunkte. Alle Zeilensummen ergeben 100. Spalten in Legendenreihenfolge.

| Jahr | Weiss nicht / keine Antwort | Die Kosten des Gesundheitswesens werden bald abnehmen. | Die Kosten des Gesundheitswesens können stabilisiert werden. | Die Kosten des Gesundheitswesens werden weiterhin zunehmen. |
|---|---|---|---|---|
| 2015 | ca. 3 | ca. 2 | ca. 16 | ca. 79 |
| 2016 | ca. 1 | ca. 8 | ca. 25 | ca. 66 |
| 2017 | ca. 1 | ca. 2 | ca. 5 | ca. 92 |
| 2018 | ca. 1 | ca. 0 | ca. 18 | ca. 81 |
| 2019 | ca. 1 | ca. 1 | ca. 15 | ca. 83 |
| 2020 | ca. 1 | ca. 1 | ca. 9 | ca. 89 |
| 2021 | ca. 0 | ca. 3 | ca. 23 | ca. 74 |
| 2022 | ca. 1 | ca. 1 | ca. 17 | ca. 81 |
| 2023 | ca. 1 | ca. 1 | ca. 13 | ca. 85 |
| 2024 | ca. 0 | ca. 1 | ca. 14 | ca. 85 |

[Hinweis Transkription: Der im Original abgedruckte Fragetext betrifft die Qualität des Gesundheitswesens, die Legende und die gezeichneten Daten dagegen die Kostenentwicklung. Dieser inhaltliche Widerspruch bleibt unverändert erhalten. Die berechneten Werte für 2024 stimmen mit den Angaben zur Kostenentwicklung im Fliesstext überein: 85 Prozent Zunahme, 14 Prozent Stabilisierung, 1 Prozent Abnahme.]



© gfs.bern, Gesundheitsmonitor 2024 (N = jeweils ca. 1’200)

**[Ende Grafik 8]**

**[Grafik 9] Verantwortung für Kostendämpfung**

Frage: «Wir haben hier die Liste mit Akteuren im Gesundheitswesen. Wer sollte Ihrer Meinung nach an erster Stelle stehen, wenn es um die Verantwortung für die Kostendämpfung im Gesundheitswesen geht?»

Darstellung: Liniendiagramm, 2015–2024, In % Stimmberechtigter; 1. und 2. Stelle summiert. Achse: 0, 20, 40, 60, 80, 100. Wertstatus: 2024 beschriftet, anhand von Linienfarbe, Endpunkt und Legende zugeordnet. Übrige dargestellte Jahreswerte berechnet aus den Vektorpfaden der PDF mit vektoren.py und grafikwerte.py; lineare Kalibrierung an den beschrifteten Endwerten, Ausgabe als ca. auf ganze Prozentpunkte (Rundungsgenauigkeit ± 0.5 Prozentpunkte). Es werden nur tatsächlich gezeichnete Stützpunkte übernommen, keine interpolierten Zusatzpunkte.

| Jahr | Krankenkassen | Pharmaindustrie | Ärztinnen und Ärzte | Bund | Spitäler | Patientinnen und Patienten | Kantone | Alle miteinander | Andere |
|---|---|---|---|---|---|---|---|---|---|
| 2015 | ca. 42 | ca. 21 | ca. 24 | ca. 34 | ca. 16 | ca. 21 | ca. 19 | ca. 14 | ca. 4 |
| 2016 | ca. 33 | ca. 24 | ca. 21 | ca. 39 | ca. 13 | ca. 20 | ca. 32 | ca. 11 | ca. 3 |
| 2017 | ca. 34 | ca. 27 | ca. 19 | ca. 34 | ca. 20 | ca. 24 | ca. 24 | ca. 14 | ca. 2 |
| 2018 | ca. 39 | ca. 30 | ca. 17 | ca. 19 | ca. 29 | ca. 17 | ca. 22 | ca. 19 | ca. 1 |
| 2019 | ca. 31 | ca. 27 | ca. 23 | ca. 30 | ca. 17 | ca. 23 | ca. 26 | ca. 15 | ca. 2 |
| 2020 | ca. 36 | ca. 30 | ca. 33 | ca. 17 | ca. 34 | ca. 18 | ca. 11 | ca. 14 | ca. 5 |
| 2021 | ca. 35 | ca. 29 | ca. 30 | ca. 15 | ca. 31 | ca. 25 | ca. 11 | ca. 17 | ca. 3 |
| 2022 | ca. 31 | ca. 26 | ca. 30 | ca. 21 | ca. 27 | ca. 25 | ca. 16 | ca. 16 | ca. 6 |
| 2023 | ca. 27 | ca. 27 | ca. 35 | ca. 18 | ca. 33 | ca. 26 | ca. 12 | ca. 19 | ca. 1 |
| 2024 (beschriftet) | 35 | 31 | 26 | 26 | 24 | 22 | 16 | 14 | 1 |



© gfs.bern, Gesundheitsmonitor 2024 (N = 1’200)

**[Ende Grafik 9]**

[[Seite 9/19 · Druckseiten 14–15]]

Die Befragten sehen am häufigsten in den Verwaltungskosten innerhalb des ganzen Gesundheitswesens den Hauptgrund für die steigenden Krankenkassenprämien (16%). Am zweithäufigsten nennt die Bevölkerung die Spitäler im Allgemeinen (14%). Auf Platz drei folgen die Krankenkassen (12%).

Die Stimmberechtigten sehen über die Jahre hinweg dieselben Hauptverursacher für die steigenden Krankenkassenprämien. Die Schuldzuweisung ist vorwiegend systembedingt und weniger stark auf der individuellen Ebene ausgeprägt.

**[Grafik 10] Verursacher für die Steigerung der Krankenkassenprämien**

Frage: «Ich gebe Ihnen hier eine Liste mit verschiedenen Verursachern für die Steigerung bei den Krankenkassenprämien. Welcher ist für Sie der hauptsächliche Grund?»

Darstellung: horizontal gestapelte Balken, In % Stimmberechtigter. Wertstatus: beschriftet; Segmente anhand der Farbe und der Legende zugeordnet. – = kein beschriftetes Segment. Die Balken zeigen 1. und 2. Nennung derselben Kategorie, keine auf 100 normierten Zeilensummen.

| Verursacher | 1. Nennung | 2. Nennung |
|---|---|---|
| Verwaltungskosten im Gesundheitswesen | 16 | 9 |
| Spitäler im Allgemeinen | 14 | 8 |
| Krankenkassen | 12 | 6 |
| Simulantinnen und Simulanten | 8 | 10 |
| Mehr alte Menschen | 8 | 10 |
| Fehlende Effizienz im Gesundheitswesen | 7 | 9 |
| Pharmaindustrie | 7 | 8 |
| Medizinische Forschung | 3 | 9 |
| Ärztinnen und Ärzte | 3 | 7 |
| Teure medizinische Instrumente | 3 | 6 |
| Steigende Erwartungen an Qualität | 4 | 4 |
| Unnötige Abklärungen | 3 | 4 |
| Süchtige | 2 | 4 |
| Spitex-Organisationen | 3 | 3 |
| Ausbau der Pflege | 3 | 1 |
| Leistungserweiterung in der Grundversicherung | 2 | 2 |
| Apotheken | 3 | 1 |
| Weiss nicht/keine Antwort | – | 1 |

© gfs.bern, Gesundheitsmonitor 2024 (N = 1’200)

**[Ende Grafik 10]**

---

— Ende Teil 1 von 2 · Kontrollwort Teil 1: WEISSHORN-11 · weiter mit teil-02.md —
