# LAV Learning Library – Katalog

Stand: 2026-11-05 · 3 Studien · Skill-Version 1.0
Zweck: Bestimmung der richtigen Studie. Inhalte stehen in den Study Cards und Volltexten.

## LAV-T01 · Gesundheitsmonitor 2024
- Volltitel: Das Wichtigste in Kürze zum GESUNDHEITSMONITOR 2024 – Zunehmende Reformbereitschaft in der Romandie [S. 1]
- Typ / Umfang: Bericht · 19 PDF-Seiten
- Volltext: 2 Teile – teil-01 S. 1–9 · teil-02 S. 10–19
- Herausgeber / Jahr: Interpharma · 2024 [S. 2]
- Methode / Stichprobe: gfs.bern; Face-to-Face; 1’200 Stimmberechtigte [S. 17]
- Themen: Qualität, Kosten, Prämien, Pharma, Medikamente [S. 4–15]
- Auch genannt: –
- Nicht verwechseln mit: LAV-T02 Gesundheitsmonitor 2025 (Folgeausgabe)
- Original: – (kein SharePoint-Link mitgeliefert)

## LAV-T02 · Gesundheitsmonitor 2025
- Volltitel: Das Wichtigste in Kürze zum Gesundheitsmonitor 2025: Kostenbewusstsein innerhalb der Bevölkerung nimmt zu
- Typ / Umfang: Bericht · 27 PDF-Seiten
- Volltext: 2 Teile – teil-01 S. 1–13 · teil-02 S. 14–27
- Herausgeber / Jahr: Interpharma · 2025
- Methode / Stichprobe: Befragung · 1’200 Stimmberechtigte · 3. bis 23. März 2025
- Themen: KVG, Prämien, Leistungskatalog, Kostendämpfung, Pharma, Medikamente, innovative Therapien
- Auch genannt: Das Wichtigste in Kürze zum Gesundheitsmonitor 2025
- Nicht verwechseln mit: LAV-T01 Gesundheitsmonitor 2024 (Vorjahresausgabe)
- Original: –

## LAV-T03 · Helsana-Arzneimittelreport 2024
- Volltitel: Helsana-Report: Arzneimittel [S. 1]
- Typ / Umfang: Bericht · 102 PDF-Seiten
- Volltext: 8 Teile – teil-01 S. 1–19 · teil-02 S. 20–31 · teil-03 S. 32–44 · teil-04 S. 45–56 · teil-05 S. 57–67 · teil-06 S. 68–79 · teil-07 S. 80–92 · teil-08 S. 93–102
- Herausgeber / Jahr: Helsana · November 2024; aktualisiert September 2026 [S. 2]
- Methode / Stichprobe: OKP-Abrechnungen 2020–2023; 1’328’056 Grundversicherte 2023 [S. 11][S. 13]
- Themen: Kosten, Bezüge, Generika, Biosimilars, JAKi, Lungenkrebs [S. 10]
- Auch genannt: Arzneimittelreport [S. 2]
- Nicht verwechseln mit: –
- Original: hochgeladene PDF; SharePoint-Link nicht angegeben

— Ende Katalog · Kontrollwort: ALVIER-60 —
