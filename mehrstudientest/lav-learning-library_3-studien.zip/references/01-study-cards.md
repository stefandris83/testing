# LAV Learning Library – Study Cards

Stand: 2026-11-05 · 3 Cards · Datei 1 von 1
Belege: [S. n] = PDF-Seite im Volltext der jeweiligen Studie.

## LAV-T01 · Gesundheitsmonitor 2024
Freigegeben: – (ausstehend) · Volltext-Version 1.0

**Fragestellung:** «Der Gesundheitsmonitor will die Einstellung der Schweizer Stimmberechtigten zum Gesundheitswesen zuverlässig ermitteln.» [S. 2]

**Methode & Stichprobe:** «Die Ergebnisse der Befragung zum Gesundheitsmonitor 2024 basieren auf einer repräsentativen Befragung von 1’200 Stimmberechtigten aus der ganzen Schweiz, welche gfs.bern im Auftrag von Interpharma durchgeführt hat. Die Befragung wurde zwischen dem 19. Februar und dem 17. März 2024 (Mean-Day: 3. März 2024) mittels persönlicher Face-to-Face-Interviews realisiert.» [S. 17]

**Kernergebnisse:**
- «Rund drei Viertel der Befragten beurteilen die Qualität des Schweizer Gesundheitswesens als sehr gut oder gut (73%).» [S. 4]
- «Die Mehrheit der Bevölkerung möchte den aktuellen Leistungskatalog beibehalten (60%).» [S. 11]
- «Die Kopfprämie ist in der Bevölkerung weiterhin mehrheitsfähig (82%).» [S. 12]
- «Die Befragten sehen in der Pharmaindustrie eine wichtige Arbeitgeberin (97%) und einen Exportmotor für die Schweizer Wirtschaft (96%).» [S. 13]
- «Drei Viertel der Befragten stufen die Medikamentenpreise in der Schweiz als zu hoch ein (75%).» [S. 14]

**Schlussfolgerungen der Studie:** «Personen aus der französischsprachigen Schweiz zeigen sich deutlich reformfreudiger als Personen aus der deutschsprachigen Schweiz. Massnahmen zur Kostensenkung – wie beispielsweise Einschränkungen bei der Wahl der Ärztin oder des Arztes und Kürzungen des Leistungskatalogs – sind bereits heute in der Romandie mehrheitsfähig. In der übrigen Schweiz herrscht hingegen ein Reformstau.» [S. 16]

**Was die Studie nicht beantwortet:** «Inwiefern sich die wahrgenommene Belastung mit der tatsächlichen Belastung deckt, kann in dieser Untersuchung nicht abschliessend dargelegt werden.» [S. 7]

**Wegweiser im Volltext:**
| Thema | PDF-Seiten | Teil |
|---|---|---|
| Qualität, Kosten, Verantwortung | 4–9 | teil-01 |
| Reformen, Leistungen, Prämien | 10–12 | teil-02 |
| Pharmaindustrie, Medikamente | 13–15 | teil-02 |
| Thesen | 16 | teil-02 |
| Datenbasis, Stichprobenfehler | 17 | teil-02 |

**Transkriptionshinweis:** Originalabweichungen sind im Volltext gekennzeichnet. [S. 5] [S. 8] [S. 14] [S. 15]

**Redaktionelle Einordnung LAV:** –

— Ende Card LAV-T01 —

## LAV-T02 · Gesundheitsmonitor 2025
Freigegeben: – · Volltext-Version 1.0

**Fragestellung:** Einstellung der Schweizer Stimmberechtigten zum Gesundheitswesen. [S. 2]

**Methode & Stichprobe:** Repräsentative Befragung von 1’200 Stimmberechtigten aus der ganzen Schweiz; 600 Face-to-Face- und 600 Online-Interviews, Panel «Polittrends»; 3. bis 23. März 2025. [S. 24]

**Kernergebnisse:**
- Zugang zur medizinischen Grundversorgung: 96 Prozent sehen das Versprechen des KVG als eher oder ganz eingelöst; für Kostendämpfung sind es 41 Prozent. [S. 8]
- 75 Prozent stufen den Prämienanstieg als überhöht ein (Skalenwerte 4 bis 6); 30 Prozent bekunden Mühe, Krankenkassenprämien zu bezahlen. [S. 9]
- Für das Belassen des Leistungskatalogs sprechen sich 49 Prozent aus, 22 Prozent für Ausbau und 19 Prozent für Abbau (2025, beschriftete Werte). [S. 12]
- 73 Prozent beurteilen das Gesundheitswesen als gut oder sehr gut, weitere 23 Prozent als eher gut. [S. 14]
- Bei 83 Prozent findet ein Zugang zu innovativen Therapien nach systemischem Nutzen Zustimmung; ein jährliches Budget pro Person lehnen 72 Prozent ab. [S. 19–20]
- Für Generika entscheiden sich 60 Prozent, für Originalmedikamente 37 Prozent; 87 Prozent halten Medikamentenpreise für zu hoch (2025, beschriftete Werte). [S. 22]

**Schlussfolgerungen der Studie:** Qualität, Solidarität und ein breiter Leistungsumfang bleiben wichtige Werte; das Kostenbewusstsein und die Offenheit für gezielte kostendämpfende Massnahmen wachsen. [S. 23]

**Was die Studie nicht beantwortet:** Die beschriebene Stichprobe umfasst Stimmberechtigte; separate Ergebnisse für nicht stimmberechtigte Personen werden nicht ausgewiesen. [S. 24]

**Wegweiser im Volltext:**
| Thema | Seiten | Teil |
|---|---|---|
| Vorwort, Executive Summary, KVG, Prämien, Leistungskatalog | 3–13 | teil-01 |
| Gesundheitswesen, Kosten, Pharma, Thesen, Methode | 14–25 | teil-02 |

**Redaktionelle Einordnung LAV** (optional; keine Studienaussage, nie mit Seitenbeleg zitieren): –

— Ende Card LAV-T02 —

## LAV-T03 · Helsana-Arzneimittelreport 2024
Freigegeben: ausstehend · Volltext-Version 1.0

**Ausgabe:** November 2024 (aktualisierte Version September 2026). [S. 2]

**Fragestellung:** Mengen- und Kostenentwicklung im Schweizer Arzneimittelmarkt; Generika/Biosimilars, JAKi-Sicherheitswarnungen und Lungenkrebstherapien. [S. 10]

**Methode & Stichprobe:** Anonymisierte ambulante OKP-Abrechnungsdaten, grundsätzlich 2020–2023; Hochrechnung nach Wohnkanton, Geschlecht und Altersstruktur. [S. 13] Helsana-Grundversicherte 2023: 1’328’056; davon 1’016’858 mit Medikamentenbezügen. [S. 11]

**Kernergebnisse** (Werte aus Tabellen bzw. Fliesstext, nicht grafisch geschätzt):
- Schweiz 2023: Medikamentenkosten CHF 9’021 Mio. (+5.9% gegenüber 2022), 136.6 Mio. Bezüge (+2.1%). [S. 18]
- Generika 2023: Quote 68.9%; theoretisch ungenutztes Einsparpotenzial CHF 263’206’290. [S. 49]
- Biosimilars 2023: theoretisch ungenutztes Einsparpotenzial CHF 39’440’514; Preismodelle nicht berücksichtigt. [S. 54]
- Kritische Ereignisse unter JAKi gegenüber TNFi: Hazard Ratio 1.60 (95% Konfidenzintervall: 1.29-1.99); lediglich Alter, Geschlecht und Wohnkanton kontrolliert. [S. 68]
- Lungenkrebs, Therapiebeginn 2021: durchschnittliche Onkologikakosten über 2 Jahre bei Beginn mit Chemo CHF 18’279, Targeted CHF 43’649, Immuno CHF 52’916, Kombination CHF 40’647. Eingeschlossen sind Folgetherapien; keine gesamten Krebsbehandlungskosten. [S. 86]

**Schlussfolgerungen der Studie:** Einsparpotenzial durch Generika bleibt erheblich. [S. 49] Detaillierte Kosten-Effektivitätsanalysen für einzelne JAKi sollten dringend durchgeführt werden. [S. 72] Kosteneffizienz neuer Lungenkrebstherapien bleibt offen. [S. 87]

**Was die Studie nicht beantwortet:** Keine selbst bezahlten OTC-Bezüge oder nicht eingereichten Rechnungen; primär ambulante Daten. [S. 13] Bezug ist nicht gleich Einnahme; Ergebnisse verschiedener Berichtsjahre sind nicht direkt vergleichbar. [S. 14] Die JAKi-Auswertung nutzt geschätzte Indikationen statt exakter klinischer Diagnosen. [S. 68]

**Wegweiser im Volltext:**
| Thema | Seiten | Teil |
|---|---|---|
| Grundlagen, Methoden, Marktüberblick | 1–19 | teil-01 |
| Medikamentengruppen, Wirkstoffe | 20–31 | teil-02 |
| Wirkstoffe und Neuheiten | 32–44 | teil-03 |
| Generika/Biosimilars, Beginn JAKi | 45–56 | teil-04 |
| JAKi: Methoden und Ergebnisse | 57–67 | teil-05 |
| JAKi: Kosten/Fazit; Lungenkrebs | 68–79 | teil-06 |
| Lungenkrebs; Anhang | 80–92 | teil-07 |
| Tabellenfortsetzung, Verzeichnisse | 93–102 | teil-08 |

**Redaktionelle Einordnung LAV:** –

— Ende Card LAV-T03 —

— Ende Study Cards Datei 1 von 1 · Kontrollwort: NEU-02 —
