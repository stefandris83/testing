# LAV Learning Library – Katalog

Stand: [JJJJ-MM-TT] · [Anzahl] Studien · Skill-Version [x.y]
Zweck: Bestimmung der richtigen Studie. Inhalte stehen in den Study Cards und Volltexten.

## LAV-[NN] · [Kurztitel] [Jahr]
- Volltitel: [wie auf dem Titelblatt]
- Typ / Umfang: [Foliendeck | Bericht] · [N] PDF-Seiten
- Volltext: [k] Teile – teil-01 S. [a–b] · teil-02 S. [c–d] · …
- Herausgeber / Jahr: [Team bzw. Institut] · [Erscheinungsdatum, Feldzeit]
- Methode / Stichprobe: [z. B. Online-Befragung, n = 1’204 Versicherte]
- Themen: [5–8 Schlagworte]
- Auch genannt: [Namen, unter denen die Studie intern bekannt ist]
- Nicht verwechseln mit: [LAV-ID und Unterschied, z. B. Vorgängerstudie 2023] | –
- Original: [SharePoint-Link]

[… ein Eintrag pro Studie, aufsteigend nach ID, je höchstens ca. 600 Zeichen …]

— Ende Katalog · Kontrollwort: [zufällig, von paket.py erzeugt] —
