# LAV Learning Library – Study Cards

Stand: [JJJJ-MM-TT] · [Anzahl] Cards · Datei [1 von k]
Belege: [S. n] = PDF-Seite im Volltext der jeweiligen Studie.

## LAV-[NN] · [Kurztitel] [Jahr]
Freigegeben: [Name, Research] · [Datum] · Volltext-Version [x.y]

**Fragestellung:** [Geschäftsfrage, Anlass] [S. n]

**Methode & Stichprobe:** [Methode, n, Zielgruppe, Feldzeit, Gewichtung] [S. n]

**Kernergebnisse:**
- [Befund mit Zahl und Basis; Wertstatus übernehmen, z. B. «ca.» oder «berechnet»] [S. n]
- [… 4–8 Befunde]

**Schlussfolgerungen der Studie:** [nur, was die Studie selbst folgert] [S. n]

**Was die Studie nicht beantwortet:** [fehlende Zielgruppen, Themen, Zeiträume;
Grenzen der Methode] [S. n]

**Wegweiser im Volltext:**
| Thema | Seiten | Teil |
|---|---|---|
| [z. B. Wechselmotive nach Alter] | [18–21] | [teil-02] |

**Redaktionelle Einordnung LAV** (optional; keine Studienaussage, nie mit Seitenbeleg
zitieren): [Einordnung, Autorin/Autor, Datum] | –

— Ende Card LAV-[NN] —

[… eine Card pro Studie, je höchstens ca. 3’000 Zeichen …]

— Ende Study Cards Datei [1 von k] · Kontrollwort: [zufällig, von paket.py erzeugt] —
