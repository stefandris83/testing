## LAV-T01 · Gesundheitsmonitor 2024
Freigegeben: – (ausstehend) · Volltext-Version 1.0

**Fragestellung:** «Der Gesundheitsmonitor will die Einstellung der Schweizer Stimmberechtigten zum Gesundheitswesen zuverlässig ermitteln.» [S. 2]

**Methode & Stichprobe:** «Die Ergebnisse der Befragung zum Gesundheitsmonitor 2024 basieren auf einer repräsentativen Befragung von 1’200 Stimmberechtigten aus der ganzen Schweiz, welche gfs.bern im Auftrag von Interpharma durchgeführt hat. Die Befragung wurde zwischen dem 19. Februar und dem 17. März 2024 (Mean-Day: 3. März 2024) mittels persönlicher Face-to-Face-Interviews realisiert.» [S. 17]

**Kernergebnisse:**
- «Rund drei Viertel der Befragten beurteilen die Qualität des Schweizer Gesundheitswesens als sehr gut oder gut (73%).» [S. 4]
- «Die Mehrheit der Bevölkerung möchte den aktuellen Leistungskatalog beibehalten (60%).» [S. 11]
- «Die Kopfprämie ist in der Bevölkerung weiterhin mehrheitsfähig (82%).» [S. 12]
- «Die Befragten sehen in der Pharmaindustrie eine wichtige Arbeitgeberin (97%) und einen Exportmotor für die Schweizer Wirtschaft (96%).» [S. 13]
- «Drei Viertel der Befragten stufen die Medikamentenpreise in der Schweiz als zu hoch ein (75%).» [S. 14]

**Schlussfolgerungen der Studie:** «Personen aus der französischsprachigen Schweiz zeigen sich deutlich reformfreudiger als Personen aus der deutschsprachigen Schweiz. Massnahmen zur Kostensenkung – wie beispielsweise Einschränkungen bei der Wahl der Ärztin oder des Arztes und Kürzungen des Leistungskatalogs – sind bereits heute in der Romandie mehrheitsfähig. In der übrigen Schweiz herrscht hingegen ein Reformstau.» [S. 16]

**Was die Studie nicht beantwortet:** «Inwiefern sich die wahrgenommene Belastung mit der tatsächlichen Belastung deckt, kann in dieser Untersuchung nicht abschliessend dargelegt werden.» [S. 7]

**Wegweiser im Volltext:**
| Thema | PDF-Seiten | Teil |
|---|---|---|
| Qualität, Kosten, Verantwortung | 4–9 | teil-01 |
| Reformen, Leistungen, Prämien | 10–12 | teil-02 |
| Pharmaindustrie, Medikamente | 13–15 | teil-02 |
| Thesen | 16 | teil-02 |
| Datenbasis, Stichprobenfehler | 17 | teil-02 |

**Transkriptionshinweis:** Originalabweichungen sind im Volltext gekennzeichnet. [S. 5] [S. 8] [S. 14] [S. 15]

**Redaktionelle Einordnung LAV:** –

— Ende Card LAV-T01 —
