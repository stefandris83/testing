## LAV-T01 · Gesundheitsmonitor 2024
- Volltitel: Das Wichtigste in Kürze zum GESUNDHEITSMONITOR 2024 – Zunehmende Reformbereitschaft in der Romandie [S. 1]
- Typ / Umfang: Bericht · 19 PDF-Seiten
- Volltext: 2 Teile – teil-01 S. 1–9 · teil-02 S. 10–19
- Herausgeber / Jahr: Interpharma · 2024 [S. 2]
- Methode / Stichprobe: gfs.bern; Face-to-Face; 1’200 Stimmberechtigte [S. 17]
- Themen: Qualität, Kosten, Prämien, Pharma, Medikamente [S. 4–15]
- Auch genannt: –
- Nicht verwechseln mit: –
- Original: – (kein SharePoint-Link mitgeliefert)
