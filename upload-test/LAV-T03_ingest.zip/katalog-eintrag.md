## LAV-T03 · Helsana-Arzneimittelreport 2024
- Volltitel: Helsana-Report: Arzneimittel [S. 1]
- Typ / Umfang: Bericht · 102 PDF-Seiten
- Volltext: 8 Teile – teil-01 S. 1–19 · teil-02 S. 20–31 · teil-03 S. 32–44 · teil-04 S. 45–56 · teil-05 S. 57–67 · teil-06 S. 68–79 · teil-07 S. 80–92 · teil-08 S. 93–102
- Herausgeber / Jahr: Helsana · November 2024; aktualisiert September 2026 [S. 2]
- Methode / Stichprobe: OKP-Abrechnungen 2020–2023; 1’328’056 Grundversicherte 2023 [S. 11][S. 13]
- Themen: Kosten, Bezüge, Generika, Biosimilars, JAKi, Lungenkrebs [S. 10]
- Auch genannt: Arzneimittelreport [S. 2]
- Nicht verwechseln mit: –
- Original: hochgeladene PDF; SharePoint-Link nicht angegeben
