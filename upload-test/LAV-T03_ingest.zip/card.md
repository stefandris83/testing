## LAV-T03 · Helsana-Arzneimittelreport 2024
Freigegeben: ausstehend · Volltext-Version 1.0

**Ausgabe:** November 2024 (aktualisierte Version September 2026). [S. 2]

**Fragestellung:** Mengen- und Kostenentwicklung im Schweizer Arzneimittelmarkt; Generika/Biosimilars, JAKi-Sicherheitswarnungen und Lungenkrebstherapien. [S. 10]

**Methode & Stichprobe:** Anonymisierte ambulante OKP-Abrechnungsdaten, grundsätzlich 2020–2023; Hochrechnung nach Wohnkanton, Geschlecht und Altersstruktur. [S. 13] Helsana-Grundversicherte 2023: 1’328’056; davon 1’016’858 mit Medikamentenbezügen. [S. 11]

**Kernergebnisse** (Werte aus Tabellen bzw. Fliesstext, nicht grafisch geschätzt):
- Schweiz 2023: Medikamentenkosten CHF 9’021 Mio. (+5.9% gegenüber 2022), 136.6 Mio. Bezüge (+2.1%). [S. 18]
- Generika 2023: Quote 68.9%; theoretisch ungenutztes Einsparpotenzial CHF 263’206’290. [S. 49]
- Biosimilars 2023: theoretisch ungenutztes Einsparpotenzial CHF 39’440’514; Preismodelle nicht berücksichtigt. [S. 54]
- Kritische Ereignisse unter JAKi gegenüber TNFi: Hazard Ratio 1.60 (95% Konfidenzintervall: 1.29-1.99); lediglich Alter, Geschlecht und Wohnkanton kontrolliert. [S. 68]
- Lungenkrebs, Therapiebeginn 2021: durchschnittliche Onkologikakosten über 2 Jahre bei Beginn mit Chemo CHF 18’279, Targeted CHF 43’649, Immuno CHF 52’916, Kombination CHF 40’647. Eingeschlossen sind Folgetherapien; keine gesamten Krebsbehandlungskosten. [S. 86]

**Schlussfolgerungen der Studie:** Einsparpotenzial durch Generika bleibt erheblich. [S. 49] Detaillierte Kosten-Effektivitätsanalysen für einzelne JAKi sollten dringend durchgeführt werden. [S. 72] Kosteneffizienz neuer Lungenkrebstherapien bleibt offen. [S. 87]

**Was die Studie nicht beantwortet:** Keine selbst bezahlten OTC-Bezüge oder nicht eingereichten Rechnungen; primär ambulante Daten. [S. 13] Bezug ist nicht gleich Einnahme; Ergebnisse verschiedener Berichtsjahre sind nicht direkt vergleichbar. [S. 14] Die JAKi-Auswertung nutzt geschätzte Indikationen statt exakter klinischer Diagnosen. [S. 68]

**Wegweiser im Volltext:**
| Thema | Seiten | Teil |
|---|---|---|
| Grundlagen, Methoden, Marktüberblick | 1–19 | teil-01 |
| Medikamentengruppen, Wirkstoffe | 20–31 | teil-02 |
| Wirkstoffe und Neuheiten | 32–44 | teil-03 |
| Generika/Biosimilars, Beginn JAKi | 45–56 | teil-04 |
| JAKi: Methoden und Ergebnisse | 57–67 | teil-05 |
| JAKi: Kosten/Fazit; Lungenkrebs | 68–79 | teil-06 |
| Lungenkrebs; Anhang | 80–92 | teil-07 |
| Tabellenfortsetzung, Verzeichnisse | 93–102 | teil-08 |

**Redaktionelle Einordnung LAV:** –

— Ende Card LAV-T03 —
