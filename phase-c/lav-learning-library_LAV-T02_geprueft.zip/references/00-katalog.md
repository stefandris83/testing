# LAV Learning Library – Katalog

Stand: 2026-10-15 · 1 Studien · Skill-Version 0.1
Zweck: Bestimmung der richtigen Studie. Inhalte stehen in den Study Cards und Volltexten.

## LAV-T02 · Gesundheitsmonitor 2025
- Volltitel: Das Wichtigste in Kürze zum Gesundheitsmonitor 2025: Kostenbewusstsein innerhalb der Bevölkerung nimmt zu
- Typ / Umfang: Bericht · 27 PDF-Seiten
- Volltext: 2 Teile – teil-01 S. 1–13 · teil-02 S. 14–27
- Herausgeber / Jahr: Interpharma · 2025
- Methode / Stichprobe: Befragung · 1’200 Stimmberechtigte · 3. bis 23. März 2025
- Themen: KVG, Prämien, Leistungskatalog, Kostendämpfung, Pharma, Medikamente, innovative Therapien
- Auch genannt: Das Wichtigste in Kürze zum Gesundheitsmonitor 2025
- Nicht verwechseln mit: –
- Original: –

— Ende Katalog · Kontrollwort: TITLIS-27 —
