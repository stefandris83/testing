# LAV Learning Library – Study Cards

Stand: 2026-10-15 · 1 Cards · Datei 1 von 1
Belege: [S. n] = PDF-Seite im Volltext der jeweiligen Studie.

## LAV-T02 · Gesundheitsmonitor 2025
Freigegeben: – · Volltext-Version 1.0

**Fragestellung:** Einstellung der Schweizer Stimmberechtigten zum Gesundheitswesen. [S. 2]

**Methode & Stichprobe:** Repräsentative Befragung von 1’200 Stimmberechtigten aus der ganzen Schweiz; 600 Face-to-Face- und 600 Online-Interviews, Panel «Polittrends»; 3. bis 23. März 2025. [S. 24]

**Kernergebnisse:**
- Zugang zur medizinischen Grundversorgung: 96 Prozent sehen das Versprechen des KVG als eher oder ganz eingelöst; für Kostendämpfung sind es 41 Prozent. [S. 8]
- 75 Prozent stufen den Prämienanstieg als überhöht ein (Skalenwerte 4 bis 6); 30 Prozent bekunden Mühe, Krankenkassenprämien zu bezahlen. [S. 9]
- Für das Belassen des Leistungskatalogs sprechen sich 49 Prozent aus, 22 Prozent für Ausbau und 19 Prozent für Abbau (2025, beschriftete Werte). [S. 12]
- 73 Prozent beurteilen das Gesundheitswesen als gut oder sehr gut, weitere 23 Prozent als eher gut. [S. 14]
- Bei 83 Prozent findet ein Zugang zu innovativen Therapien nach systemischem Nutzen Zustimmung; ein jährliches Budget pro Person lehnen 72 Prozent ab. [S. 19–20]
- Für Generika entscheiden sich 60 Prozent, für Originalmedikamente 37 Prozent; 87 Prozent halten Medikamentenpreise für zu hoch (2025, beschriftete Werte). [S. 22]

**Schlussfolgerungen der Studie:** Qualität, Solidarität und ein breiter Leistungsumfang bleiben wichtige Werte; das Kostenbewusstsein und die Offenheit für gezielte kostendämpfende Massnahmen wachsen. [S. 23]

**Was die Studie nicht beantwortet:** Die beschriebene Stichprobe umfasst Stimmberechtigte; separate Ergebnisse für nicht stimmberechtigte Personen werden nicht ausgewiesen. [S. 24]

**Wegweiser im Volltext:**
| Thema | Seiten | Teil |
|---|---|---|
| Vorwort, Executive Summary, KVG, Prämien, Leistungskatalog | 3–13 | teil-01 |
| Gesundheitswesen, Kosten, Pharma, Thesen, Methode | 14–25 | teil-02 |

**Redaktionelle Einordnung LAV** (optional; keine Studienaussage, nie mit Seitenbeleg zitieren): –

— Ende Card LAV-T02 —

— Ende Study Cards Datei 1 von 1 · Kontrollwort: ALVIER-82 —
