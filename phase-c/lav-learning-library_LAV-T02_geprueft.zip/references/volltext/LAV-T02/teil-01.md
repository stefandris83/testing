# LAV-T02 · Volltext · Teil 1 von 2 (PDF-Seiten 1–13 von 27)

Studie: Das Wichtigste in Kürze zum Gesundheitsmonitor 2025: Kostenbewusstsein innerhalb der Bevölkerung nimmt zu · Quelldatei: gesundheitsmonitor-2025-f5238f4c.pdf · Transkript-Version 1.0 · 2026-10-15
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 2 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T02, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 1/27 · Umschlag]]

interpharma

## Das Wichtigste in Kürze zum GESUNDHEITSMONITOR 2025

Kostenbewusstsein innerhalb der Bevölkerung nimmt zu

gfs.bern

Projektteam
- Urs Bieri, Co-Leiter
- Tobias Keller, Projektleiter und Teamleader Data Analytics
- Corina Schena, Projektleiterin
- Sara Rellstab, Data Scientist

[Bild: Stilisierte Schweizer Karte in einem Kreis vor grossen Ziffern «25».]

[[Seite 2/27 · Druckseite 1]]

Eine Studie im Auftrag von Interpharma.

Der Gesundheitsmonitor will die Einstellung der Schweizer Stimmberechtigten zum Gesundheitswesen zuverlässig ermitteln.

Die Repräsentativbefragung wird seit 1996 einmal jährlich durchgeführt. 2025 wurden 1’200 Stimmberechtigte in allen Sprachregionen hierfür in Face-to-Face-Interviews befragt.

Nachfolgend berichten wir über die Hauptergebnisse.

Interpharma · Verband der forschenden pharmazeutischen Firmen der Schweiz · Petersgraben 35 · Postfach · 4009 Basel

Telefon 061 264 34 00 · E-Mail info@interpharma.ch

Die Inhalte der Broschüre finden Sie auch auf der Website von Interpharma unter www.interpharma.ch. Grafiken der jeweils aktuellsten Version können Sie zu Ihrer freien Verwendung unter Quellenangabe herunterladen.

Disponible en traduction française · © Interpharma, 2025, Basel

Abdruck mit Quellenangabe erwünscht

## Inhaltsverzeichnis

| Kapitel | Inhalt | Seite |
|---|---|---|
| 1 | Vorwort | 2 |
| 2 | Executive Summary | 10 |
| 3 | Schwerpunktthemen 2025 | 12 |
| 4 | Ausgewählte Analysen | 24 |
| 4.1 | Entwicklungen im Gesundheitswesen | 24 |
| 4.2 | Pharmaindustrie und Medikamente | 34 |
| 5 | Thesen | 42 |
| 6 | Datenbasis der aktuellen Welle | 44 |
| 7 | Anhang | 46 |
| 7.1 | gfs.bern-Team | 46 |

[[Seite 3/27 · Druckseiten 2–3]]

## 1 Vorwort

[Bild: Porträt eines Mannes neben dem ersten Absatz des Vorworts.]

Der Gesundheitsmonitor, von Interpharma in Auftrag gegeben und vom Forschungsinstitut gfs.bern durchgeführt, feiert dieses Jahr sein 25-jähriges Bestehen. Seit einem Vierteljahrhundert liefert diese Studie wichtige Einblicke in die Haltung der Schweizer Bevölkerung zum Gesundheitssystem und zu der Rolle, welche die Schweizer Pharmaindustrie darin spielt. Der Gesundheitsmonitor ist somit eines der ältesten Monitorings der Schweiz, welches die Stimmbevölkerung jährlich zu Gesundheitsthemen befragt. Er bildet eine aufschlussreiche Schnittstelle zwischen der Öffentlichkeit und der Pharmabranche und greift regelmässig die Sorgen, Erwartungen und Meinungen zu einem der komplexesten, innenpolitischen Themen auf: dem Schweizer Gesundheitswesen. Wir sind stolz darauf, damit einen wichtigen Beitrag zum gesundheitspolitischen Diskurs zu leisten.

## Ein Vierteljahrhundert Gesundheitsmonitor

Der jährlich erscheinende Gesundheitsmonitor wurde kurz nach Inkrafttreten des Krankenversicherungsgesetzes (KVG) ins Leben gerufen. Das KVG ist ein Meilenstein in der Geschichte des Schweizer Gesundheitswesens. Mit diesem Gesetz wurde die Grundlage für ein solidarisch finanziertes Gesundheitssystem geschaffen, das bis heute Bestand hat.

Vor diesem Hintergrund wollen wir in diesem Artikel die Entwicklung der Umfrageergebnisse der letzten 25 Jahre analysieren und den 1996 definierten Zielen des KVG gegenüberstellen. Zusätzlich interessiert uns, in welchem Verhältnis das subjektive Empfinden der Befragten zu den objektiv messbaren Fakten steht. Zur besseren Übersicht fassen wir die im KVG definierten Ziele in drei übergeordnete Themenbereiche zusammen: Solidarität, Qualität und Kosten. Diese werden im Folgenden einzeln betrachtet.

**[Grafik] Selbstbezahlte Leistungen/Krankenkassenleistungen**

Frage: «Es gibt ein paar Situationen, wo Leistungen in der Grundversicherung vergütet werden können. Bitte geben Sie bei jeder an, wann Ihrer Ansicht nach die betroffene Person selbst die Leistungen bezahlen sollte und wann Sie der Ansicht sind, dass die Kassen dies tun sollten.»

Darstellung: Liniendiagramm, in % Stimmberechtigte*, Kassenzahlung; Zeitachse 97, 99, 01, 03, 05, 07, 09, 11, 13, 15, 17, 19, 21, 23, 25; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; die übrigen Jahreswerte sind nicht eindeutig ablesbar (dichte Linien ohne Beschriftung).

| Jahr | Bei seltenen Krankheiten | Bei Behinderung eines Familienangehörigen | Bei der Vorbeugung von Herz-/Kreislaufkrankheiten | Bei psychischen Beschwerden | Bei Beschwerden, durch Stress verursacht | Bei gewichtsbedingten Beschwerden | Bei Schäden, die durch Rauchen oder Alkohol entstehen |
|---|---|---|---|---|---|---|---|
| 2025 (beschriftet) | 93 | 91 | 84 | 81 | 70 | 53 | 23 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’190)

**[Ende Grafik]**

## Der Solidaritätsgedanke ist stark verankert

Mit dem Obligatorium der Grundversicherung wird eine solidarisch finanzierte Krankenversicherung sichergestellt. Auf diesem Weg erhalten jene Unterstützung, die aufgrund einer Krankheit hohe Gesundheitsausgaben haben.

Dieser Solidaritätsgedanke wird von der Bevölkerung weiterhin mitgetragen. So zeigt sich eine konstant hohe Solidarität bei der Unterstützung gegen seltene Krankheiten oder bei Behinderung eines Familienangehörigen. Die grosse Mehrheit der Befragten befürwortet deren Deckung durch die Grundversicherung. Die Solidarität gegenüber Behandlungskosten von seltenen Krankheiten nimmt leicht ab, was in Anbetracht der Zeitreihe aber den natürlichen Schwankungen entspricht. Bei selbstverschuldeten Behandlungskosten durch Erkrankungen aufgrund von Tabak- und Alkoholkonsums sinkt die Solidarität jedoch deutlich.

[[Seite 4/27 · Druckseiten 4–5]]

Was bezüglich der Solidarität oft vergessen geht: Unser Gesundheitswesen finanziert sich nicht nur über Prämien und Subventionen. Rund 30 Prozent von den fast 94 Mrd. Franken, die das Schweizer Gesundheitssystem 2023 insgesamt kostete, stammen aus Steuergeldern – und auch diese basieren auf dem Solidaritätsprinzip, da sie einkommens- und vermögensabhängig erhoben werden.

**[Grafik] Verfügbarkeit von innovativen Medikamenten im internationalen Vergleich, 2020–2023**

Darstellung: gruppierte Säulen, (EMA N=173 zugelassene Arzneimittel (100%)*; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: alle sechs Säulen beschriftet.

| Verfügbarkeit | Deutschland | Schweiz |
|---|---|---|
| Voll verfügbar | 90% | 47% |
| Teilweise verfügbar | 1% | 27% |
| Nicht verfügbar | 10% | 27% |

Quellen: Darstellung Interpharma mit Datengrundlage EFPIA Patients W.A.I.T. Indicator 2024 Survey.

* Abweichungen wegen Rundungen

**[Ende Grafik]**

## Trotz guter Qualität gibt es Verbesserungspotenzial

Im Bereich der Qualität steht im Vordergrund, dass die Schweizer Bevölkerung Zugang zu einem hochwertigen Gesundheitssystem hat – und dass alle schnell und gezielt von den neuesten wissenschaftlichen Fortschritten und medizinischen Innovationen profitieren können. Die Schweizer Bevölkerung schätzt die Qualität ihres Gesundheitswesens und somit auch des Patientenzugangs seit Jahren konstant hoch ein. Teil davon ist eine starke und unabhängige Arzneimittelbehörde, welche im Interesse der Patientensicherheit und des Pharmastandorts Schweiz ist. Aufgrund neuer, attraktiver Verfahren zeigt sich im internationalen Vergleich mit anderen Behörden bei der Durchlaufzeit für die Schweizer Marktzulassung eine substanzielle Verbesserung über die Jahre 2019 bis 2021, und sie ist nun vergleichbar mit der Durchlaufzeit bei der Europäischen Zulassungsbehörde EMA (European Medicines Agency).

Ein Blick hinter die Kulissen des Patientenzugangs zeigt aber: Mit der Zulassung durch die Arzneimittelbehörde steht ein Arzneimittel den Patientinnen und Patienten noch nicht gleichberechtigt zur Verfügung. Zuvor muss die Vergütung durch die Grundversicherung (OKP) festgelegt werden. Patientinnen und Patienten warten immer länger, bis ein neu zugelassenes Medikament von den Krankenkassen vergütet wird und damit breit verfügbar ist. Über die Aufnahme auf die Spezialitätenliste und die damit hergestellte, breite Verfügbarkeit entscheidet das Bundesamt für Gesundheit (BAG). 2024 betrug die Wartezeit von der Marktzulassung bis zur Aufnahme in die Spezialitätenliste 189 Tage – maximal 60 Tage sollten es laut Gesetz sein. Der langjährige Trend zeigt klar nach oben. Nur in 6 Prozent der Fälle wurde vom BAG die gesetzliche Frist von 60 Tagen eingehalten. Darunter leiden die Patientinnen und Patienten, denn viele von ihnen können nicht so lange warten. Für ein qualitativ hochstehendes Gesundheitswesen, das allen Patientinnen und Patienten offenstehen soll, ist das inakzeptabel. Ein Vergleich mit Deutschland zeigt den dringenden Nachholbedarf der Schweiz auf. In Deutschland sind rund 90 Prozent der neuen innovativen Medikamente, welche in der EMA in den Jahren 2020 bis 2023 zugelassen wurden, standardmässig verfügbar. In der Schweiz sind es mit 47 Prozent gerade einmal halb so viele wie in Deutschland. Jede zweite innovative Behandlungsmöglichkeit bleibt hierzulande unzugänglich – nicht aus medizinischen, sondern aus administrativen Gründen. Deutschland muss hier Benchmark sein.

[[Seite 5/27 · Druckseiten 6–7]]

## Kostenwahrnehmung und Faktenlage teilweise im Ungleichgewicht

Die Kostenfrage lässt sich in der Bevölkerung sehr gut anhand der Meinung über die Krankenkassenprämien ermitteln. Betrachtet man die Ergebnisse der aktuellen Umfrage, zeigt sich, dass diese erneut als grösste finanzielle Last für das Haushaltsbudget empfunden werden.

**[Grafik] Dauerhaftes oder gelegentliches Problem**

Frage: «Können Sie für jeden der folgenden Ausgabenbereiche Ihres Haushalts angeben, inwiefern er für Sie ein Problem darstellt?»

Darstellung: Liniendiagramm, gleitender Mittelwert über 3 Jahre, in % Stimmberechtigte; dauerhaftes/gelegentliches Problem; Zeitachse 97, 99, 01, 03, 05, 07, 09, 11, 13, 15, 17, 19, 21, 23, 25; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; übrige Punkte nicht eindeutig ablesbar (Linien ohne Wertbeschriftung).

| Jahr | Krankenkassenprämien | Zahnarztrechnungen | Steuern | Arztrechnungen, Ausgaben für Medikamente | Sonstige Versicherungen | Miete für die Wohnung oder für Wohneigentum |
|---|---|---|---|---|---|---|
| 2025 (beschriftet) | 30 | 26 | 26 | 20 | 15 | 13 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’180)

**[Ende Grafik]**

Mit Blick bis 1997 zurück ist erkennbar, dass dieses Empfinden grossen Schwankungen ausgesetzt ist. Die Krankenkassenprämien wogen einerseits schon immer schwer, andererseits ist es dennoch überraschend, wie viel mehr Gewicht sie beispielsweise 2011 hatten. Von da an begann die wahrgenommene Belastung für das Haushaltsbudget stetig zu sinken. Ab der COVID-19-Pandemie jedoch stagnierte diese Abnahme und der Trend zeigt wieder nach oben. Auffällig: Die wechselhafte Entwicklung der letzten 25 Jahre passt nicht zum Verhältnis von Prämien, Reallöhnen und dem BIP: Die Reallöhne und das BIP der Schweiz sind in absoluten Werten stärker gestiegen als die Krankenkassenprämien. Demzufolge müsste die Sorge über die hohen Prämien theoretisch sinken. Eine potenzielle Ursache könnte der verstärkte öffentliche Diskurs über Gesundheitskosten sein, welcher möglicherweise dazu führt, dass die tatsächliche Prämienlast stärker wahrgenommen wird.

**[Grafik] Pro-Kopf Wachstum von OKP-Kosten, BIP und Löhnen**

Darstellung: Liniendiagramm; Zeitachse 96, 97, 98, 99, 00, 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23; Werteachse 0, 20’000, 40’000, 60’000, 80’000, 100’000. Reihen: Gesamtwirtschaft (BIP pro Kopf); Mittlere Prämie in Franken je versicherte Person; Löhne (Median-Bruttoeinkommen). Wertstatus: nicht eindeutig ablesbar; für einzelne Jahre und Reihen keine Zahlen an den Linien beschriftet, der Verlauf ist ohne quantitative Zuordnung dargestellt.

Darstellung Interpharma mit Datengrundlage: Bundesamt für Gesundheit (2025), Statistik der obligatorischen Krankenpflegeversicherung. Bundesamt für Statistik (2025), Wachstums- und Produktivitätsstatistik (WPS). Bundesamt für Statistik (2025), Schweizerische Arbeitskräfteerhebung (SAKE).

**[Ende Grafik]**

Dies geht womöglich mit der Entwicklung einher, dass der Bund seit COVID-19 immer stärker für die Kostendämpfung verantwortlich gemacht wird. Heute wird er gar als klarer Hauptverantwortlicher gesehen. Dies, obwohl der Bund bzw. das BAG nur Medikamentenpreise festlegen kann, während die Tarifpartner und die Kantone grösseren Einfluss auf die Kosten ausüben können.

Die Sorge um die hohen Prämien fördert das Narrativ, Medikamente seien einer der Haupttreiber der Gesundheitskosten – ein Bild, das von vielen Akteuren verstärkt wird. Die Medikamentenpreise sind jedoch nicht das Problem. Zwar steigen die Gesundheitskosten weiter an – ebenso wie die Anzahl neuer Therapien und die durchschnittliche Lebenserwartung in der Schweiz. Die Medikamentenpreise hingegen sanken kontinuierlich. Doch ein genauerer Blick zeigt: Der Anteil der Medikamente an den Gesundheitskosten und den OKP-Gesamtkosten blieb über die vergangenen Jahre stabil oder stieg unterdurchschnittlich an. Konkret bedeutet das, dass nicht die Preise einzelner Medikamente der eigentliche Kostentreiber sind, sondern vielmehr die steigende verschriebene Menge jener Medikamente. Dies hat unter anderem mit der demografischen Entwicklung in der Schweiz sowie dem Erfolg in der Bekämpfung komplexer Krankheiten zu tun. Gerade in der Bekämpfung diverser Krebsarten macht die Forschung seit vielen Jahren riesige Fortschritte.

[[Seite 6/27 · Druckseiten 8–9]]

## Fazit

Im Hinblick auf die Solidarität haben das KVG und das Schweizer Gesundheitswesen grundsätzlich ihre Aufgaben und Ziele erfüllt. Der solidarische Grundgedanke ist fest in der Bevölkerung verankert. Allerdings zeigt sich auch, dass nach einer längeren Phase des Anstiegs die Solidarität aktuell abnimmt und das Kostenbewusstsein überwiegt – besonders dann, wenn eine Krankheit und damit die anfallenden Behandlungskosten als einfach vermeidbar gelten.

Auch die Qualität des Gesundheitswesens wird seit je positiv beurteilt. Dennoch sieht Interpharma Handlungsbedarf – besonders beim Zugang zu neuen innovativen Medikamenten, der sich im Verlauf der letzten Jahre stetig verschlechtert hat: Nur 47 Prozent der von der EMA zugelassenen neuen innovativen Medikamente sind in der Schweiz standardmässig verfügbar – ein echtes Problem für viele Patientinnen und Patienten. Benchmark ist hier Deutschland mit seiner 90-prozentigen, also etwa doppelt so hohen vollständigen Verfügbarkeit an EMA-zugelassenen Medikamenten.

Die Prämienlast wurde in der Vergangenheit teilweise als höher empfunden als heute und stand nicht immer an erster Stelle der Budgetbelastung. Obwohl Reallöhne und BIP stärker wachsen als die Prämien, steigt seit COVID-19 das Kostenbewusstsein wieder deutlich. Fälschlicherweise werden dafür seit Jahren die Medikamentenpreise stark mitverantwortlich gemacht. Vielmehr ist die kontinuierlich wachsende Menge verschriebener Medikamente für die, absolut gesehen, hohen Medikamentenkosten verantwortlich. Dies kann aber unter anderem mit den wachsenden medizinischen Möglichkeiten begründet werden – viele Krankheiten, die früher ein Todesurteil bedeuteten, können heute erfolgreich behandelt werden.

[Bild: Handschriftliche Unterschrift.]

Dr. René Buholzer
Geschäftsführer und Delegierter des Vorstandes

[[Seite 7/27 · Druckseiten 10–11]]

## 2 Executive Summary

## Zentrale Versprechen des KVG eingelöst, doch Reformdruck wächst

Fast drei Jahrzehnte nach Einführung des Krankenversicherungsgesetzes (KVG) sieht eine klare Mehrheit die zentralen Versprechen des Gesetzes als eingelöst, etwa den Zugang zur Grundversorgung oder die solidarische Prämienverbilligung. Demgegenüber bewertet die Bevölkerung das Ziel der Kostendämpfung als nicht erreicht. Zudem bleibt das sogenannte Prämienproblem ihrer Meinung nach ungelöst: Die Prämienentwicklung stösst auf wenig Verständnis. Reformen gewinnen an Zustimmung. Die Kopfprämie wird weiterhin mehrheitlich getragen, doch die Bereitschaft zur Weiterentwicklung steigt.

## Kostensensibilität wächst

Schweizweit zeigt sich eine wachsende Sensibilität gegenüber Kostenaspekten. Bei mehreren Zielkonflikten ist eine zunehmende Offenheit für kostenorientierte Lösungen erkennbar. Zwar bleibt der Wunsch nach einem qualitativ hochwertigen Gesundheitswesen weiter bestehen, doch mehren sich Anzeichen dafür, dass Kostenüberlegungen bei der Ausgestaltung stärker ins Gewicht fallen. Die Stimmbevölkerung ist zunehmend bereit, unter anderem bei der freien Arzt- und Spitalwahl sowie beim Umfang des Leistungskatalogs, Einschränkungen in Kauf zu nehmen.

## Sprachregionale Unterschiede zu Beobachten

In der Romandie bekunden rund zwei Drittel der Befragten Mühe bei der Bezahlung der Krankenkassenprämien. Dieser Wert liegt deutlich über jenem der übrigen Landesteile und erreicht ein Niveau, das zuletzt um das Jahr 2011 zu beobachten war. In der Deutschschweiz hingegen bleibt der wahrgenommene Problemdruck vergleichsweise moderat, obwohl auch hier eine leichte Zunahme gegenüber dem Vorjahr festzustellen ist. Parallel dazu zeigt sich in der Romandie eine besonders ausgeprägte Bereitschaft, persönliche Einschränkungen zur Kostendämpfung zu akzeptieren. Gleichzeitig fällt dort die Zufriedenheit mit der Qualität des Gesundheitswesens etwas zurückhaltender aus, auch wenn sie insgesamt weiterhin sehr hoch ist.

## Solidarischer Zugang zu innovativen Therapien gewünscht

Beim Zugang zu innovativen und kostenintensiven Therapien zeigt sich eine klare Haltung: Die Stimmbevölkerung befürwortet eine Übernahme durch die Grundversicherung, sofern ein systemischer Nutzen gegeben ist, etwa durch Einsparungen im Pflegebereich oder eine berufliche Wiedereingliederung. Gleichzeitig lehnen die Stimmberechtigten pauschale Begrenzungen wie fixe Jahresbudgets oder starre Maximalbeträge pro Lebensjahr mehrheitlich ab. Gewünscht wird eine faire, aber effizient gesteuerte Versorgung im Interesse der Gemeinschaft.

[[Seite 8/27 · Druckseiten 12–13]]

## 3 Schwerpunktthemen 2025

Fast drei Jahrzehnte nach Einführung des Krankenversicherungsgesetzes (KVG) zeigt sich ein differenziertes Urteil der Schweizer Bevölkerung. Das zentrale Ziel, allen Einwohnerinnen und Einwohnern Zugang zur medizinischen Grundversorgung zu ermöglichen, wird aus Sicht der Stimmberechtigten klar erreicht. Insgesamt 96 Prozent sehen dieses Versprechen als eher oder ganz eingelöst. Auch die individuelle Prämienverbilligung zur Entlastung einkommensschwacher Haushalte beurteilen sie mehrheitlich positiv. 83 Prozent erachten dieses Ziel als erfüllt. Ebenfalls gross ist die Zustimmung zur Zielsetzung, allen Versicherten unabhängig von der gewählten Kasse dieselben medizinischen Grundleistungen bereitzustellen (72%).

Etwas zurückhaltender fällt die Bewertung der finanzierungs- und strukturpolitischen Zielsetzungen aus. 67 Prozent finden, dass ein faires und solidarisch finanziertes System verwirklicht wurde. 29 Prozent beurteilen dieses Ziel hingegen als eher oder überhaupt nicht erreicht. Die Aussage, dass eine freie Kassenwahl den Wettbewerb fördert und dadurch bessere Angebote entstehen, bewerten die Stimmberechtigten gemischt. Während etwas mehr als die Hälfte diesem Punkt zustimmt (58%), lehnen 34 Prozent diese Einschätzung ab.

Besonders skeptisch ist die Bevölkerung bei der Frage nach der Wirksamkeit von Massnahmen zur Kostendämpfung und zur effizienten Nutzung der Ressourcen. Nur 41 Prozent sehen dieses Ziel als erfüllt an, während 49 Prozent der Meinung sind, dass es verfehlt worden ist.

**[Kernaussagen]**
Die sozialpolitischen Kernanliegen des KVG sind aus Sicht der Bevölkerung mehrheitlich eingelöst worden. Deutlich weniger Zustimmung erfahren jedoch jene Elemente, die auf ökonomische Steuerung und systemische Effizienz zielen.
**[Ende Kernaussagen]**

**[Grafik 1] Einlösung Versprechen KVG**

Frage: «Mit der Einführung des Krankenversicherungsgesetzes (KVG) im Jahr 1996 wurden verschiedene Ziele verfolgt. Sind die folgenden Versprechen Ihrer Meinung nach eingelöst worden?»

Darstellung: gestapelte horizontale Balken, in % Stimmberechtigte. Wertstatus: alle Segmente beschriftet.

| Versprechen | Voll und ganz eingelöst | Eher eingelöst | Weiss nicht / keine Antwort | Eher nicht eingelöst | Überhaupt nicht eingelöst |
|---|---|---|---|---|---|
| Alle Einwohnerinnen und Einwohner der Schweiz haben durch die Einführung der obligatorischen Krankenversicherung Zugang zur medizinischen Grundversorgung. | 40 | 56 | 1 | 2 | 1 |
| Um die finanzielle Belastung von einkommensschwachen Haushalten zu verringern gibt es eine soziale Absicherung durch die individuelle Prämienverbilligung. | 21 | 62 | 2 | 11 | 4 |
| Alle Versicherten sollen dieselben medizinischen Grundleistungen erhalten, unabhängig von ihrer Krankenkasse. | 21 | 51 | 6 | 17 | 5 |
| Ein faireres Finanzierungsmodell, bei dem alle solidarisch zur Deckung der Gesundheitskosten beitragen. | 24 | 43 | 4 | 22 | 7 |
| Die freie Wahl der Krankenkassen, die zu mehr Wettbewerb zwischen den Krankenkassen und dadurch zu besseren Angeboten für die Versicherten führt. | 15 | 43 | 8 | 18 | 16 |
| Dämpfung der Kostensteigerung und effizientere Nutzung der Ressourcen. | 11 | 30 | 10 | 26 | 23 |

© gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 1]**

[[Seite 9/27 · Druckseiten 14–15]]

Ein Aspekt, der im Zusammenhang mit dem KVG seit jeher zu Diskussionen führt, sind die Krankenkassenprämien. Die Schweizer Stimmberechtigten empfinden den Anstieg der Krankenkassenprämien mehrheitlich als nicht verhältnismässig. Schweizweit gesehen stufen drei Viertel der Befragten den Prämienanstieg als überhöht ein (75%, Skalenwerte 4 bis 6). In der Deutschschweiz fällt die Bewertung etwas differenzierter aus. Hier zeigt sich eine leicht grössere Bereitschaft, den Anstieg der Prämien als nachvollziehbar zu akzeptieren. In der Romandie und der Svizzera italiana hingegen überwiegt eine deutlich kritischere Haltung.

**[Kernaussagen]**
Diese Einschätzung verdeutlicht eine breite Unzufriedenheit mit der Prämienentwicklung. Der Prämienanstieg wird vielfach als nicht im Einklang mit den tatsächlichen Kostensteigerungen wahrgenommen.
**[Ende Kernaussagen]**

Die Unzufriedenheit mit der Höhe der Krankenkassenprämie spiegelt sich auch in der Bewertung der finanziellen Belastung im Alltag wider: Knapp ein Drittel bekundet Mühe, die Krankenkassenprämien zu bezahlen (30%). Die Begleichung von Zahnarztrechnungen (26%) und Steuern (26%) stellt für rund ein Viertel ein gelegentliches oder dauerhaftes Problem dar. Weniger stark ins Gewicht fallen Arztrechnungen und Ausgaben für Medikamente (20%), sonstige Versicherungen (15%) und die Miete für die Wohnung resp. die Zinsen für das Wohneigentum (18%).

**[Hinweis Transkription: Der Fliesstext nennt für Miete/Zinsen 18%, die Grafik 3 beschriftet den Endwert der entsprechenden Reihe mit 13; Werte wie gedruckt belassen.]**

**[Grafik 2] Verhältnismässigkeit Prämienanstieg nach Sprache**

Frage: «Seit der Einführung des Krankenversicherungsgesetzes (KVG) im Jahr 1996 sind die Prämien der Grundversicherung in der Schweiz stetig gestiegen. Dieser Anstieg wird unterschiedlich wahrgenommen. Es folgen zwei Aussagen zum Prämienanstieg. Wenn Sie mit Aussage A übereinstimmen, wählen Sie die Zahl 1 oder eine Zahl nahe bei 1. Wenn Sie mit Aussage B übereinstimmen, wählen Sie die Zahl 6 oder eine Zahl nahe bei 6. Mit den Werten dazwischen können Sie Ihre Meinung abstufen. Der Prämienanstieg ist ... A) nachvollziehbar, da er den steigenden Kosten im Gesundheitswesen entspricht oder B) überhöht und steht nicht im Verhältnis zu den tatsächlichen Kostensteigerungen.»

Darstellung: gestapelte Säulen, in % Stimmberechtigte. Wertstatus: gedruckte Segmentwerte beschriftet; nicht beschriftetes Segment 2 der ICH «–».

| Sprache | 1 A) nachvollziehbar | 2 | 3 | 4 | 5 | 6 B) überhöht | Weiss nicht / keine Antwort |
|---|---|---|---|---|---|---|---|
| DCH | 8 | 7 | 12 | 24 | 26 | 22 | 1 |
| FCH | 1 | 3 | 15 | 40 | 18 | 21 | 2 |
| ICH | 1 | – | 3 | 20 | 47 | 27 | 2 |

© gfs.bern, Gesundheitsmonitor 2025 (N = 1’209), sig., Cramér’s V=0.22

**[Ende Grafik 2]**

**[Grafik 3] Dauerhaftes oder gelegentliches Problem**

Frage: «Können Sie für jeden der folgenden Ausgabenbereiche Ihres Haushalts angeben, inwiefern er für Sie ein Problem darstellt?»

Darstellung: Liniendiagramm, gleitender Mittelwert über 3 Jahre, in % Stimmberechtigte, dauerhaftes/gelegentliches Problem; Zeitachse 97, 99, 01, 03, 05, 07, 09, 11, 13, 15, 17, 19, 21, 23, 25; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; übrige Jahre nicht eindeutig ablesbar (Linien ohne Wertbeschriftung).

| Jahr | Krankenkassenprämien | Zahnarztrechnungen | Steuern | Arztrechnungen, Ausgaben für Medikamente | Sonstige Versicherungen | Miete für die Wohnung oder für Wohneigentum |
|---|---|---|---|---|---|---|
| 2025 (beschriftet) | 30 | 26 | 26 | 20 | 15 | 13 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’180)

**[Ende Grafik 3]**

[[Seite 10/27 · Druckseiten 16–17]]

Langfristig betrachtet bleibt die wahrgenommene Kostenbelastung in der deutsch- und italienischsprachigen Schweiz unterdurchschnittlich, wobei in der Deutschschweiz eine leichte Zunahme im Vergleich zum Vorjahr zu beobachten ist. Der Problemdruck rund um Zahnarztrechnungen (18%, +6 Prozentpunkte), Krankenkassenprämien (17%, +7 Prozentpunkte) und Steuern (15%, +5 Prozentpunkte) nimmt am stärksten zu.

In der Romandie ist die Wahrnehmung finanzieller Probleme in sämtlichen Ausgabenbereichen deutlich ausgeprägter als in den übrigen Sprachregionen. Dennoch zeigt sich in fast allen Bereichen – mit Ausnahme der Krankenkassenprämien – ein rückläufiger Trend.

Bezüglich der Krankenkassenprämien geben rund zwei Drittel der Befragten an, gelegentlich oder dauerhaft Schwierigkeiten bei der Begleichung der Rechnungen zu haben (69%). Damit erreicht dieser Wert erneut ein Niveau, das zuletzt um das Jahr 2011 beobachtet wurde. Trotz zwischenzeitlicher Entspannung blieb die Bezahlung der Krankenkassenprämien ein zentrales Thema im öffentlichen Diskurs.

**[Grafik 4] Dauerhaftes oder gelegentliches Problem, Deutschschweiz**

Frage: «Können Sie für jeden der folgenden Ausgabenbereiche Ihres Haushalts angeben, inwiefern er für Sie ein Problem darstellt?»

Darstellung: Liniendiagramm, gleitender Mittelwert über 3 Jahre, in % Stimmberechtigte*, dauerhaftes/gelegentliches Problem; Zeitachse 97, 99, 01, 03, 05, 07, 09, 11, 13, 15, 17, 19, 21, 23, 25; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; andere Jahreswerte nicht eindeutig ablesbar (Linien ohne Wertbeschriftung).

| Jahr | Zahnarztrechnungen | Krankenkassenprämien | Steuern | Arztrechnungen, Ausgaben für Medikamente | Sonstige Versicherungen | Miete für die Wohnung oder für Wohneigentum |
|---|---|---|---|---|---|---|
| 2025 (beschriftet) | 18 | 17 | 15 | 7 | 9 | 6 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 710)

**[Ende Grafik 4]**

**[Grafik 5] Dauerhaftes oder gelegentliches Problem, Romandie**

Frage: «Können Sie für jeden der folgenden Ausgabenbereiche Ihres Haushalts angeben, inwiefern er für Sie ein Problem darstellt.?»

Darstellung: Liniendiagramm, gleitender Mittelwert über 3 Jahre, in % Stimmberechtigte*, dauerhaftes/gelegentliches Problem; Zeitachse 97, 99, 01, 03, 05, 07, 09, 11, 13, 15, 17, 19, 21, 23, 25; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; andere Jahreswerte nicht eindeutig ablesbar (Linien ohne Wertbeschriftung).

| Jahr | Krankenkassenprämien | Zahnarztrechnungen | Steuern | Arztrechnungen, Ausgaben für Medikamente | Sonstige Versicherungen | Miete für die Wohnung oder für Wohneigentum |
|---|---|---|---|---|---|---|
| 2025 (beschriftet) | 69 | 52 | 60 | 53 | 46 | 37 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 300)

**[Ende Grafik 5]**

[[Seite 11/27 · Druckseiten 18–19]]

Doch wen sieht die Stimmbevölkerung in der Verantwortung für den Prämienanstieg? Die Stimmberechtigten sehen die Ursachen für den Anstieg der Krankenkassenprämien breit gestreut, mit deutlicher Fokussierung auf Personen, die medizinische Leistungen in Anspruch nehmen, obwohl sie nicht krank sind (31%). Es folgen die Verwaltungskosten im ganzen Gesundheitswesen (26%). Weitere häufig genannte Ursachen sind die steigende Anzahl älterer Menschen (21%), die Krankenkassen selbst (17%), unnötige Abklärungen (15%) sowie die Pharmaindustrie (14%). Auch strukturelle Schwächen wie fehlende Effizienz (13%) und die steigende Erwartungshaltung gegenüber der Gesundheitsversorgung (11%) nimmt die Bevölkerung als relevante Kostentreiber wahr.

**[Kernaussagen]**
Die Befragten sehen die Hauptursachen für steigende Prämien eher im System selbst, beispielsweise durch Übernutzung, organisatorische Ineffizienzen und bei den Verwaltungskosten als bei einzelnen Berufsgruppen.
**[Ende Kernaussagen]**

Um das Krankenversicherungssystem zu verbessern, stehen verschiedene Forderungen im Raum. Gleichzeitig zeigt sich die Bevölkerung mit dem bestehenden Prämiensystem, das aus Kopfprämien und individueller Prämienverbilligung besteht, nach wie vor sehr zufrieden (84%). Die höchste Reformbereitschaft zeigt sich bei der Einführung einer Gebühr für Bagatellfälle in der Spitalnotfallaufnahme (86%). Knapp dahinter folgen der Vorschlag, dass Medikamente für Bagatellen nicht mehr von der Krankenkasse bezahlt werden sollen (81%), und der vollumfängliche Abzug der Prämien vom steuerbaren Einkommen (81%). Die Einführung von automatischen Massnahmen zur Kostenbegrenzung (67%), die Gestaltung von einkommensabhängigen Prämien (56%) und Kostenübernahmen für medizinische Behandlungen im Ausland (56%) finden ebenfalls bei einer klaren Mehrheit Zuspruch. Die Hälfte spricht sich für eine Budget-Krankenkasse, die den Bezug von Generika, die Wahl einer höheren Franchise und das elektronische Patientendossier (EPD) voraussetzt, aus (50%). Sowohl eine staatliche Krankenkasse (48%) als auch die Erhöhung der Maximal- (41%) und der Minimalfranchise (35%) unterstützen weniger als die Hälfte. Die Idee, nur noch Versicherungsmodelle anzubieten, die eine Erstanlaufstelle vorsehen, stösst lediglich bei rund einem Viertel auf Interesse (27%).

**[Grafik 6] Verursacher für die Steigerung der Krankenkassenprämien**

Frage: «Ich gebe Ihnen hier eine Liste mit verschiedenen Verursachern für die Steigerung bei den Krankenkassenprämien. Welcher ist für Sie der hauptsächliche Grund, was der zweite Grund?»

Darstellung: horizontale Balken, in % Stimmberechtigte. Wertstatus: Werte für 1. und 2. Nennung beschriftet; bei Weiss nicht/keine Antwort nur 1. Nennung beschriftet.

| Verursacher | 1. Nennung | 2. Nennung |
|---|---|---|
| Menschen, die zum Arzt gehen, obwohl sie nicht krank sind | 18 | 13 |
| Verwaltungskosten im ganzen Gesundheitswesen | 14 | 12 |
| Die steigende Anzahl von alten Menschen | 11 | 10 |
| Krankenkassen selbst | 6 | 11 |
| Unnötige Abklärungen | 6 | 9 |
| Pharmaindustrie | 8 | 6 |
| Fehlende Effizienz im Gesundheitswesen | 7 | 6 |
| Steigende Erwartungen an die Qualität der Gesundheitsversorgung | 8 | 3 |
| Leistungserweiterung in der Grundversicherung | 5 | 3 |
| Spitäler im Allgemeinen | 3 | 4 |
| Süchtige | 3 | 4 |
| Teure medizinische Instrumente | 2 | 3 |
| Ausbau der Pflege | 2 | 3 |
| Spitex-Organisationen | 2 | 2 |
| Ärztinnen und Ärzte | 1 | 3 |
| Medizinische Forschung | 1 | 2 |
| Apotheken | 1 | 1 |
| Weiss nicht/keine Antwort | 3 | – |

© gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 6]**

[[Seite 12/27 · Druckseiten 20–21]]

**[Grafik 7] Forderungen zu den Krankenkassen**

Frage: «Aktuell werden in der Politik rund um Krankenkassen verschiedene Vorschläge diskutiert. Bitte geben Sie jeweils an, ob Sie mit den verschiedenen Vorschlägen einverstanden sind?»

Darstellung: gestapelte horizontale Balken, in % Stimmberechtigte. Wertstatus: alle Segmentwerte beschriftet.

| Forderung | Sehr einverstanden | Eher einverstanden | Weiss nicht / keine Antwort | Eher nicht einverstanden | Gar nicht einverstanden |
|---|---|---|---|---|---|
| Gebühr für Bagatellfälle in Spitalnotfallaufnahme | 33 | 53 | 3 | 7 | 4 |
| Kopfprämie | 26 | 56 | 5 | 9 | 4 |
| Medikamente für Bagatellen nicht bezahlen | 28 | 53 | 3 | 10 | 6 |
| Vollumfänglicher Abzug vom steuerbaren Einkommen | 34 | 47 | 5 | 11 | 3 |
| Automatische Massnahmen zur Kostenbegrenzung | 25 | 42 | 8 | 18 | 7 |
| Einkommensabhängig Prämie | 13 | 43 | 7 | 27 | 10 |
| Günstigere Behandlungen im Ausland bezahlen | 22 | 34 | 10 | 27 | 7 |
| Budget-Krankenkasse | 11 | 39 | 11 | 32 | 7 |
| Einheitskasse | 17 | 31 | 17 | 26 | 9 |
| Maximalfranchise erhöhen | 12 | 29 | 5 | 40 | 14 |
| Minimale Franchise erhöhen | 10 | 25 | 4 | 41 | 20 |
| Nur Versicherungsmodelle mit Erstanlaufstelle | 5 | 22 | 11 | 42 | 20 |

© gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 7]**

Die Zustimmung zum aktuellen Prämiensystem aus einer Kopfprämie und Subventionen für tiefere Einkommen bleibt über die Jahre hinweg weitgehend stabil. Gleichzeitig zeigt sich ein wachsender Zuspruch für Reformvorschläge, was auf eine zunehmende Offenheit der Bevölkerung gegenüber strukturellen Neuerungen im Gesundheitssystem hinweist.

**[Grafik 8] Leistungskatalog**

Frage: «Die Grundversicherung deckt alle notwendigen medizinischen Leistungen ab und wurde in verschiedenen Bereichen ausgebaut. Darüber hinausgehende Leistungen müssen die Versicherten mit Zusatzversicherungen abdecken, wobei die Kassen hier nicht verpflichtet sind, den Versicherten aufzunehmen. Sind Sie beim Leistungskatalog, der durch die Grundversicherung abgedeckt wird, ...»

Darstellung: gestapelte Säulen, in % Stimmberechtigte*. Wertstatus: alle Segmentwerte beschriftet (Zeilensummen = 100).

| Jahr | Für einen Ausbau | Für das Belassen auf heutigen Stand | Für einen Abbau | Weiss nicht/keine Antwort |
|---|---|---|---|---|
| 2016 | 29 | 59 | 9 | 3 |
| 2017 | 27 | 58 | 11 | 4 |
| 2018 | 16 | 70 | 5 | 9 |
| 2019 | 26 | 63 | 5 | 6 |
| 2020 | 25 | 67 | 4 | 4 |
| 2021 | 43 | 48 | 7 | 2 |
| 2022 | 36 | 55 | 6 | 3 |
| 2023 | 37 | 57 | 4 | 2 |
| 2024 | 33 | 60 | 4 | 3 |
| 2025 | 22 | 49 | 19 | 10 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 8]**

Eine weitere Möglichkeit, wie das Krankenversicherungssystem umgestaltet werden könnte, liegt in der Anpassung des Leistungskatalogs.

Eine relative Mehrheit der Stimmberechtigten spricht sich weiterhin für das Belassen des aktuellen Leistungskatalogs der obligatorischen Grundversicherung aus. 49 Prozent befürworten den heutigen Umfang beizubehalten. Jeweils rund ein Fünftel der Befragten unterstützt eine Anpassung des Katalogs, wobei sich 22 Prozent für einen Ausbau und 19 Prozent für eine Reduktion der abgedeckten Leistungen aussprechen.

[[Seite 13/27 · Druckseiten 22–23]]

Die Frage, welche konkreten Leistungen von der obligatorischen Grundversicherung übernommen werden sollen und welche zulasten der versicherten Person gehen, wird in der Bevölkerung unterschiedlich beurteilt. Die Stimmberechtigten differenzieren zwischen medizinischen Indikationen, bei denen eine solidarische Finanzierung erwartet wird, und solchen, bei denen Eigenverantwortung im Vordergrund steht.

Eine klare Mehrheit der Bevölkerung erwartet eine Finanzierung über die Grundversicherung insbesondere bei schwerwiegenden, chronischen oder nicht selbst verschuldeten Erkrankungen. So befürworten 93 Prozent eine Kassenleistung bei seltenen Krankheiten, 91 Prozent eine solche bei der Betreuung von Angehörigen mit einer Behinderung, und 90 Prozent eine Kassenleistung bei der Früherkennung von Krebs. Auch bei der Prävention von Herz-Kreislauf-Erkrankungen (84%), bei psychischen Beschwerden (81%) sowie bei stressbedingten Beschwerden (70%) wird mehrheitlich eine Kostenübernahme durch die Versicherung gewünscht. Bei Themen mit möglichem Bezug zum individuellen Lebensstil spricht sich nur eine Minderheit für eine Kostenübernahme durch die Krankenkasse aus. Die Einschätzungen zur Kostenübernahme durch die Grundversicherung zeigen sich über die Jahre hinweg weitgehend konstant. Gleichzeitig ist bei einzelnen Leistungen eine abnehmende Zustimmung zur Finanzierung durch die Krankenkassen erkennbar. Deutlich rückläufig ist die Erwartung einer Kostenübernahme bei der ärztlich verordneten Heroinabgabe, bei ungewollter Kinderlosigkeit, bei Schäden, die durch Rauch oder Alkohol entstehen, sowie bei gewichtsbedingten Beschwerden.

**[Kernaussagen]**
Die Stimmbevölkerung differenziert nach Ursache und Schweregrad der Gesundheitsbelastung. Während Solidarität bei schweren, chronischen oder genetisch bedingten Erkrankungen breit getragen wird, tritt bei vermeidbaren oder selbstbeeinflussbaren Risiken zunehmend das Prinzip der Eigenverantwortung in den Vordergrund.
**[Ende Kernaussagen]**

**[Grafik 9] Selbstbezahlte Leistungen/Krankenkassenleistungen**

Frage: «Es gibt ein paar Situationen, wo Leistungen in der Grundversicherung vergütet werden können. Bitte geben Sie bei jeder an, wann Ihrer Ansicht nach die betroffene Person selbst die Leistungen bezahlen sollte und wann Sie der Ansicht sind, dass die Kassen dies tun sollten.»

Darstellung: Liniendiagramm, in % Stimmberechtigte*, Kassenzahlung; Zeitachse 97, 99, 01, 03, 05, 07, 09, 11, 13, 15, 17, 19, 21, 23, 25; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; übrige Jahre nicht eindeutig ablesbar (dichte Linien ohne Wertbeschriftung).

| Leistung | 2025 (beschriftet) |
|---|---|
| Bei seltenen Krankheiten | 93 |
| Bei Behinderung eines Familienangehörigen | 91 |
| Bei der Früherkennung von Krebs | 90 |
| Bei der Vorbeugung von Herz-/Kreislaufkrankheiten | 84 |
| Bei psychischen Beschwerden | 81 |
| Bei Beschwerden, durch Stress verursacht | 70 |
| Bei gewichtsbedingten Beschwerden | 53 |
| Bei ungewollter Kinderlosigkeit | 49 |
| Bei der Vorbeugung von Geschlechtskrankheiten (Prep/HPV-lmpfung) | 43 |
| Bei ärztlich verordneter Heroinabgabe | 35 |
| Bei Schäden, die durch Rauchen oder Alkohol entstehen | 23 |
| Bei Abhängigkeit von Drogen | 17 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’190)

**[Ende Grafik 9]**

---

— Ende Teil 1 von 2 · Kontrollwort Teil 1: UETLIBERG-26 · weiter mit teil-02.md —
