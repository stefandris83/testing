# LAV-T02 · Volltext · Teil 2 von 2 (PDF-Seiten 14–27 von 27)

Studie: Das Wichtigste in Kürze zum Gesundheitsmonitor 2025: Kostenbewusstsein innerhalb der Bevölkerung nimmt zu · Quelldatei: gesundheitsmonitor-2025-f5238f4c.pdf · Transkript-Version 1.0 · 2026-10-15
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 2 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T02, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 14/27 · Druckseiten 24–25]]

## 4 Ausgewählte Analysen

## 4.1 Entwicklungen im Gesundheitswesen

Die Schweizer Stimmbevölkerung ist mit der Qualität des Gesundheitswesens weiterhin äusserst zufrieden. Rund drei Viertel der Befragten schätzen sie als gut oder sehr gut ein (73%). Weitere 23 Prozent stufen das Schweizer Gesundheitswesen als eher gut ein. Kritik an der Qualität wird kaum geäussert.

**[Kernaussagen]**
Während in der deutsch- und der italienischsprachigen Schweiz rund ein Viertel das Gesundheitswesen als sehr gut bewertet (27% resp. 25%), sind es in der Romandie lediglich 16 Prozent. Insgesamt überwiegt auch in der französischsprachigen Schweiz die Zufriedenheit mit der Qualität des Gesundheitswesens. Sie fällt insgesamt jedoch etwas verhaltener aus als in den übrigen Sprachregionen.
**[Ende Kernaussagen]**

Die Wunschvorstellungen hinsichtlich der Ausgestaltung des Gesundheitswesens bleiben im Grossen und Ganzen stabil. Dennoch lassen sich im Jahr 2025 einige Trends erkennen, die für ein wachsendes Kostenbewusstsein seitens der Bevölkerung sprechen.

Die Forderung nach einer Grundversicherung, die sämtliche Leistungen abdeckt, ist nach wie vor vorhanden. Gleichzeitig zeigt sich erstmals seit 2019 eine gewisse Offenheit gegenüber einem Modell, das stärker auf die Abdeckung hoher Risiken fokussiert ist. Zudem soll das Gesundheitswesen gemäss der Bevölkerung gleichermassen durch den Markt und durch den Staat reguliert werden. Die Stimmberechtigten sehen den Bund gemeinsam mit den Kantonen in der Verantwortung für die Steuerung des Systems.

**[Grafik 10] Qualität Gesundheitswesen**

Frage: «Wie schätzen Sie ganz allgemein die Qualität des schweizerischen Gesundheitswesens ein?»

Darstellung: gestapelte Säulen, 04–25, in % Stimmberechtigte*. Wertstatus: die grossen Segmente 2025 sind beschriftet; kleine Segmente am oberen Rand und ihre Zuordnung nicht eindeutig ablesbar (überlagerte Beschriftungen in der Textebene). Die Zahlen 2 und 2 stehen oberhalb der 2025-Säule, ihre genaue Serienzuordnung ist nicht eindeutig ablesbar. Die drei grossen Kategorien sind für 2004–2025 beschriftet und in der untenstehenden Jahrestabelle wiedergegeben. Die übrigen kleinen Segmente sind nicht eindeutig zuzuordnen. Werteachse: 0, 20, 40, 60, 80, 100.

| Jahr | Sehr gut | Gut | Eher gut | Weiss nicht/keine Antwort | Eher schlecht | Schlecht | Sehr schlecht |
|---|---|---|---|---|---|---|---|
| 2025 (beschriftet) | 24 | 49 | 23 | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar | nicht eindeutig ablesbar |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’210)

Weitere im Seitenbild eindeutig beschriftete Segmente (2004–2025, drei grosse Kategorien):

| Jahr | Sehr gut | Gut | Eher gut |
|---|---|---|---|
| 04 | 26 | 49 | 19 |
| 05 | 26 | 41 | 23 |
| 06 | 29 | 41 | 25 |
| 07 | 27 | 46 | 21 |
| 08 | 33 | 43 | 20 |
| 09 | 26 | 48 | 21 |
| 10 | 44 | 33 | 19 |
| 11 | 36 | 41 | 20 |
| 12 | 35 | 41 | 20 |
| 13 | 26 | 44 | 27 |
| 14 | 23 | 43 | 31 |
| 15 | 21 | 48 | 27 |
| 16 | 24 | 51 | 23 |
| 17 | 20 | 51 | 23 |
| 18 | 23 | 57 | 19 |
| 19 | 20 | 41 | 37 |
| 20 | 16 | 49 | 32 |
| 21 | 17 | 48 | 32 |
| 22 | 25 | 40 | 31 |
| 23 | 16 | 57 | 23 |
| 24 | 25 | 48 | 24 |
| 25 | 24 | 49 | 23 |

**[Ende Grafik 10]**

**[Grafik 11] Wunschvorstellung Gesundheitswesen in der Schweiz**

Frage: «Bitte sagen Sie mir, was für ein Gesundheitswesen in der Schweiz Sie sich wünschen. Wenn Sie mit dem ersten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 1 oder nahe bei 1. Wenn Sie mit dem zweiten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 6 oder eine Zahl nahe bei 6.»

Darstellung: Liniendiagramm, Stimmberechtigte*, Mittelwerte; Jahre 2016–2025, Skala 1–5 (1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5). Wertstatus: Endwerte 2025 beschriftet; Zwischenjahre nicht eindeutig ablesbar (keine Wertbeschriftung).

| Wertepolarität | 2025 (beschriftet) |
|---|---|
| Risiko (vs. sämtliche Leistungen) | 3.6 |
| Markt (vs. Staat) | 3.5 |
| Kantone (vs. Bund) | 3.4 |
| Gemeinschaftsverantwortung (vs. Eigenverantwortung) | 3.2 |
| Quantität Leistungen (vs. Kosten) | 2.8 |
| Zugang zu Medikamenten (vs. Kosten) | 2.6 |
| Qualität Leistungen (vs. Kosten) | 2.4 |
| Freie Arztwahl (vs. vorgegebene Arztwahl) | 2.2 |

Lesehilfe: Bei jeder Wertepolarität war es möglich, sich zwischen dem einen und dem anderen Pol auf einer ganzzahligen Skala von 1 bis 6 zu positionieren. Werte von 3.5 bedeuten, dass die Stimmberechtigten im Durchschnitt genau zwischen den Polen stehen. Je grösser die Abweichung davon auf die eine oder andere Seite ist, desto klarer neigen die Befragten dem entsprechenden Werte-Pol zu.

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’190)

**[Ende Grafik 11]**

[[Seite 15/27 · Druckseiten 26–27]]

Mit Blick auf die Verantwortung favorisiert die Stimmbevölkerung weiterhin eine gemeinschaftlich getragene Verantwortung gegenüber der Eigenverantwortung. Dennoch ist eine Verschiebung zu mehr Eigenverantwortung erkennbar. Wenn sich Leistungsmenge und Kosten gegenüberstehen, bleibt die Tendenz bestehen, der Menge den Vorrang zu geben. Allerdings gewinnt auch hier die Kostenorientierung an Bedeutung. Ähnliche Verschiebungen zeigen sich beim Zugang zu Medikamenten: Dieser soll nach wie vor breit gewährleistet sein, doch nimmt das Kostenbewusstsein auch in diesem Bereich zu.

Auch bei der Abwägung von Qualität und Kosten wird die Qualität weiterhin klar bevorzugt, jedoch mit zunehmender Offenheit für kostensensible Überlegungen. Die freie Arztwahl bleibt ein verbreiteter Wunsch, doch auch hier zeigen sich Anzeichen einer gewissen Akzeptanz von Einschränkungen.

**[Kernaussagen]**
Schweizweit nimmt die Sensibilität für Kostenaspekte im Gesundheitswesen zu. Bei mehreren Wertepolaritäten zeigt sich eine wachsende Offenheit für kostenorientierte Lösungen. Die Bereitschaft, gewisse Einschränkungen zugunsten der Kostenkontrolle in Kauf zu nehmen, steigt.
**[Ende Kernaussagen]**

In der Romandie zeigt sich eine Annäherung an die Präferenzen der Gesamtbevölkerung. Während sich die Stimmberechtigten in der französischsprachigen Schweiz in früheren Jahren tendenziell ein stärker marktwirtschaftlich geprägtes Gesundheitswesen wünschten, ist nun eine Tendenz zu mehr staatlicher Steuerung erkennbar.

Hinsichtlich der Verantwortung bevorzugen die Befragten ein Modell, das sowohl gemeinschaftliche als auch individuelle Verantwortung berücksichtigt. Auch beim Leistungskatalog zeigt sich eine vermittelnde Haltung: Die Stimmberechtigten in der Romandie sprechen sich tendenziell für ein System aus, das ein ausgewogenes Verhältnis zwischen umfassender Leistungsabdeckung und einer Beschränkung auf hohe Risiken findet. In der Frage der Zuständigkeit zwischen Kantonen und Bund zeichnet sich ebenfalls ein ausgeglicheneres Bild ab.

**[Grafik 12] Wunschvorstellung Gesundheitswesen in der Schweiz, Romandie**

Frage: «Bitte sagen Sie mir, was für ein Gesundheitswesen in der Schweiz Sie sich wünschen. Wenn Sie mit dem ersten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 1 oder nahe bei 1. Wenn Sie mit dem zweiten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 6 oder eine Zahl nahe bei 6.»

Darstellung: Liniendiagramm, Stimmberechtigte*, Mittelwerte; Jahre 2016–2025, Skala 1–5 (1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5). Wertstatus: Endwerte 2025 beschriftet; andere Jahre nicht eindeutig ablesbar (Linien ohne Wertbeschriftung).

| Wertepolarität | 2025 (beschriftet) |
|---|---|
| Markt (vs. Staat) | 3.7 |
| Gemeinschaftsverantwortung (vs. Eigenverantwortung) | 3.6 |
| Risiko (vs. sämtliche Leistungen) | 3.5 |
| Kantone (vs. Bund) | 3.5 |
| Quantität Leistungen (vs. Kosten) | 3.1 |
| Zugang zu Medikamenten (vs. Kosten) | 3.0 |
| Qualität Leistungen (vs. Kosten) | 2.9 |
| Freie Arztwahl (vs. vorgegebene Arztwahl) | 2.7 |

Lesehilfe: Bei jeder Wertepolarität war es möglich, sich zwischen dem einen und dem anderen Pol auf einer ganzzahligen Skala von 1 bis 6 zu positionieren. Werte von 3.5 bedeuten, dass die Stimmberechtigten im Durchschnitt genau zwischen den Polen stehen. Je grösser die Abweichung davon auf die eine oder andere Seite ist, desto klarer neigen die Befragten dem entsprechenden Werte-Pol zu.

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 290)

**[Ende Grafik 12]**

[[Seite 16/27 · Druckseiten 28–29]]

Die Gewichtung der Leistungsmenge gegenüber den Kosten bleibt relativ stabil zugunsten der Menge. Auch die Qualität bewerten die Befragten weiterhin höher als die Kosten. Zudem gewinnt die freie Arztwahl im Meinungsbild der französischsprachigen Bevölkerung wieder leicht an Bedeutung. 

**[Kernaussagen]**
Das Kostenbewusstsein in der Romandie liegt auf einem ähnlichen Niveau wie im gesamtschweizerischen Durchschnitt. Frühere Unterschiede nehmen tendenziell ab. Insgesamt zeigen sich über die Sprachregionen hinweg Annäherungen in den Vorstellungen zur Ausgestaltung des Gesundheitswesens. 
**[Ende Kernaussagen]**

Die seit Jahrzehnten ansteigenden Gesundheitskosten stellen sowohl für die Politik als auch für die Bevölkerung eine zentrale Herausforderung dar, weshalb Reformen erforderlich sind. Vor diesem Hintergrund ist es von Bedeutung, zu wissen, welche Ausgestaltungen des Gesundheitssystems in der Bevölkerung mehrheitsfähig sind. Ebenso ist ein vertieftes Verständnis darüber notwendig, welche Ursachen die Stimmberechtigten für den Kostenanstieg erkennen und welche Massnahmen zur Kostensenkung sie sich vorstellen können. 

Als wichtigsten Grund für steigende Gesundheitskosten nennt die Stimmbevölkerung die Alterung der Bevölkerung. 93 Prozent der Befragten stufen sie als bedeutenden Treiber der Kosten ein. Ebenfalls zentral werden Behandlungen von chronischen Krankheiten bewertet, die gemäss 90 Prozent der Befragten zur Erhöhung der Kosten im Gesundheitswesen beitragen. Auch medizinische Fortschritte, die neue und kostenintensive Behandlungsmöglichkeiten mit sich bringen (87%) sowie komplexe administrative Abläufe (87%), werden als relevante Faktoren genannt.

**[Grafik 13] Wichtigkeit Gründe für den Gesundheitskostenanstieg**

Frage: «Die Kosten des Gesundheitswesens sind in den vergangenen Jahrzehnten angestiegen. Wie wichtig sind die folgenden Gründe Ihrer Meinung nach für den Kostenanstieg?»

Darstellung: gestapelte horizontale Balken, in % Stimmberechtigte. Wertstatus: alle Segmente beschriftet (Zeilensummen = 100).

| Grund | Sehr wichtig | Eher wichtig | Weiss nicht / keine Antwort | Eher nicht wichtig | Überhaupt nicht wichtig |
|---|---|---|---|---|---|
| Die Alterung der Bevölkerung lässt die Kosten im Gesundheitswesen steigen. | 37 | 56 | 1 | 5 | 1 |
| Chronische Krankheiten nehmen zu und verursachen langfristig hohe Behandlungskosten. | 31 | 59 | 1 | 7 | 2 |
| Fortschritte in der Medizin bringen teure Behandlungen mit sich. | 25 | 62 | 3 | 8 | 2 |
| Komplexe administrative Abläufe erhöhen die Betriebskosten im Gesundheitswesen. | 43 | 44 | 6 | 5 | 2 |
| Die Kosten im Gesundheitswesen steigen, weil einzelne Gruppen für sich finanzielle Vorteile daraus ziehen. | 33 | 45 | 13 | 7 | 2 |
| Durch die Zuwanderung erhöht sich die Nachfrage nach medizinischen Leistungen und treibt dadurch die Gesundheitskosten in die Höhe. | 31 | 46 | 5 | 13 | 5 |
| Bessere Diagnosetechniken und ein höheres Gesundheitsbewusstsein führen dazu, dass mehr Menschen ärztliche Leistungen in Anspruch nehmen. | 19 | 55 | 6 | 17 | 3 |
| Gut ausgebildetes Fachpersonal wird besser bezahlt, was die Lohnkosten antreibt. | 17 | 49 | 7 | 23 | 4 |

© gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 13]**

[[Seite 17/27 · Druckseiten 30–31]]

Rund drei Viertel sehen wirtschaftliche Interessen einzelner Gruppen (78%), die Zuwanderung (77%) und häufigere Konsultationen infolge besserer Diagnosetechniken (74%) als mitverantwortlich für die Kostenentwicklung. 

Etwas differenzierter beurteilt die Bevölkerung den Einfluss steigender Löhne im Gesundheitsbereich. 66 Prozent stufen dies als wichtigen Grund ein, während rund ein Viertel diesen Zusammenhang eher nicht oder gar nicht unterstützt (27%). 

**[Kernaussagen]**
Die Bevölkerung nimmt den Anstieg der Gesundheitskosten nicht als Folge einzelner isolierter Faktoren wahr, sondern als Ergebnis eines vielschichtigen Zusammenspiels struktureller, medizinischer und gesellschaftlicher Entwicklungen. 
**[Ende Kernaussagen]**

Um dem Anstieg der Gesundheitskosten entgegenzuwirken, kommen verschiedene Massnahmen in Betracht. Das zunehmende Kostenbewusstsein zeigt sich auch in der Bereitschaft der Bevölkerung, gewisse Einschränkungen zur Entlastung des Systems zu akzeptieren. 

Die grösste Zustimmung findet der Verzicht auf die freie Spitalwahl. 49 Prozent der Stimmberechtigten können sich diese Massnahme vorstellen, sofern damit eine Kostenreduktion erreicht wird. Etwas geringere Unterstützung erhalten Massnahmen wie die Einschränkung der freien Arztwahl (43%), ein eingeschränkter Zugang zu neuen Medikamenten oder neuen Behandlungsformen (41%), die Einschränkung der Verschreibungsfreiheit (37%) sowie eine Reduktion des Leistungskatalogs (36%). Auch wenn die Zustimmungswerte in diesen Bereichen tiefer liegen, lässt sich in allen hier erwähnten Fällen eine tendenzielle Zunahme der Akzeptanz feststellen.

**[Grafik 14] Haltung Massnahmen zur Kostensenkung**

Frage: «Welche der folgenden Massnahmen wären Sie selber bereit, für sich in Kauf zu nehmen, wenn dadurch die Kosten im Gesundheitswesen sinken würden?»

Darstellung: Liniendiagramm, in % Stimmberechtigte*, Auf jeden Fall und je nach Höhe Kostensenkung; Jahre 2016–2025; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; übrige Jahre nicht eindeutig ablesbar (keine Wertbeschriftung).

| Massnahme | 2025 (beschriftet) |
|---|---|
| Keine freie Spitalwahl | 49 |
| Keine freie Arztwahl | 43 |
| Eingeschränkter Zugang zu neuen modernen Medikamenten oder zu neuen Behandlungsformen | 41 |
| Keine Verschreibungsfreiheit | 37 |
| Kürzung des Leistungskatalogs in der Grundversicherung | 36 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 14]**

[[Seite 18/27 · Druckseiten 32–33]]

In der Romandie zeigt sich weiterhin eine deutlich höhere Bereitschaft, persönliche Einschränkungen zur Senkung der Gesundheitskosten in Kauf zu nehmen. Besonders gross ist die Akzeptanz für eine Abschaffung der freien Spitalwahl (80%). 

Auch andere Massnahmen stossen auf breite Zustimmung: Keine freie Arztwahl (65%), eingeschränkter Zugang zu neuen Medikamenten oder Behandlungsformen (59%), keine Verschreibungsfreiheit (56%) und selbst die Kürzung des Leistungskatalogs (47%) werden von einem substanziellen Anteil der Befragten zumindest unter bestimmten Bedingungen befürwortet. 

**[Kernaussagen]**
Personen aus der Romandie zeigen sich weiterhin kompromissbereiter als Personen aus den übrigen Regionen der Schweiz. Im Vergleich zu den Vorjahren ist jedoch ein Rückgang dieser Kompromissbereitschaft – mit Ausnahme bei der freien Spitalwahl – erkennbar. 
**[Ende Kernaussagen]**

In der öffentlichen Wahrnehmung zeigt sich eine Verschiebung hinsichtlich der Verantwortung für kostendämpfende Massnahmen im Gesundheitswesen. Erstmals wird der Bund von einer relativen Mehrheit der Stimmberechtigten (38%) als vorrangig verantwortlicher Akteur genannt. An zweiter Stelle folgen die Krankenkassen (29%), noch vor der Pharmaindustrie (22%), wobei beiden Akteuren im Vergleich zum Vorjahr weniger Verantwortung zugeschrieben wird. 

Rund ein Fünftel der Befragten (19%) sieht die Verantwortung bei den Kantonen. Die Erwartungshaltung gegenüber den Patientinnen und Patienten (19%), den Ärztinnen und Ärzten (15%) und den Spitälern (15%) ist rückläufig. Den kollektiven Ansatz, wonach alle Akteursgruppen gemeinsam zur Kostendämpfung beitragen sollen, unterstützen 20 Prozent der Befragten. 

**[Kernaussagen]**
Es zeigt sich ein wachsendes Bedürfnis nach klarer Zuständigkeit. Die Bevölkerung bevorzugt eine zentral koordinierte Verantwortung, bei der dem Bund eine führende Rolle zukommt. Wobei weitere systemrelevante Akteure wie Krankenkassen und die Pharmaindustrie ebenfalls Teil der Lösung sein sollen.
**[Ende Kernaussagen]**

**[Grafik 15] Haltung Massnahmen zur Kostensenkung, Romandie**

Frage: «Welche der folgenden Massnahmen wären Sie selber bereit, für sich in Kauf zu nehmen, wenn dadurch die Kosten im Gesundheitswesen sinken würden?»

Darstellung: Liniendiagramm, in % Stimmberechtigte, Auf jeden Fall und je nach Höhe Kostensenkung; Jahre 2016–2025; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; andere Jahreswerte nicht eindeutig ablesbar (Linien ohne Wertbeschriftung).

| Massnahme | 2025 (beschriftet) |
|---|---|
| Keine freie Spitalwahl | 80 |
| Keine freie Arztwahl | 65 |
| Eingeschränkter Zugang zu neuen modernen Medikamenten oder zu neuen Behandlungsformen | 59 |
| Keine Verschreibungsfreiheit | 56 |
| Kürzung des Leistungskatalogs in der Grundversicherung | 47 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 300)

**[Ende Grafik 15]**

**[Grafik 16] Verantwortung für Kostendämpfung**

Frage: «Wir haben hier die Liste mit Akteuren im Gesundheitswesen. Wer sollte Ihrer Meinung nach an erster Stelle stehen, wenn es um die Verantwortung für die Kostendämpfung im Gesundheitswesen geht?»

Darstellung: Liniendiagramm, in % Stimmberechtigte*, 1. und 2. Stelle summiert; Jahre 2016–2025; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; frühere Jahre nicht eindeutig ablesbar (Linien ohne Wertbeschriftung).

| Akteur | 2025 (beschriftet) |
|---|---|
| Bund | 38 |
| Krankenkassen | 29 |
| Pharmaindustrie | 22 |
| Alle miteinander | 20 |
| Patientinnen und Patienten | 19 |
| Kantone | 19 |
| Spitäler | 15 |
| Ärztinnen und Ärzte | 15 |
| Andere | 1 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 16]**

[[Seite 19/27 · Druckseiten 34–35]]

## 4.2 Pharmaindustrie und Medikamente



Ein weiterer wichtiger Akteur innerhalb des Gesundheitswesens ist die Pharmabranche. Die Stimmberechtigten erkennen die wirtschaftliche und die gesellschaftliche Bedeutung der Pharmaindustrie klar an. Für 95 Prozent ist sie eine wichtige Arbeitgeberin. Sie geniesst international einen guten professionellen Ruf (91%), und 90 Prozent sehen sie als Motor der Exportwirtschaft. Hinsichtlich der Standortbindung zeigen sich die Stimmberechtigten der Pharmabranche gegenüber ebenfalls wohlgesinnt. Vier Fünftel der Bevölkerung sind der Meinung, dass sich die Branche für den Standort Schweiz interessiert (80%). 

Etwas skeptischer ist die Bevölkerung, wenn es um die Gewinnverwendung und Transparenz geht. Rund die Hälfte hält hohe Gewinne für nötig zur Finanzierung von Forschung (53%), während 40 Prozent dieser Aussage gleichzeitig widersprechen. Besonders kritisch fällt das Urteil bei der Informationspolitik der Branche aus. 27 Prozent halten die Pharmaindustrie in der Schweiz für eine transparente Informantin. Mehr als die Hälfte hingegen beurteilt die Kommunikation als nicht ausreichend offen (58%). 

Die Erforschung und Entwicklung innovativer Therapien ist ein zentrales Handlungsfeld der Pharmaindustrie. Solche Therapien gelten als medizinisch vielversprechend, sind jedoch häufig mit hohen Kosten verbunden. Entsprechend intensiv wird die Frage diskutiert, unter welchen Bedingungen der Zugang zu solchen Behandlungen erfolgen soll. 

83 Prozent befürworten einen Zugang zu innovativen Therapien, sofern deren systemischer Nutzen ausgewiesen ist, etwa durch Einsparungen bei Pflegekosten oder durch eine erleichterte Wiedereingliederung in den Arbeitsmarkt. Ein gleichberechtigter Zugang zu innovativen Therapien geniesst ebenfalls hohe Zustimmungswerte (79%).

**[Grafik 17] Aussagen zur Pharmaindustrie**

Frage: «Es folgen allgemeine Aussagen zur Pharmaindustrie in der Schweiz. Inwiefern treffen die folgenden Aussagen Ihrer Meinung nach auf die Pharmaindustrie zu?»

Darstellung: gestapelte horizontale Balken, in % Stimmberechtigte. Wertstatus: ausgewiesene Segmente beschriftet; fehlende unbeschriftete Segmente «–».

| Aussage | Trifft voll und ganz zu | Trifft eher zu | Weiss nicht / keine Antwort | Trifft eher nicht zu | Trifft gar nicht zu |
|---|---|---|---|---|---|
| Die Pharmaindustrie ist eine wichtige Arbeitgeberin in der Schweiz. | 38 | 57 | 2 | 3 | – |
| Die Pharmaindustrie in der Schweiz geniesst einen guten professionellen Ruf im Ausland. | 35 | 56 | 5 | 4 | – |
| Die Pharmaindustrie ist über den Export ein Motor der schweizerischen Wirtschaft. | 30 | 60 | 4 | 4 | 2 |
| Die Pharmaindustrie interessiert sich für den Standort Schweiz. | 19 | 61 | 9 | 8 | 3 |
| Grosse Gewinne der Pharmaindustrie sind nötig, um die Forschung zu finanzieren. | 17 | 36 | 7 | 32 | 8 |
| Die Pharmaindustrie in der Schweiz informiert transparent über ihre Tätigkeiten. | 6 | 21 | 15 | 37 | 21 |

© gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 17]**

[[Seite 20/27 · Druckseiten 36–37]]

Bedingte Zugangskriterien, beispielsweise gestützt auf medizinische Erfolgsaussichten oder Gesundheitsindikatoren, stossen auf ein geteiltes Meinungsbild. 42 Prozent befürworten solche Regelungen, während 49 Prozent dagegen sind. Gleichzeitig sehen 35 Prozent der Befragten einen uneingeschränkten Zugang für alle Versicherten als zu kostspielig für das Gesundheitssystem an. Pauschale Begrenzungen der Kosten werden mehrheitlich abgelehnt. Ein fixes Jahresbudget pro Patientin oder Patient stösst bei 72 Prozent auf Ablehnung. Auch eine Begrenzung auf einen Maximalbetrag pro gerettetem Lebensjahr weisen 59 Prozent der Stimmberechtigten zurück. 

**[Kernaussagen]**
Die Bevölkerung wünscht sich einen solidarischen und fairen Zugang, ist aber offen für effizienzorientierte Steuerung. Pauschale Rationierungsmechanismen hingegen lehnt sie klar ab. 
**[Ende Kernaussagen]**

Neben der Frage des Zugangs ist auch die Entscheidung über die Kostenübernahme bei innovativen oder kostenintensiven Therapien von Bedeutung. Wenn es darum geht, ob eine teure Behandlung mit ungünstigem Kosten-Nutzen-Verhältnis von der obligatorischen Krankenversicherung übernommen werden soll, bevorzugt die Mehrheit der Stimmberechtigten eine Lösung, bei der Ärztinnen und Ärzte gemeinsam mit Patientinnen und Patienten entscheiden. 

Rund zwei Drittel sprechen sich für ein solches partizipatives Vorgehen aus (66%). Auch Entscheidungsmodelle mit Kommissionen, in denen verschiedene Anspruchsgruppen vertreten sind, finden mit 51 Prozent breite Unterstützung. Der Einbezug von Ärztinnen und Ärzten (50%) und von Patientinnen und Patienten (37%) jeweils in getrennten Prozessen erfährt ebenfalls zunehmende Unterstützung.

**[Grafik 18] Regelung Zugang zu innovativen Therapien**

Frage: «Die Pharmaindustrie entwickelt derzeit eine Vielzahl von hochwirksamen, aber teuren Therapien, die gezielt für einzelne Krankheiten und Patientinnen und Patienten angepasst sind. Es gibt verschiedene Meinungen dazu, wie der Zugang zu diesen innovativen Therapien geregelt werden soll. Wie schätzen Sie dies ein?»

Darstellung: gestapelte horizontale Balken, in % Stimmberechtigte. Wertstatus: alle Segmente beschriftet (Zeilensummen = 100).

| Regelung | Voll einverstanden | Eher einverstanden | Weiss nicht / keine Antwort | Eher nicht einverstanden | Überhaupt nicht einverstanden |
|---|---|---|---|---|---|
| Zugang nach systemischem Nutzen | 20 | 63 | 5 | 7 | 5 |
| Gleichberechtigter Zugang zu innovativen Therapien | 27 | 52 | 8 | 11 | 2 |
| Zugang nach Gesundheitskriterien | 10 | 32 | 9 | 37 | 12 |
| Uneingeschränkte Therapien zu teuer | 8 | 27 | 13 | 43 | 9 |
| Vergütung bis zu einem maximalen Betrag pro gerettetem Lebensjahr | 4 | 25 | 12 | 46 | 13 |
| Jährliches Budget pro Person | 3 | 19 | 6 | 51 | 21 |

© gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 18]**

[[Seite 21/27 · Druckseiten 38–39]]

Deutlich weniger Zustimmung erhalten politisch-administrative oder institutionelle Entscheidungsträger. Das Bundesamt für Gesundheit (22%), die Konferenz der kantonalen Gesundheitsdirektorinnen und Gesundheitsdirektoren (19%) sowie das Bundesgericht (15%) werden nur von einer Minderheit als geeignete Instanzen angesehen. Auch Spitalleitungen (12%) und Krankenkassen (10%) stossen auf geringe Akzeptanz.

**[Kernaussagen]**
Die Bevölkerung möchte somit bei Behandlungsentscheiden eher auf fachlich fundierte, patientennahe Verfahren setzen als auf administrativ oder politisch geprägte Entscheidungsstrukturen.
**[Ende Kernaussagen]**

Nicht nur bei innovativen Therapien oder teuren Behandlungen, sondern auch bei der Verschreibung von Medikamenten kommen unterschiedliche Entscheidungskriterien zur Anwendung.

Eine knappe Mehrheit der Stimmberechtigten spricht sich dafür aus, dass Ärztinnen und Ärzte grundsätzlich das medizinisch geeignetste Medikament verschreiben sollen (51%). An zweiter Stelle steht die individuelle Abwägung. 30 Prozent der Befragten befürworten, dass die Wahl des Medikaments im Einzelfall erfolgen sollte, wobei zwischen Kosten und Nutzen abgewogen wird. Reine Kostenerwägungen spielen weiterhin eine Rolle, ihre Bedeutung nimmt jedoch tendenziell zugunsten einer Einzelfallabwägung ab (17%).

**[Kernaussagen]**
Die Bevölkerung wünscht sich medizinisch fundierte Verschreibungsentscheide. Gleichzeitig besteht ein zunehmendes Bewusstsein dafür, dass auch ökonomische Überlegungen berücksichtigt werden können, sofern dieser Einbezug differenziert und auf den konkreten Fall zugeschnitten erfolgt.
**[Ende Kernaussagen]**


**[Grafik 19] Entscheid Übernahme von teuren Behandlungen**

Frage: «Wer soll darüber entscheiden, ob eine sehr teure Behandlung aufgrund eines ungünstigen Kosten-/Nutzenverhältnis von den Krankenkassen nicht bezahlt werden soll?»

Darstellung: Liniendiagramm, in % Stimmberechtigte*, Entscheiden; Jahre 2016–2025; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: Endwerte 2025 beschriftet; übrige Jahre nicht eindeutig ablesbar (Linien ohne Wertbeschriftung).

| Entscheider | 2025 (beschriftet) |
|---|---|
| Ärzt:innen gemeinsam mit Patient:innen | 66 |
| Kommission mit Vertreter:innen aller Beteiligten | 51 |
| Ärztinnen und Ärzte | 50 |
| Patientinnen und Patienten | 37 |
| Bundesamt für Gesundheit | 22 |
| Konferenz der kantonalen Gesundheitsdirektor:innen | 19 |
| Bundesgericht | 15 |
| Spitalleitung | 12 |
| Krankenkassen | 10 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 19]**

**[Grafik 20] Haltung Medikamentenabgabe**

Frage: «Für die meisten Beschwerden gibt es eine Auswahl von mehreren Medikamenten zur Behandlung. Welche Kriterien sollte eine Ärztin oder ein Arzt bei der Verschreibung eines Medikaments vorrangig berücksichtigen?»

Darstellung: gestapelte Säulen, in % Stimmberechtigte*, 2016–2025. Wertstatus: beschriftete Werte jeder Kategorie; unbeschriftete Segmente «–». Abweichungen der ausgewiesenen Zeilensummen von 100 wie im Original belassen.

| Jahr | Sollte immer das geeignetste Medikament verschreiben | Sollte darauf achten, dass die Medikamente nicht zu teuer sind | Sollte in jedem Fall abwägen | Weiss nicht / keine Antwort |
|---|---|---|---|---|
| 2016 | 43 | 34 | 21 | 2 |
| 2017 | 52 | 23 | 23 | 2 |
| 2018 | 53 | 18 | 28 | 1 |
| 2019 | 51 | 16 | 32 | 1 |
| 2020 | 50 | 26 | 23 | 1 |
| 2021 | 55 | 22 | 23 | – |
| 2022 | 49 | 25 | 25 | 1 |
| 2023 | 55 | 24 | 21 | – |
| 2024 | 53 | 22 | 24 | 1 |
| 2025 | 51 | 17 | 30 | 2 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 20]**

[[Seite 22/27 · Druckseiten 40–41]]

Beim Entscheid zwischen einem Originalmedikament und einem Generikum zeigt sich eine klare Präferenz zugunsten des Generikums. 60 Prozent der Stimmberechtigten tendieren zum Generikum, während nur 37 Prozent das Originalpräparat bevorzugen.

Diese Entwicklung weist auf ein gestiegenes Kostenbewusstsein sowie ein zunehmendes Vertrauen in Generika hin. Gleichzeitig dürfte auch die Einführung des höheren Selbstbehalts beim Bezug von Originalpräparaten zur verstärkten Nutzung kostengünstiger Alternativen beigetragen haben.

Die Kritik an den Medikamentenpreisen hat im Verlauf der letzten Jahre zugenommen und erreicht im Jahr 2025 einen neuen Höchststand. 87 Prozent sind der Meinung, dass die Medikamentenpreise zu hoch sind. 10 Prozent empfinden die Preise als angemessen. Die aktuelle Kritik liegt damit wieder auf einem ähnlich hohen Niveau wie in der Phase vom Ende der 1990er-Jahre bis in die frühen 2010er-Jahre, als die Unzufriedenheit mit den Medikamentenpreisen bereits stark ausgeprägt war.

**[Kernaussagen]**
Die Vorbehalte gegenüber der Preisgestaltung haben sich verstärkt. Trotz hoher Zustimmung für Generika und wachsendem Kostenbewusstsein in der Bevölkerung scheint die Preisentwicklung im Arzneimittelbereich nicht mit den Erwartungen der Stimmberechtigten Schritt zu halten.
**[Ende Kernaussagen]**


**[Grafik 21] Haltung Original/Generika**

Frage: «Wenn Sie die Auswahl haben, was würden Sie eher kaufen?»

Darstellung: gestapelte Säulen, in % Stimmberechtigte*, 2016–2025. Wertstatus: alle Werte beschriftet (Zeilensummen = 100).

| Jahr | Originalmedikament | Generikum | Weiss nicht/keine Antwort |
|---|---|---|---|
| 2016 | 52 | 40 | 8 |
| 2017 | 52 | 40 | 8 |
| 2018 | 57 | 29 | 14 |
| 2019 | 56 | 35 | 9 |
| 2020 | 50 | 40 | 10 |
| 2021 | 67 | 25 | 8 |
| 2022 | 55 | 35 | 10 |
| 2023 | 57 | 35 | 8 |
| 2024 | 62 | 28 | 10 |
| 2025 | 37 | 60 | 3 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 21]**

**[Grafik 22] Haltung Medikamentenpreise**

Frage: «Wie stufen Sie die Medikamentenpreise in der Schweiz Ihrer Meinung nach alles in allem ein?»

Darstellung: gestapelte Säulen, in % Stimmberechtigte*, Jahre 97, 99, 00–25; Werteachse 0, 20, 40, 60, 80, 100. Wertstatus: «Zu hoch» und «Angemessen» sind für alle 28 Säulen beschriftet; «Zu tief» und «Weiss nicht / keine Antwort» am oberen Rand nicht überall eindeutig zuzuordnen (überlagerte Kleinbeschriftungen), daher «nicht eindeutig ablesbar». Für 2025 ist 3 («Weiss nicht / keine Antwort») beschriftet; «Zu tief» ist nicht als Segment vorhanden und wird mit «–» wiedergegeben. Zeilensummen nicht zur Ergänzung unsicherer Originalwerte berechnet.

| Jahr | Zu hoch | Angemessen | Zu tief | Weiss nicht / keine Antwort |
|---|---|---|---|---|
| 1997 | 89 | 9 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 1999 | 88 | 10 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2000 | 90 | 9 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2001 | 86 | 10 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2002 | 84 | 11 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2003 | 87 | 9 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2004 | 88 | 11 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2005 | 81 | 16 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2006 | 87 | 12 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2007 | 91 | 9 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2008 | 80 | 17 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2009 | 87 | 13 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2010 | 87 | 12 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2011 | 81 | 17 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2012 | 86 | 12 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2013 | 75 | 22 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2014 | 65 | 34 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2015 | 71 | 24 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2016 | 69 | 29 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2017 | 69 | 27 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2018 | 76 | 20 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2019 | 77 | 18 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2020 | 76 | 19 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2021 | 59 | 38 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2022 | 64 | 32 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2023 | 75 | 22 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2024 | 75 | 23 | nicht eindeutig ablesbar | nicht eindeutig ablesbar |
| 2025 | 87 | 10 | – | 3 |

© gfs.bern, Gesundheitsmonitor 2025

* Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’170)

**[Ende Grafik 22]**

[[Seite 23/27 · Druckseiten 42–43]]

## 5 Thesen

Zusammengefasst zeichnet sich das Meinungsbild der Schweizer Stimmberechtigten rund um Gesundheitsfragen durch 7 Entwicklungen aus:

- Die grundlegenden Zielsetzungen des KVG, wie der garantierte Zugang zur medizinischen Versorgung und die solidarische Prämienverbilligung, werden von einer breiten Mehrheit der Stimmberechtigten als erfüllt betrachtet. Gleichzeitig zeigt sich ein deutliches Unverständnis gegenüber dem kontinuierlichen Anstieg der Krankenkassenprämien. Trotz dieser Kritik bleibt das Modell der Kopfprämie mit Subventionen für tiefere Einkommen klar mehrheitsfähig. Dennoch erfahren Reformideen vermehrt Zuspruch.

- Zentrale Werte wie Qualität, Solidarität und ein breiter Leistungsumfang bleiben bestehen. Der Bevölkerung ist es weiterhin ein zentrales Anliegen, allen Versicherten einen möglichst umfassenden Zugang zu medizinischen Leistungen zu gewährleisten. Gleichzeitig nimmt das Kostenbewusstsein zu, wodurch beispielsweise auch Modelle an Akzeptanz gewinnen, die eine stärkere Fokussierung auf die Abdeckung hoher Risiken vorsehen. Die Bevölkerung wünscht sich eine ausgewogene Regulierung durch Markt und Staat sowie eine gemeinsame Steuerungsverantwortung von Bund und Kantonen. Die zunehmende Offenheit gegenüber kostenorientierten Steuerungsprinzipien deutet auf eine schrittweise Integration wirtschaftlicher Überlegungen in die gesundheitspolitischen Leitbilder hin.

- Die gesundheitspolitische Meinungsbildung wird zunehmend von einem wachsenden Kostenbewusstsein geprägt. Ein immer grösserer Teil der Stimmberechtigten zeigt sich bereit, unter bestimmten Voraussetzungen Einschränkungen im Leistungsangebot zu akzeptieren. Diese Entwicklung geht mit einer steigenden Offenheit gegenüber strukturellen Reformen und gezielten kostendämpfenden Massnahmen einher, die zur langfristigen Stabilisierung des Gesundheitssystems beitragen sollen.

- Eine relative Mehrheit der Stimmberechtigten spricht sich dafür aus, den heutigen Umfang der durch die obligatorische Grundversicherung abgedeckten Leistungen beizubehalten. Gleichzeitig erreicht die Zustimmung zu einem Abbau des Leistungskatalogs mit 19 Prozent den bisher höchsten gemessenen Wert, was auf ein wachsendes Kostenbewusstsein in der Bevölkerung hinweist. Ein Ausbau der Leistungen wird hingegen nur noch von 22 Prozent befürwortet. Diese Entwicklung zeigt, dass die Bevölkerung zunehmend bereit ist, über gezielte Einsparungen im Leistungskatalog nachzudenken, insbesondere wenn diese der langfristigen Finanzierbarkeit des Systems dienen.

- Die Bevölkerung misst der Pharmaindustrie eine hohe wirtschaftliche und gesellschaftliche Bedeutung bei, insbesondere als Arbeitgeberin, Innovationsmotor und Stütze des Wirtschaftsstandorts Schweiz. Gleichzeitig steigen die Erwartungen an eine transparentere Informationspolitik. Nur etwa ein Viertel der Stimmberechtigten ist der Meinung, dass die Pharmaindustrie in der Schweiz offen über ihre Tätigkeiten informiert.

- Eine klare Mehrheit der Stimmberechtigten befürwortet den Zugang zu innovativen Therapien, sofern deren systemischer Nutzen ausgewiesen ist, etwa durch Einsparungen im Pflegebereich oder durch eine erleichterte Wiedereingliederung in den Arbeitsmarkt. Während ein gleichberechtigter Zugang breite Zustimmung erfährt, lehnt die Bevölkerung pauschale Rationierungsmechanismen wie fixe Jahresbudgets oder Maximalbeträge pro Lebensjahr mehrheitlich ab. Damit artikuliert sich der Wunsch nach einer effizienzorientierten, aber zugleich solidarisch legitimierten Steuerung der Gesundheitsversorgung im Bereich neuer und kostenintensiver Behandlungen.

- Ein wachsender Anteil der Bevölkerung bevorzugt Generika gegenüber Originalpräparaten, was sowohl auf ein gestiegenes Kostenbewusstsein als auch auf zunehmendes Vertrauen in die therapeutische Wirksamkeit günstiger Alternativen hinweist. Diese Entwicklung wird durch gesundheitspolitische Massnahmen wie den höheren Selbstbehalt für Originalmedikamente begünstigt. Gleichzeitig erreicht die Kritik an den Medikamentenpreisen einen neuen Höchstwert.

[[Seite 24/27 · Druckseiten 44–45]]

## 6 Datenbasis der aktuellen Welle

Die Ergebnisse der Befragung zum Gesundheitsmonitor 2025 basieren auf einer repräsentativen Befragung von 1’200 Stimmberechtigten aus der ganzen Schweiz, welche gfs.bern im Auftrag von Interpharma durchgeführt hat.

Im Jahr 2025 wurde die Befragungsmethode angepasst. Von den 1’200 Interviews wurden 600 via einer Face-to-Face- und 600 via einer Online-Befragung erhoben (bis 2024 1’200 via Face-to-Face-Befragung). Für die Online-Befragung wurde auf das Panel «Polittrends» zurückgegriffen. Die Befragung wurde zwischen dem 3. und dem 23. März 2025 durchgeführt. Der jeweilige statistische Fehler für die Stichprobengrösse bei den ausgewiesenen Gruppen beträgt:

**Tabelle 1: Stichprobenfehler**

Ausgewählte statistische Stichprobenfehler nach Stichprobengrösse und Basisverteilung

| Stichprobengrösse | Fehlerquote Basisverteilung 50% zu 50% | Fehlerquote Basisverteilung 20% zu 80% |
|---|---|---|
| N = 1’200 | ± 2.9 Prozentpunkte | ± 2.3 Prozentpunkte |
| N = 1’000 | ± 3.2 Prozentpunkte | ± 2.5 Prozentpunkte |
| N = 600 | ± 4.1 Prozentpunkte | ± 3.3 Prozentpunkte |
| N = 100 | ± 10.0 Prozentpunkte | ± 8.1 Prozentpunkte |
| N = 50 | ± 14.0 Prozentpunkte | ± 11.5 Prozentpunkte |

Lesebeispiel: Bei rund 1’200 Befragten und einem ausgewiesenen Wert von 50 Prozent liegt der effektive Wert zwischen 50 Prozent und ± 2.9 Prozentpunkte, bei einem Basiswert von 20 Prozent zwischen 20 Prozent und ± 2.3 Prozentpunkte. Dabei setzt man in der Umfrageforschung zumeist ein Sicherheitsmass von 95 Prozent, das heisst, man akzeptiert eine Irrtumswahrscheinlichkeit von 5 Prozent, dass der nachgewiesene statistische Zusammenhang so in der Bevölkerung nicht vorhanden ist.

[[Seite 25/27 · Druckseiten 46–47]]

## 7 Anhang

## 7.1 Das Team von gfs.bern

[Bild: Porträt von Urs Bieri.]

## URS BIERI urs.bieri@gfsbern.ch

Co-Leiter und Mitglied des Verwaltungsrats gfs.bern, Politik- und Medienwissenschafter (lic. rer. soc.), Executive MBA FH in strategischem Management, Dozent am VMI der Universität Fribourg und an der ZHAW Winterthur

Schwerpunkte

Themen- und Issue Monitoring, Image- und Reputationsanalysen, Risikotechnologien, Abstimmungsanalysen, Kampagnenvorbereitung und -begleitung, integrierte Kommunikationsanalysen, qualitative Methoden

Publikationen in Buchform, in Sammelbänden, in Fachmagazinen, in der Tagespresse und im Internet, aktuelle Publikation: Bieri, U et al. Digitalisierung der Schweizer Demokratie, Technologische Revolution trifft auf traditionelles Meinungsbildungssystem. Vdf 2021.

[Bild: Porträt von Tobias Keller.]

## TOBIAS KELLER tobias.keller@gfsbern.ch

Projektleiter und Teamleader Data Analytics, Kommunikationswissenschafter, Dr. phil.

Schwerpunkte

politische Kommunikation, Wahlen, Abstimmungen, (digitale) Kampagnen, Issue Monitoring, Image- und Reputationsanalysen, Medienanalysen, Digitalisierung, Social Media, computergestützte Methoden, quantitative Analysen

Publikationen in internationalen und nationalen Fachmagazinen, in der Tagespresse und im Internet

[Bild: Porträt von Corina Schena.]

## CORINA SCHENA corina.schena@gfsbern.ch

Projektleiterin

Schwerpunkte

Wahlen, Abstimmungen, Gesundheitspolitik, Gesundheitskampagnen, Image- und Reputationsanalysen, qualitative und quantitative Methoden sowie Moderation

[Bild: Porträt von Sara Rellstab.]

## SARA RELLSTAB sara.rellstab@gfsbern.ch

Data Scientist

Ökonomin PhD

Schwerpunkte

Datenanalyse, Programmierungen, Visualisierungen, Recherchen, quantitative und qualitative Methoden

[Bild: Porträt von Roland Rey.]

## ROLAND REY roland.rey@gfsbern.ch

Projektmitarbeiter/Administration

Schwerpunkte

Desktop-Publishing, Visualisierungen, Projektadministration, Vortragsadministration

[[Seite 26/27 · Druckseiten 48–49]]

[leere Seite]

[[Seite 27/27 · Rückseite]]

Interpharma
Petersgraben 35, Postfach
CH-4009 Basel
Telefon +41 (0)61 264 34 00
info@interpharma.ch
www.interpharma.ch

---

— Ende Teil 2 von 2 · Kontrollwort Teil 2: RIGI-29 · DOKUMENTENDE LAV-T02 —
