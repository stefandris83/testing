# LAV Learning Library – Study Cards

Stand: 2026-10-14 · 1 Card · Datei 1 von 1
Belege: [S. n] = PDF-Seite im Volltext der jeweiligen Studie.

## LAV-T02 · Gesundheitsmonitor 2025
Freigegeben: Beispiel (nicht durch Research geprüft) · 2026-10-14 · Volltext-Version 1.0

**Fragestellung:** Einstellungen der Schweizer Stimmberechtigten zum Gesundheitswesen; jährliche Repräsentativbefragung seit 1996 [S. 2]

**Methode & Stichprobe:** Repräsentativbefragung von 1’200 Stimmberechtigten in allen Sprachregionen; 2025 Mixed Mode (Face-to-Face und Online-Panel) [S. 2, S. 10]

**Kernergebnisse:**
- Leistungskatalog: 49 % für das Belassen, 22 % für einen Ausbau, 19 % für einen Abbau (2025; 2024: 4 % Abbau) [S. 12]
- Romandie: 69 % haben gelegentlich oder dauerhaft Mühe, die Krankenkassenprämien zu bezahlen [S. 10]
- Medikamentenabgabe: 51 % wollen, dass immer das geeignetste Medikament verschrieben wird; 17 %, dass auf die Kosten geachtet wird (2025) [S. 21]
- Innovative Therapien: Ein jährliches Budget pro Person lehnen 72 % ab (51 % eher nicht, 21 % überhaupt nicht einverstanden) [S. 20]
- Wartezeit von der Marktzulassung bis zur Aufnahme in die Spezialitätenliste: 189 Tage (2024) [S. 4]

**Schlussfolgerungen der Studie:** Das Kostenbewusstsein in der Bevölkerung nimmt zu [S. 1]

**Was die Studie nicht beantwortet:** keine Aussagen zu einzelnen Versicherern oder Versicherungsmodellen; keine Wartezeiten für Arzttermine; Befragung von Stimmberechtigten, nicht der Gesamtbevölkerung [S. 2]

**Wegweiser im Volltext:**
| Thema | Seiten | Teil |
|---|---|---|
| Problemdruck Ausgabenbereiche (Deutschschweiz, Romandie) | 10 | teil-03 |
| Leistungskatalog | 12 | teil-04 |
| Zugang zu innovativen Therapien | 20 | teil-06 |

**Redaktionelle Einordnung LAV** (optional; keine Studienaussage, nie mit Seitenbeleg zitieren): –

— Ende Card LAV-T02 —

— Ende Study Cards Datei 1 von 1 · Kontrollwort: CALANDA-20 —
