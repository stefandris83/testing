# LAV-T02 · Volltext · Teil 7 von 7 (PDF-Seiten 23–27 von 27)

Studie: Gesundheitsmonitor 2025 – Das Wichtigste in Kürze (gfs.bern im Auftrag von Interpharma) · Quelldatei: gesundheitsmonitor-2025.pdf · Transkript-Version 1.0 · 2026-10-14
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 7 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T02, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 23/27 · Druckseiten 42–43]]

## 5 Thesen

Zusammengefasst zeichnet sich das Meinungsbild der Schweizer Stimmberechtigten rund um Gesundheitsfragen durch 7 Entwicklungen aus:

Die grundlegenden Zielsetzungen des KVG, wie der garantierte Zugang zur medizinischen Versorgung und die solidarische Prämienverbilligung, werden von einer breiten Mehrheit der Stimmberechtigten als erfüllt betrachtet. Gleichzeitig zeigt sich ein deutliches Unverständnis gegenüber dem kontinuierlichen Anstieg der Krankenkassenprämien. Trotz dieser Kritik bleibt das Modell der Kopfprämie mit Subventionen für tiefere Einkommen klar mehrheitsfähig. Dennoch erfahren Reformideen vermehrt Zuspruch.

Zentrale Werte wie Qualität, Solidarität und ein breiter Leistungsumfang bleiben bestehen. Der Bevölkerung ist es weiterhin ein zentrales Anliegen, allen Versicherten einen möglichst umfassenden Zugang zu medizinischen Leistungen zu gewährleisten. Gleichzeitig nimmt das Kostenbewusstsein zu, wodurch beispielsweise auch Modelle an Akzeptanz gewinnen, die eine stärkere Fokussierung auf die Abdeckung hoher Risiken vorsehen. Die Bevölkerung wünscht sich eine ausgewogene Regulierung durch Markt und Staat sowie eine gemeinsame Steuerungsverantwortung von Bund und Kantonen. Die zunehmende Offenheit gegenüber kostenorientierten Steuerungsprinzipien deutet auf eine schrittweise Integration wirtschaftlicher Überlegungen in die gesundheitspolitischen Leitbilder hin.

Die gesundheitspolitische Meinungsbildung wird zunehmend von einem wachsenden Kostenbewusstsein geprägt. Ein immer grösserer Teil der Stimmberechtigten zeigt sich bereit, unter bestimmten Voraussetzungen Einschränkungen im Leistungsangebot zu akzeptieren. Diese Entwicklung geht mit einer steigenden Offenheit gegenüber strukturellen Reformen und gezielten kostendämpfenden Massnahmen einher, die zur langfristigen Stabilisierung des Gesundheitssystems beitragen sollen.

Eine relative Mehrheit der Stimmberechtigten spricht sich dafür aus, den heutigen Umfang der durch die obligatorische Grundversicherung abgedeckten Leistungen beizubehalten. Gleichzeitig erreicht die Zustimmung zu einem Abbau des Leistungskatalogs mit 19 Prozent den bisher höchsten gemessenen Wert, was auf ein wachsendes Kostenbewusstsein in der Bevölkerung hinweist. Ein Ausbau der Leistungen wird hingegen nur noch von 22 Prozent befürwortet. Diese Entwicklung zeigt, dass die Bevölkerung zunehmend bereit ist, über gezielte Einsparungen im Leistungskatalog nachzudenken, insbesondere wenn diese der langfristigen Finanzierbarkeit des Systems dienen.

Die Bevölkerung misst der Pharmaindustrie eine hohe wirtschaftliche und gesellschaftliche Bedeutung bei, insbesondere als Arbeitgeberin, Innovationsmotor und Stütze des Wirtschaftsstandorts Schweiz. Gleichzeitig steigen die Erwartungen an eine transparentere Informationspolitik. Nur etwa ein Viertel der Stimmberechtigten ist der Meinung, dass die Pharmaindustrie in der Schweiz offen über ihre Tätigkeiten informiert.

Eine klare Mehrheit der Stimmberechtigten befürwortet den Zugang zu innovativen Therapien, sofern deren systemischer Nutzen ausgewiesen ist, etwa durch Einsparungen im Pflegebereich oder durch eine erleichterte Wiedereingliederung in den Arbeitsmarkt. Während ein gleichberechtigter Zugang breite Zustimmung erfährt, lehnt die Bevölkerung pauschale Rationierungsmechanismen wie fixe Jahresbudgets oder Maximalbeträge pro Lebensjahr mehrheitlich ab. Damit artikuliert sich der Wunsch nach einer effizienzorientierten, aber zugleich solidarisch legitimierten Steuerung der Gesundheitsversorgung im Bereich neuer und kostenintensiver Behandlungen.

Ein wachsender Anteil der Bevölkerung bevorzugt Generika gegenüber Originalpräparaten, was sowohl auf ein gestiegenes Kostenbewusstsein als auch auf zunehmendes Vertrauen in die therapeutische Wirksamkeit günstiger Alternativen hinweist. Diese Entwicklung wird durch gesundheitspolitische Massnahmen wie den höheren Selbstbehalt für Originalmedikamente begünstigt. Gleichzeitig erreicht die Kritik an den Medikamentenpreisen einen neuen Höchstwert.

[Bild: Die sieben Thesen sind im Original je mit einem Symbol gekennzeichnet (Pfeile, Hände mit Herz, Geldscheine, Waage, Mikroskop, Infusion, Diagramm). Links stehen die Thesen 1–3, rechts die Thesen 4–7.]

---

[[Seite 24/27 · Druckseiten 44–45]]

## 6 Datenbasis der aktuellen Welle

Die Ergebnisse der Befragung zum Gesundheitsmonitor 2025 basieren auf einer repräsentativen Befragung von 1’200 Stimmberechtigten aus der ganzen Schweiz, welche gfs.bern im Auftrag von Interpharma durchgeführt hat.

Im Jahr 2025 wurde die Befragungsmethode angepasst. Von den 1’200 Interviews wurden 600 via einer Face-to-Face- und 600 via einer Online-Befragung erhoben (bis 2024 1’200 via Face-to-Face-Befragung). Für die Online-Befragung wurde auf das Panel «Polittrends» zurückgegriffen. Die Befragung wurde zwischen dem 3. und dem 23. März 2025 durchgeführt. Der jeweilige statistische Fehler für die Stichprobengrösse bei den ausgewiesenen Gruppen beträgt:

**Tabelle 1: Stichprobenfehler** – Ausgewählte statistische Stichprobenfehler nach Stichprobengrösse und Basisverteilung

| Stichprobengrösse | Fehlerquote Basisverteilung 50 % zu 50 % | Fehlerquote Basisverteilung 20 % zu 80 % |
|---|---|---|
| N = 1’200 | ± 2.9 Prozentpunkte | ± 2.3 Prozentpunkte |
| N = 1’000 | ± 3.2 Prozentpunkte | ± 2.5 Prozentpunkte |
| N = 600 | ± 4.1 Prozentpunkte | ± 3.3 Prozentpunkte |
| N = 100 | ± 10.0 Prozentpunkte | ± 8.1 Prozentpunkte |
| N = 50 | ± 14.0 Prozentpunkte | ± 11.5 Prozentpunkte |

Lesebeispiel: Bei rund 1’200 Befragten und einem ausgewiesenen Wert von 50 Prozent liegt der effektive Wert zwischen 50 Prozent und ± 2.9 Prozentpunkte, bei einem Basiswert von 20 Prozent zwischen 20 Prozent und ± 2.3 Prozentpunkte. Dabei setzt man in der Umfrageforschung zumeist ein Sicherheitsmass von 95 Prozent, das heisst, man akzeptiert eine Irrtumswahrscheinlichkeit von 5 Prozent, dass der nachgewiesene statistische Zusammenhang so in der Bevölkerung nicht vorhanden ist.

[Druckseite 45 ist leer.]

[[Seite 25/27 · Druckseiten 46–47]]

## 7 Anhang

**7.1 Das Team von gfs.bern**

URS BIERI urs.bieri@gfsbern.ch Co-Leiter und Mitglied des Verwaltungsrats gfs.bern, Politik- und Medienwissenschafter (lic. rer. soc.), Executive MBA FH in strategischem Management, Dozent am VMI der Universität Fribourg und an der ZHAW Winterthur

Schwerpunkte Themen- und Issue Monitoring, Image- und Reputationsanalysen, Risikotechnologien, Abstimmungsanalysen, Kampagnenvorbereitung und -begleitung, integrierte Kommunikationsanalysen, qualitative Methoden

Publikationen in Buchform, in Sammelbänden, in Fachmagazinen, in der Tagespresse und im Internet, aktuelle Publikation: Bieri, U et al. Digitalisierung der Schweizer Demokratie, Technologische Revolution trifft auf traditionelles Meinungsbildungssystem. Vdf 2021.

TOBIAS KELLER tobias.keller@gfsbern.ch Projektleiter und Teamleader Data Analytics, Kommunikationswissenschafter, Dr. phil.

Schwerpunkte politische Kommunikation, Wahlen, Abstimmungen, (digitale) Kampagnen, Issue Monitoring, Image- und Reputationsanalysen, Medienanalysen, Digitalisierung, Social Media, computergestützte Methoden, quantitative Analysen

Publikationen in internationalen und nationalen Fachmagazinen, in der Tagespresse und im Internet

CORINA SCHENA corina.schena@gfsbern.ch Projektleiterin

Schwerpunkte Wahlen, Abstimmungen, Gesundheitspolitik, Gesundheitskampagnen, Image- und Reputationsanalysen, qualitative und quantitative Methoden sowie Moderation

SARA RELLSTAB sara.rellstab@gfsbern.ch Data Scientist Ökonomin PhD

Schwerpunkte Datenanalyse, Programmierungen, Visualisierungen, Recherchen, quantitative und qualitative Methoden

ROLAND REY roland.rey@gfsbern.ch Projektmitarbeiter/Administration

Schwerpunkte Desktop-Publishing, Visualisierungen, Projektadministration, Vortragsadministration

[Bild: Porträtfotos der fünf Teammitglieder von gfs.bern]

[[Seite 26/27 · Druckseiten 48–49]]

[Druckseiten 48–49 sind leer.]

[[Seite 27/27 · Rückseite]]

**Interpharma** · Petersgraben 35, Postfach, CH-4009 Basel · Telefon +41 (0)61 264 34 00 · info@interpharma.ch · www.interpharma.ch

[Rückseite der Broschüre]

---

---

— Ende Teil 7 von 7 · Kontrollwort Teil 7: PILATUS-35 · DOKUMENTENDE LAV-T02 —
