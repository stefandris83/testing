# LAV-T02 · Volltext · Teil 2 von 7 (PDF-Seiten 5–8 von 27)

Studie: Gesundheitsmonitor 2025 – Das Wichtigste in Kürze (gfs.bern im Auftrag von Interpharma) · Quelldatei: gesundheitsmonitor-2025.pdf · Transkript-Version 1.0 · 2026-10-14
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 7 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T02, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 5/27 · Druckseiten 6–7]]

**Kostenwahrnehmung und Faktenlage teilweise im Ungleichgewicht**

Die Kostenfrage lässt sich in der Bevölkerung sehr gut anhand der Meinung über die Krankenkassenprämien ermitteln. Betrachtet man die Ergebnisse der aktuellen Umfrage, zeigt sich, dass diese erneut als grösste finanzielle Last für das Haushaltsbudget empfunden werden.

**[Grafik] Dauerhaftes oder gelegentliches Problem**

Frage: «Können Sie für jeden der folgenden Ausgabenbereiche Ihres Haushalts angeben, inwiefern er für Sie ein Problem darstellt?»

Darstellung: Liniendiagramm, gleitender Mittelwert über 3 Jahre, 1998–2025, Anteil «dauerhaftes/gelegentliches Problem» in % Stimmberechtigte. Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 1 Prozentpunkt). Die Werte bis 2024 stimmen mit der entsprechenden Grafik im Gesundheitsmonitor 2024 überein.

| Jahr | Krankenkassenprämien | Steuern | Zahnarztrechnungen | Arztrechnungen, Ausgaben für Medikamente | Sonstige Versicherungen | Miete für die Wohnung oder für Wohneigentum |
|---|---|---|---|---|---|---|
| 1998 | 33 | 37 | – | 24 | 23 | 16 |
| 1999 | 33 | 37 | – | 25 | 24 | 17 |
| 2000 | 33 | 36 | – | 23 | 23 | 15 |
| 2001 | 35 | 38 | – | 24 | 24 | 15 |
| 2002 | 38 | 36 | – | 21 | 22 | 13 |
| 2003 | 44 | 40 | 36 | 24 | 25 | 17 |
| 2004 | 48 | 41 | 37 | 25 | 25 | 17 |
| 2005 | 48 | 44 | 39 | 30 | 27 | 19 |
| 2006 | 48 | 44 | 41 | 31 | 27 | 18 |
| 2007 | 45 | 42 | 40 | 29 | 27 | 19 |
| 2008 | 46 | 44 | 38 | 28 | 29 | 22 |
| 2009 | 47 | 44 | 40 | 26 | 28 | 24 |
| 2010 | 50 | 40 | 37 | 24 | 26 | 23 |
| 2011 | 52 | 34 | 34 | 22 | 25 | 21 |
| 2012 | 50 | 32 | 32 | 22 | 23 | 20 |
| 2013 | 47 | 40 | 41 | 26 | 24 | 24 |
| 2014 | 43 | 45 | 42 | 28 | 21 | 24 |
| 2015 | 41 | 48 | 42 | 29 | 22 | 24 |
| 2016 | 40 | 46 | 38 | 31 | 23 | 24 |
| 2017 | 38 | 43 | 38 | 30 | 22 | 26 |
| 2018 | 30 | 33 | 36 | 25 | 17 | 21 |
| 2019 | 28 | 27 | 30 | 19 | 10 | 16 |
| 2020 | 23 | 20 | 26 | 15 | 9 | 11 |
| 2021 | 28 | 23 | 23 | 16 | 10 | 14 |
| 2022 | 22 | 22 | 22 | 15 | 10 | 13 |
| 2023 | 26 | 24 | 23 | 18 | 11 | 13 |
| 2024 | 24 | 24 | 23 | 21 | 14 | 13 |
| 2025 (beschriftet) | 30 | 26 | 26 | 20 | 15 | 13 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’180)

**[Ende Grafik]**

Mit Blick bis 1997 zurück ist erkennbar, dass dieses Empfinden grossen Schwankungen ausgesetzt ist. Die Krankenkassenprämien wogen einerseits schon immer schwer, andererseits ist es dennoch überraschend, wie viel mehr Gewicht sie beispielsweise 2011 hatten. Von da an begann die wahrgenommene Belastung für das Haushaltsbudget stetig zu sinken. Ab der COVID-19-Pandemie jedoch stagnierte diese Abnahme und der Trend zeigt wieder nach oben. Auffällig: Die wechselhafte Entwicklung der letzten 25 Jahre passt nicht zum Verhältnis von Prämien, Reallöhnen und dem BIP: Die Reallöhne und das BIP der Schweiz sind in absoluten Werten stärker gestiegen als die Krankenkassenprämien. Demzufolge müsste die Sorge über die hohen Prämien theoretisch sinken. Eine potenzielle Ursache könnte der verstärkte öffentliche Diskurs über Gesundheitskosten sein, welcher möglicherweise dazu führt, dass die tatsächliche Prämienlast stärker wahrgenommen wird.

**[Grafik] Pro-Kopf Wachstum von OKP-Kosten, BIP und Löhnen**

Darstellung: Liniendiagramm, 1996–2023, in Franken. Werte nicht beschriftet; aus der Vektorgrafik berechnet und auf 500 Franken gerundet (Genauigkeit ca. ± 1’000 Franken; die Prämienlinie liegt nahe der Nulllinie und ist nur grob ablesbar).

| Jahr | Gesamtwirtschaft (BIP pro Kopf) | Löhne (Median-Bruttoeinkommen) | Mittlere Prämie in Franken je versicherte Person |
|---|---|---|---|
| 1996 | 59’000 | 66’500 | 1’000 |
| 1997 | 60’000 | 66’500 | 1’000 |
| 1998 | 61’500 | 67’000 | 1’500 |
| 1999 | 62’000 | 67’500 | 1’500 |
| 2000 | 65’000 | 68’500 | 1’500 |
| 2001 | 66’500 | 71’000 | 1’500 |
| 2002 | 66’000 | 72’000 | 1’500 |
| 2003 | 66’000 | 73’000 | 2’000 |
| 2004 | 67’500 | 73’000 | 2’000 |
| 2005 | 70’000 | 74’500 | 2’000 |
| 2006 | 74’000 | 74’500 | 2’000 |
| 2007 | 78’000 | 76’000 | 2’000 |
| 2008 | 80’500 | 78’500 | 2’000 |
| 2009 | 78’000 | 80’000 | 2’000 |
| 2010 | 80’000 | 78’000 | 2’500 |
| 2011 | 80’500 | 78’500 | 2’500 |
| 2012 | 81’000 | 79’000 | 2’500 |
| 2013 | 81’500 | 79’500 | 2’500 |
| 2014 | 81’500 | 80’000 | 2’500 |
| 2015 | 81’000 | 80’500 | 3’000 |
| 2016 | 81’500 | 80’000 | 3’000 |
| 2017 | 81’500 | 80’500 | 3’000 |
| 2018 | 83’500 | 81’000 | 3’500 |
| 2019 | 84’000 | 82’000 | 3’500 |
| 2020 | 81’000 | 82’500 | 3’500 |
| 2021 | 86’000 | 83’000 | 3’500 |
| 2022 | 90’000 | 82’500 | 3’500 |
| 2023 | 90’500 | 85’000 | 3’500 |

Quelle: Darstellung Interpharma mit Datengrundlage: Bundesamt für Gesundheit (2025), Statistik der obligatorischen Krankenpflegeversicherung. Bundesamt für Statistik (2025), Wachstums- und Produktivitätsstatistik (WPS). Bundesamt für Statistik (2025), Schweizerische Arbeitskräfteerhebung (SAKE).

**[Ende Grafik]**

Dies geht womöglich mit der Entwicklung einher, dass der Bund seit COVID-19 immer stärker für die Kostendämpfung verantwortlich gemacht wird. Heute wird er gar als klarer Hauptverantwortlicher gesehen. Dies, obwohl der Bund bzw. das BAG nur Medikamentenpreise festlegen kann, während die Tarifpartner und die Kantone grösseren Einfluss auf die Kosten ausüben können.

Die Sorge um die hohen Prämien fördert das Narrativ, Medikamente seien einer der Haupttreiber der Gesundheitskosten – ein Bild, das von vielen Akteuren verstärkt wird. Die Medikamentenpreise sind jedoch nicht das Problem. Zwar steigen die Gesundheitskosten weiter an – ebenso wie die Anzahl neuer Therapien und die durchschnittliche Lebenserwartung in der Schweiz. Die Medikamentenpreise hingegen sanken kontinuierlich. Doch ein genauerer Blick zeigt: Der Anteil der Medikamente an den Gesundheitskosten und den OKP-Gesamtkosten blieb über die vergangenen Jahre stabil oder stieg unterdurchschnittlich an. Konkret bedeutet das, dass nicht die Preise einzelner Medikamente der eigentliche Kostentreiber sind, sondern vielmehr die steigende verschriebene Menge jener Medikamente. Dies hat unter anderem mit der demografischen Entwicklung in der Schweiz sowie dem Erfolg in der Bekämpfung komplexer Krankheiten zu tun. Gerade in der Bekämpfung diverser Krebsarten macht die Forschung seit vielen Jahren riesige Fortschritte.

[[Seite 6/27 · Druckseiten 8–9]]

**Fazit**

Im Hinblick auf die Solidarität haben das KVG und das Schweizer Gesundheitswesen grundsätzlich ihre Aufgaben und Ziele erfüllt. Der solidarische Grundgedanke ist fest in der Bevölkerung verankert. Allerdings zeigt sich auch, dass nach einer längeren Phase des Anstiegs die Solidarität aktuell abnimmt und das Kostenbewusstsein überwiegt – besonders dann, wenn eine Krankheit und damit die anfallenden Behandlungskosten als einfach vermeidbar gelten.

Auch die Qualität des Gesundheitswesens wird seit je positiv beurteilt. Dennoch sieht Interpharma Handlungsbedarf – besonders beim Zugang zu neuen innovativen Medikamenten, der sich im Verlauf der letzten Jahre stetig verschlechtert hat: Nur 47 Prozent der von der EMA zugelassenen neuen innovativen Medikamente sind in der Schweiz standardmässig verfügbar – ein echtes Problem für viele Patientinnen und Patienten. Benchmark ist hier Deutschland mit seiner 90-prozentigen, also etwa doppelt so hohen vollständigen Verfügbarkeit an EMA-zugelassenen Medikamenten.

Die Prämienlast wurde in der Vergangenheit teilweise als höher empfunden als heute und stand nicht immer an erster Stelle der Budgetbelastung. Obwohl Reallöhne und BIP stärker wachsen als die Prämien, steigt seit COVID-19 das Kostenbewusstsein wieder deutlich. Fälschlicherweise werden dafür seit Jahren die Medikamentenpreise stark mitverantwortlich gemacht. Vielmehr ist die kontinuierlich wachsende Menge verschriebener Medikamente für die, absolut gesehen, hohen Medikamentenkosten verantwortlich. Dies kann aber unter anderem mit den wachsenden medizinischen Möglichkeiten begründet werden – viele Krankheiten, die früher ein Todesurteil bedeuteten, können heute erfolgreich behandelt werden.

**Dr. René Buholzer**

Geschäftsführer und Delegierter des Vorstandes

[Bild: Unterschrift René Buholzer]

[Druckseite 9 ist leer.]

[[Seite 7/27 · Druckseiten 10–11]]

## 2 Executive Summary

**Zentrale Versprechen des KVG eingelöst, doch Reformdruck wächst**

Fast drei Jahrzehnte nach Einführung des Krankenversicherungsgesetzes (KVG) sieht eine klare Mehrheit die zentralen Versprechen des Gesetzes als eingelöst, etwa den Zugang zur Grundversorgung oder die solidarische Prämienverbilligung. Demgegenüber bewertet die Bevölkerung das Ziel der Kostendämpfung als nicht erreicht. Zudem bleibt das sogenannte Prämienproblem ihrer Meinung nach ungelöst: Die Prämienentwicklung stösst auf wenig Verständnis. Reformen gewinnen an Zustimmung. Die Kopfprämie wird weiterhin mehrheitlich getragen, doch die Bereitschaft zur Weiterentwicklung steigt.

**Kostensensibilität wächst**

Schweizweit zeigt sich eine wachsende Sensibilität gegenüber Kostenaspekten. Bei mehreren Zielkonflikten ist eine zunehmende Offenheit für kostenorientierte Lösungen erkennbar. Zwar bleibt der Wunsch nach einem qualitativ hochwertigen Gesundheitswesen weiter bestehen, doch mehren sich Anzeichen dafür, dass Kostenüberlegungen bei der Ausgestaltung stärker ins Gewicht fallen. Die Stimmbevölkerung ist zunehmend bereit, unter anderem bei der freien Arzt- und Spitalwahl sowie beim Umfang des Leistungskatalogs, Ein-schränkungen in Kauf zu nehmen.

**Sprachregionale Unterschiede zu Beobachten**

In der Romandie bekunden rund zwei Drittel der Befragten Mühe bei der Bezahlung der Krankenkassenprämien. Dieser Wert liegt deutlich über jenem der übrigen Landesteile und erreicht ein Niveau, das zuletzt um das Jahr 2011 zu beobachten war. In der Deutschschweiz hingegen bleibt der wahrgenommene Problemdruck vergleichsweise moderat, obwohl auch hier eine leichte Zunahme gegenüber dem Vorjahr festzustellen ist. Parallel dazu zeigt sich in der Romandie eine besonders ausgeprägte Bereitschaft, persönliche Einschränkungen zur Kostendämpfung zu akzeptieren. Gleichzeitig fällt dort die Zufriedenheit mit der Qualität des Gesundheitswesens etwas zurückhaltender aus, auch wenn sie insgesamt weiterhin sehr hoch ist.

**Solidarischer Zugang zu innovativen Therapien gewünscht**

Beim Zugang zu innovativen und kostenintensiven Therapien zeigt sich eine klare Haltung: Die Stimmbevölkerung befürwortet eine Übernahme durch die Grundversicherung, sofern ein systemischer Nutzen gegeben ist, etwa durch Einsparungen im Pflegebereich oder eine berufliche Wiedereingliederung. Gleichzeitig lehnen die Stimmberechtigten pauschale Begrenzungen wie fixe Jahresbudgets oder starre Maximalbeträge pro Lebensjahr mehrheitlich ab. Gewünscht wird eine faire, aber effizient gesteuerte Versorgung im Interesse der Gemeinschaft.

[[Seite 8/27 · Druckseiten 12–13]]

## 3 Schwerpunktthemen 2025

Fast drei Jahrzehnte nach Einführung des Krankenversicherungsgesetzes (KVG) zeigt sich ein differenziertes Urteil der Schweizer Bevölkerung. Das zentrale Ziel, allen Einwohnerinnen und Einwohnern Zugang zur medizinischen Grundversorgung zu ermöglichen, wird aus Sicht der Stimmberechtigten klar erreicht. Insgesamt 96 Prozent sehen dieses Versprechen als eher oder ganz eingelöst. Auch die individuelle Prämienverbilligung zur Entlastung einkommensschwacher Haushalte beurteilen sie mehrheitlich positiv. 83 Prozent erachten dieses Ziel als erfüllt. Ebenfalls gross ist die Zustimmung zur Zielsetzung, allen Versicherten unabhängig von der gewählten Kasse dieselben medizinischen Grundleistungen bereitzustellen (72%).

Etwas zurückhaltender fällt die Bewertung der finanzierungs- und strukturpolitischen Zielsetzungen aus. 67 Prozent finden, dass ein faires und solidarisch finanziertes System verwirklicht wurde. 29 Prozent beurteilen dieses Ziel hingegen als eher oder überhaupt nicht erreicht. Die Aussage, dass eine freie Kassenwahl den Wettbewerb fördert und dadurch bessere Angebote entstehen, bewerten die Stimmberechtigten gemischt. Während etwas mehr als die Hälfte diesem Punkt zustimmt (58%), lehnen 34 Prozent diese Einschätzung ab.

Besonders skeptisch ist die Bevölkerung bei der Frage nach der Wirksamkeit von Massnahmen zur Kostendämpfung und zur effizienten Nutzung der Ressourcen. Nur 41 Prozent sehen dieses Ziel als erfüllt an, während 49 Prozent der Meinung sind, dass es verfehlt worden ist.

Die sozialpolitischen Kernanliegen des KVG sind aus Sicht der Bevölkerung mehrheitlich eingelöst worden. Deutlich weniger Zustimmung erfahren jedoch jene Elemente, die auf ökonomische Steuerung und systemische Effizienz zielen.

[Symbol: Personengruppe – markiert den Hinweis auf Unterschiede zwischen Bevölkerungsgruppen]

**[Grafik 1] Einlösung Versprechen KVG**

Frage: «Mit der Einführung des Krankenversicherungsgesetzes (KVG) im Jahr 1996 wurden verschiedene Ziele verfolgt. Sind die folgenden Versprechen Ihrer Meinung nach eingelöst worden?»

Darstellung: gestapelte horizontale Balken (100 %), in % Stimmberechtigte, 2025; alle Werte beschriftet.

| Versprechen | Voll und ganz eingelöst | Eher eingelöst | Weiss nicht / keine Antwort | Eher nicht eingelöst | Überhaupt nicht eingelöst |
|---|---|---|---|---|---|
| Alle Einwohnerinnen und Einwohner der Schweiz haben durch die Einführung der obligatorischen Krankenversicherung Zugang zur medizinischen Grundversorgung. | 40 | 56 | 1 | 2 | 1 |
| Um die finanzielle Belastung von einkommensschwachen Haushalten zu verringern gibt es eine soziale Absicherung durch die individuelle Prämienverbilligung. | 21 | 62 | 2 | 11 | 4 |
| Alle Versicherten sollen dieselben medizinischen Grundleistungen erhalten, unabhängig von ihrer Krankenkasse. | 21 | 51 | 6 | 17 | 5 |
| Ein faireres Finanzierungsmodell, bei dem alle solidarisch zur Deckung der Gesundheitskosten beitragen. | 24 | 43 | 4 | 22 | 7 |
| Die freie Wahl der Krankenkassen, die zu mehr Wettbewerb zwischen den Krankenkassen und dadurch zu besseren Angeboten für die Versicherten führt. | 15 | 43 | 8 | 18 | 16 |
| Dämpfung der Kostensteigerung und effizientere Nutzung der Ressourcen. | 11 | 30 | 10 | 26 | 23 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 1]**

---

— Ende Teil 2 von 7 · Kontrollwort Teil 2: OBERALP-91 · weiter mit teil-03.md —
