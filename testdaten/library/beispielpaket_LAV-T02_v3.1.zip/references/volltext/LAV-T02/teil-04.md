# LAV-T02 · Volltext · Teil 4 von 7 (PDF-Seiten 12–14 von 27)

Studie: Gesundheitsmonitor 2025 – Das Wichtigste in Kürze (gfs.bern im Auftrag von Interpharma) · Quelldatei: gesundheitsmonitor-2025.pdf · Transkript-Version 1.0 · 2026-10-14
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 7 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T02, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 12/27 · Druckseiten 20–21]]

**[Grafik 7] Forderungen zu den Krankenkassen**

Frage: «Aktuell werden in der Politik rund um Krankenkassen verschiedene Vorschläge diskutiert. Bitte geben Sie jeweils an, ob Sie mit den verschiedenen Vorschlägen einverstanden sind?»

Darstellung: gestapelte horizontale Balken (100 %), in % Stimmberechtigte, 2025; alle Werte beschriftet.

| Vorschlag | Sehr einverstanden | Eher einverstanden | Weiss nicht / keine Antwort | Eher nicht einverstanden | Gar nicht einverstanden |
|---|---|---|---|---|---|
| Gebühr für Bagatellfälle in Spitalnotfallaufnahme | 33 | 53 | 3 | 7 | 4 |
| Kopfprämie | 26 | 56 | 5 | 9 | 4 |
| Medikamente für Bagatellen nicht bezahlen | 28 | 53 | 3 | 10 | 6 |
| Vollumfänglicher Abzug vom steuerbaren Einkommen | 34 | 47 | 5 | 11 | 3 |
| Automatische Massnahmen zur Kostenbegrenzung | 25 | 42 | 8 | 18 | 7 |
| Einkommensabhängig Prämie | 13 | 43 | 7 | 27 | 10 |
| Günstigere Behandlungen im Ausland bezahlen | 22 | 34 | 10 | 27 | 7 |
| Budget-Krankenkasse | 11 | 39 | 11 | 32 | 7 |
| Einheitskasse | 17 | 31 | 17 | 26 | 9 |
| Maximalfranchise erhöhen | 12 | 29 | 5 | 40 | 14 |
| Minimale Franchise erhöhen | 10 | 25 | 4 | 41 | 20 |
| Nur Versicherungsmodelle mit Erstanlaufstelle | 5 | 22 | 11 | 42 | 20 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 7]**

Die Zustimmung zum aktuellen Prämiensystem aus einer Kopfprämie und Subventionen für tiefere Einkommen bleibt über die Jahre hinweg weitgehend stabil. Gleichzeitig zeigt sich ein wachsender Zuspruch für Reformvorschläge, was auf eine zunehmende Offenheit der Bevölkerung gegenüber strukturellen Neuerungen im Gesundheitssystem hinweist.

**[Grafik 8] Leistungskatalog**

Frage: «Die Grundversicherung deckt alle notwendigen medizinischen Leistungen ab und wurde in verschiedenen Bereichen ausgebaut. Darüber hinausgehende Leistungen müssen die Versicherten mit Zusatzversicherungen abdecken, wobei die Kassen hier nicht verpflichtet sind, den Versicherten aufzunehmen. Sind Sie beim Leistungskatalog, der durch die Grundversicherung abgedeckt wird, …»

Darstellung: gestapelte Säulen (100 %), 2016–2025, in % Stimmberechtigte; alle Werte beschriftet (Zeilensummen = 100).

| Jahr | Für einen Ausbau | Für das Belassen auf heutigen Stand | Für einen Abbau | Weiss nicht/keine Antwort |
|---|---|---|---|---|
| 2016 | 29 | 59 | 9 | 3 |
| 2017 | 27 | 58 | 11 | 4 |
| 2018 | 16 | 70 | 5 | 9 |
| 2019 | 26 | 63 | 5 | 6 |
| 2020 | 25 | 67 | 4 | 4 |
| 2021 | 43 | 48 | 7 | 2 |
| 2022 | 36 | 55 | 6 | 3 |
| 2023 | 37 | 57 | 4 | 2 |
| 2024 | 33 | 60 | 4 | 3 |
| 2025 | 22 | 49 | 19 | 10 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 8]**

Eine weitere Möglichkeit, wie das Krankenversicherungssystem umgestaltet werden könnte, liegt in der Anpassung des Leistungskatalogs.

Eine relative Mehrheit der Stimmberechtigten spricht sich weiterhin für das Belassen des aktuellen Leistungskatalogs der obligatorischen Grundversicherung aus. 49 Prozent befürworten den heutigen Umfang beizubehalten. Jeweils rund ein Fünftel der Befragten unterstützt eine Anpassung des Katalogs, wobei sich 22 Prozent für einen Ausbau und 19 Prozent für eine Reduktion der abgedeckten Leistungen aussprechen.

---

[[Seite 13/27 · Druckseiten 22–23]]

Die Frage, welche konkreten Leistungen von der obligatorischen Grundversicherung übernommen werden sollen und welche zulasten der versicherten Person gehen, wird in der Bevölkerung unterschiedlich beurteilt. Die Stimmberechtigten differenzieren zwischen medizinischen Indikationen, bei denen eine solidarische Finanzierung erwartet wird, und solchen, bei denen Eigenverantwortung im Vordergrund steht.

Eine klare Mehrheit der Bevölkerung erwartet eine Finanzierung über die Grundversicherung insbesondere bei schwerwiegenden, chronischen oder nicht selbst verschuldeten Erkrankungen. So befürworten 93 Prozent eine Kassenleistung bei seltenen Krankheiten, 91 Prozent eine solche bei der Betreuung von Angehörigen mit einer Behinderung, und 90 Prozent eine Kassenleistung bei der Früherkennung von Krebs. Auch bei der Prävention von Herz-Kreislauf-Erkrankungen (84%), bei psychischen Beschwerden (81%) sowie bei stressbedingten Beschwerden (70%) wird mehrheitlich eine Kostenübernahme durch die Versicherung gewünscht. Bei Themen mit möglichem Bezug zum individuellen Lebensstil spricht sich nur eine Minderheit für eine Kostenübernahme durch die Krankenkasse aus. Die Einschätzungen zur Kostenübernahme durch die Grundversicherung zeigen sich über die Jahre hinweg weitgehend konstant. Gleichzeitig ist bei einzelnen Leistungen eine abnehmende Zustimmung zur Finanzierung durch die Krankenkassen erkennbar. Deutlich rückläufig ist die Erwartung einer Kostenübernahme bei der ärztlich verordneten Heroinabgabe, bei ungewollter Kinderlosigkeit, bei Schäden, die durch Rauch oder Alkohol entstehen, sowie bei gewichtsbedingten Beschwerden.

Die Stimmbevölkerung differenziert nach Ursache und Schweregrad der Gesundheitsbelastung. Während Solidarität bei schweren, chronischen oder genetisch bedingten Erkrankungen breit getragen wird, tritt bei vermeidbaren oder selbstbeeinflussbaren Risiken zunehmend das Prinzip der Eigenverantwortung in den Vordergrund.

[Symbol: Personengruppe – markiert den Hinweis auf Unterschiede zwischen Bevölkerungsgruppen]

**[Grafik 9] Selbstbezahlte Leistungen/Krankenkassenleistungen**

Frage: «Es gibt ein paar Situationen, wo Leistungen in der Grundversicherung vergütet werden können. Bitte geben Sie bei jeder an, wann Ihrer Ansicht nach die betroffene Person selbst die Leistungen bezahlen sollte und wann Sie der Ansicht sind, dass die Kassen dies tun sollten.»

Darstellung: Liniendiagramm, Zeitachse 1997–2025, Anteil «Kassenzahlung» in % Stimmberechtigte. Beschriftet sind nur die Werte 2025. Die Zeitreihe umfasst 28 Messpunkte: 1997, ein Messpunkt 1998 oder 1999 (Jahr aus der Grafik nicht eindeutig) und jährlich 2000–2025. Die Tabelle zeigt 2000–2025 (aus der Vektorgrafik berechnet, ± 1 Prozentpunkt). Mehrere Reihen beginnen erst 2024 (Früherkennung von Krebs, Vorbeugung von Herz-/Kreislaufkrankheiten, Vorbeugung von Geschlechtskrankheiten).

| Jahr | Bei seltenen Krankheiten | Bei Behinderung eines Familienangehörigen | Bei der Früherkennung von Krebs | Bei der Vorbeugung von Herz-/Kreislaufkrankheiten | Bei psychischen Beschwerden | Bei Beschwerden, durch Stress verursacht | Bei gewichtsbedingten Beschwerden | Bei ungewollter Kinderlosigkeit | Bei der Vorbeugung von Geschlechtskrankheiten (PrEP/HPV-Impfung) | Bei ärztlich verordneter Heroinabgabe | Bei Schäden, die durch Rauchen oder Alkohol entstehen | Bei Abhängigkeit von Drogen |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2000 | – | 86 | – | – | 76 | 58 | 47 | 44 | – | – | 42 | 41 |
| 2001 | – | 83 | – | – | 76 | 46 | 41 | 38 | – | – | 38 | 39 |
| 2002 | – | 83 | – | – | 74 | 41 | 35 | 32 | – | – | 32 | 30 |
| 2003 | – | 90 | – | – | 70 | 51 | 44 | 48 | – | 37 | 33 | 38 |
| 2004 | – | 89 | – | – | 61 | 43 | 32 | 34 | – | 29 | 28 | 27 |
| 2005 | – | 89 | – | – | 79 | 62 | 49 | 41 | – | 41 | 36 | 37 |
| 2006 | – | 93 | – | – | 68 | 50 | 33 | 32 | – | 46 | 31 | 47 |
| 2007 | – | 93 | – | – | 73 | 60 | 46 | 50 | – | 50 | 33 | 43 |
| 2008 | – | 91 | – | – | 69 | 57 | 38 | 38 | – | 42 | 26 | 40 |
| 2009 | – | 83 | – | – | 64 | 60 | 46 | 38 | – | 51 | 31 | 36 |
| 2010 | – | 87 | – | – | 66 | 48 | 38 | 56 | – | 62 | 26 | 56 |
| 2011 | 83 | 91 | – | – | 70 | 51 | 37 | 40 | – | 54 | 30 | 45 |
| 2012 | 92 | 93 | – | – | 72 | 52 | 38 | 40 | – | 46 | 27 | 33 |
| 2013 | 84 | 83 | – | – | 71 | 60 | 44 | 53 | – | 34 | 39 | 31 |
| 2014 | 94 | 93 | – | – | 89 | 74 | 56 | 61 | – | 51 | 45 | 48 |
| 2015 | 89 | 87 | – | – | 78 | 71 | 52 | 62 | – | 49 | 42 | 50 |
| 2016 | 87 | 82 | – | – | 72 | 57 | 54 | 67 | – | 38 | 42 | 38 |
| 2017 | 86 | 82 | – | – | 74 | 67 | 51 | 53 | – | 42 | 37 | 37 |
| 2018 | 100 | 96 | – | – | 93 | 83 | 66 | 56 | – | 35 | 39 | 31 |
| 2019 | 93 | 90 | – | – | 85 | 78 | 61 | 62 | – | 57 | 41 | 45 |
| 2020 | 93 | 90 | – | – | 89 | 78 | 66 | 71 | – | 66 | 41 | 35 |
| 2021 | 99 | 96 | – | – | 90 | 79 | 61 | 84 | – | 56 | 40 | 39 |
| 2022 | 95 | 95 | – | – | 92 | 88 | 66 | 69 | – | 66 | 53 | 39 |
| 2023 | 99 | 99 | – | – | 92 | 91 | 70 | 83 | – | 62 | 44 | 23 |
| 2024 | 99 | 97 | 96 | 90 | 87 | 74 | 70 | 84 | 46 | 59 | 40 | 20 |
| 2025 (beschriftet) | 93 | 91 | 90 | 84 | 81 | 70 | 53 | 49 | 43 | 35 | 23 | 17 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’190)

**[Ende Grafik 9]**

[[Seite 14/27 · Druckseiten 24–25]]

## 4 Ausgewählte Analysen

**4.1 Entwicklungen im Gesundheitswesen**

Die Schweizer Stimmbevölkerung ist mit der Qualität des Gesundheitswesens weiterhin äusserst zufrieden. Rund drei Viertel der Befragten schätzen sie als gut oder sehr gut ein (73%). Weitere 23 Prozent stufen das Schweizer Gesundheitswesen als eher gut ein. Kritik an der Qualität wird kaum geäussert.

Während in der deutsch- und der italienischsprachigen Schweiz rund ein Viertel das Gesundheitswesen als sehr gut bewertet (27% resp. 25%), sind es in der Romandie lediglich 16 Prozent. Insgesamt überwiegt auch in der französischsprachigen Schweiz die Zufriedenheit mit der Qualität des Gesundheitswesens. Sie fällt insgesamt jedoch etwas verhaltener aus als in den übrigen Sprachregionen.

Die Wunschvorstellungen hinsichtlich der Ausgestaltung des Gesundheitswesens bleiben im Grossen und Ganzen stabil. Dennoch lassen sich im Jahr 2025 einige Trends erkennen, die für ein wachsendes Kostenbewusstsein seitens der Bevölkerung sprechen.

Die Forderung nach einer Grundversicherung, die sämtliche Leistungen abdeckt, ist nach wie vor vorhanden. Gleichzeitig zeigt sich erstmals seit 2019 eine gewisse Offenheit gegenüber einem Modell, das stärker auf die Abdeckung hoher Risiken fokussiert ist. Zudem soll das Gesundheitswesen gemäss der Bevölkerung gleichermassen durch den Markt und durch den Staat reguliert werden. Die Stimmberechtigten sehen den Bund gemeinsam mit den Kantonen in der Verantwortung für die Steuerung des Systems.

[Symbol: Personengruppe – markiert den Hinweis auf Unterschiede zwischen Bevölkerungsgruppen]

**[Grafik 10] Qualität Gesundheitswesen**

Frage: «Wie schätzen Sie ganz allgemein die Qualität des schweizerischen Gesundheitswesens ein?»

Darstellung: gestapelte Säulen (100 %), 2004–2025, in % Stimmberechtigte; alle Werte beschriftet («–» = kein beschriftetes Segment). Die beschrifteten Werte ergeben nicht in jedem Jahr genau 100 (z. B. 2017: 95).

| Jahr | Sehr gut | Gut | Eher gut | Weiss nicht / keine Antwort | Eher schlecht | Schlecht | Sehr schlecht |
|---|---|---|---|---|---|---|---|
| 2004 | 26 | 49 | 19 | 1 | 4 | 1 | – |
| 2005 | 26 | 41 | 23 | 1 | 7 | 2 | – |
| 2006 | 29 | 41 | 25 | – | 4 | 1 | – |
| 2007 | 27 | 46 | 21 | – | 5 | 1 | – |
| 2008 | 33 | 43 | 20 | – | 3 | 1 | – |
| 2009 | 26 | 48 | 21 | – | 4 | 1 | – |
| 2010 | 44 | 33 | 19 | – | 3 | 1 | – |
| 2011 | 36 | 41 | 20 | – | 2 | 1 | – |
| 2012 | 35 | 41 | 20 | – | 3 | – | – |
| 2013 | 26 | 44 | 27 | – | 2 | 1 | – |
| 2014 | 23 | 43 | 31 | 1 | 2 | – | – |
| 2015 | 21 | 48 | 27 | 1 | – | 1 | – |
| 2016 | 24 | 51 | 23 | – | 1 | 1 | – |
| 2017 | 20 | 51 | 23 | – | 1 | – | – |
| 2018 | 23 | 57 | 19 | 1 | – | – | – |
| 2019 | 20 | 41 | 37 | 1 | 1 | – | – |
| 2020 | 16 | 49 | 32 | 1 | 2 | – | – |
| 2021 | 17 | 48 | 32 | – | 3 | – | – |
| 2022 | 25 | 40 | 31 | – | 2 | 1 | – |
| 2023 | 16 | 57 | 26 | – | 1 | – | – |
| 2024 | 25 | 48 | 24 | – | 2 | 1 | – |
| 2025 | 24 | 49 | 23 | – | 2 | – | 2 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’210)

**[Ende Grafik 10]**

**[Grafik 11] Wunschvorstellung Gesundheitswesen in der Schweiz**

Frage: «Bitte sagen Sie mir, was für ein Gesundheitswesen in der Schweiz Sie sich wünschen. Wenn Sie mit dem ersten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 1 oder nahe bei 1. Wenn Sie mit dem zweiten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 6 oder eine Zahl nahe bei 6.»

Darstellung: Liniendiagramm, 2016–2025, Mittelwerte Stimmberechtigte auf der Skala 1–6 (1 = erster Pol, vor «vs.»; 6 = zweiter Pol, nach «vs.»). Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 0.1).

| Wertepolarität | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 (beschriftet) |
|---|---|---|---|---|---|---|---|---|---|---|
| Risiko (vs. sämtliche Leistungen) | 3.5 | 3.7 | 4.4 | 3.7 | 4.0 | 4.1 | 3.9 | 4.3 | 4.3 | 3.6 |
| Markt (vs. Staat) | 3.0 | 3.3 | 3.3 | 3.5 | 3.5 | 3.5 | 3.6 | 3.9 | 3.8 | 3.5 |
| Kantone (vs. Bund) | 3.0 | 3.5 | 3.6 | 3.5 | 3.9 | 3.4 | 3.6 | 3.9 | 3.8 | 3.4 |
| Gemeinschaftsverantwortung (vs. Eigenverantwortung) | 3.3 | 3.2 | 3.6 | 3.1 | 4.0 | 3.0 | 3.1 | 2.7 | 2.9 | 3.2 |
| Quantität Leistungen (vs. Kosten) | 2.8 | 2.6 | 2.3 | 2.5 | 2.4 | 2.3 | 2.3 | 2.2 | 2.2 | 2.8 |
| Zugang zu Medikamenten (vs. Kosten) | – | – | – | 2.0 | 2.2 | 2.2 | 2.2 | 2.0 | 2.1 | 2.6 |
| Qualität Leistungen (vs. Kosten) | 2.3 | 2.3 | 1.9 | 2.2 | 2.2 | 2.2 | 2.2 | 1.9 | 2.0 | 2.4 |
| Freie Arztwahl (vs. vorgegebene Arztwahl) | 2.4 | 2.4 | 2.0 | 2.1 | 2.1 | 2.3 | 2.2 | 1.9 | 2.0 | 2.2 |

Lesehilfe: Bei jeder Wertepolarität war es möglich, sich zwischen dem einen und dem anderen Pol auf einer ganzzahligen Skala von 1 bis 6 zu positionieren. Werte von 3.5 bedeuten, dass die Stimmberechtigten im Durchschnitt genau zwischen den Polen stehen. Je grösser die Abweichung davon auf die eine oder andere Seite ist, desto klarer neigen die Befragten dem entsprechenden Werte-Pol zu.

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’190)

**[Ende Grafik 11]**

---

— Ende Teil 4 von 7 · Kontrollwort Teil 4: ALPENROSE-65 · weiter mit teil-05.md —
