# LAV-T02 · Volltext · Teil 6 von 7 (PDF-Seiten 19–22 von 27)

Studie: Gesundheitsmonitor 2025 – Das Wichtigste in Kürze (gfs.bern im Auftrag von Interpharma) · Quelldatei: gesundheitsmonitor-2025.pdf · Transkript-Version 1.0 · 2026-10-14
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 7 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T02, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 19/27 · Druckseiten 34–35]]

**4.2 Pharmaindustrie und Medikamente**

Ein weiterer wichtiger Akteur innerhalb des Gesundheitswesens ist die Pharmabranche. Die Stimmberechtigten erkennen die wirtschaftliche und die gesellschaftliche Bedeutung der Pharmaindustrie klar an. Für 95 Prozent ist sie eine wichtige Arbeitgeberin. Sie geniesst international einen guten professionellen Ruf (91%), und 90 Prozent sehen sie als Motor der Exportwirtschaft. Hinsichtlich der Standortbindung zeigen sich die Stimmberechtigten der Pharmabranche gegenüber ebenfalls wohlgesinnt. Vier Fünftel der Bevölkerung sind der Meinung, dass sich die Branche für den Standort Schweiz interessiert (80%).

Etwas skeptischer ist die Bevölkerung, wenn es um die Gewinnverwendung und Transparenz geht. Rund die Hälfte hält hohe Gewinne für nötig zur Finanzierung von Forschung (53%), während 40 Prozent dieser Aussage gleichzeitig widersprechen. Besonders kritisch fällt das Urteil bei der Informationspolitik der Branche aus. 27 Prozent halten die Pharmaindustrie in der Schweiz für eine transparente Informantin. Mehr als die Hälfte hingegen beurteilt die Kommunikation als nicht ausreichend offen (58%).

Die Erforschung und Entwicklung innovativer Therapien ist ein zentrales Handlungsfeld der Pharmaindustrie. Solche Therapien gelten als medizinisch vielversprechend, sind jedoch häufig mit hohen Kosten verbunden. Entsprechend intensiv wird die Frage diskutiert, unter welchen Bedingungen der Zugang zu solchen Behandlungen erfolgen soll.

83 Prozent befürworten einen Zugang zu innovativen Therapien, sofern deren systemischer Nutzen ausgewiesen ist, etwa durch Einsparungen bei Pflegekosten oder durch eine erleichterte Wiedereingliederung in den Arbeitsmarkt. Ein gleichberechtigter Zugang zu innovativen Therapien geniesst ebenfalls hohe Zustimmungswerte (79%).

**[Grafik 17] Aussagen zur Pharmaindustrie**

Frage: «Es folgen allgemeine Aussagen zur Pharmaindustrie in der Schweiz. Inwiefern treffen die folgenden Aussagen Ihrer Meinung nach auf die Pharmaindustrie zu?»

Darstellung: gestapelte horizontale Balken (100 %), in % Stimmberechtigte, 2025; alle Werte beschriftet.

| Aussage | Trifft voll und ganz zu | Trifft eher zu | Weiss nicht / keine Antwort | Trifft eher nicht zu | Trifft gar nicht zu |
|---|---|---|---|---|---|
| Die Pharmaindustrie ist eine wichtige Arbeitgeberin in der Schweiz. | 38 | 57 | 2 | 3 | – |
| Die Pharmaindustrie in der Schweiz geniesst einen guten professionellen Ruf im Ausland. | 35 | 56 | 5 | 4 | – |
| Die Pharmaindustrie ist über den Export ein Motor der schweizerischen Wirtschaft. | 30 | 60 | 4 | 4 | 2 |
| Die Pharmaindustrie interessiert sich für den Standort Schweiz. | 19 | 61 | 9 | 8 | 3 |
| Grosse Gewinne der Pharmaindustrie sind nötig, um die Forschung zu finanzieren. | 17 | 36 | 7 | 32 | 8 |
| Die Pharmaindustrie in der Schweiz informiert transparent über ihre Tätigkeiten. | 6 | 21 | 15 | 37 | 21 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 17]**

[[Seite 20/27 · Druckseiten 36–37]]

Bedingte Zugangskriterien, beispielsweise gestützt auf medizinische Erfolgsaussichten oder Gesundheitsindikatoren, stossen auf ein geteiltes Meinungsbild. 42 Prozent befürworten solche Regelungen, während 49 Prozent dagegen sind. Gleichzeitig sehen 35 Prozent der Befragten einen uneingeschränkten Zugang für alle Versicherten als zu kostspielig für das Gesundheitssystem an. Pauschale Begrenzungen der Kosten werden mehrheitlich abgelehnt. Ein fixes Jahresbudget pro Patientin oder Patient stösst bei 72 Prozent auf Ablehnung. Auch eine Begrenzung auf einen Maximalbetrag pro gerettetem Lebensjahr weisen 59 Prozent der Stimmberechtigten zurück.

Die Bevölkerung wünscht sich einen solidarischen und fairen Zugang, ist aber offen für effizienzorientierte Steuerung. Pauschale Rationierungsmechanismen hingegen lehnt sie klar ab.

Neben der Frage des Zugangs ist auch die Entscheidung über die Kostenübernahme bei innovativen oder kostenintensiven Therapien von Bedeutung. Wenn es darum geht, ob eine teure Behandlung mit ungünstigem Kosten-Nutzen-Verhältnis von der obligatorischen Krankenversicherung übernommen werden soll, bevorzugt die Mehrheit der Stimmberechtigten eine Lösung, bei der Ärztinnen und Ärzte gemeinsam mit Patientinnen und Patienten entscheiden.

Rund zwei Drittel sprechen sich für ein solches partizipatives Vorgehen aus (66%). Auch Entscheidungsmodelle mit Kommissionen, in denen verschiedene Anspruchsgruppen vertreten sind, finden mit 51 Prozent breite Unterstützung. Der Einbezug von Ärztinnen und Ärzten (50%) und von Patientinnen und Patienten (37%) jeweils in getrennten Prozessen erfährt ebenfalls zunehmende Unterstützung.

[Symbol: Personengruppe – markiert den Hinweis auf Unterschiede zwischen Bevölkerungsgruppen]

**[Grafik 18] Regelung Zugang zu innovativen Therapien**

Frage: «Die Pharmaindustrie entwickelt derzeit eine Vielzahl von hochwirksamen, aber teuren Therapien, die gezielt für einzelne Krankheiten und Patientinnen und Patienten angepasst sind. Es gibt verschiedene Meinungen dazu, wie der Zugang zu diesen innovativen Therapien geregelt werden soll. Wie schätzen Sie dies ein?»

Darstellung: gestapelte horizontale Balken (100 %), in % Stimmberechtigte, 2025; alle Werte beschriftet.

| Regelung | Voll einverstanden | Eher einverstanden | Weiss nicht / keine Antwort | Eher nicht einverstanden | Überhaupt nicht einverstanden |
|---|---|---|---|---|---|
| Zugang nach systemischem Nutzen | 20 | 63 | 5 | 7 | 5 |
| Gleichberechtigter Zugang zu innovativen Therapien | 27 | 52 | 8 | 11 | 2 |
| Zugang nach Gesundheitskriterien | 10 | 32 | 9 | 37 | 12 |
| Uneingeschränkte Therapien zu teuer | 8 | 27 | 13 | 43 | 9 |
| Vergütung bis zu einem maximalen Betrag pro gerettetem Lebensjahr | 4 | 25 | 12 | 46 | 13 |
| Jährliches Budget pro Person | 3 | 19 | 6 | 51 | 21 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 18]**

[[Seite 21/27 · Druckseiten 38–39]]

Deutlich weniger Zustimmung erhalten politisch-administrative oder institutionelle Entscheidungsträger. Das Bundesamt für Gesundheit (22%), die Konferenz der kantonalen Gesundheitsdirektorinnen und Gesundheitsdirektoren (19%) sowie das Bundesgericht (15%) werden nur von einer Minderheit als geeignete Instanzen angesehen. Auch Spitalleitungen (12%) und Krankenkassen (10%) stossen auf geringe Akzeptanz.

Die Bevölkerung möchte somit bei Behandlungsentscheiden eher auf fachlich fundierte, patientennahe Verfahren setzen als auf administrativ oder politisch geprägte Entscheidungsstrukturen.

Nicht nur bei innovativen Therapien oder teuren Behandlungen, sondern auch bei der Verschreibung von Medikamenten kommen unterschiedliche Entscheidungskriterien zur Anwendung.

Eine knappe Mehrheit der Stimmberechtigten spricht sich dafür aus, dass Ärztinnen und Ärzte grundsätzlich das medizinisch geeignetste Medikament verschreiben sollen (51%). An zweiter Stelle steht die individuelle Abwägung. 30 Prozent der Befragten befürworten, dass die Wahl des Medikaments im Einzelfall erfolgen sollte, wobei zwischen Kosten und Nutzen abgewogen wird. Reine Kostenerwägungen spielen weiterhin eine Rolle, ihre Bedeutung nimmt jedoch tendenziell zugunsten einer Einzelfallabwägung ab (17%).

Die Bevölkerung wünscht sich medizinisch fundierte Verschreibungsentscheide. Gleichzeitig besteht ein zunehmendes Bewusstsein dafür, dass auch ökonomische Überlegungen berücksichtigt werden können, sofern dieser Einbezug differenziert und auf den konkreten Fall zugeschnitten erfolgt.

**[Grafik 19] Entscheid Übernahme von teuren Behandlungen**

Frage: «Wer soll darüber entscheiden, ob eine sehr teure Behandlung aufgrund eines ungünstigen Kosten-/Nutzenverhältnis von den Krankenkassen nicht bezahlt werden soll?»

Darstellung: Liniendiagramm, 2016–2025, Anteil «entscheiden» in % Stimmberechtigte. Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 1 Prozentpunkt).

| Instanz | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 (beschriftet) |
|---|---|---|---|---|---|---|---|---|---|---|
| Ärzt:innen gemeinsam mit Patient:innen | 68 | 71 | 82 | 63 | 54 | 54 | 63 | 53 | 61 | 66 |
| Kommission mit Vertreter:innen aller Beteiligten | 42 | 49 | 67 | 50 | 41 | 37 | 46 | 43 | 48 | 51 |
| Ärztinnen und Ärzte | 41 | 50 | 70 | 51 | 41 | 42 | 41 | 36 | 30 | 50 |
| Patientinnen und Patienten | 47 | 53 | 60 | 40 | 24 | 32 | 28 | 17 | 13 | 37 |
| Bundesamt für Gesundheit | 20 | 34 | 21 | 14 | 15 | 10 | 10 | 8 | 8 | 22 |
| Konferenz der kantonalen Gesundheitsdirektor:innen | 22 | 26 | 19 | 14 | 12 | 9 | 11 | 9 | 8 | 19 |
| Bundesgericht | 25 | 30 | 16 | 13 | 9 | 16 | 8 | 10 | 7 | 15 |
| Spitalleitung | 18 | 26 | 22 | 21 | 13 | 36 | 34 | 31 | 33 | 12 |
| Krankenkassen | 17 | 24 | 14 | 20 | 16 | 21 | 20 | 19 | 22 | 10 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 19]**

**[Grafik 20] Haltung Medikamentenabgabe**

Frage: «Für die meisten Beschwerden gibt es eine Auswahl von mehreren Medikamenten zur Behandlung. Welche Kriterien sollte eine Ärztin oder ein Arzt bei der Verschreibung eines Medikaments vorrangig berücksichtigen?»

Darstellung: gestapelte Säulen (100 %), 2016–2025, in % Stimmberechtigte; alle Werte beschriftet.

| Jahr | Sollte immer das geeignetste Medikament verschreiben | Sollte darauf achten, dass die Medikamente nicht zu teuer sind | Sollte in jedem Fall abwägen | Weiss nicht / keine Antwort |
|---|---|---|---|---|
| 2016 | 43 | 34 | 21 | 2 |
| 2017 | 52 | 23 | 23 | 2 |
| 2018 | 53 | 18 | 28 | 1 |
| 2019 | 51 | 16 | 32 | 1 |
| 2020 | 50 | 26 | 23 | 1 |
| 2021 | 55 | 22 | 23 | – |
| 2022 | 49 | 25 | 25 | 1 |
| 2023 | 55 | 24 | 21 | – |
| 2024 | 53 | 22 | 24 | 1 |
| 2025 | 51 | 17 | 30 | 2 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 20]**

[[Seite 22/27 · Druckseiten 40–41]]

Beim Entscheid zwischen einem Originalmedikament und einem Generikum zeigt sich eine klare Präferenz zugunsten des Generikums. 60 Prozent der Stimmberechtigten tendieren zum Generikum, während nur 37 Prozent das Originalpräparat bevorzugen.

Diese Entwicklung weist auf ein gestiegenes Kostenbewusstsein sowie ein zunehmendes Vertrauen in Generika hin. Gleichzeitig dürfte auch die Einführung des höheren Selbstbehalts beim Bezug von Originalpräparaten zur verstärkten Nutzung kostengünstiger Alternativen beigetragen haben.

Die Kritik an den Medikamentenpreisen hat im Verlauf der letzten Jahre zugenommen und erreicht im Jahr 2025 einen neuen Höchststand. 87 Prozent sind der Meinung, dass die Medikamentenpreise zu hoch sind. 10 Prozent empfinden die Preise als angemessen. Die aktuelle Kritik liegt damit wieder auf einem ähnlich hohen Niveau wie in der Phase vom Ende der 1990er-Jahre bis in die frühen 2010er-Jahre, als die Unzufriedenheit mit den Medikamentenpreisen bereits stark ausgeprägt war.

Die Vorbehalte gegenüber der Preisgestaltung haben sich verstärkt. Trotz hoher Zustimmung für Generika und wachsendem Kostenbewusstsein in der Bevölkerung scheint die Preisentwicklung im Arzneimittelbereich nicht mit den Erwartungen der Stimmberechtigten Schritt zu halten.

**[Grafik 21] Haltung Original/Generika**

Frage: «Wenn Sie die Auswahl haben, was würden Sie eher kaufen?»

Darstellung: gestapelte Säulen (100 %), 2016–2025, in % Stimmberechtigte; alle Werte beschriftet.

| Jahr | Originalmedikament | Generikum | Weiss nicht/keine Antwort |
|---|---|---|---|
| 2016 | 52 | 40 | 8 |
| 2017 | 52 | 40 | 8 |
| 2018 | 57 | 29 | 14 |
| 2019 | 56 | 35 | 9 |
| 2020 | 50 | 40 | 10 |
| 2021 | 67 | 25 | 8 |
| 2022 | 55 | 35 | 10 |
| 2023 | 57 | 35 | 8 |
| 2024 | 62 | 28 | 10 |
| 2025 | 37 | 60 | 3 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 21]**

**[Grafik 22] Haltung Medikamentenpreise**

Frage: «Wie stufen Sie die Medikamentenpreise in der Schweiz Ihrer Meinung nach alles in allem ein?»

Darstellung: gestapelte Säulen (100 %), 28 Erhebungen 1997–2025, in % Stimmberechtigte; alle Werte beschriftet. Die zweite Säule (zwischen den Achsenbeschriftungen 97 und 00) ist das Jahr 1998 oder 1999; aus der Grafik nicht eindeutig.

| Jahr | Zu hoch | Angemessen | Zu tief | Weiss nicht / keine Antwort |
|---|---|---|---|---|
| 1997 | 89 | 9 | – | 2 |
| 1998 oder 1999 | 88 | 10 | – | 2 |
| 2000 | 90 | 9 | – | 1 |
| 2001 | 86 | 10 | – | 4 |
| 2002 | 84 | 11 | – | 5 |
| 2003 | 87 | 9 | 1 | 3 |
| 2004 | 88 | 11 | – | 1 |
| 2005 | 81 | 16 | – | 3 |
| 2006 | 87 | 12 | – | 1 |
| 2007 | 91 | 9 | – | – |
| 2008 | 80 | 17 | – | 3 |
| 2009 | 87 | 13 | – | – |
| 2010 | 87 | 12 | – | 1 |
| 2011 | 81 | 17 | – | 2 |
| 2012 | 86 | 12 | – | 2 |
| 2013 | 75 | 22 | 1 | 2 |
| 2014 | 65 | 34 | – | 1 |
| 2015 | 71 | 24 | – | 5 |
| 2016 | 69 | 29 | 1 | 2 |
| 2017 | 69 | 27 | 1 | 3 |
| 2018 | 76 | 20 | – | 4 |
| 2019 | 77 | 18 | – | 5 |
| 2020 | 76 | 19 | 1 | 4 |
| 2021 | 59 | 38 | 1 | 2 |
| 2022 | 64 | 32 | 2 | 2 |
| 2023 | 75 | 22 | 2 | 1 |
| 2024 | 75 | 23 | 1 | 1 |
| 2025 | 87 | 10 | – | 3 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’170)

**[Ende Grafik 22]**

---

— Ende Teil 6 von 7 · Kontrollwort Teil 6: WEISSHORN-93 · weiter mit teil-07.md —
