# LAV-T02 · Volltext · Teil 1 von 7 (PDF-Seiten 1–4 von 27)

Studie: Gesundheitsmonitor 2025 – Das Wichtigste in Kürze (gfs.bern im Auftrag von Interpharma) · Quelldatei: gesundheitsmonitor-2025.pdf · Transkript-Version 1.0 · 2026-10-14
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 7 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T02, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 1/27 · Umschlag]]

## Das Wichtigste in Kürze zum Gesundheitsmonitor 2025

**Kostenbewusstsein innerhalb der Bevölkerung nimmt zu**

Auftraggeberin: Interpharma · Durchführung: gfs.bern

Projektteam: Urs Bieri, Co-Leiter; Tobias Keller, Projektleiter und Teamleader Data Analytics; Corina Schena, Projektleiterin; Sara Rellstab, Data Scientist

[Bild: Titelgrafik mit Mikroskop und Schweizerkarte; Logos interpharma und gfs.bern]

[[Seite 2/27 · Umschlag innen + Druckseite 1]]

Eine Studie im Auftrag von Interpharma.

Der Gesundheitsmonitor will die Einstellung der Schweizer Stimmberechtigten zum Gesundheitswesen zuverlässig ermitteln.

Die Repräsentativbefragung wird seit 1996 einmal jährlich durchgeführt. 2025 wurden 1’200 Stimmberechtigte in allen Sprachregionen hierfür in Face-to-Face-Interviews befragt. [Hinweis Transkription: Laut Datenbasis-Kapitel und Grafikfussnoten wurde 2025 erstmals im Mixed Mode erhoben (Face-to-Face und Online-Panel).]

Nachfolgend berichten wir über die Hauptergebnisse.

Interpharma, Verband der forschenden pharmazeutischen Firmen der Schweiz, Petersgraben 35, Postfach, 4009 Basel · Telefon 061 264 34 00 · E-Mail info@interpharma.ch

Die Inhalte der Broschüre finden Sie auch auf der Website von Interpharma unter www.interpharma.ch. Grafiken der jeweils aktuellsten Version können Sie zu Ihrer freien Verwendung unter Quellenangabe herunterladen.

Disponible en traduction française · © Interpharma, 2025, Basel · Abdruck mit Quellenangabe erwünscht

## Inhaltsverzeichnis

| Kapitel | Druckseite |
|---|---|
| 1 Vorwort | 2 |
| 2 Executive Summary | 10 |
| 3 Schwerpunktthemen 2025 | 12 |
| 4 Ausgewählte Analysen | 24 |
| 4.1 Entwicklungen im Gesundheitswesen | 24 |
| 4.2 Pharmaindustrie und Medikamente | 34 |
| 5 Thesen | 42 |
| 6 Datenbasis der aktuellen Welle | 44 |
| 7 Anhang | 46 |
| 7.1 gfs.bern-Team | 46 |

[[Seite 3/27 · Druckseiten 2–3]]

## 1 Vorwort

Der Gesundheitsmonitor, von Interpharma in Auftrag gegeben und vom Forschungsinstitut gfs.bern durchgeführt, feiert dieses Jahr sein 25-jähriges Bestehen. Seit einem Vierteljahrhundert liefert diese Studie wichtige Einblicke in die Haltung der Schweizer Bevölkerung zum Gesundheitssystem und zu der Rolle, welche die Schweizer Pharmaindustrie darin spielt. Der Gesundheitsmonitor ist somit eines der ältesten Monitorings der Schweiz, welches die Stimmbevölkerung jährlich zu Gesundheitsthemen befragt. Er bildet eine aufschlussreiche Schnittstelle zwischen der Öffentlichkeit und der Pharmabranche und greift regelmässig die Sorgen, Erwartungen und Meinungen zu einem der komplexesten, innenpolitischen Themen auf: dem Schweizer Gesundheitswesen. Wir sind stolz darauf, damit einen wichtigen Beitrag zum gesundheitspolitischen Diskurs zu leisten.

**Ein Vierteljahrhundert Gesundheitsmonitor**

Der jährlich erscheinende Gesundheitsmonitor wurde kurz nach Inkrafttreten des Krankenversicherungsgesetzes (KVG) ins Leben gerufen. Das KVG ist ein Meilenstein in der Geschichte des Schweizer Gesundheitswesens. Mit diesem Gesetz wurde die Grundlage für ein solidarisch finanziertes Gesundheitssystem geschaffen, das bis heute Bestand hat.

Vor diesem Hintergrund wollen wir in diesem Artikel die Entwicklung der Umfrageergebnisse der letzten 25 Jahre analysieren und den 1996 definierten Zielen des KVG gegenüberstellen. Zusätzlich interessiert uns, in welchem Verhältnis das subjektive Empfinden der Befragten zu den objektiv messbaren Fakten steht. Zur besseren Übersicht fassen wir die im KVG definierten Ziele in drei übergeordnete Themenbereiche zusammen: Solidarität, Qualität und Kosten. Diese werden im Folgenden einzeln betrachtet.

[Bild: Porträtfoto von Dr. René Buholzer]

**[Grafik] Selbstbezahlte Leistungen/Krankenkassenleistungen**

Frage: «Es gibt ein paar Situationen, wo Leistungen in der Grundversicherung vergütet werden können. Bitte geben Sie bei jeder an, wann Ihrer Ansicht nach die betroffene Person selbst die Leistungen bezahlen sollte und wann Sie der Ansicht sind, dass die Kassen dies tun sollten.»

Darstellung: Liniendiagramm, Zeitachse 1997–2025, Anteil «Kassenzahlung» in % Stimmberechtigte. Beschriftet sind nur die Werte 2025. Die Zeitreihe umfasst 28 Messpunkte: 1997, ein Messpunkt 1998 oder 1999 (Jahr aus der Grafik nicht eindeutig) und jährlich 2000–2025. Die Tabelle zeigt 2000–2025 (aus der Vektorgrafik berechnet, ± 1 Prozentpunkt). Die Reihe «Bei seltenen Krankheiten» beginnt 2011, «Vorbeugung von Herz-/Kreislaufkrankheiten» 2024. Die ersten beiden Messpunkte (berechnet): Behinderung 68/80, psychische Beschwerden 66/68, Stress 25/46, Gewicht 20/37, Rauchen/Alkohol 20/38.

| Jahr | Bei seltenen Krankheiten | Bei Behinderung eines Familienangehörigen | Bei der Vorbeugung von Herz-/Kreislaufkrankheiten | Bei psychischen Beschwerden | Bei Beschwerden, durch Stress verursacht | Bei gewichtsbedingten Beschwerden | Bei Schäden, die durch Rauchen oder Alkohol entstehen |
|---|---|---|---|---|---|---|---|
| 2000 | – | 86 | – | 76 | 58 | 47 | 42 |
| 2001 | – | 83 | – | 76 | 46 | 41 | 38 |
| 2002 | – | 83 | – | 74 | 41 | 35 | 32 |
| 2003 | – | 90 | – | 70 | 51 | 44 | 33 |
| 2004 | – | 89 | – | 61 | 43 | 32 | 28 |
| 2005 | – | 89 | – | 79 | 62 | 49 | 36 |
| 2006 | – | 93 | – | 68 | 50 | 33 | 31 |
| 2007 | – | 93 | – | 73 | 60 | 46 | 33 |
| 2008 | – | 91 | – | 69 | 57 | 38 | 26 |
| 2009 | – | 83 | – | 64 | 60 | 46 | 31 |
| 2010 | – | 87 | – | 66 | 48 | 38 | 26 |
| 2011 | 83 | 91 | – | 70 | 51 | 37 | 30 |
| 2012 | 92 | 93 | – | 72 | 52 | 38 | 27 |
| 2013 | 84 | 83 | – | 71 | 60 | 44 | 39 |
| 2014 | 94 | 93 | – | 89 | 74 | 56 | 45 |
| 2015 | 89 | 87 | – | 78 | 71 | 52 | 42 |
| 2016 | 87 | 82 | – | 72 | 57 | 54 | 42 |
| 2017 | 86 | 82 | – | 74 | 67 | 51 | 37 |
| 2018 | 100 | 96 | – | 93 | 83 | 66 | 39 |
| 2019 | 93 | 90 | – | 85 | 78 | 61 | 41 |
| 2020 | 93 | 90 | – | 89 | 78 | 66 | 41 |
| 2021 | 99 | 96 | – | 90 | 79 | 61 | 40 |
| 2022 | 95 | 95 | – | 92 | 88 | 66 | 53 |
| 2023 | 99 | 99 | – | 92 | 91 | 70 | 44 |
| 2024 | 99 | 97 | 90 | 87 | 74 | 70 | 40 |
| 2025 (beschriftet) | 93 | 91 | 84 | 81 | 70 | 53 | 23 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’190)

**[Ende Grafik]**

**Der Solidaritätsgedanke ist stark verankert**

Mit dem Obligatorium der Grundversicherung wird eine solidarisch finanzierte Krankenversicherung sichergestellt. Auf diesem Weg erhalten jene Unterstützung, die aufgrund einer Krankheit hohe Gesundheitsausgaben haben.

Dieser Solidaritätsgedanke wird von der Bevölkerung weiterhin mitgetragen. So zeigt sich eine konstant hohe Solidarität bei der Unterstützung gegen seltene Krankheiten oder bei Behinderung eines Familienangehörigen. Die grosse Mehrheit der Befragten befürwortet deren Deckung durch die Grundversicherung. Die Solidarität gegenüber Behandlungskosten von seltenen Krankheiten nimmt leicht ab, was in Anbetracht der Zeitreihe aber den natürlichen Schwankungen entspricht. Bei selbstverschuldeten Behandlungskosten durch Erkrankungen aufgrund von Tabak- und Alkoholkonsums sinkt die Solidarität jedoch deutlich.

[[Seite 4/27 · Druckseiten 4–5]]

Was bezüglich der Solidarität oft vergessen geht: Unser Gesundheitswesen finanziert sich nicht nur über Prämien und Subventionen. Rund 30 Prozent von den fast 94 Mrd. Franken, die das Schweizer Gesundheitssystem 2023 insgesamt kostete, stammen aus Steuergeldern – und auch diese basieren auf dem Solidaritätsprinzip, da sie einkommens- und vermögensabhängig erhoben werden.

**[Grafik] Verfügbarkeit von innovativen Medikamenten im internationalen Vergleich, 2020–2023**

Basis: EMA N=173 zugelassene Arzneimittel (100 %)*

Darstellung: Säulendiagramm; alle Werte beschriftet.

| Verfügbarkeit | Deutschland | Schweiz |
|---|---|---|
| Voll verfügbar | 90 % | 47 % |
| Teilweise verfügbar | 1 % | 27 % |
| Nicht verfügbar | 10 % | 27 % |

Quellen: Darstellung Interpharma mit Datengrundlage EFPIA Patients W.A.I.T. Indicator 2024 Survey. * Abweichungen wegen Rundungen

**[Ende Grafik]**

**Trotz guter Qualität gibt es Verbesserungspotenzial**

Im Bereich der Qualität steht im Vordergrund, dass die Schweizer Bevölkerung Zugang zu einem hochwertigen Gesundheitssystem hat – und dass alle schnell und gezielt von den neuesten wissenschaftlichen Fortschritten und medizinischen Innovationen profitieren können. Die Schweizer Bevölkerung schätzt die Qualität ihres Gesundheitswesens und somit auch des Patientenzugangs seit Jahren konstant hoch ein. Teil davon ist eine starke und unabhängige Arzneimittelbehörde, welche im Interesse der Patientensicherheit und des Pharmastandorts Schweiz ist. Aufgrund neuer, attraktiver Verfahren zeigt sich im internationalen Vergleich mit anderen Behörden bei der Durchlaufzeit für die Schweizer Marktzulassung eine substanzielle Verbesserung über die Jahre 2019 bis 2021, und sie ist nun vergleichbar mit der Durchlaufzeit bei der Europäischen Zulassungsbehörde EMA (European Medicines Agency).

Ein Blick hinter die Kulissen des Patientenzugangs zeigt aber: Mit der Zulassung durch die Arzneimittelbehörde steht ein Arzneimittel den Patientinnen und Patienten noch nicht gleichberechtigt zur Verfügung. Zuvor muss die Vergütung durch die Grundversicherung (OKP) festgelegt werden. Patientinnen und Patienten warten immer länger, bis ein neu zugelassenes Medikament von den Krankenkassen vergütet wird und damit breit verfügbar ist. Über die Aufnahme auf die Spezialitätenliste und die damit hergestellte, breite Verfügbarkeit entscheidet das Bundesamt für Gesundheit (BAG). 2024 betrug die Wartezeit von der Marktzulassung bis zur Aufnahme in die Spezialitätenliste 189 Tage – maximal 60 Tage sollten es laut Gesetz sein. Der langjährige Trend zeigt klar nach oben. Nur in 6 Prozent der Fälle wurde vom BAG die gesetzliche Frist von 60 Tagen eingehalten. Darunter leiden die Patientinnen und Patienten, denn viele von ihnen können nicht so lange warten. Für ein qualitativ hochstehendes Gesundheitswesen, das allen Patientinnen und Patienten offenstehen soll, ist das inakzeptabel. Ein Vergleich mit Deutschland zeigt den dringenden Nachholbedarf der Schweiz auf. In Deutschland sind rund 90 Prozent der neuen innovativen Medikamente, welche in der EMA in den Jahren 2020 bis 2023 zugelassen wurden, standardmässig verfügbar. In der Schweiz sind es mit 47 Prozent gerade einmal halb so viele wie in Deutschland. Jede zweite innovative Behandlungsmöglichkeit bleibt hierzulande unzugänglich – nicht aus medizinischen, sondern aus administrativen Gründen. Deutschland muss hier Benchmark sein.

---

— Ende Teil 1 von 7 · Kontrollwort Teil 1: CHASSERAL-92 · weiter mit teil-02.md —
