# LAV-T02 · Volltext · Teil 5 von 7 (PDF-Seiten 15–18 von 27)

Studie: Gesundheitsmonitor 2025 – Das Wichtigste in Kürze (gfs.bern im Auftrag von Interpharma) · Quelldatei: gesundheitsmonitor-2025.pdf · Transkript-Version 1.0 · 2026-10-14
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 7 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T02, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 15/27 · Druckseiten 26–27]]

Mit Blick auf die Verantwortung favorisiert die Stimmbevölkerung weiterhin eine gemeinschaftlich getragene Verantwortung gegenüber der Eigenverantwortung. Dennoch ist eine Verschiebung zu mehr Eigenverantwortung erkennbar. Wenn sich Leistungsmenge und Kosten gegenüberstehen, bleibt die Tendenz bestehen, der Menge den Vorrang zu geben. Allerdings gewinnt auch hier die Kostenorientierung an Bedeutung. Ähnliche Verschiebungen zeigen sich beim Zugang zu Medikamenten: Dieser soll nach wie vor breit gewährleistet sein, doch nimmt das Kostenbewusstsein auch in diesem Bereich zu.

Auch bei der Abwägung von Qualität und Kosten wird die Qualität weiterhin klar bevorzugt, jedoch mit zunehmender Offenheit für kostensensible Überlegungen. Die freie Arztwahl bleibt ein verbreiteter Wunsch, doch auch hier zeigen sich Anzeichen einer gewissen Akzeptanz von Einschränkungen.

Schweizweit nimmt die Sensibilität für Kostenaspekte im Gesundheitswesen zu. Bei mehreren Wertepolaritäten zeigt sich eine wachsende Offenheit für kostenorientierte Lösungen. Die Bereitschaft, gewisse Einschränkungen zugunsten der Kostenkontrolle in Kauf zu nehmen, steigt.

In der Romandie zeigt sich eine Annäherung an die Präferenzen der Gesamtbevölkerung. Während sich die Stimmberechtigten in der französischsprachigen Schweiz in früheren Jahren tendenziell ein stärker marktwirtschaftlich geprägtes Gesundheitswesen wünschten, ist nun eine Tendenz zu mehr staatlicher Steuerung erkennbar.

Hinsichtlich der Verantwortung bevorzugen die Befragten ein Modell, das sowohl gemeinschaftliche als auch individuelle Verantwortung berücksichtigt. Auch beim Leistungskatalog zeigt sich eine vermittelnde Haltung: Die Stimmberechtigten in der Romandie sprechen sich tendenziell für ein System aus, das ein ausgewogenes Verhältnis zwischen umfassender Leistungsabdeckung und einer Beschränkung auf hohe Risiken findet. In der Frage der Zuständigkeit zwischen Kantonen und Bund zeichnet sich ebenfalls ein ausgeglicheneres Bild ab.

[Symbol: Personengruppe – markiert den Hinweis auf Unterschiede zwischen Bevölkerungsgruppen]

**[Grafik 12] Wunschvorstellung Gesundheitswesen in der Schweiz, Romandie**

Frage: «Bitte sagen Sie mir, was für ein Gesundheitswesen in der Schweiz Sie sich wünschen. Wenn Sie mit dem ersten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 1 oder nahe bei 1. Wenn Sie mit dem zweiten Teil der Vorgabe übereinstimmen, wählen Sie die Zahl 6 oder eine Zahl nahe bei 6.»

Darstellung: Liniendiagramm, 2016–2025, Mittelwerte Stimmberechtigte der Romandie auf der Skala 1–6. Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 0.1).

| Wertepolarität | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 (beschriftet) |
|---|---|---|---|---|---|---|---|---|---|---|
| Markt (vs. Staat) | 3.1 | 3.5 | 2.8 | 3.4 | 3.3 | 3.2 | 3.5 | 3.2 | 3.5 | 3.7 |
| Gemeinschaftsverantwortung (vs. Eigenverantwortung) | 3.5 | 3.3 | 3.6 | 3.9 | 3.7 | 3.4 | 3.6 | 3.2 | 3.3 | 3.6 |
| Risiko (vs. sämtliche Leistungen) | 3.8 | 3.7 | 4.7 | 4.1 | 4.0 | 3.4 | 3.5 | 3.4 | 3.4 | 3.5 |
| Kantone (vs. Bund) | 2.9 | 3.2 | 3.4 | 3.5 | 3.3 | 3.1 | 3.4 | 3.2 | 3.3 | 3.5 |
| Quantität Leistungen (vs. Kosten) | 2.5 | 3.0 | 2.9 | 2.9 | 3.2 | 3.0 | 2.9 | 3.0 | 3.0 | 3.1 |
| Zugang zu Medikamenten (vs. Kosten) | – | – | – | 2.4 | 3.0 | 3.2 | 2.7 | 3.0 | 3.3 | 3.0 |
| Qualität Leistungen (vs. Kosten) | 2.1 | 2.9 | 1.9 | 2.5 | 3.0 | 3.1 | 2.8 | 2.6 | 3.0 | 2.9 |
| Freie Arztwahl (vs. vorgegebene Arztwahl) | 2.3 | 3.0 | 1.9 | 2.3 | 2.8 | 3.1 | 2.7 | 2.7 | 2.9 | 2.7 |

Lesehilfe: Bei jeder Wertepolarität war es möglich, sich zwischen dem einen und dem anderen Pol auf einer ganzzahligen Skala von 1 bis 6 zu positionieren. Werte von 3.5 bedeuten, dass die Stimmberechtigten im Durchschnitt genau zwischen den Polen stehen. Je grösser die Abweichung davon auf die eine oder andere Seite ist, desto klarer neigen die Befragten dem entsprechenden Werte-Pol zu.

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 290)

**[Ende Grafik 12]**

[[Seite 16/27 · Druckseiten 28–29]]

Die Gewichtung der Leistungsmenge gegenüber den Kosten bleibt relativ stabil zugunsten der Menge. Auch die Qualität bewerten die Befragten weiterhin höher als die Kosten. Zudem gewinnt die freie Arztwahl im Meinungsbild der französischsprachigen Bevölkerung wieder leicht an Bedeutung.

Das Kostenbewusstsein in der Romandie liegt auf einem ähnlichen Niveau wie im gesamtschweizerischen Durchschnitt. Frühere Unterschiede nehmen tendenziell ab. Insgesamt zeigen sich über die Sprachregionen hinweg Annäherungen in den Vorstellungen zur Ausgestaltung des Gesundheitswesens.

Die seit Jahrzehnten ansteigenden Gesundheitskosten stellen sowohl für die Politik als auch für die Bevölkerung eine zentrale Herausforderung dar, weshalb Reformen erforderlich sind. Vor diesem Hintergrund ist es von Bedeutung, zu wissen, welche Ausgestaltungen des Gesundheitssystems in der Bevölkerung mehrheitsfähig sind. Ebenso ist ein vertieftes Verständnis darüber notwendig, welche Ursachen die Stimmberechtigten für den Kostenanstieg erkennen und welche Massnahmen zur Kostensenkung sie sich vorstellen können.

Als wichtigsten Grund für steigende Gesundheitskosten nennt die Stimmbevölkerung die Alterung der Bevölkerung. 93 Prozent der Befragten stufen sie als bedeutenden Treiber der Kosten ein. Ebenfalls zentral werden Behandlungen von chronischen Krankheiten bewertet, die gemäss 90 Prozent der Befragten zur Erhöhung der Kosten im Gesundheitswesen beitragen. Auch medizinische Fortschritte, die neue und kostenintensive Behandlungsmöglichkeiten mit sich bringen (87%) sowie komplexe administrative Abläufe (87%), werden als relevante Faktoren genannt.

[Symbol: Personengruppe – markiert den Hinweis auf Unterschiede zwischen Bevölkerungsgruppen]

**[Grafik 13] Wichtigkeit Gründe für den Gesundheitskostenanstieg**

Frage: «Die Kosten des Gesundheitswesens sind in den vergangenen Jahrzehnten angestiegen. Wie wichtig sind die folgenden Gründe Ihrer Meinung nach für den Kostenanstieg?»

Darstellung: gestapelte horizontale Balken (100 %), in % Stimmberechtigte, 2025; alle Werte beschriftet.

| Grund | Sehr wichtig | Eher wichtig | Weiss nicht / keine Antwort | Eher nicht wichtig | Überhaupt nicht wichtig |
|---|---|---|---|---|---|
| Die Alterung der Bevölkerung lässt die Kosten im Gesundheitswesen steigen. | 37 | 56 | 1 | 5 | 1 |
| Chronische Krankheiten nehmen zu und verursachen langfristig hohe Behandlungskosten. | 31 | 59 | 1 | 7 | 2 |
| Fortschritte in der Medizin bringen teure Behandlungen mit sich. | 25 | 62 | 3 | 8 | 2 |
| Komplexe administrative Abläufe erhöhen die Betriebskosten im Gesundheitswesen. | 43 | 44 | 6 | 5 | 2 |
| Die Kosten im Gesundheitswesen steigen, weil einzelne Gruppen für sich finanzielle Vorteile daraus ziehen. | 33 | 45 | 13 | 7 | 2 |
| Durch die Zuwanderung erhöht sich die Nachfrage nach medizinischen Leistungen und treibt dadurch die Gesundheitskosten in die Höhe. | 31 | 46 | 5 | 13 | 5 |
| Bessere Diagnosetechniken und ein höheres Gesundheitsbewusstsein führen dazu, dass mehr Menschen ärztliche Leistungen in Anspruch nehmen. | 19 | 55 | 6 | 17 | 3 |
| Gut ausgebildetes Fachpersonal wird besser bezahlt, was die Lohnkosten antreibt. | 17 | 49 | 7 | 23 | 4 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 13]**

[[Seite 17/27 · Druckseiten 30–31]]

Rund drei Viertel sehen wirtschaftliche Interessen einzelner Gruppen (78%), die Zuwanderung (77%) und häufigere Konsultationen infolge besserer Diagnosetechniken (74%) als mitverantwortlich für die Kostenentwicklung.

Etwas differenzierter beurteilt die Bevölkerung den Einfluss steigender Löhne im Gesundheitsbereich. 66 Prozent stufen dies als wichtigen Grund ein, während rund ein Viertel diesen Zusammenhang eher nicht oder gar nicht unterstützt (27%).

Die Bevölkerung nimmt den Anstieg der Gesundheitskosten nicht als Folge einzelner isolierter Faktoren wahr, sondern als Ergebnis eines vielschichtigen Zusammenspiels struktureller, medizinischer und gesellschaftlicher Entwicklungen.

Um dem Anstieg der Gesundheitskosten entgegenzuwirken, kommen verschiedene Massnahmen in Betracht. Das zunehmende Kostenbewusstsein zeigt sich auch in der Bereitschaft der Bevölkerung, gewisse Einschränkungen zur Entlastung des Systems zu akzeptieren.

Die grösste Zustimmung findet der Verzicht auf die freie Spitalwahl. 49 Prozent der Stimmberechtigten können sich diese Massnahme vorstellen, sofern damit eine Kostenreduktion erreicht wird. Etwas geringere Unterstützung erhalten Massnahmen wie die Einschränkung der freien Arztwahl (43%), ein eingeschränkter Zugang zu neuen Medikamenten oder neuen Behandlungsformen (41%), die Einschränkung der Verschreibungsfreiheit (37%) sowie eine Reduktion des Leistungskatalogs (36%). Auch wenn die Zustimmungswerte in diesen Bereichen tiefer liegen, lässt sich in allen hier erwähnten Fällen eine tendenzielle Zunahme der Akzeptanz feststellen.

[Symbol: Personengruppe – markiert den Hinweis auf Unterschiede zwischen Bevölkerungsgruppen]

**[Grafik 14] Haltung Massnahmen zur Kostensenkung**

Frage: «Welche der folgenden Massnahmen wären Sie selber bereit, für sich in Kauf zu nehmen, wenn dadurch die Kosten im Gesundheitswesen sinken würden?»

Darstellung: Liniendiagramm, 2016–2025, in % Stimmberechtigte, Anteil «auf jeden Fall» und «je nach Höhe Kostensenkung». Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 1 Prozentpunkt). Die Werte 2016–2024 stimmen mit der entsprechenden Grafik im Gesundheitsmonitor 2024 überein.

| Massnahme | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 (beschriftet) |
|---|---|---|---|---|---|---|---|---|---|---|
| Keine freie Spitalwahl | 67 | 66 | 54 | 58 | 41 | 54 | 37 | 39 | 37 | 49 |
| Keine freie Arztwahl | 59 | 51 | 37 | 27 | 25 | 33 | 22 | 30 | 31 | 43 |
| Eingeschränkter Zugang zu neuen modernen Medikamenten oder zu neuen Behandlungsformen | 36 | 43 | 19 | 38 | 25 | 26 | 27 | 23 | 33 | 41 |
| Keine Verschreibungsfreiheit | 52 | 60 | 54 | 47 | 33 | 32 | 28 | 27 | 30 | 37 |
| Kürzung des Leistungskatalogs in der Grundversicherung | 50 | 54 | 31 | 26 | 20 | 24 | 19 | 19 | 23 | 36 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 14]**

[[Seite 18/27 · Druckseiten 32–33]]

In der Romandie zeigt sich weiterhin eine deutlich höhere Bereitschaft, persönliche Einschränkungen zur Senkung der Gesundheitskosten in Kauf zu nehmen. Besonders gross ist die Akzeptanz für eine Abschaffung der freien Spitalwahl (80%).

Auch andere Massnahmen stossen auf breite Zustimmung: Keine freie Arztwahl (65%), eingeschränkter Zugang zu neuen Medikamenten oder Behandlungsformen (59%), keine Verschreibungsfreiheit (56%) und selbst die Kürzung des Leistungskatalogs (47%) werden von einem substanziellen Anteil der Befragten zumindest unter bestimmten Bedingungen befürwortet.

Personen aus der Romandie zeigen sich weiterhin kompromissbereiter als Personen aus den übrigen Regionen der Schweiz. Im Vergleich zu den Vorjahren ist jedoch ein Rückgang dieser Kompromissbereitschaft – mit Ausnahme bei der freien Spitalwahl – erkennbar.

In der öffentlichen Wahrnehmung zeigt sich eine Verschiebung hinsichtlich der Verantwortung für kostendämpfende Massnahmen im Gesundheitswesen. Erstmals wird der Bund von einer relativen Mehrheit der Stimmberechtigten (38%) als vorrangig verantwortlicher Akteur genannt. An zweiter Stelle folgen die Krankenkassen (29%), noch vor der Pharmaindustrie (22%), wobei beiden Akteuren im Vergleich zum Vorjahr weniger Verantwortung zugeschrieben wird.

Rund ein Fünftel der Befragten (19%) sieht die Verantwortung bei den Kantonen. Die Erwartungshaltung gegenüber den Patientinnen und Patienten (19%), den Ärztinnen und Ärzten (15%) und den Spitälern (15%) ist rückläufig. Den kollektiven Ansatz, wonach alle Akteursgruppen gemeinsam zur Kostendämpfung beitragen sollen, unterstützen 20 Prozent der Befragten.

Es zeigt sich ein wachsendes Bedürfnis nach klarer Zuständigkeit. Die Bevölkerung bevorzugt eine zentral koordinierte Verantwortung, bei der dem Bund eine führende Rolle zukommt. Wobei weitere systemrelevante Akteure wie Krankenkassen und die Pharmaindustrie ebenfalls Teil der Lösung sein sollen.

**[Grafik 15] Haltung Massnahmen zur Kostensenkung, Romandie**

Frage: wie Grafik 14.

Darstellung: Liniendiagramm, 2016–2025, in % Stimmberechtigte der Romandie, Anteil «auf jeden Fall» und «je nach Höhe Kostensenkung». Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 1 Prozentpunkt).

| Massnahme | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 (beschriftet) |
|---|---|---|---|---|---|---|---|---|---|---|
| Keine freie Spitalwahl | 61 | 75 | 71 | 79 | 74 | 82 | 65 | 88 | 75 | 80 |
| Keine freie Arztwahl | 47 | 62 | 44 | 49 | 57 | 67 | 54 | 72 | 74 | 65 |
| Eingeschränkter Zugang zu neuen modernen Medikamenten oder zu neuen Behandlungsformen | 36 | 53 | 12 | 48 | 42 | 22 | 53 | 62 | 66 | 59 |
| Keine Verschreibungsfreiheit | 46 | 61 | 64 | 59 | 59 | 59 | 56 | 68 | 72 | 56 |
| Kürzung des Leistungskatalogs in der Grundversicherung | 45 | 55 | 36 | 35 | 51 | 61 | 60 | 64 | 66 | 47 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 300)

**[Ende Grafik 15]**

**[Grafik 16] Verantwortung für Kostendämpfung**

Frage: «Wir haben hier die Liste mit Akteuren im Gesundheitswesen. Wer sollte Ihrer Meinung nach an erster Stelle stehen, wenn es um die Verantwortung für die Kostendämpfung im Gesundheitswesen geht?»

Darstellung: Liniendiagramm, 2016–2025, in % Stimmberechtigte, 1. und 2. Stelle summiert. Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 1 Prozentpunkt).

| Akteur | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 (beschriftet) |
|---|---|---|---|---|---|---|---|---|---|---|
| Bund | 39 | 34 | 19 | 30 | 17 | 15 | 21 | 18 | 26 | 38 |
| Krankenkassen | 33 | 34 | 39 | 31 | 36 | 35 | 31 | 27 | 35 | 29 |
| Pharmaindustrie | 24 | 27 | 30 | 27 | 30 | 29 | 26 | 27 | 31 | 22 |
| Alle miteinander | 11 | 14 | 19 | 15 | 14 | 17 | 16 | 19 | 14 | 20 |
| Kantone | 32 | 24 | 22 | 26 | 11 | 11 | 16 | 13 | 16 | 19 |
| Patientinnen und Patienten | 20 | 24 | 17 | 23 | 18 | 25 | 25 | 26 | 22 | 19 |
| Ärztinnen und Ärzte | 21 | 19 | 17 | 23 | 33 | 30 | 30 | 35 | 26 | 15 |
| Spitäler | 13 | 20 | 29 | 17 | 34 | 31 | 27 | 33 | 24 | 15 |
| Andere | 3 | 2 | 0 | 2 | 5 | 3 | 6 | 0 | 0 | 1 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’200)

**[Ende Grafik 16]**

---

— Ende Teil 5 von 7 · Kontrollwort Teil 5: BERGDOHLE-87 · weiter mit teil-06.md —
