# LAV-T02 · Volltext · Teil 3 von 7 (PDF-Seiten 9–11 von 27)

Studie: Gesundheitsmonitor 2025 – Das Wichtigste in Kürze (gfs.bern im Auftrag von Interpharma) · Quelldatei: gesundheitsmonitor-2025.pdf · Transkript-Version 1.0 · 2026-10-14
Lesehinweis: Die Studie ist nur vollständig gelesen, wenn alle 7 Teile bis zum Ende gelesen sind.
Konventionen: [[Seite n/N]] = Beginn der PDF-Seite n (zitieren als [LAV-T02, S. n]) · Grafikwerte mit Status (beschriftet, berechnet, abgelesen ca., nicht eindeutig ablesbar) · [Fussnote n] · [Bild: …] · [unleserlich]

---

[[Seite 9/27 · Druckseiten 14–15]]

Ein Aspekt, der im Zusammenhang mit dem KVG seit jeher zu Diskussionen führt, sind die Krankenkassenprämien. Die Schweizer Stimmberechtigten empfinden den Anstieg der Krankenkassenprämien mehrheitlich als nicht verhältnismässig. Schweizweit gesehen stufen drei Viertel der Befragten den Prämienanstieg als überhöht ein (75%, Skalenwerte 4 bis 6). In der Deutschschweiz fällt die Bewertung etwas differenzierter aus. Hier zeigt sich eine leicht grössere Bereitschaft, den Anstieg der Prämien als nachvollziehbar zu akzeptieren. In der Romandie und der Svizzera italiana hingegen überwiegt eine deutlich kritischere Haltung.

Diese Einschätzung verdeutlicht eine breite Unzufriedenheit mit der Prämienentwicklung. Der Prämienanstieg wird vielfach als nicht im Einklang mit den tatsächlichen Kostensteigerungen wahrgenommen.

Die Unzufriedenheit mit der Höhe der Krankenkassenprämie spiegelt sich auch in der Bewertung der finanziellen Belastung im Alltag wider: Knapp ein Drittel bekundet Mühe, die Krankenkassenprämien zu bezahlen (30%). Die Begleichung von Zahnarztrechnungen (26%) und Steuern (26%) stellt für rund ein Viertel ein gelegentliches oder dauerhaftes Problem dar. Weniger stark ins Gewicht fallen Arztrechnungen und Ausgaben für Medikamente (20%), sonstige Versicherungen (15%) und die Miete für die Wohnung resp. die Zinsen für das Wohneigentum (18%).

[Symbol: Personengruppe – markiert den Hinweis auf Unterschiede zwischen Bevölkerungsgruppen]

**[Grafik 2] Verhältnismässigkeit Prämienanstieg nach Sprache**

Frage: «Seit der Einführung des Krankenversicherungsgesetzes (KVG) im Jahr 1996 sind die Prämien der Grundversicherung in der Schweiz stetig gestiegen. Dieser Anstieg wird unterschiedlich wahrgenommen. Es folgen zwei Aussagen zum Prämienanstieg. Wenn Sie mit Aussage A übereinstimmen, wählen Sie die Zahl 1 oder eine Zahl nahe bei 1. Wenn Sie mit Aussage B übereinstimmen, wählen Sie die Zahl 6 oder eine Zahl nahe bei 6. Mit den Werten dazwischen können Sie Ihre Meinung abstufen. Der Prämienanstieg ist … A) nachvollziehbar, da er den steigenden Kosten im Gesundheitswesen entspricht oder B) überhöht und steht nicht im Verhältnis zu den tatsächlichen Kostensteigerungen.»

Darstellung: gestapelte Säulen (100 %) nach Sprachregion, in % Stimmberechtigte, 2025; alle Werte beschriftet (kleine Segmente neben der Säule). DCH = Deutschschweiz, FCH = französischsprachige Schweiz, ICH = italienischsprachige Schweiz.

| Skalenwert | DCH | FCH | ICH |
|---|---|---|---|
| 1 A) nachvollziehbar | 8 | 1 | – |
| 2 | 7 | 3 | 1 |
| 3 | 12 | 15 | 3 |
| 4 | 24 | 40 | 20 |
| 5 | 26 | 18 | 47 |
| 6 B) überhöht | 22 | 21 | 27 |
| Weiss nicht / keine Antwort | 1 | 2 | 2 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 (N = 1’209), sig., Cramér’s V = 0.22

**[Ende Grafik 2]**

**[Grafik 3] Dauerhaftes oder gelegentliches Problem**

Frage: «Können Sie für jeden der folgenden Ausgabenbereiche Ihres Haushalts angeben, inwiefern er für Sie ein Problem darstellt?»

Darstellung: identisch mit der Grafik auf Druckseite 6 (Vorwort): Liniendiagramm, gleitender Mittelwert über 3 Jahre, 1998–2025, Anteil «dauerhaftes/gelegentliches Problem» in % Stimmberechtigte. Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 1 Prozentpunkt). [Hinweis Transkription: Der Text nennt für die Miete 18 %, die Grafik zeigt für 2025 den Wert 13.]

| Jahr | Krankenkassenprämien | Steuern | Zahnarztrechnungen | Arztrechnungen, Ausgaben für Medikamente | Sonstige Versicherungen | Miete für die Wohnung oder für Wohneigentum |
|---|---|---|---|---|---|---|
| 1998 | 33 | 37 | – | 24 | 23 | 16 |
| 1999 | 33 | 37 | – | 25 | 24 | 17 |
| 2000 | 33 | 36 | – | 23 | 23 | 15 |
| 2001 | 35 | 38 | – | 24 | 24 | 15 |
| 2002 | 38 | 36 | – | 21 | 22 | 13 |
| 2003 | 44 | 40 | 36 | 24 | 25 | 17 |
| 2004 | 48 | 41 | 37 | 25 | 25 | 17 |
| 2005 | 48 | 44 | 39 | 30 | 27 | 19 |
| 2006 | 48 | 44 | 41 | 31 | 27 | 18 |
| 2007 | 45 | 42 | 40 | 29 | 27 | 19 |
| 2008 | 46 | 44 | 38 | 28 | 29 | 22 |
| 2009 | 47 | 44 | 40 | 26 | 28 | 24 |
| 2010 | 50 | 40 | 37 | 24 | 26 | 23 |
| 2011 | 52 | 34 | 34 | 22 | 25 | 21 |
| 2012 | 50 | 32 | 32 | 22 | 23 | 20 |
| 2013 | 47 | 40 | 41 | 26 | 24 | 24 |
| 2014 | 43 | 45 | 42 | 28 | 21 | 24 |
| 2015 | 41 | 48 | 42 | 29 | 22 | 24 |
| 2016 | 40 | 46 | 38 | 31 | 23 | 24 |
| 2017 | 38 | 43 | 38 | 30 | 22 | 26 |
| 2018 | 30 | 33 | 36 | 25 | 17 | 21 |
| 2019 | 28 | 27 | 30 | 19 | 10 | 16 |
| 2020 | 23 | 20 | 26 | 15 | 9 | 11 |
| 2021 | 28 | 23 | 23 | 16 | 10 | 14 |
| 2022 | 22 | 22 | 22 | 15 | 10 | 13 |
| 2023 | 26 | 24 | 23 | 18 | 11 | 13 |
| 2024 | 24 | 24 | 23 | 21 | 14 | 13 |
| 2025 (beschriftet) | 30 | 26 | 26 | 20 | 15 | 13 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 1’180)

**[Ende Grafik 3]**

[[Seite 10/27 · Druckseiten 16–17]]

Langfristig betrachtet bleibt die wahrgenommene Kostenbelastung in der deutsch- und italienischsprachigen Schweiz unterdurchschnittlich, wobei in der Deutschschweiz eine leichte Zunahme im Vergleich zum Vorjahr zu beobachten ist. Der Problemdruck rund um Zahnarztrechnungen (18%, +6 Prozentpunkte), Krankenkassenprämien (17%, +7 Prozentpunkte) und Steuern (15%, +5 Prozentpunkte) nimmt am stärksten zu.

In der Romandie ist die Wahrnehmung finanzieller Probleme in sämtlichen Ausgabenbereichen deutlich ausgeprägter als in den übrigen Sprachregionen. Dennoch zeigt sich in fast allen Bereichen – mit Ausnahme der Krankenkassenprämien – ein rückläufiger Trend.

Bezüglich der Krankenkassenprämien geben rund zwei Drittel der Befragten an, gelegentlich oder dauerhaft Schwierigkeiten bei der Begleichung der Rechnungen zu haben (69%). Damit erreicht dieser Wert erneut ein Niveau, das zuletzt um das Jahr 2011 beobachtet wurde. Trotz zwischenzeitlicher Entspannung blieb die Bezahlung der Krankenkassenprämien ein zentrales Thema im öffentlichen Diskurs.

**[Grafik 4] Dauerhaftes oder gelegentliches Problem, Deutschschweiz**

Frage: «Können Sie für jeden der folgenden Ausgabenbereiche Ihres Haushalts angeben, inwiefern er für Sie ein Problem darstellt?»

Darstellung: Liniendiagramm, gleitender Mittelwert über 3 Jahre, 1998–2025, Anteil «dauerhaftes/gelegentliches Problem» in % Stimmberechtigte der Deutschschweiz. Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 1 Prozentpunkt).

| Jahr | Zahnarztrechnungen | Krankenkassenprämien | Steuern | Sonstige Versicherungen | Arztrechnungen, Ausgaben für Medikamente | Miete für die Wohnung oder für Wohneigentum |
|---|---|---|---|---|---|---|
| 1998 | – | 28 | 32 | 19 | 12 | 18 |
| 1999 | – | 28 | 32 | 20 | 13 | 19 |
| 2000 | – | 27 | 30 | 18 | 11 | 17 |
| 2001 | – | 29 | 33 | 19 | 13 | 19 |
| 2002 | – | 33 | 31 | 16 | 11 | 17 |
| 2003 | 31 | 39 | 34 | 18 | 14 | 20 |
| 2004 | 30 | 43 | 34 | 19 | 13 | 18 |
| 2005 | 33 | 40 | 35 | 22 | 13 | 18 |
| 2006 | 34 | 42 | 37 | 23 | 13 | 18 |
| 2007 | 34 | 38 | 34 | 21 | 13 | 18 |
| 2008 | 32 | 40 | 37 | 19 | 16 | 21 |
| 2009 | 34 | 40 | 35 | 17 | 17 | 20 |
| 2010 | 31 | 44 | 31 | 15 | 16 | 18 |
| 2011 | 28 | 48 | 26 | 14 | 15 | 16 |
| 2012 | 26 | 47 | 25 | 14 | 15 | 16 |
| 2013 | 36 | 44 | 35 | 20 | 19 | 20 |
| 2014 | 38 | 39 | 41 | 22 | 18 | 18 |
| 2015 | 39 | 38 | 45 | 22 | 18 | 18 |
| 2016 | 34 | 37 | 43 | 24 | 19 | 19 |
| 2017 | 35 | 36 | 40 | 24 | 22 | 19 |
| 2018 | 33 | 27 | 30 | 21 | 17 | 15 |
| 2019 | 27 | 26 | 24 | 15 | 13 | 8 |
| 2020 | 21 | 19 | 16 | 11 | 6 | 5 |
| 2021 | 17 | 21 | 15 | 10 | 6 | 4 |
| 2022 | 13 | 12 | 11 | 6 | 2 | 2 |
| 2023 | 13 | 12 | 12 | 6 | 2 | 2 |
| 2024 | 12 | 10 | 10 | 8 | 3 | 2 |
| 2025 (beschriftet) | 18 | 17 | 15 | 9 | 7 | 6 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 710)

**[Ende Grafik 4]**

**[Grafik 5] Dauerhaftes oder gelegentliches Problem, Romandie**

Frage: wie Grafik 4.

Darstellung: Liniendiagramm, gleitender Mittelwert über 3 Jahre, 1998–2025, Anteil «dauerhaftes/gelegentliches Problem» in % Stimmberechtigte der Romandie. Beschriftet sind die Werte 2025; übrige Jahre aus der Vektorgrafik berechnet (± 1 Prozentpunkt). Die Werte bis 2024 stimmen mit der Romandie-Grafik im Gesundheitsmonitor 2024 überein.

| Jahr | Krankenkassenprämien | Steuern | Arztrechnungen, Ausgaben für Medikamente | Zahnarztrechnungen | Sonstige Versicherungen | Miete für die Wohnung oder für Wohneigentum |
|---|---|---|---|---|---|---|
| 1998 | 45 | 49 | 38 | – | 36 | 28 |
| 1999 | 47 | 53 | 41 | – | 38 | 29 |
| 2000 | 50 | 54 | 42 | – | 39 | 26 |
| 2001 | 52 | 56 | 44 | – | 41 | 23 |
| 2002 | 50 | 53 | 41 | – | 39 | 19 |
| 2003 | 57 | 58 | 43 | 54 | 41 | 26 |
| 2004 | 63 | 63 | 45 | 57 | 46 | 30 |
| 2005 | 73 | 71 | 54 | 58 | 55 | 38 |
| 2006 | 69 | 68 | 53 | 60 | 55 | 36 |
| 2007 | 71 | 68 | 56 | 63 | 58 | 42 |
| 2008 | 67 | 67 | 55 | 61 | 56 | 44 |
| 2009 | 72 | 70 | 55 | 61 | 58 | 50 |
| 2010 | 71 | 65 | 51 | 56 | 56 | 47 |
| 2011 | 71 | 61 | 49 | 55 | 56 | 43 |
| 2012 | 65 | 54 | 49 | 54 | 50 | 38 |
| 2013 | 58 | 55 | 47 | 55 | 42 | 38 |
| 2014 | 53 | 54 | 46 | 53 | 35 | 38 |
| 2015 | 49 | 54 | 45 | 49 | 33 | 37 |
| 2016 | 45 | 53 | 49 | 48 | 32 | 35 |
| 2017 | 43 | 50 | 48 | 48 | 29 | 33 |
| 2018 | 39 | 44 | 38 | 47 | 24 | 31 |
| 2019 | 36 | 35 | 29 | 42 | 17 | 23 |
| 2020 | 31 | 31 | 25 | 41 | 20 | 22 |
| 2021 | 45 | 47 | 35 | 40 | 25 | 34 |
| 2022 | 49 | 55 | 43 | 46 | 32 | 42 |
| 2023 | 64 | 61 | 56 | 52 | 39 | 47 |
| 2024 | 65 | 63 | 60 | 57 | 50 | 45 |
| 2025 (beschriftet) | 69 | 60 | 53 | 52 | 46 | 37 |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 · * Datenerhebung: bis 2024 Face-to-Face, ab 2025 Mixed Mode: Face-to-Face und Online-Panel (N = jeweils ca. 300)

**[Ende Grafik 5]**

[[Seite 11/27 · Druckseiten 18–19]]

Doch wen sieht die Stimmbevölkerung in der Verantwortung für den Prämienanstieg? Die Stimmberechtigten sehen die Ursachen für den Anstieg der Krankenkassenprämien breit gestreut, mit deutlicher Fokussierung auf Personen, die medizinische Leistungen in Anspruch nehmen, obwohl sie nicht krank sind (31%). Es folgen die Verwaltungskosten im ganzen Gesundheitswesen (26%). Weitere häufig genannte Ursachen sind die steigende Anzahl älterer Menschen (21%), die Krankenkassen selbst (17%), unnötige Abklärungen (15%) sowie die Pharmaindustrie (14%). Auch strukturelle Schwächen wie fehlende Effizienz (13%) und die steigende Erwartungshaltung gegenüber der Gesundheitsversorgung (11%) nimmt die Bevölkerung als relevante Kostentreiber wahr.

Die Befragten sehen die Hauptursachen für steigende Prämien eher im System selbst, beispielsweise durch Übernutzung, organisatorische Ineffizienzen und bei den Verwaltungskosten als bei einzelnen Berufsgruppen.

Um das Krankenversicherungssystem zu verbessern, stehen verschiedene Forderungen im Raum. Gleichzeitig zeigt sich die Bevölkerung mit dem bestehenden Prämiensystem, das aus Kopfprämien und individueller Prämienverbilligung besteht, nach wie vor sehr zufrieden (84%). Die höchste Reformbereitschaft zeigt sich bei der Einführung einer Gebühr für Bagatellfälle in der Spitalnotfallaufnahme (86%). Knapp dahinter folgen der Vorschlag, dass Medikamente für Bagatellen nicht mehr von der Krankenkasse bezahlt werden sollen (81%), und der vollumfängliche Abzug der Prämien vom steuerbaren Einkommen (81%). Die Einführung von automatischen Massnahmen zur Kostenbegrenzung (67%), die Gestaltung von einkommensabhängigen Prämien (56%) und Kostenübernahmen für medizinische Behandlungen im Ausland (56%) finden ebenfalls bei einer klaren Mehrheit Zuspruch. Die Hälfte spricht sich für eine Budget-Krankenkasse, die den Bezug von Generika, die Wahl einer höheren Franchise und das elektronische Patientendossier (EPD) voraussetzt, aus (50%). Sowohl eine staatliche Krankenkasse (48%) als auch die Erhöhung der Maximal- (41%) und der Minimalfranchise (35%) unterstützen weniger als die Hälfte. Die Idee, nur noch Versicherungsmodelle anzubieten, die eine Erstanlaufstelle vorsehen, stösst lediglich bei rund einem Viertel auf Interesse (27%).

[Symbol: Personengruppe – markiert den Hinweis auf Unterschiede zwischen Bevölkerungsgruppen]

**[Grafik 6] Verursacher für die Steigerung der Krankenkassenprämien**

Frage: «Ich gebe Ihnen hier eine Liste mit verschiedenen Verursachern für die Steigerung bei den Krankenkassenprämien. Welcher ist für Sie der hauptsächliche Grund, was der zweite Grund?»

Darstellung: gestapelte horizontale Balken, in % Stimmberechtigte, 1. und 2. Nennung, 2025; alle Werte beschriftet. [Hinweis Transkription: Die Antwortliste unterscheidet sich von der Ausgabe 2024 (u. a. neu «Menschen, die zum Arzt gehen, obwohl sie nicht krank sind»; 2024 «Simulantinnen und Simulanten»).]

| Verursacher | 1. Nennung | 2. Nennung |
|---|---|---|
| Menschen, die zum Arzt gehen, obwohl sie nicht krank sind | 18 | 13 |
| Verwaltungskosten im ganzen Gesundheitswesen | 14 | 12 |
| Die steigende Anzahl von alten Menschen | 11 | 10 |
| Krankenkassen selbst | 6 | 11 |
| Unnötige Abklärungen | 6 | 9 |
| Pharmaindustrie | 8 | 6 |
| Fehlende Effizienz im Gesundheitswesen | 7 | 6 |
| Steigende Erwartungen an die Qualität der Gesundheitsversorgung | 8 | 3 |
| Leistungserweiterung in der Grundversicherung | 5 | 3 |
| Spitäler im Allgemeinen | 3 | 4 |
| Süchtige | 3 | 4 |
| Teure medizinische Instrumente | 2 | 3 |
| Ausbau der Pflege | 2 | 3 |
| Spitex-Organisationen | 2 | 2 |
| Ärztinnen und Ärzte | 1 | 3 |
| Medizinische Forschung | 1 | 2 |
| Apotheken | 1 | 1 |
| Weiss nicht/keine Antwort | 3 | – |

Quelle: © gfs.bern, Gesundheitsmonitor 2025 (N = 1’209)

**[Ende Grafik 6]**

---

— Ende Teil 3 von 7 · Kontrollwort Teil 3: LAGERN-42 · weiter mit teil-04.md —
