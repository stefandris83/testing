# LAV Learning Library – Katalog

Stand: 2026-10-14 · 1 Studie · Skill-Version 0.1 (Test)
Zweck: Bestimmung der richtigen Studie. Inhalte stehen in den Study Cards und Volltexten.

## LAV-T02 · Gesundheitsmonitor 2025
- Volltitel: Das Wichtigste in Kürze zum Gesundheitsmonitor 2025 – Kostenbewusstsein innerhalb der Bevölkerung nimmt zu
- Typ / Umfang: Bericht (Doppelseiten) · 27 PDF-Seiten
- Volltext: 7 Teile – teil-01 S. 1–4 · teil-02 S. 5–8 · teil-03 S. 9–11 · teil-04 S. 12–14 · teil-05 S. 15–18 · teil-06 S. 19–22 · teil-07 S. 23–27
- Herausgeber / Jahr: gfs.bern im Auftrag von Interpharma · 2025
- Methode / Stichprobe: Repräsentativbefragung Stimmberechtigte, n = 1’209, Mixed Mode
- Themen: Krankenkassenprämien, Kostenbewusstsein, Leistungskatalog, Qualität, Medikamente
- Auch genannt: «Gesundheitsmonitor», «GM 2025»
- Nicht verwechseln mit: LAV-T01 (Gesundheitsmonitor 2024, Vorjahresausgabe)
- Original: gesundheitsmonitor-2025.pdf

— Ende Katalog · Kontrollwort: TOEDI-41 —
