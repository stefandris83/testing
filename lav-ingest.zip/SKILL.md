---
name: lav-ingest
description: Transkribiert eine LAV-Studie (PDF) vollständig, seitengetreu und wörtlich in Markdown-Dateien für die LAV Learning Library und prüft Skill-Pakete vor dem Upload. Verwenden bei «Studie aufnehmen», «transkribieren», «Ingest» oder «Paket prüfen».
---

# LAV Ingest

Du überträgst Studien vollständig, seitengetreu und wörtlich in Dateien. Du kürzt nie, du
paraphrasierst nie, du rätst keine Zahlen. Was du nicht sicher lesen kannst, kennzeichnest du.
Du arbeitest in Dateien in deinem Arbeitsverzeichnis, nie in Chat-Antworten zum Kopieren.

## Einstellungen
- TEILGROESSE = 45000 (Bytes, UTF-8). Gemessen im Plattformtest P2: Stufe c in beiden Durchgängen bestanden.
- ETAPPEN_PRO_ANTWORT = 1 (eine Etappe = höchstens 5 Seiten). Wird nach dem Plattformtest P9 festgelegt.
- ZWISCHENSTAND_ALLE = 20 Seiten (nur bei Studien ab 40 Seiten).
- Skripte: `scripts/inventar.py`, `scripts/pruefen.py`, `scripts/aufteilen.py`, `scripts/paket.py`,
  `scripts/wiki.py`.
  Lässt sich ein Skript nicht direkt aus dem Skill ausführen: Lies `references/skripte.md`, schreibe
  den Codeblock des Skripts unverändert als Datei in dein Arbeitsverzeichnis und führe ihn dort aus.
- PDF-Zugriff: Die Plattform kann den ersten Zugriff auf eine hochgeladene PDF ablehnen, z. B. mit «Denied by preToolUse
  hook: Before working with <pfad>, preprocess it with the analyzing-pdf skill». Dann zuerst diese Vorverarbeitung mit dem
  genannten Skill ausführen und den abgelehnten Befehl danach unverändert wiederholen. Der Pfad der PDF enthält eine
  Kennung (z. B. /app/uploads/<name>-<kennung>.pdf): Pfad nie raten, sondern mit `ls` im Upload-Ordner nachsehen.
- Regeln je Element: `references/transkriptionsregeln.md`. Vorlagen: `references/vorlagen.md`.
- In den Befehlen unten steht `<pdf>` für den Pfad der hochgeladenen PDF und `LAV-NN` für die Studien-ID.

## Ablauf «Studie aufnehmen» (eine Studie pro Gespräch)
Voraussetzung: Die PDF ist hochgeladen; der Nutzer nennt Studien-ID (LAV-NN), Kurztitel und Jahr.
Fehlt etwas davon, frage einmal nach.

1. Lege `arbeit/LAV-NN/` an. Notiere für jeden Schritt Start- und Endzeit (Befehl `date`) in
   `arbeit/LAV-NN/zeiterfassung.csv` (Spalten: schritt;start;ende).

2. Inventar erstellen, dann `inventar.txt` lesen und dem Nutzer melden: Seitenzahl, Seiten ohne
   Textebene, Querformat-Seiten (mögliche Doppelseiten), Seiten mit Grafiken.
   ```
   python inventar.py <pdf> arbeit/LAV-NN
   ```

3. Transkription in Etappen von höchstens 5 Seiten, höchstens ETAPPEN_PRO_ANTWORT Etappen pro Antwort.
   Danach kurz melden (fertige Seiten, offene Befunde, nächste Seite) und auf «weiter» warten. Erlaubt
   der Nutzer ausdrücklich mehr (z. B. «weiter bis Seite 30»), gilt das für diese Antwort.
   Für jede Seite n:
   a. Lies `rohtext/sNNN.txt` (und `rohtext/sNNN-tabellen.md`, falls vorhanden).
   b. Sieh dir `bilder/sNNN.png` an – immer bei Seiten mit Grafiken, Tabellen, Kästen oder mehreren
      Spalten und bei Seiten ohne Textebene.
   c. Schreibe `seiten/sNNN.md` nach den Transkriptionsregeln. Erste Zeile: `[[Seite n/N]]`, bei
      abweichender Druckseite `[[Seite n/N · Druckseite x]]` bzw. `[[Seite n/N · Druckseiten x–y]]`.
   d. Text wörtlich aus der Textebene; Lesereihenfolge und Struktur nach dem Seitenbild.
   e. Jede Grafik als Block `[Grafik] … [Ende Grafik]` mit Wertstatus.
   Nach jeder Etappe prüfen und Befunde der Etappe sofort beheben:
   ```
   python pruefen.py <pdf> arbeit/LAV-NN/seiten --nur-vorhandene --protokoll arbeit/LAV-NN/zwischen.txt
   ```
   Bei Studien ab 40 Seiten nach jeweils ZWISCHENSTAND_ALLE fertigen Seiten ein Zwischen-ZIP
   `LAV-NN_zwischenstand_bis-S-xx.zip` (Ordner `seiten/`, `zeiterfassung.csv`, `befunde-begruendet.txt`,
   `zwischen.txt`) zum Herunterladen anbieten.

4. Schlussprüfung:
   ```
   python pruefen.py <pdf> arbeit/LAV-NN/seiten --protokoll arbeit/LAV-NN/pruefprotokoll.txt
   ```
   Jede gemeldete Seite am Seitenbild prüfen: korrigieren oder begründen, warum es kein Fehler ist
   (z. B. «Grafikbeschriftungen überlappen in der Textebene, Werte im Seitenbild geprüft»).
   Begründungen in `befunde-begruendet.txt` (Seite;Meldung;Begründung). Wiederholen, bis jede
   Meldung behoben oder begründet ist.

5. Aufteilen (schreibt `volltext/`, `kontrollwoerter.csv` und `katalog-zeile.txt`):
   ```
   python aufteilen.py arbeit/LAV-NN/seiten arbeit/LAV-NN/volltext --id LAV-NN --titel "<Volltitel>" --quelle <dateiname.pdf> --max TEILGROESSE
   ```

6. Study Card und Katalog-Eintrag nach `references/vorlagen.md`, ausschliesslich aus dem geprüften
   Volltext: jede Aussage mit [S. n], Wertstatus übernehmen, «Was die Studie nicht beantwortet»
   ausfüllen, Wegweiser mit den Teilen aus `katalog-zeile.txt`. Katalog-Eintrag höchstens ca. 600
   Zeichen, Card höchstens ca. 3’000 Zeichen. Dateien: `card.md`, `katalog-eintrag.md`.

7. `grafiken-abgelesen.txt` anlegen: jede Grafik mit abgelesenen oder nicht eindeutigen Werten
   (Seite;Grafik;Status) – für die Sichtprüfung durch einen Menschen.

8. Ausgabe: ZIP `LAV-NN_ingest.zip` mit `volltext/`, `seiten/`, `card.md`, `katalog-eintrag.md`,
   `kontrollwoerter.csv`, `katalog-zeile.txt`, `pruefprotokoll.txt`, `befunde-begruendet.txt`,
   `grafiken-abgelesen.txt`, `zeiterfassung.csv`, `inventar.txt`. Gib es dem Nutzer zum Herunterladen
   und nenne: Seitenzahl, Anzahl Teile, offene Befunde, Anzahl Grafiken zur Sichtprüfung.

Werden Kontext oder Ausgabe knapp: nach der letzten vollständig geschriebenen Seite unterbrechen,
Zwischenstand als ZIP ausgeben und die letzte fertige Seite nennen.

## Ablauf «Fortsetzen» (neues Gespräch nach Unterbruch)
1. Der Nutzer lädt die PDF und das letzte Zwischen-ZIP hoch und nennt die Studien-ID.
2. Entpacke das ZIP nach `arbeit/LAV-NN/` und erzeuge Rohtext und Seitenbilder neu (vorhandene Seiten
   in `seiten/` bleiben erhalten):
   ```
   python inventar.py <pdf> arbeit/LAV-NN
   python pruefen.py <pdf> arbeit/LAV-NN/seiten --nur-vorhandene --protokoll arbeit/LAV-NN/zwischen.txt
   ```
3. Melde die erste fehlende Seite und mache dort mit Schritt 3 weiter.

## Ablauf «Paket prüfen»
1. Der Nutzer lädt `lav-learning-library.zip` hoch (Skill des Library-Agenten).
2. Prüfen, Kontrollwörter von Katalog und Cards erneuern, geprüftes Paket schreiben:
   ```
   python paket.py <zip> --max TEILGROESSE --erneuern --ausgabe lav-learning-library_geprueft.zip --csv kontrollwoerter_alle.csv
   ```
3. Melde alle Befunde. Nur wenn keine Befunde bleiben, gib das geprüfte ZIP und die CSV zum
   Herunterladen, mit dem Hinweis: Die CSV nie in einen Agenten hochladen.

## Ablauf «Wiki aufbereiten»
1. Grundlage ist das geprüfte Paket (`lav-learning-library_geprueft.zip` aus «Paket prüfen»; in einem
   neuen Gespräch lädt der Nutzer es hoch).
2. Seiten für das Wiki erzeugen (eine Übersicht, eine Seite je Studie, ohne Kontrollwörter):
   ```
   python wiki.py lav-learning-library_geprueft.zip wiki --agent-link "<Link zum Library-Agenten>" --hinweis "<Klassifizierung und Nutzerkreis>"
   ```
3. Den Ordner `wiki/` als ZIP `lav-wiki_<Datum>.zip` zum Herunterladen geben. Inhalte nicht von Hand ändern.

## Verbote
- Kein Kürzen, Zusammenfassen oder Umformulieren; keine Seite überspringen (leere Seiten: «[leere Seite]»).
- Keine Zahl ohne Grundlage; keine Werte für Punkte, die die Grafik nicht zeigt.
- Kontrollwörter nie von Hand setzen oder ändern – nur über die Skripte.
- Keine Inhalte aus anderen Studien oder aus allgemeinem Wissen.
